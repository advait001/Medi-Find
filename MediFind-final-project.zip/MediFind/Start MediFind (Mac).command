#!/bin/bash
# Double-click to start MediFind with its machine-learning backend (macOS).
# On Linux, run: bash "Start MediFind (Mac).command"
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found. Install Python 3.10 or newer from https://www.python.org/downloads/ and run this file again."
  read -r -p "Press Enter to close." _
  exit 1
fi
if [ ! -x .venv/bin/python ]; then
  echo "Setting up MediFind for the first time. This takes a few minutes..."
  if ! python3 -m venv .venv || ! .venv/bin/python -m pip install -r requirements.txt; then
    echo "Setup did not finish. Check your internet connection and run this file again."
    rm -rf .venv
    read -r -p "Press Enter to close." _
    exit 1
  fi
fi
.venv/bin/python run_medifind.py "$@"
