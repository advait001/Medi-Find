@echo off
title MediFind
rem Double-click to start MediFind with its machine-learning backend (Windows).
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" during installation. Then run this file again.
  echo.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Setting up MediFind for the first time. This takes a few minutes...
  python -m venv .venv
  if errorlevel 1 goto failed
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" run_medifind.py %*
echo.
pause
exit /b 0

:failed
echo.
echo Setup did not finish. Check your internet connection and run this file again.
rmdir /s /q .venv 2>nul
pause
exit /b 1
