#!/usr/bin/env python3
"""Starts MediFind: the web app (frontend/) together with its machine-learning backend (backend/).

    python run_medifind.py                 # opens http://127.0.0.1:5050 in your browser
    python run_medifind.py --port 8080     # use another port
    python run_medifind.py --no-browser    # do not open a browser tab
    python run_medifind.py --retrain       # retrain the model before starting

The backend (backend/ml/api.py, Flask) serves the app and POST /api/predict,
where the trained Logistic Regression model makes the predictions. The app
finds the backend by itself and says on every result which engine made it.
Opened directly as a file, frontend/index.html still works with its
built-in rules.
"""
from __future__ import annotations

import argparse
import importlib.util
import platform
import subprocess
import sys
import threading
import warnings
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRONTEND_PAGE = ROOT / "frontend" / "index.html"
BACKEND = ROOT / "backend"
MODEL_FILE = BACKEND / "models" / "medifind_model.joblib"
REQUIRED_PACKAGES = {"numpy": "numpy", "pandas": "pandas", "sklearn": "scikit-learn", "joblib": "joblib",
                     "matplotlib": "matplotlib", "flask": "flask"}


def check_python() -> None:
    if sys.version_info < (3, 10):
        sys.exit(f"MediFind needs Python 3.10 or newer; this is Python {platform.python_version()}.")


def check_packages() -> None:
    missing = [name for module, name in REQUIRED_PACKAGES.items() if importlib.util.find_spec(module) is None]
    if missing:
        sys.exit("These Python packages are missing: " + ", ".join(missing) + "\n"
                 f"Install them with:\n    \"{sys.executable}\" -m pip install -r \"{ROOT / 'requirements.txt'}\"")


def reason_to_train() -> str | None:
    """Why the model has to be trained on this computer first, or None."""
    if not MODEL_FILE.exists():
        return "no trained model was found"
    import joblib
    import sklearn
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            bundle = joblib.load(MODEL_FILE)
    except Exception as problem:  # an incompatible library version, a damaged file...
        return f"the saved model could not be loaded here ({type(problem).__name__})"
    saved_with = bundle.get("sklearn_version")
    if saved_with != sklearn.__version__:
        return f"it was saved with scikit-learn {saved_with} and this computer has scikit-learn {sklearn.__version__}"
    return None


def train_model() -> None:
    print("Training the model on this computer. This takes about 2 to 5 minutes and is needed only once...\n", flush=True)
    subprocess.run([sys.executable, str(BACKEND / "ml" / "train_models.py")], cwd=BACKEND, check=True)
    print(flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Start MediFind with its machine-learning backend")
    parser.add_argument("--host", default="127.0.0.1",
                        help="address to listen on (default 127.0.0.1: this computer only; 0.0.0.0 shares it on your network)")
    parser.add_argument("--port", type=int, default=5050, help="port (default 5050)")
    parser.add_argument("--no-browser", action="store_true", help="do not open a browser tab")
    parser.add_argument("--retrain", action="store_true", help="retrain the model before starting")
    args = parser.parse_args()

    check_python()
    check_packages()
    if not FRONTEND_PAGE.exists():
        sys.exit(f"The app is missing: {FRONTEND_PAGE}")

    reason = "you asked for it" if args.retrain else reason_to_train()
    if reason:
        print(f"The model will be trained first, because {reason}.")
        try:
            train_model()
        except subprocess.CalledProcessError:
            sys.exit("Training did not finish; see the messages above.")

    sys.path.insert(0, str(BACKEND / "ml"))
    from api import create_app  # backend/ml/api.py

    app = create_app(app_html=FRONTEND_PAGE)
    shown_host = "127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host
    url = f"http://{shown_host}:{args.port}/"
    print("=" * 64)
    print(" MediFind is running with its machine-learning backend")
    print(f" Open {url} in your browser")
    print(" Keep this window open while you use MediFind.")
    print(" To stop, close this window or press Ctrl+C.")
    if args.host not in ("127.0.0.1", "localhost"):
        print(" Shared on your network: the backend has no login or HTTPS,")
        print(" so use this only on a network you trust.")
    print("=" * 64, flush=True)
    if not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    try:
        app.run(host=args.host, port=args.port, debug=False, use_reloader=False)
    except OSError as problem:
        sys.exit(f"Could not start on port {args.port} ({problem}). Another program may be using it; "
                 f"try: python run_medifind.py --port 5060")


if __name__ == "__main__":
    main()
