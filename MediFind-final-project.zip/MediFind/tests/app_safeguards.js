// Passes the trained model's answers through MediFind's own normaliseApiPrediction()
// (frontend/src/js/08-prediction.js), exactly as the app does, and counts the results.
// Called by tests/safeguards_report.py; not meant to be run on its own.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'frontend', 'src', 'js');
const FILES = ['01-config.js', '02-state.js', '03a-auth.js', '04-intake.js', '05-questionnaire.js', '05a-body-figure.js', '05b-bodymap.js',
  '06-branching.js', '07-preprocessing.js', '08-prediction.js', '09-confidence.js', '10-safety.js', '11-specialist.js', '12a-plain-language.js', '17-utils.js'];
const EXPORTS = ['encodeSymptoms', 'constructFeatureVector', 'preprocessFeatures', 'predictLocally', 'normaliseApiPrediction', 'DEMO_CASES'];

const context = {
  console, Math, JSON, Date, Object, Array, Number, String, Set, Map, Boolean, RegExp, Error, Symbol, Promise, Intl, isFinite, parseFloat, parseInt,
  window: { matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }), localStorage: null, sessionStorage: null, crypto: undefined },
  document: { body: { dataset: {} }, documentElement: { dataset: {} }, getElementById: () => null, querySelector: () => null, querySelectorAll: () => [], addEventListener() {} },
  navigator: { userAgent: 'node' }, performance: { now: () => 0 }, setTimeout, clearTimeout,
};
vm.createContext(context);
const source = FILES.map((f) => fs.readFileSync(path.join(SRC, f), 'utf8')).join('\n');
vm.runInContext(`${source}\n;globalThis.__app = { ${EXPORTS.join(', ')} };`, context, { filename: 'medifind-app.js' });
const app = context.__app;

function viaApp(patientIn, answers, response) {
  const patient = { name: '', age: patientIn.age ?? '', gender: patientIn.gender ?? '', contact: '', complaint: patientIn.complaint, description: '' };
  const encoding = app.encodeSymptoms(answers, patient.complaint);
  const processed = app.preprocessFeatures(app.constructFeatureVector(patient, encoding), encoding);
  const p = app.normaliseApiPrediction(response, processed, { complaint: patient.complaint });
  return { department: p.isInconclusive ? 'general' : p.predictedCategoryId, inconclusive: p.isInconclusive, factors: p.modelFactors };
}

const input = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const cases = new Map();
fs.readFileSync(path.join(ROOT, 'backend', 'data', 'questionnaire_answers.jsonl'), 'utf8').trim().split('\n').forEach((line) => {
  const record = JSON.parse(line);
  cases.set(record.case_id, record);
});

const test = { cases: 0, inconclusive: 0, routedCorrectly: 0, limitedByRules: 0, contradictionPenalty: 0, capped: 0 };
input.test.forEach(({ id, truth, response }) => {
  const record = cases.get(id);
  const result = viaApp(record.patient, record.answers, response);
  test.cases += 1;
  test.inconclusive += result.inconclusive ? 1 : 0;
  test.routedCorrectly += result.department === truth ? 1 : 0;
  test.limitedByRules += result.factors.limitedByRules ? 1 : 0;
  test.contradictionPenalty += result.factors.penalty > 0 ? 1 : 0;
  test.capped += result.factors.capped ? 1 : 0;
});

const handWritten = new Map();
JSON.parse(fs.readFileSync(path.join(ROOT, 'frontend', 'tests', 'condition-scenarios.json'), 'utf8')).forEach((s) => handWritten.set(s.id, s));
app.DEMO_CASES.forEach((d) => handWritten.set(d.id, d));
const vignettes = { cases: 0, departmentMatch: 0, onlyInconclusive: 0, onlyInconclusiveCaught: 0, named: 0, namedMadeInconclusive: 0 };
input.vignettes.forEach(({ id, expectedDepartments, onlyInconclusive, named, response }) => {
  const scenario = handWritten.get(id);
  const result = viaApp(scenario.patient, scenario.answers, response);
  vignettes.cases += 1;
  vignettes.departmentMatch += expectedDepartments.includes(result.department) ? 1 : 0;
  if (onlyInconclusive) {
    vignettes.onlyInconclusive += 1;
    vignettes.onlyInconclusiveCaught += result.inconclusive ? 1 : 0;
  }
  if (named) {
    vignettes.named += 1;
    vignettes.namedMadeInconclusive += result.inconclusive ? 1 : 0;
  }
});

process.stdout.write(JSON.stringify({ test, vignettes }));
