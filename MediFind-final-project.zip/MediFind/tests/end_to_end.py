"""End-to-end test: the MediFind web app and its machine-learning backend working together.

Starts MediFind with run_medifind.py on a free port, opens the app in Chromium
(Playwright), signs in with a test desk account and runs every demo case.

It checks that:
  - the app finds the backend: the dashboard and the top bar name the trained model;
  - every result comes from the model (/api/predict is called once per assessment),
    the confidence never goes above 94% and the results screen says which engine made it;
  - routine demo cases reach their department and show the department's doctor;
  - the vague and the contradictory demo cases become "General / Inconclusive";
  - the urgent demo case goes to Emergency & Triage with no condition;
  - the "Why was this recommended?" panel lists the answers behind the model's result;
  - the preliminary report names the trained model;
  - when the backend stops, the next assessment uses the built-in rules and says so.

Run from the project folder:
    pip install playwright && playwright install chromium
    python tests/end_to_end.py
"""
from __future__ import annotations

import hashlib
import json
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
RESULTS = []


def check(name: str, ok: bool, detail: str = "") -> None:
    RESULTS.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok or not detail else f"  ({detail})"), flush=True)


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_for_health(base: str, seconds: int = 600) -> dict:
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            return json.load(urllib.request.urlopen(base + "api/health", timeout=2))
        except OSError:
            time.sleep(1)
    raise RuntimeError("MediFind did not start")


SALT = bytes.fromhex("5eed5eed5eed5eed5eed5eed5eed5eed")
ACCOUNT = {
    "id": "acct-e2e", "firstName": "Asha", "lastName": "Verma", "email": "asha@hospital.test", "role": "receptionist",
    "hospital": "Multispeciality Hospital", "desk": "Reception desk", "createdAt": "2026-01-05T09:00:00.000Z", "lastSignInAt": None,
    "safeUseConfirmedAt": "2026-01-05T09:00:00.000Z",
    "password": {"algorithm": "PBKDF2-SHA-256", "iterations": 1000, "salt": SALT.hex(),
                 "hash": hashlib.pbkdf2_hmac("sha256", b"desk-test-2026", SALT, 1000).hex()},
}
SIGN_IN = """(() => { try {
  if (!localStorage.getItem('medifind.accounts.v1')) localStorage.setItem('medifind.accounts.v1', JSON.stringify([%s]));
  if (!sessionStorage.getItem('medifind.session.v1')) sessionStorage.setItem('medifind.session.v1', JSON.stringify({ accountId: 'acct-e2e', startedAt: new Date().toISOString() }));
} catch (e) {} })();""" % json.dumps(ACCOUNT)

READ_RESULT = """({
  engine: state.assessment.prediction.engine,
  fallback: !!state.assessment.prediction.engineFallback,
  department: state.assessment.recommendation.department,
  inconclusive: !!state.assessment.prediction.isInconclusive,
  condition: state.assessment.prediction.predictedCondition || null,
  conditionId: state.assessment.prediction.predictedConditionId || null,
  confidence: state.assessment.prediction.confidence,
  withheld: !!state.assessment.prediction.conditionWithheld,
  doctor: (recommendedDoctor(state.assessment.recommendation) || {}).name || null,
  factors: state.assessment.prediction.modelFactors || null,
})"""


def run_demo(page, demo_id: str) -> dict:
    page.click("[data-action=new-assessment] >> nth=0")
    if page.query_selector(".modal"):
        page.click('.modal button:has-text("Discard and start new")')
    page.click("summary:has-text('Load demo case')")
    page.click(f"[data-demo-id={demo_id}]")
    page.click("[data-action=save-patient]")
    page.wait_for_selector(".screen--bodymap, .screen--questionnaire, [data-action=submit-answer]", timeout=10000)
    if page.query_selector("[data-action=bm-continue]"):
        page.click("[data-action=bm-continue]")
        page.wait_for_timeout(150)
    for _ in range(25):
        if page.query_selector("[data-action=run-assessment]"):
            break
        page.click("[data-action=submit-answer]")
        page.wait_for_timeout(60)
    page.click("[data-action=run-assessment]")
    page.wait_for_selector(".route-sign", timeout=20000)
    page.wait_for_timeout(250)
    return page.evaluate(READ_RESULT)


def main() -> int:
    port = free_port()
    base = f"http://127.0.0.1:{port}/"
    server = subprocess.Popen([sys.executable, str(ROOT / "run_medifind.py"), "--no-browser", "--port", str(port)],
                              cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        health = wait_for_health(base)
        check("backend: health check answers", health.get("status") == "ok" and health.get("conditions") == 73, json.dumps(health))

        predict_calls, console_errors = [], []
        with sync_playwright() as p:
            browser = p.chromium.launch()
            context = browser.new_context(viewport={"width": 1366, "height": 900})
            context.add_init_script(SIGN_IN)
            page = context.new_page()
            page.on("request", lambda r: predict_calls.append(r.url) if r.url.endswith("/api/predict") else None)
            page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
            page.goto(base)
            page.wait_for_selector("#hero-title")
            page.wait_for_function("document.body.dataset.engine === 'api'", timeout=10000)
            page.wait_for_timeout(200)
            dashboard = page.inner_text("#screen")
            check("app: finds the backend", page.evaluate("PredictionService.mode") == "api")
            check("dashboard: names the trained model", "trained ML model (Logistic Regression v1.0.0)" in dashboard)
            check("top bar: status says the model is predicting",
                  "machine-learning model" in page.get_attribute(".topbar__meta .status-pill:not(#storage-status)", "title"))

            demos = page.evaluate("DEMO_CASES.map((d) => ({ id: d.id, label: d.label, expect: d.expect, expectCondition: d.expectCondition || null }))")
            rows = []
            for demo in demos:
                calls_before = len(predict_calls)
                result = run_demo(page, demo["id"])
                text = page.inner_text("#screen")
                rows.append((demo, result))
                name = demo["id"]
                check(f"{name}: predicted by the trained model", result["engine"] == "api" and not result["fallback"], json.dumps(result))
                check(f"{name}: one call to /api/predict", len(predict_calls) == calls_before + 1, str(len(predict_calls) - calls_before))
                check(f"{name}: department {demo['expect']}", result["department"] == demo["expect"], result["department"])
                if demo["expect"] == "Emergency & Triage":
                    check(f"{name}: condition withheld", result["withheld"] and result["condition"] is None)
                    continue
                check(f"{name}: confidence at most 94%", result["confidence"] <= 94, str(result["confidence"]))
                check(f"{name}: results say the model calculated it", "Calculated by the trained ML model (Logistic Regression v1.0.0)" in text)
                check(f"{name}: doctor shown", bool(result["doctor"]) and "Doctor to see" in text, str(result["doctor"]))
                if demo["expect"] == "General Medicine" and not demo["expectCondition"]:
                    check(f"{name}: shown as General / Inconclusive", result["inconclusive"], json.dumps(result["factors"]))
                elif demo["expectCondition"]:
                    check(f"{name}: names a condition", not result["inconclusive"] and bool(result["condition"]), str(result["condition"]))

            # "Why was this recommended?" and the report, for the cardiology demo
            run_demo(page, "demo-cardio")
            page.click("[data-action=open-why]")
            page.wait_for_timeout(400)
            why = page.inner_text("body")
            check("why panel: answers behind the model's result", "Answers that pushed the model towards this result" in why and "Worse with physical effort" in why)
            check("why panel: what shaped the confidence", "What shaped the model confidence" in why and "Capped at 94%" in why)
            page.keyboard.press("Escape")
            page.wait_for_timeout(200)
            page.click("[data-action=generate-report]")
            page.wait_for_selector(".screen--report", timeout=10000)
            report = page.inner_text("#screen")
            check("report: names the trained model", "trained machine-learning model (Logistic Regression v1.0.0) on the MediFind backend" in report)
            check("report: model probability explained", "Model probability" in report and "not the chance that the patient has it" in report)

            # The backend stops: the next assessment uses the built-in rules and says so.
            server.terminate()
            server.wait(10)
            page.evaluate("navigateTo('dashboard')")
            result = run_demo(page, "demo-cardio")
            toast = page.inner_text("body")
            check("backend stopped: built-in rules used", result["engine"] != "api" and result["fallback"], json.dumps(result))
            check("backend stopped: warning shown", "could not be reached" in toast)
            check("backend stopped: results say the built-in rules calculated it", "Calculated by the built-in rules in this browser." in page.inner_text("#screen"))

            check("browser: no console errors", not [e for e in console_errors if "/api/predict" not in e and "Failed to load resource" not in e],
                  "; ".join(console_errors[:3]))
            browser.close()

        print("\nDemo case                           Department          Condition                                 Confidence")
        for demo, r in rows:
            shown = "General / Inconclusive" if r["inconclusive"] else (r["condition"] or "withheld")
            print(f"{demo['label'][:35]:35s} {r['department'][:19]:19s} {shown[:41]:41s} {r['confidence']}%")
    finally:
        if server.poll() is None:
            server.terminate()
            server.wait(10)

    failed = [name for name, ok, _ in RESULTS if not ok]
    print(f"\n{len(RESULTS) - len(failed)} passed, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
