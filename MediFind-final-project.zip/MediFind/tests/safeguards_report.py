"""How the app's safeguards change the trained model's results.

Runs the trained model on the 4,015 test cases and on MediFind's hand-written
cases, then passes every answer through the app's own normaliseApiPrediction()
(frontend/src/js/08-prediction.js) with Node.js, exactly as the app does:
contradiction penalties, the weak-evidence check, the 55% threshold and the
94% cap. Urgent warning signs are left out here, as in the model's own scores.

Run from the project folder (needs Node.js 18 or newer):
    python tests/safeguards_report.py
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend" / "ml"))
import medifind_ml as mm  # noqa: E402

FALLBACK_DEPARTMENT = {
    "cardio_unspecified": "cardiovascular", "resp_unspecified": "respiratory", "msk_unspecified": "musculoskeletal",
    "derm_unspecified": "dermatological", "neuro_unspecified": "neurological", "gi_unspecified": "gastrointestinal",
    "general_unspecified": "general", "inconclusive": "general",
}


def main() -> None:
    bundle = joblib.load(mm.MODEL_PATH)
    schema = mm.load_schema()
    index = mm.condition_index(mm.load_conditions())
    order = bundle["category_order"]

    df = mm.load_dataset()
    X = mm.preprocess(df, schema)
    y = df[mm.LABEL_COLUMN].to_numpy()
    _, X_test, _, y_test, _, id_test = train_test_split(
        X, y, df["case_id"], test_size=mm.TEST_SIZE, stratify=y, random_state=mm.RANDOM_STATE)
    proba = bundle["model"].predict_proba(X_test)
    truth = mm.department_of(y_test, index)
    test = [{"id": cid, "truth": t, "response": mm.build_prediction(row, bundle)} for cid, t, row in zip(id_test, truth, proba)]
    model_only = mm.category_probabilities(proba, bundle["classes"], index, order)
    model_routed = np.where(model_only.max(1) < mm.INCONCLUSIVE_BELOW, "general", np.asarray(order)[model_only.argmax(1)])

    vig = pd.read_csv(mm.VIGNETTES_PATH, low_memory=False)
    vig = vig[vig["expected_condition"].notna() & (vig["expected_condition"] != "")].reset_index(drop=True)
    vproba = bundle["model"].predict_proba(mm.preprocess(vig, schema))
    vignettes = []
    for (_, row), p in zip(vig.iterrows(), vproba):
        ids = row["expected_condition"].split("|")
        departments = sorted({index[i]["category"] if i in index else FALLBACK_DEPARTMENT.get(i) for i in ids} - {None})
        vignettes.append({"id": row["vignette_id"], "expectedDepartments": departments, "onlyInconclusive": ids == ["inconclusive"],
                          "named": any(i in index for i in ids), "response": mm.build_prediction(p, bundle)})

    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as handle:
        json.dump({"test": test, "vignettes": vignettes}, handle)
    out = subprocess.run(["node", str(ROOT / "tests" / "app_safeguards.js"), handle.name], capture_output=True, text=True, check=True)
    Path(handle.name).unlink()
    result = json.loads(out.stdout)

    t, v = result["test"], result["vignettes"]
    print(f"Test set ({t['cases']} cases), department as MediFind shows it:")
    print(f"  model alone (below 55% -> General Medicine): {np.mean(model_routed == truth):.1%} routed correctly, "
          f"{np.mean(model_only.max(1) < mm.INCONCLUSIVE_BELOW):.1%} inconclusive")
    print(f"  with the app's safeguards:                   {t['routedCorrectly'] / t['cases']:.1%} routed correctly, "
          f"{t['inconclusive'] / t['cases']:.1%} inconclusive")
    print(f"  limited by the built-in rules: {t['limitedByRules']} cases; contradiction penalty: {t['contradictionPenalty']}; "
          f"capped at 94%: {t['capped'] / t['cases']:.1%}")
    print(f"Hand-written cases ({v['cases']} with an expected non-urgent result):")
    print(f"  expected department reached: {v['departmentMatch']}/{v['cases']} ({v['departmentMatch'] / v['cases']:.1%})")
    print(f"  cases whose only expected result is inconclusive, shown as inconclusive: {v['onlyInconclusiveCaught']}/{v['onlyInconclusive']}")
    print(f"  cases naming a condition that became inconclusive: {v['namedMadeInconclusive']}/{v['named']}")


if __name__ == "__main__":
    main()
