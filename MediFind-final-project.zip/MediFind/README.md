# MediFind: Smart Disease Prediction & Doctor Recommendation

This is the complete MediFind project: the web app (frontend) and the machine-learning
backend, working together. Start MediFind with one of the options below. The app then
sends each patient's answers to the backend, where the trained model (Logistic
Regression) predicts the department and the most likely condition. The results screen,
the "Why was this recommended?" panel and the printed report all say that the trained
model made the prediction.

> MediFind is a decision-support prototype for a hospital reception desk. It never
> diagnoses or prescribes. The model was trained on simulated cases, not on real
> patient records, so its scores are not clinical accuracy.

## Start MediFind

You need **Python 3.10 or newer** ([python.org/downloads](https://www.python.org/downloads/)).
On Windows, tick **"Add python.exe to PATH"** when you install it.

### Windows
1. Unzip `MediFind-final-project.zip` and open the `MediFind` folder.
2. Double-click **`Start MediFind (Windows).bat`**.
3. The first time, it installs the libraries it needs. This takes a few minutes and needs
   internet. It may also train the model once (2–5 minutes).
4. Your browser opens MediFind at **http://127.0.0.1:5050**.
5. Keep the black window open while you use MediFind. To stop, close that window.

### Mac
1. Unzip the file and open the `MediFind` folder.
2. Double-click **`Start MediFind (Mac).command`**. If macOS says it can't check the
   file, right-click it, choose **Open**, then **Open** again.
3. Steps 3–5 are the same as for Windows.

### From a terminal (any computer)
```bash
cd MediFind
pip install -r requirements.txt
python run_medifind.py
```
Options: `--port 8080` uses another port, `--no-browser` doesn't open a browser tab, and
`--retrain` trains the model again before starting.

### Google Colab
Upload **`MediFind_on_Colab.ipynb`** to [colab.research.google.com](https://colab.research.google.com)
(File → Upload notebook). Click **Runtime → Run all**, upload `MediFind-final-project.zip`
when asked, then click the link the notebook shows.

## Using it

1. The first time, create a desk account. It is stored only in this browser.
2. The dashboard shows **"Prediction engine: trained ML model (Logistic Regression v1.0.0)
   on the MediFind backend"**. That means the app and the backend are connected.
3. Start a new assessment, or open **Load demo case** for a ready-made patient, and answer
   the questions.
4. The results show the department, the doctor to see and the predicted condition. Under
   the model confidence, it says **"Calculated by the trained ML model (Logistic Regression
   v1.0.0) on the MediFind backend."**
5. Click **Why was this recommended?** to see the answers that pushed the model towards
   the result. Click **Generate Preliminary Report** to print it or save it as a PDF.

## How the frontend and backend work together

```
 Browser: MediFind app (frontend/index.html)
   │ 1. GET  /api/health    → the app finds the backend and switches to the model
   │ 2. POST /api/predict   → the 160 encoded answers (no name or contact number)
   ▼
 Backend: Flask service (backend/ml/api.py)
   │ 3. trained model (backend/models/medifind_model.joblib) → a probability for each
   │    of the 73 conditions and 7 departments, plus the answers behind the result
   ▼
 Browser: MediFind app
     4. safety checks → department, doctor, condition, explanation, report
```

The app's safety checks also apply to the model's results:

- **Urgent warning signs always come first.** The patient goes to Emergency & Triage and
  no condition is shown.
- **The confidence is capped at 94%** so a result never looks certain. Condition
  probabilities are shown up to 90%.
- **Contradictory answers lower the confidence.**
- **When the evidence is too weak or mixed, the result is "General / Inconclusive".** This
  happens when the confidence is below 55%, or when the built-in rules can't decide and
  either the model is less than 90% sure or some answers contradict each other. The
  patient then goes to General Medicine.
- **If the backend stops, the app keeps working.** It uses its built-in rules for the next
  assessment and shows a warning. Every result and report records which engine made it.
- **`frontend/index.html` still works on its own.** Opened directly, without the backend,
  it uses the built-in rules and says so.

## What is in the folder

| Path | What it is |
| --- | --- |
| `Start MediFind (Windows).bat`, `Start MediFind (Mac).command` | Double-click to set up (first time) and start MediFind |
| `run_medifind.py` | Starts the backend with the app and opens the browser |
| `requirements.txt` | The Python libraries: numpy, pandas, scikit-learn, joblib, matplotlib, flask |
| `MediFind_on_Colab.ipynb` | Runs the whole project on Google Colab |
| `frontend/index.html` | The MediFind web app (one self-contained file) |
| `frontend/src/` | The app's source code; `frontend/build.py` builds `index.html` from it |
| `frontend/tests/` | The app's tests |
| `backend/` | The machine-learning backend: dataset, training code, trained model, reports, Flask API, tests (see `backend/README.md`) |
| `tests/end_to_end.py` | Starts MediFind and runs all 12 demo cases in a real browser to check that the app and the backend work together |
| `tests/safeguards_report.py` | Measures how the app's safety checks change the model's results on the test cases (needs Node.js) |

## Good to know

- **The doctor names are samples.** Put in the hospital's real names in `DOCTOR_DIRECTORY`
  in `frontend/src/js/01-config.js`, then rebuild the app: `pip install pillow`, then
  `python frontend/build.py`.
- **It only runs on this computer by default** (127.0.0.1). `python run_medifind.py --host 0.0.0.0`
  shares it on your network. The backend has no login or HTTPS, so do this only on a
  network you trust.
- **This uses Flask's built-in server, which is fine for a demo.** For real use, put the
  backend behind a production server with HTTPS and access control. The model would also
  need to be retrained and validated on real, clinically labelled records.
- **Accounts and saved assessments stay in the browser** (localStorage). The backend stores
  nothing.

## For developers

| Task | Command (from the `MediFind` folder) |
| --- | --- |
| Rebuild the app after changing `frontend/src` | `pip install pillow` then `python frontend/build.py` |
| App engine tests (Node.js) | `node frontend/tests/engine.test.js` |
| App browser tests (Playwright) | `python frontend/tests/acceptance.py` |
| Backend tests | `cd backend && python -m unittest discover -s tests -v` |
| App + backend together (Playwright) | `python tests/end_to_end.py` |
| What the app's safety checks change | `python tests/safeguards_report.py` (needs Node.js) |
| Retrain the model | `python run_medifind.py --retrain`, or `cd backend && python ml/train_models.py` |

The browser tests need `pip install playwright` and `playwright install chromium`.
