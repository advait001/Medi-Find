#!/usr/bin/env python3
"""Assembles src/ into a single self-contained index.html."""
import base64
import json
import re
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).parent
SRC = ROOT / "src"
VENDOR = ROOT / "vendor"
ASSETS = ROOT / "assets" / "generated"   # made by tools/prepare_logo.py and tools/prepare_body_map.py

JS_ORDER = [
    "01-config.js", "02-state.js", "03-navigation.js", "03a-auth.js", "04-intake.js", "05-questionnaire.js", "05a-body-figure.js", "05b-bodymap.js",
    "06-branching.js", "07-preprocessing.js", "08-prediction.js", "09-confidence.js", "10-safety.js",
    "11-specialist.js", "12-report.js", "12a-plain-language.js", "13-repository.js", "14-history.js", "15-print.js",
    "16-rendering.js", "@ICONS", "17-utils.js", "18-init.js",
]

def png_uri(name: str) -> str:
    return "data:image/png;base64," + base64.b64encode((ASSETS / name).read_bytes()).decode("ascii")


def png_size(name: str) -> tuple:
    with Image.open(ASSETS / name) as image:
        return image.size


def asset_sprite() -> str:
    """Hidden SVG holding every picture once: the MediFind logo (normal and
    light), the mark, the sign-in glow and the two body map views. The page shows them with <use href="#id">,
    so re-rendering a screen never re-sends the image data."""
    logo_w, logo_h = png_size("medifind-logo.png")
    mark_w, mark_h = png_size("medifind-mark.png")
    body_w, body_h = png_size("body-front.png")
    return (
        '<svg class="asset-sprite" width="0" height="0" aria-hidden="true" focusable="false"><defs>'
        f'<symbol id="mf-logo" viewBox="0 0 {logo_w} {logo_h}"><image href="{png_uri("medifind-logo.png")}" width="{logo_w}" height="{logo_h}"/></symbol>'
        f'<symbol id="mf-mark" viewBox="0 0 {mark_w} {mark_h}"><image href="{png_uri("medifind-mark.png")}" width="{mark_w}" height="{mark_h}"/></symbol>'
        f'<symbol id="mf-logo-light" viewBox="0 0 {logo_w} {logo_h}"><image href="{png_uri("medifind-logo-light.png")}" width="{logo_w}" height="{logo_h}"/></symbol>'
        '<symbol id="mf-glow" viewBox="0 0 48 48"><image href="' + png_uri("medifind-glow.png") + '" width="48" height="48"/></symbol>'
        f'<image id="bm-art-front" href="{png_uri("body-front.png")}" width="{body_w}" height="{body_h}"/>'
        f'<image id="bm-art-back" href="{png_uri("body-back.png")}" width="{body_w}" height="{body_h}"/>'
        '</defs></svg>'
    )

CUSTOM_ICONS = {
    "lungs": '<path d="M12 4v7.5"/><path d="M12 11.5c-.7 1.1-1.7 1.8-3 2"/><path d="M12 11.5c.7 1.1 1.7 1.8 3 2"/>'
             '<path d="M8.6 7.3C5.7 7.9 3.5 11.7 3.5 16.4c0 1.9.9 3.1 2.6 3.1 2 0 3.5-1.3 3.5-3.6V9.3c0-1.2-.4-2-1-2z"/>'
             '<path d="M15.4 7.3c2.9.6 5.1 4.4 5.1 9.1 0 1.9-.9 3.1-2.6 3.1-2 0-3.5-1.3-3.5-3.6V9.3c0-1.2.4-2 1-2z"/>',
    "stomach": '<path d="M9 2.5v3.3a2.6 2.6 0 0 0 2.6 2.6h1.9a5.6 5.6 0 0 1 5.6 5.6v.3a7.2 7.2 0 0 1-7.2 7.2h-.5a5.9 5.9 0 0 1-5.9-5.9v-.4a1.8 1.8 0 0 1 3.6-.2c.2 1.5 1.4 2.6 2.9 2.6"/>'
               '<path d="M19.6 12.6c1.1.4 1.9 1.3 1.9 2.6"/>',
    "skin": '<path d="M3 8.5c1.5-1.2 3-1.2 4.5 0s3 1.2 4.5 0 3-1.2 4.5 0 3 1.2 4.5 0"/><path d="M3 13.5h18"/><path d="M3 18.5h18"/>'
            '<path d="M12 8.6V4"/><circle cx="7.5" cy="16" r=".9" fill="currentColor" stroke="none"/><circle cx="16" cy="11" r=".9" fill="currentColor" stroke="none"/>',
    "spiral": '<path d="M12.6 12a.6.6 0 1 1-.6-.6 2.2 2.2 0 0 1 2.2 2.2A3.8 3.8 0 0 1 10.4 17.4 5.4 5.4 0 0 1 5 12a7 7 0 0 1 7-7 8.6 8.6 0 0 1 8.6 8.6"/>',
}


def icon_svg(body: str) -> str:
    return f'<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">{body}</svg>'


def build_icons_js(icons: dict) -> str:
    lines = [
        "/* ---------------------------------------------------------------------",
        "   Icon set: Lucide icons (ISC licence) plus custom medical icons",
        "   (lungs, stomach, skin, spiral) drawn in the same 24px stroke style.",
        "   --------------------------------------------------------------------- */",
        "",
        "const ICONS = {",
    ]
    for name in sorted(icons):
        lines.append(f"  {json.dumps(name)}: {json.dumps(icons[name])},")
    lines.append("};")
    return "\n".join(lines)


def font_face(family: str, path: Path, weight: str) -> str:
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return (
        f"@font-face {{ font-family: '{family}'; font-style: normal; font-weight: {weight}; font-display: swap; "
        f"src: url(data:font/woff2;base64,{data}) format('woff2'); }}"
    )


def main() -> None:
    icons = json.loads((ROOT / "build" / "lucide-icons.json").read_text())
    icons.update(CUSTOM_ICONS)

    parts = []
    for name in JS_ORDER:
        if name == "@ICONS":
            parts.append(build_icons_js(icons))
        else:
            parts.append((SRC / "js" / name).read_text().rstrip())
    script = "\n\n".join(parts)

    styles = (SRC / "styles.css").read_text().rstrip()

    jakarta = next(VENDOR.glob("fontsource-variable-plus-jakarta-sans-*/package/files/plus-jakarta-sans-latin-wght-normal.woff2"))
    serif = next(VENDOR.glob("fontsource-source-serif-4-*/package/files/source-serif-4-latin-600-normal.woff2"))
    fonts = "\n".join([
        font_face("Plus Jakarta Sans", jakarta, "200 800"),
        font_face("Source Serif 4", serif, "600"),
    ])

    logo_w, logo_h = png_size("medifind-logo.png")
    mark_w, mark_h = png_size("medifind-mark.png")
    script = (script
              .replace("{{LOGO_VIEWBOX}}", f"0 0 {logo_w} {logo_h}")
              .replace("{{MARK_VIEWBOX}}", f"0 0 {mark_w} {mark_h}"))
    # Light theme shows the black wordmark, dark theme the white one (CSS picks the <use>).
    logo = (f'<svg class="brand__logo" viewBox="0 0 {logo_w} {logo_h}" role="img" aria-label="MediFind" focusable="false">'
            '<use class="logo-on-light" href="#mf-logo"/><use class="logo-on-dark" href="#mf-logo-light"/></svg>'
            f'<svg class="brand__mark" viewBox="0 0 {mark_w} {mark_h}" role="img" aria-label="MediFind" focusable="false"><use href="#mf-mark"/></svg>')
    # Phones hide the sidebar, so the top bar carries the mark there.
    topbar_mark = f'<svg class="topbar__mark" viewBox="0 0 {mark_w} {mark_h}" role="img" aria-label="MediFind" focusable="false"><use href="#mf-mark"/></svg>'

    shell = (SRC / "shell.html").read_text()
    shell = re.sub(r"\{\{icon:([a-z0-9-]+)\}\}", lambda m: icon_svg(icons[m.group(1)]), shell)
    out = (shell
           .replace("{{STYLES}}", styles)
           .replace("{{SCRIPT}}", script)
           .replace("{{FONTS}}", fonts)
           .replace("{{LOGO}}", logo)
           .replace("{{TOPBAR_MARK}}", topbar_mark)
           .replace("{{ASSET_SPRITE}}", asset_sprite())
           .replace("{{FAVICON}}", png_uri("favicon.png")))

    leftovers = re.findall(r"\{\{[A-Za-z:_-]+\}\}", out)
    if leftovers:
        raise SystemExit(f"Unreplaced placeholders: {leftovers}")

    (ROOT / "index.html").write_text(out)
    print(f"index.html written: {len(out) / 1024:.0f} KB, {out.count(chr(10))} lines")


if __name__ == "__main__":
    main()
