/* =====================================================================
   13. LOCAL STORAGE REPOSITORY
   ---------------------------------------------------------------------
   Prototype persistence in localStorage. Every read and write is guarded:
   if storage is blocked (private mode, disabled site data) or full, the
   app keeps working from memory for the rest of the session.
   PRODUCTION INTEGRATION POINT: replace AssessmentRepository with calls
   to the hospital backend (e.g. MySQL behind the Flask / Django API).
   ===================================================================== */

const STORAGE_UNAVAILABLE_TEXT = 'Browser storage is unavailable here, so assessments are lost when this page is reloaded or closed.';

const SafeStorage = (() => {
  const memory = new Map();
  let persistent = false;
  try {
    const probe = '__sdp_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    persistent = true;
  } catch (error) {
    persistent = false;
  }

  function fallBackToMemory() {
    try {
      Object.values(APP_CONFIG.storageKeys).forEach((key) => {
        const value = window.localStorage.getItem(key);
        if (value !== null && !memory.has(key)) memory.set(key, value);
      });
    } catch (error) { /* storage unreadable: memory only */ }
    persistent = false;
  }

  return {
    get persistent() { return persistent; },
    read(key, fallback) {
      try {
        const text = persistent ? window.localStorage.getItem(key) : memory.get(key);
        if (text === null || text === undefined) return fallback;
        return JSON.parse(text);
      } catch (error) {
        return fallback;
      }
    },
    write(key, value) {
      const text = JSON.stringify(value);
      if (persistent) {
        try {
          window.localStorage.setItem(key, text);
          return true;
        } catch (error) {
          fallBackToMemory();
        }
      }
      memory.set(key, text);
      return false;
    },
    remove(key) {
      memory.delete(key);
      if (!persistent) return;
      try { window.localStorage.removeItem(key); } catch (error) { /* ignore */ }
    },
  };
})();

function isValidRecord(record) {
  return Boolean(record && typeof record === 'object' && typeof record.id === 'string'
    && record.patient && typeof record.patient === 'object' && record.answers && typeof record.answers === 'object');
}

const AssessmentRepository = {
  key: APP_CONFIG.storageKeys.assessments,

  readAll() {
    const items = SafeStorage.read(this.key, []);
    return Array.isArray(items) ? items.filter(isValidRecord) : [];
  },

  /* Newest first. */
  list() {
    return this.readAll().sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  },

  get(id) {
    return this.readAll().find((record) => record.id === id) || null;
  },

  save(record) {
    const items = this.readAll();
    const copy = deepClone(record);
    const index = items.findIndex((item) => item.id === copy.id);
    if (index >= 0) items[index] = copy;
    else items.push(copy);
    return SafeStorage.write(this.key, items);
  },

  clear() {
    SafeStorage.remove(this.key);
  },

  /* Sequential IDs per year, e.g. MF-2026-0001. The counter only moves
     forward, so an ID is never reused even after history is cleared.
     Records saved before the MediFind name keep their SDP- IDs. */
  nextId(date = new Date()) {
    const year = date.getFullYear();
    const prefix = `${APP_CONFIG.idPrefix}-${year}-`;
    const counters = SafeStorage.read(APP_CONFIG.storageKeys.counters, {});
    const safeCounters = counters && typeof counters === 'object' ? counters : {};
    const highestSaved = this.readAll()
      .filter((record) => record.id.startsWith(prefix))
      .reduce((max, record) => Math.max(max, Number.parseInt(record.id.slice(prefix.length), 10) || 0), 0);
    const next = Math.max(Number(safeCounters[year]) || 0, highestSaved) + 1;
    safeCounters[year] = next;
    SafeStorage.write(APP_CONFIG.storageKeys.counters, safeCounters);
    return `${prefix}${String(next).padStart(4, '0')}`;
  },
};

const DraftStore = {
  key: APP_CONFIG.storageKeys.draft,
  save(snapshot) { SafeStorage.write(this.key, snapshot); },
  load() {
    const draft = SafeStorage.read(this.key, null);
    return draft && typeof draft === 'object' ? draft : null;
  },
  clear() { SafeStorage.remove(this.key); },
};

/* Saves the working copy as a completed assessment (creating its ID the
   first time) and returns whether it reached persistent storage. */
function saveAssessment() {
  const assessment = state.assessment;
  const now = new Date();
  if (!assessment.id) {
    assessment.id = AssessmentRepository.nextId(now);
    assessment.createdAt = now.toISOString();
  }
  assessment.updatedAt = now.toISOString();
  assessment.status = 'completed';
  assessment.questionHistory = currentSequence().path.filter((id) => hasOwn(assessment.answers, id));
  const persisted = AssessmentRepository.save(assessment);
  DraftStore.clear();
  if (!persisted) {
    showToast('Browser storage is unavailable, so this assessment is lost when this page is reloaded or closed.', 'warning');
  }
  return persisted;
}

/* Loads a saved assessment into the working copy. */
function loadAssessment(id) {
  const record = AssessmentRepository.get(id);
  if (!record) return false;
  const empty = createEmptyAssessment();
  state.assessment = { ...empty, ...deepClone(record), patient: { ...empty.patient, ...deepClone(record.patient) } };
  state.assessment.bodyMap = normaliseBodyMap(record.bodyMap, state.assessment.patient.complaint);
  state.ui = { ...createEmptyUiState(), historyQuery: state.ui.historyQuery };
  return true;
}
