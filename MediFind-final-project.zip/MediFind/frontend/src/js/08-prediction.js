/* =====================================================================
   8. PREDICTION ENGINE
   ---------------------------------------------------------------------
   MediFind has two prediction engines. Every result records which one
   produced it (prediction.engine), and the screens and report say so.

   1. The trained machine-learning model (engine 'api'), used when the app
      is started with its Python backend (run_medifind.py). The backend
      (backend/ml/api.py, Flask) serves this page and POST /api/predict,
      where a Logistic Regression trained with scikit-learn on simulated
      cases returns a probability for each of the 73 conditions. At start-up
      PredictionService.detect() asks GET /api/health on the same address
      and switches to the model only when the backend answers with the same
      feature schema. The app sends buildPredictionPayload() (schema version,
      feature order and the normalised vector: no name or contact number) and
      normaliseApiPrediction() maps the answer onto the shape used below,
      applying the same safeguards as the built-in engine (see that function).

   2. The built-in rules (predictLocally), used when the page is opened on
      its own as a file, or when the backend cannot be reached. They are
      deterministic and work in two stages, mirroring the algorithm document
      ("predict the disease, then map it to the specialist"):
        1. Category: weighted symptom scoring plus decision rules,
           normalised into category scores. The category decides the
           department and the model confidence.
        2. Condition: the conditions belonging to that category (CONDITIONS)
           are scored with the same features; the best match becomes the
           predicted condition, with a relative likelihood and the next
           most likely alternatives.

   Urgent warning signs are checked by the app itself (section 10) and
   always override either engine. Neither engine uses randomness, so the
   same assessment always produces the same result.
   ===================================================================== */

const PredictionService = {
  mode: 'local', // 'local' (built-in rules in this browser) | 'api' (trained model on the MediFind backend)
  endpoint: API_SETTINGS.predictPath,
  backend: null, // what GET /api/health reported, while the backend is connected
  detecting: null,

  /* Looks for the MediFind backend on the same address as the page. A page
     opened as a file (file://) has no backend and keeps the built-in rules. */
  detect() {
    const location = typeof window !== 'undefined' && window.location ? window.location : null;
    if (!location || !/^https?:$/.test(location.protocol || '') || typeof fetch !== 'function') return Promise.resolve(this.mode);
    if (this.detecting) return this.detecting;
    this.detecting = (async () => {
      try {
        const response = await fetchWithTimeout(API_SETTINGS.healthPath, { headers: { Accept: 'application/json' } }, API_SETTINGS.detectTimeoutMs);
        const health = response.ok ? await response.json() : null;
        if (health && health.status === 'ok' && health.schemaVersion === FEATURE_SCHEMA_VERSION) {
          this.mode = 'api';
          this.backend = {
            model: String(health.model || ''),
            version: String(health.version || ''),
            trainedAt: health.trainedAt || null,
            conditions: Number(health.conditions) || null,
            trainingData: String(health.trainingData || ''),
          };
        } else {
          this.useLocal();
        }
      } catch (error) {
        this.useLocal();
      } finally {
        this.detecting = null;
      }
      return this.mode;
    })();
    return this.detecting;
  },

  useLocal() {
    this.mode = 'local';
    this.backend = null;
  },

  async predict(processed, context) {
    if (this.mode === 'api') {
      try {
        const response = await fetchWithTimeout(this.endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(buildPredictionPayload(processed, context)),
        }, API_SETTINGS.predictTimeoutMs);
        if (!response.ok) throw new Error(`Prediction service responded with ${response.status}`);
        return normaliseApiPrediction(await response.json(), processed, context);
      } catch (error) {
        // The backend stopped or failed: this assessment uses the built-in rules,
        // and the result says so (engine + engineFallback).
        this.useLocal();
        const fallback = predictLocally(processed, context);
        fallback.engineFallback = true;
        return fallback;
      }
    }
    return predictLocally(processed, context);
  },
};

function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
  if (typeof AbortController !== 'function') return fetch(url, options);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

async function runPrediction(featureVector, context = {}) {
  return PredictionService.predict(featureVector, context);
}

function buildPredictionPayload(processed, context) {
  return {
    schemaVersion: processed.schemaVersion,
    featureOrder: processed.order,
    features: processed.vector,
    completeness: processed.meta.completeness,
    complaint: context.complaint || null,
  };
}

/* Maps the trained model's answer onto the local output shape.
   The model's probability for the department becomes the confidence
   ("probability of the selected class", as in the algorithm document),
   with the safeguards the built-in engine also applies:
     - contradictory answers lower it (the same penalties as CONSISTENCY_RULES);
     - when the built-in rules find the evidence too weak or mixed to decide,
       and the model is less than 90% sure or some answers contradict each
       other, it is limited to the rules' own confidence (the model was
       trained only on clear-cut cases, tends to be sure of itself even when
       the answers are vague, and cannot see contradictions);
     - it is capped at 94%, so a result is never shown as certain (condition
       probabilities are shown up to 90%, like the built-in match strength).
   Below 55%, or with no symptom evidence at all, the result is
   "General / Inconclusive" and the model's strongest candidates are listed
   for the General Physician, as in the built-in engine. */
function normaliseApiPrediction(response, processed, context) {
  const probabilities = (response && response.probabilities) || {};
  const ranked = CATEGORY_ORDER
    .map((id) => ({ id, label: CATEGORIES[id].label, score: clamp(Number(probabilities[id]) || 0, 0, 1) }))
    .sort((a, b) => (b.score - a.score) || (CATEGORY_ORDER.indexOf(a.id) - CATEGORY_ORDER.indexOf(b.id)));
  const total = ranked.reduce((sum, item) => sum + item.score, 0) || 1;
  // Shares are shown up to 99%: a model probability is never shown as 100%.
  ranked.forEach((item) => { item.share = Math.min(99, round((item.score / total) * 100)); item.score = round(item.score, 4); });
  const top = ranked[0];
  const settings = CONFIDENCE_THRESHOLDS;

  const rules = predictLocally(processed, context); // the built-in rules' view of the same answers
  const inconsistencies = rules.inconsistencies;
  const probability = top.score;
  const penalty = inconsistencies.reduce((sum, item) => sum + item.penalty, 0);
  const adjusted = (probability - penalty) * 100;
  let confidence = Math.round(clamp(adjusted, settings.floor, settings.cap));
  const uncertainModel = probability < API_SETTINGS.rulesCheckBelow;
  const limitedByRules = rules.isInconclusive && (uncertainModel || inconsistencies.length > 0) && rules.confidence < confidence;
  if (limitedByRules) confidence = rules.confidence;
  const noEvidence = !(rules.confidenceFactors && rules.confidenceFactors.topScore > 0);
  const isInconclusive = noEvidence || confidence < settings.inconclusiveBelow;
  const band = confidenceBand(confidence);

  const toPercent = (value) => (value !== null && value !== undefined && Number.isFinite(Number(value)) ? Math.round(clamp(Number(value) * 100, 0, 100)) : null);
  const describe = (id, name) => (id && CONDITION_INDEX[id]) || findConditionByName(name) || { id: slugify(name), name, short: name, description: '' };
  const named = (item) => item && (item.disease || item.condition || item.name);
  const candidates = [
    ...(named(response) ? [{ disease: named(response), diseaseId: response.diseaseId, probability: response.diseaseProbability }] : []),
    ...(Array.isArray(response && response.differentials) ? response.differentials : []),
  ].filter(named).map((item) => {
    // Condition probabilities are shown up to the same 90% cap as the built-in match strength.
    const percent = toPercent(item.probability);
    return { info: describe(item.diseaseId, named(item)), likelihood: percent === null ? null : Math.min(percent, CONDITION_SETTINGS.likelihoodCap) };
  });

  // The answers that pushed the model towards / against the predicted condition.
  const evidence = (response && response.evidence) || {};
  const answers = (items, sign) => (Array.isArray(items) ? items : [])
    .filter((item) => item && FEATURE_INDEX[item.feature] && !FEATURE_INDEX[item.feature].internal && Math.sign(Number(item.contribution)) === sign)
    .map((item) => ({ key: item.feature, label: describeFeature(item.feature, processed.raw), points: round(Number(item.contribution), 2) }));
  const supporting = answers(evidence.supporting, 1);

  let condition;
  if (isInconclusive) {
    condition = inconclusiveCondition(candidates.slice(0, CONDITION_SETTINGS.maxDifferentials).map(({ info }) => {
      const categoryKey = CONDITION_INDEX[info.id] ? primaryCategory(CONDITION_INDEX[info.id]) : 'general';
      return { id: info.id, name: info.name, short: info.short || info.name, categoryId: categoryKey, department: SPECIALIST_MAPPING[categoryKey].department };
    }));
  } else {
    const best = candidates[0];
    const known = best ? best.info : CATEGORIES[top.id].fallbackCondition;
    condition = {
      predictedConditionId: known.id,
      predictedCondition: known.name,
      conditionShort: known.short || known.name,
      conditionDescription: known.description || '',
      conditionLikelihood: best ? best.likelihood : null,
      conditionIsFallback: !best,
      differentials: candidates.slice(1, 1 + CONDITION_SETTINGS.maxDifferentials)
        .map(({ info, likelihood }) => ({ id: info.id, name: info.name, short: info.short || info.name, likelihood })),
      conditionEvidence: [],
      conditionAgainst: answers(evidence.against, -1).slice(0, 3),
      consideredConditions: [],
    };
  }

  const model = response && response.model && typeof response.model === 'object' ? response.model : {};
  return {
    engine: ENGINE_INFO_API.id,
    model: { name: String(model.name || 'Trained model'), version: String(model.version || '') },
    predictedCategoryId: isInconclusive ? INCONCLUSIVE_RESULT.id : top.id,
    predictedCategory: isInconclusive ? INCONCLUSIVE_RESULT.label : top.label,
    predictedPattern: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].patternLabel,
    ...condition,
    topCategoryId: top.id,
    categoryScores: ranked.map(({ id, label, score, share }) => ({ id, label, score, share })),
    confidence,
    confidenceLevel: band.id,
    confidenceLabel: band.label,
    confidenceFactors: null,
    modelFactors: {
      probability: Math.min(99, Math.round(probability * 100)), // shown up to 99%, never as 100%
      penalty: Math.round(penalty * 100),
      rulesConfidence: rules.confidence,
      limitedByRules,
      limitedBecause: limitedByRules ? (uncertainModel ? 'uncertain-model' : 'contradictions') : null,
      noEvidence,
      capped: adjusted > settings.cap && !limitedByRules,
    },
    matchedSymptoms: supporting,
    consideredSymptoms: consideredSymptoms(processed.raw),
    firedRules: [],
    inconsistencies,
    isInconclusive,
  };
}

/* Which engine produced a result. Results saved before the model existed
   came from the built-in rules. */
function isModelResult(prediction) {
  return Boolean(prediction && prediction.engine === ENGINE_INFO_API.id);
}

/* Whether the condition shown came from the trained model (not re-estimated by the rules). */
function conditionFromModel(prediction) {
  return isModelResult(prediction) && !prediction.conditionByRules;
}

function engineInfoFor(prediction) {
  if (!isModelResult(prediction)) return ENGINE_INFO;
  const model = prediction.model || {};
  const label = model.name && model.name !== 'Trained model' ? ` (${model.name}${model.version ? ` v${model.version}` : ''})` : '';
  return { ...ENGINE_INFO_API, name: `${ENGINE_INFO_API.name}${label}` };
}

/* One line saying which engine calculated a result. */
function engineSourceText(prediction) {
  if (!isModelResult(prediction)) return 'Calculated by the built-in rules in this browser.';
  const text = `Calculated by the ${engineInfoFor(prediction).name.replace(/^Trained ML model/, 'trained ML model')} on the MediFind backend.`;
  return prediction.conditionByRules ? `${text} The condition was worked out again by the built-in rules after the urgent mark was removed.` : text;
}

/* Dashboard line for the engine that will run the next assessment. */
function engineStatusText() {
  return PredictionService.mode === 'api' ? MODEL_TEXT.dashboard(PredictionService.backend) : 'Prediction engine: local prototype, runs in this browser';
}

function predictLocally(processed, context) {
  const f = processed.named;
  const scored = calculateCategoryScores(f);
  const ranked = rankCategories(scored);
  const top = ranked[0];
  const inconsistencies = detectInconsistencies(processed.raw, context);
  const topCondition = predictCondition(f, processed.raw, top.score > 0 ? top.id : null);
  const confidence = calculateConfidence(ranked, processed.meta.completeness, inconsistencies, conditionFitFor(topCondition));
  const isInconclusive = top.score <= 0 || confidence.value < CONFIDENCE_THRESHOLDS.inconclusiveBelow;
  const band = confidenceBand(confidence.value);
  const condition = isInconclusive ? predictCondition(f, processed.raw, null) : topCondition;

  return {
    engine: ENGINE_INFO.id,
    predictedCategoryId: isInconclusive ? INCONCLUSIVE_RESULT.id : top.id,
    predictedCategory: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].label,
    predictedPattern: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].patternLabel,
    ...condition,
    topCategoryId: top.id,
    categoryScores: ranked.map(({ id, label, score, share }) => ({ id, label, score: round(score, 2), share })),
    confidence: confidence.value,
    confidenceLevel: band.id,
    confidenceLabel: band.label,
    confidenceFactors: confidence.factors,
    matchedSymptoms: matchedSymptomsFor(top, processed.raw),
    consideredSymptoms: consideredSymptoms(processed.raw),
    firedRules: top.firedRules,
    inconsistencies,
    isInconclusive,
  };
}

/* Weighted score for every category. Negative totals are floored at 0. */
function calculateCategoryScores(f) {
  return CATEGORY_ORDER.map((id) => {
    const rule = PREDICTION_RULES[id];
    let score = 0;
    const contributions = [];
    Object.entries(rule.weights).forEach(([key, weight]) => {
      const value = f[key] || 0;
      if (!value) return;
      const points = weight * value;
      score += points;
      contributions.push({ key, weight, value, points: round(points, 2) });
    });
    const firedRules = [];
    (rule.rules || []).forEach((decision) => {
      let fired = false;
      try { fired = Boolean(decision.when(f)); } catch (error) { fired = false; }
      if (fired) {
        score += decision.bonus;
        firedRules.push({ id: decision.id, label: decision.label, bonus: decision.bonus });
      }
    });
    return { id, label: CATEGORIES[id].label, score: Math.max(0, score), contributions, firedRules };
  });
}

/* Sorts by score; ties resolve by the fixed CATEGORY_ORDER, keeping the
   result deterministic. Adds each category's share of the total score. */
function rankCategories(scored) {
  const total = scored.reduce((sum, item) => sum + item.score, 0);
  const ranked = scored
    .map((item) => ({ ...item, share: total > 0 ? (item.score / total) * 100 : 0 }))
    .sort((a, b) => (b.score - a.score) || (CATEGORY_ORDER.indexOf(a.id) - CATEGORY_ORDER.indexOf(b.id)));
  // Round shares so they add up to exactly 100.
  if (total > 0) {
    const floors = ranked.map((item) => Math.floor(item.share));
    let remainder = 100 - floors.reduce((sum, v) => sum + v, 0);
    const order = ranked
      .map((item, index) => ({ index, fraction: item.share - Math.floor(item.share) }))
      .sort((a, b) => b.fraction - a.fraction);
    order.forEach(({ index }) => { if (remainder > 0) { floors[index] += 1; remainder -= 1; } });
    ranked.forEach((item, index) => { item.share = floors[index]; });
  }
  return ranked;
}

/* ---------- Stage 2: condition prediction ---------- */

function conditionCategories(condition) {
  return Array.isArray(condition.category) ? condition.category : [condition.category];
}

/* Scores one condition. A condition whose `requires` test fails is not
   considered (score 0), because its defining symptom is missing. */
function scoreCondition(condition, f) {
  let met = true;
  if (typeof condition.requires === 'function') {
    try { met = Boolean(condition.requires(f)); } catch (error) { met = false; }
  }
  if (!met) return { condition, score: 0, met: false, contributions: [] };
  let score = 0;
  const contributions = [];
  Object.entries(condition.weights).forEach(([key, weight]) => {
    const value = f[key] || 0;
    if (!value) return;
    const points = weight * value;
    score += points;
    contributions.push({ key, weight, value, points: round(points, 2) });
  });
  return { condition, score: Math.max(0, round(score, 3)), met: true, contributions };
}

/* Highest score first; ties keep the configuration order (deterministic). */
function rankConditions(scored) {
  return scored
    .map((item, index) => ({ ...item, index: CONDITIONS.indexOf(item.condition) >= 0 ? CONDITIONS.indexOf(item.condition) : index }))
    .sort((a, b) => (b.score - a.score) || (a.index - b.index));
}

/* Match strength: softmax share against the candidate conditions plus a
   residual standing for conditions the prototype does not cover, scaled
   by how much evidence supports the condition, so a condition backed by
   a single answer never reads as a near-certain match. */
function conditionLikelihoods(ranked) {
  const settings = CONDITION_SETTINGS;
  const candidates = ranked.filter((item) => item.score > 0);
  const weights = candidates.map((item) => Math.exp(item.score / settings.temperature));
  const total = weights.reduce((sum, w) => sum + w, 0) + Math.exp(settings.residualScore / settings.temperature);
  return candidates.map((item, i) => {
    const support = 1 - Math.exp(-item.score / settings.fitScale);
    return { ...item, likelihood: Math.round(clamp((weights[i] / total) * support * 100, 0, settings.likelihoodCap)) };
  });
}

function conditionEvidence(contributions, rawFeatures, sign) {
  return contributions
    .filter((item) => (sign > 0 ? item.points > 0 : item.points < 0))
    .sort((a, b) => (sign > 0 ? b.points - a.points : a.points - b.points))
    .map((item) => ({ key: item.key, label: describeFeature(item.key, rawFeatures), points: item.points }));
}

function primaryCategory(condition) {
  return conditionCategories(condition)[0];
}

function inconclusiveCondition(considered) {
  return {
    predictedConditionId: INCONCLUSIVE_RESULT.id,
    predictedCondition: INCONCLUSIVE_RESULT.conditionLabel,
    conditionShort: INCONCLUSIVE_RESULT.conditionShort,
    conditionDescription: INCONCLUSIVE_RESULT.conditionMessage,
    conditionLikelihood: null,
    conditionScore: null,
    conditionIsFallback: true,
    differentials: [],
    conditionEvidence: [],
    conditionAgainst: [],
    consideredConditions: considered,
  };
}

/* Predicts the condition within the chosen category. With no category
   (inconclusive result) no condition is named; the strongest candidates
   from any category are listed for the General Physician instead. */
function predictCondition(f, rawFeatures, categoryId) {
  const settings = CONDITION_SETTINGS;
  const scored = CONDITIONS.map((condition) => scoreCondition(condition, f));

  if (!categoryId || !CATEGORIES[categoryId]) {
    const considered = rankConditions(scored)
      .filter((item) => item.score >= settings.consideredMinScore)
      .slice(0, settings.maxDifferentials)
      .map((item) => {
        const categoryKey = primaryCategory(item.condition);
        return {
          id: item.condition.id,
          name: item.condition.name,
          short: item.condition.short,
          categoryId: categoryKey,
          department: SPECIALIST_MAPPING[categoryKey].department,
        };
      });
    return inconclusiveCondition(considered);
  }

  const eligible = rankConditions(scored.filter((item) => conditionCategories(item.condition).includes(categoryId)));
  const candidates = conditionLikelihoods(eligible);
  const best = candidates[0];
  const runnerUp = candidates[1];
  const weak = !best || best.score < settings.minScore;
  const tie = !weak && runnerUp && runnerUp.score >= settings.minScore && best.likelihood - runnerUp.likelihood < settings.tieMargin;

  if (weak || tie) {
    // No single condition stands out within the category: describe the
    // category instead and list the closest matches.
    const fallback = CATEGORIES[categoryId].fallbackCondition;
    return {
      predictedConditionId: fallback.id,
      predictedCondition: fallback.name,
      conditionShort: fallback.short,
      conditionDescription: fallback.description,
      conditionLikelihood: null,
      conditionScore: best ? round(best.score, 2) : 0,
      conditionIsFallback: true,
      conditionTie: Boolean(tie),
      differentials: candidates.slice(0, settings.maxDifferentials)
        .map((item) => ({ id: item.condition.id, name: item.condition.name, short: item.condition.short, likelihood: tie ? item.likelihood : null })),
      conditionEvidence: [],
      conditionAgainst: [],
      consideredConditions: [],
    };
  }

  return {
    predictedConditionId: best.condition.id,
    predictedCondition: best.condition.name,
    conditionShort: best.condition.short,
    conditionDescription: best.condition.description,
    conditionLikelihood: best.likelihood,
    conditionScore: round(best.score, 2),
    conditionIsFallback: false,
    differentials: candidates.slice(1)
      .filter((item) => item.likelihood >= settings.minDifferentialLikelihood)
      .slice(0, settings.maxDifferentials)
      .map((item) => ({ id: item.condition.id, name: item.condition.name, short: item.condition.short, likelihood: item.likelihood })),
    conditionEvidence: conditionEvidence(best.contributions, rawFeatures, 1),
    conditionAgainst: conditionEvidence(best.contributions, rawFeatures, -1),
    consideredConditions: [],
  };
}

/* ---------- Urgent cases: no condition is kept ---------- */

const CONDITION_FIELDS = ['predictedConditionId', 'predictedCondition', 'conditionShort', 'conditionDescription', 'conditionLikelihood',
  'conditionScore', 'conditionIsFallback', 'conditionTie', 'differentials', 'conditionEvidence', 'conditionAgainst', 'consideredConditions'];

/* Urgent cases are not diagnosed: the condition is removed from the
   result itself, so it is never shown, printed or stored. */
function withholdCondition(prediction) {
  if (!prediction) return;
  CONDITION_FIELDS.forEach((key) => { delete prediction[key]; });
  prediction.conditionWithheld = true;
}

/* When reception removes an urgent mark (and no warning signs remain),
   the condition is predicted again from the stored features. This uses
   the built-in condition scoring, also when the department came from the
   trained model; the result then says so (conditionByRules). */
function restoreCondition(assessment) {
  const prediction = assessment.prediction;
  if (!prediction || !prediction.conditionWithheld || !assessment.features) return;
  const categoryId = prediction.isInconclusive ? null : prediction.predictedCategoryId;
  Object.assign(prediction, predictCondition(assessment.features.named, assessment.features.raw, categoryId));
  if (isModelResult(prediction)) prediction.conditionByRules = true;
  delete prediction.conditionWithheld;
}

function findConditionByName(name) {
  const key = String(name || '').trim().toLowerCase();
  if (!key) return null;
  return CONDITIONS.find((condition) => condition.id === key || condition.name.toLowerCase() === key || condition.short.toLowerCase() === key) || null;
}

function slugify(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'condition';
}

/* ---------- Explanations ---------- */

function describeFeature(key, rawFeatures) {
  const label = SYMPTOM_LABELS[key] || key;
  const value = rawFeatures[key];
  if (key === 'breathingDifficulty' && value > 0) return `${label} (${BREATHING_OPTIONS[value].label.toLowerCase()})`;
  if (key === 'painScore' && value !== null) return `Pain ${value}/10`;
  if (key === 'durationBand' && value) {
    const option = DURATION_OPTIONS.find((item) => item.score === value);
    return option ? `${label}: ${option.label.toLowerCase()}` : label;
  }
  if (key === 'severity' && value) {
    const option = SEVERITY_OPTIONS.find((item) => item.score === value);
    return option ? `${label}: ${option.label.toLowerCase()}` : label;
  }
  return label;
}

function matchedSymptomsFor(category, rawFeatures) {
  return category.contributions
    .filter((item) => item.points > 0 && !(FEATURE_INDEX[item.key] || {}).internal)
    .sort((a, b) => b.points - a.points)
    .map((item) => ({ key: item.key, label: describeFeature(item.key, rawFeatures), points: item.points }));
}

function consideredSymptoms(rawFeatures) {
  return FEATURE_SCHEMA
    .filter((definition) => !definition.internal && definition.type === 'binary' && rawFeatures[definition.key] === 1)
    .map((definition) => ({ key: definition.key, label: SYMPTOM_LABELS[definition.key] }));
}
