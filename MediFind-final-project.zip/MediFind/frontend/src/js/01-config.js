/* =====================================================================
   1. CONFIGURATION
   ---------------------------------------------------------------------
   All clinical-routing business logic lives in the configuration objects
   below: the decision-tree questionnaire, the feature schema, the
   prototype scoring rules, the specialist mapping and the safety rules.
   The UI and engines read from these objects; nothing clinical is
   hard-coded into individual screens.
   ===================================================================== */

const APP_CONFIG = {
  systemName: 'MediFind: Smart Disease Prediction & Doctor Recommendation System',
  shortName: 'MediFind',
  tagline: 'Smart disease prediction & doctor recommendation',
  hospitalName: 'Multispeciality Hospital',
  deskName: 'Reception desk',
  version: '1.0.0',
  idPrefix: 'MF',
  // Storage keys keep their original names so assessments saved before the
  // MediFind name are still found.
  storageKeys: {
    assessments: 'sdp.assessments.v1',
    counters: 'sdp.idCounters.v1',
    draft: 'sdp.draft.v1',
    accounts: 'medifind.accounts.v1',
    session: 'medifind.session.v1',
    theme: 'medifind.theme.v1', // 'light' or 'dark'; absent = follow the computer's setting
  },
  analysisStepMs: 260, // per analysis stage, about 1.3 s in total
  recentLimit: 6,
};

/* Staff accounts and sign-in (section 3a). Accounts are kept in this
   browser only; see the note at the top of 03a-auth.js. */
const AUTH_CONFIG = {
  passwordMin: 8,
  passwordMax: 128,
  hashIterations: 600000, // PBKDF2-SHA-256, the OWASP guidance at the time of writing
  quickPickLimit: 4, // accounts offered as one-click choices on the log-in screen
  roles: [
    { value: 'receptionist', label: 'Receptionist' },
    { value: 'nurse', label: 'Nurse' },
    { value: 'doctor', label: 'Doctor' },
    { value: 'administrator', label: 'Administrator' },
  ],
  signupSteps: [
    { id: 'account', label: 'Create your account', title: 'Create your account', lead: 'Enter your details to set up MediFind on this computer.' },
    { id: 'desk', label: 'Set up your desk', title: 'Set up your desk', lead: 'The desk name shows at the top of the screen. Both names are printed on reports.' },
    { id: 'confirm', label: 'Confirm safe use', title: 'Confirm safe use', lead: 'Read how MediFind should be used at the desk.' },
  ],
  safeUse: [
    'MediFind suggests which department a patient should see and may show a preliminary condition match. It does not diagnose and never prescribes medicines.',
    'A condition match is for the clinician. Never tell a patient it is their diagnosis.',
    'If a warning sign appears, follow the hospital’s emergency process straight away.',
    'A qualified clinician makes every medical decision.',
  ],
  // Shown on the log-in screen: the steps of an assessment, once signed in.
  tour: ['Record the patient’s details', 'Mark the symptoms on the body map', 'Get the suggested department'],
};

/* The built-in rules: used when the page is opened on its own (as a file),
   or when the MediFind backend cannot be reached. */
const ENGINE_INFO = {
  id: 'local-weighted-v1',
  name: 'Local prototype classifier',
  method: 'Weighted symptom scoring + decision rules → category scores; condition scoring within the matched category',
  note: 'Runs entirely in this browser. No trained model or server is connected. Start MediFind with its backend (run_medifind.py) to use the trained machine-learning model instead.',
};

/* The trained machine-learning model, used when MediFind is started with its
   Python backend (run_medifind.py). PredictionService.detect() switches to it
   only when GET /api/health answers with the same feature schema. */
const ENGINE_INFO_API = {
  id: 'api',
  name: 'Trained ML model',
  method: 'Multinomial logistic regression over 73 conditions (Python, scikit-learn), trained on simulated cases; department probability = sum of its conditions’ probabilities',
  note: 'Runs on the MediFind backend (Python and Flask) started with the app. The model was trained on simulated cases generated from MediFind’s own medical knowledge base, not on real patient records. Only the encoded answers are sent to the backend, never the patient’s name or contact number, and the backend does not store them. Urgent warning signs are checked by the app and always take priority.',
};

/* Connection to the MediFind backend (backend/ml/api.py), on the same address as the page. */
const API_SETTINGS = {
  healthPath: '/api/health',
  predictPath: '/api/predict',
  detectTimeoutMs: 3000,
  predictTimeoutMs: 15000,
  // When the built-in rules find the evidence too weak or mixed to decide, and the
  // model is less than 90% sure (or answers contradict each other), the confidence
  // shown is limited to the rules' own.
  rulesCheckBelow: 0.9,
};

/* Wording for results produced by the trained model. */
const MODEL_TEXT = {
  likelihoodLabel: 'Model probability',
  cardHelp: 'The trained model’s probability for this condition among the 73 it knows, shown up to 90%. Not the chance that the patient has it.',
  helperText: 'Model probability is the trained model’s estimate for each condition among the 73 it knows, learned from simulated cases and shown up to 90%. It is not the chance that the patient has the condition.',
  shareNote: 'The trained model’s probability for each category.',
  confidenceNote: 'Model confidence is the model’s probability for the department, lowered for contradictory answers, limited when the built-in rules find the evidence too weak to decide, and capped at 94%.',
  analysisLead: 'Structuring the responses and asking the trained machine-learning model for the most likely department.',
  dashboard: (backend) => `Prediction engine: trained ML model (${backend && backend.model ? backend.model : 'machine learning'}${backend && backend.version ? ` v${backend.version}` : ''}) on the MediFind backend`,
  statusTitle: 'The trained machine-learning model on the MediFind backend is making the predictions.',
  localStatusTitle: 'The prototype prediction engine is running locally in this browser.',
  fallbackToast: 'The MediFind backend could not be reached, so the built-in rules were used for this assessment. Restart MediFind and reload the page to use the trained model again.',
};

const GENDER_OPTIONS = [
  { value: 'female', label: 'Female' },
  { value: 'male', label: 'Male' },
  { value: 'other', label: 'Other' },
  { value: 'undisclosed', label: 'Prefer not to say' },
];

/* Main complaints. `entry` is the first decision-tree question for the
   complaint; `sets` records the features implied by the complaint itself. */
const COMPLAINTS = [
  { id: 'pain', label: 'Pain', hint: 'Chest, head, abdomen, joints or back', icon: 'zap', entry: 'pain_location' },
  { id: 'fever', label: 'Fever', hint: 'Raised temperature, chills', icon: 'thermometer', entry: 'fever_duration', sets: { fever: 1 } },
  { id: 'respiratory', label: 'Cough / Respiratory Issue', hint: 'Cough, breathlessness, wheeze', icon: 'lungs', entry: 'resp_cough' },
  { id: 'skin', label: 'Skin Problem', hint: 'Rash, itching, patches, wounds', icon: 'skin', entry: 'skin_type' },
  { id: 'dizziness', label: 'Dizziness', hint: 'Spinning, light-headed, unsteady', icon: 'spiral', entry: 'dizzy_type', sets: { dizziness: 1 } },
  { id: 'digestive', label: 'Digestive Problem', hint: 'Stomach pain, vomiting, acidity', icon: 'stomach', entry: 'gi_main' },
  { id: 'joint_limb', label: 'Joint / Limb Pain', hint: 'Knee, shoulder, ankle, hand', icon: 'bone', entry: 'joint_site', sets: { jointLimbPain: 1 } },
  { id: 'neuro', label: 'Headache / Neurological Complaint', hint: 'Headache, numbness, seizures', icon: 'brain', entry: 'neuro_main' },
  { id: 'weakness', label: 'Weakness / Fatigue', hint: 'Tiredness, low energy, faintness', icon: 'battery-low', entry: 'weak_type' },
  { id: 'other', label: 'Other / Unsure', hint: 'Not sure which applies', icon: 'circle-help', entry: 'other_area' },
];

/* ---------------------------------------------------------------------
   Reusable answer option sets
   --------------------------------------------------------------------- */

const YES_NO_OPTIONS = [
  { value: 'yes', label: 'Yes' },
  { value: 'no', label: 'No' },
];

const YES_NO_UNSURE_OPTIONS = [
  ...YES_NO_OPTIONS,
  { value: 'unsure', label: 'Not sure', unsure: true },
];

const DURATION_OPTIONS = [
  { value: 'lt24h', label: 'Less than 24 hours', score: 1 },
  { value: '1to3d', label: '1–3 days', score: 2 },
  { value: '4to7d', label: '4–7 days', score: 3 },
  { value: '1to4w', label: '1–4 weeks', score: 4 },
  { value: 'gt1m', label: 'More than a month', score: 5 },
];

const BREATHING_OPTIONS = [
  { value: 'none', label: 'No', hint: 'Breathing normally', score: 0 },
  { value: 'mild', label: 'Mild', hint: 'Slightly short of breath', score: 1 },
  { value: 'moderate', label: 'Moderate', hint: 'Breathless while talking or walking', score: 2 },
  { value: 'severe', label: 'Severe', hint: 'Struggling to breathe or speak', score: 3 },
];

const SEVERITY_OPTIONS = [
  { value: 'mild', label: 'Mild', hint: 'Noticeable, but daily activities are manageable', score: 1 },
  { value: 'moderate', label: 'Moderate', hint: 'Interferes with daily activities', score: 2 },
  { value: 'severe', label: 'Severe', hint: 'Very hard to bear, or unable to carry on', score: 3 },
];

/* 0–10 pain bands. Presentation bands for the scale, not clinical standards. */
const PAIN_BANDS = [
  { min: 0, max: 0, label: 'No pain', level: 0 },
  { min: 1, max: 3, label: 'Mild', level: 1 },
  { min: 4, max: 6, label: 'Moderate', level: 2 },
  { min: 7, max: 10, label: 'Severe', level: 3 },
];

/* Plain descriptions for each pain scale, by body area: what 1 and 10
   feel like, and what the mild, moderate and severe bands mean. Shown at
   the ends of every 0–10 scale and next to the selected score. */
const PAIN_SCALES = {
  chest: {
    low: 'Barely there, like a light pressure', high: 'Crushing, the worst pain you can imagine',
    mild: 'Uncomfortable, but you can carry on', moderate: 'Hard to ignore; you need to stop and rest', severe: 'Very strong; hard to talk, move or breathe deeply',
  },
  head: {
    low: 'A faint ache you can ignore', high: 'The worst headache of your life',
    mild: 'You can carry on with your day', moderate: 'Hard to concentrate or work', severe: 'You need to lie down; light or noise hurts',
  },
  abdomen: {
    low: 'Mild discomfort, like trapped gas', high: 'Unbearable; you cannot stand straight or keep still',
    mild: 'Uncomfortable, but you can eat and move', moderate: 'You need to stop and hold your stomach', severe: 'Doubled over; hard to stand up',
  },
  joint: {
    low: 'Like someone pinched you', high: 'Like a bone breaking',
    mild: 'Noticeable, but you can still use it', moderate: 'Hard to use it or put weight on it', severe: 'You cannot use it; hard to think of anything else',
  },
  back: {
    low: 'Slight stiffness', high: 'You cannot move, sit or stand because of it',
    mild: 'Stiff, but you can move normally', moderate: 'Bending, sitting or walking hurts', severe: 'You can barely move',
  },
  throat: {
    low: 'A slight scratch', high: 'You cannot swallow at all',
    mild: 'Scratchy, but swallowing is fine', moderate: 'Swallowing hurts', severe: 'Very hard to swallow food or drinks',
  },
  ear: {
    low: 'A slight ache', high: 'Sharp, unbearable pain',
    mild: 'A dull ache you notice now and then', moderate: 'A throbbing ache that is hard to ignore', severe: 'Sharp pain; hard to sleep or think',
  },
  teeth: {
    low: 'Slight sensitivity to hot or cold', high: 'Throbbing, unbearable pain',
    mild: 'Sensitive when eating or drinking', moderate: 'Aching; chewing is hard', severe: 'Throbbing; you cannot eat or sleep',
  },
  pelvis: {
    low: 'Mild discomfort', high: 'Unbearable; you cannot sit or walk',
    mild: 'Noticeable, but you can carry on', moderate: 'Hurts when walking or sitting', severe: 'Very hard to walk or sit',
  },
  urine: {
    low: 'A slight sting', high: 'Severe burning; very hard to pass urine',
    mild: 'Slight stinging when passing urine', moderate: 'Burning every time you pass urine', severe: 'Severe burning; you avoid passing urine',
  },
  body: {
    low: 'A mild ache', high: 'Aching so badly you cannot get up',
    mild: 'Aches you can live with', moderate: 'Aches that slow you down', severe: 'Aching all over; hard to get out of bed',
  },
  general: {
    low: 'Barely noticeable', high: 'The worst pain you can imagine',
    mild: 'Noticeable, but you can carry on', moderate: 'Hard to ignore; it limits what you do', severe: 'Very strong; you cannot do normal things',
  },
};

/* `scale` is a PAIN_SCALES key, or a function of the answers so far. */
function painScaleQuestion(id, section, next, text, scale = 'general') {
  return {
    id, section, type: 'scale', min: 0, max: 10, featureKey: 'painScore', short: 'Pain score', painScale: scale,
    text: text || 'How severe is the pain right now, on a scale of 0 to 10?',
    helpText: '0 means no pain at all. The descriptions at each end show what 1 and 10 feel like.',
    next,
  };
}

function durationQuestion(id, section, text, next) {
  return {
    id, section, type: 'duration', featureKey: 'durationBand', short: 'Duration',
    text, options: DURATION_OPTIONS, next,
  };
}

/* ---------------------------------------------------------------------
   QUESTION_TREE — decision-tree questionnaire
   ---------------------------------------------------------------------
   Question fields
     id         unique id, also the key in state.assessment.answers
     section    branch name shown to the receptionist
     type       yesno | single | multi | severity | scale | number | duration | location
     text       question read to the patient
     helpText   guidance for the receptionist
     options    answer options; `set` lists the features a chosen option records
     featureKey feature written by yes/no, scored, scale and number answers
     condition  (activeAnswers) => boolean; when false the question is skipped
     next       id | { answerValue: id, default: id } | (answer, activeAnswers) => id
                null ends the questionnaire
     lookAhead  true when a function `next` ignores this question's own answer,
                so the route can be followed past it before it is answered
     areaScoreKey  scale questions: a second feature that also records the score
   Multi-select options use `feature` (1 when ticked, 0 when not) and
   `alsoSet` (extra features recorded only when ticked).
   --------------------------------------------------------------------- */

const QUESTION_TREE = defineQuestions([
  /* ----- Pain ----- */
  {
    id: 'pain_location', section: 'Pain', type: 'location', short: 'Pain location',
    text: 'Where is the pain?',
    helpText: 'Ask the patient to point to the area. If the pain is in more than one place, choose where it is worst.',
    options: [
      { value: 'chest', label: 'Chest', region: 'chest', set: { chestPain: 1 } },
      { value: 'head', label: 'Head', region: 'head', set: { headache: 1 } },
      { value: 'abdomen', label: 'Abdomen', region: 'abdomen', set: { abdominalPain: 1 } },
      { value: 'joint', label: 'Joint / Limb', region: 'limb', set: { jointLimbPain: 1 } },
      { value: 'back', label: 'Back or neck', region: 'back', set: { backPain: 1 } },
      { value: 'other', label: 'Other', region: 'other', set: { otherPain: 1 } },
    ],
    next: { chest: 'chest_breathing', head: 'head_sudden', abdomen: 'abd_location', joint: 'joint_site', back: 'back_area', other: 'pain_other_area' },
  },

  /* ----- Chest pain branch ----- */
  {
    id: 'chest_breathing', section: 'Chest pain', type: 'single', short: 'Difficulty breathing',
    text: 'Are you experiencing difficulty breathing?',
    options: BREATHING_OPTIONS, featureKey: 'breathingDifficulty',
    next: 'chest_dizziness',
  },
  {
    id: 'chest_dizziness', section: 'Chest pain', type: 'yesno', short: 'Dizziness',
    text: 'Are you feeling dizzy or light-headed?', featureKey: 'dizziness',
    next: 'chest_sweating',
  },
  {
    id: 'chest_sweating', section: 'Chest pain', type: 'yesno', short: 'Unusual sweating',
    text: 'Are you sweating unusually?',
    helpText: 'For example, a cold sweat that is not explained by heat or exercise.',
    featureKey: 'sweating',
    next: 'chest_pattern',
  },
  {
    id: 'chest_pattern', section: 'Chest pain', type: 'single', short: 'What makes it worse',
    text: 'What makes the chest pain worse?',
    options: [
      { value: 'exertion', label: 'Physical effort, such as walking or climbing stairs', set: { exertionalSymptoms: 1 } },
      { value: 'breathing', label: 'Breathing in deeply or coughing', set: { pleuriticPain: 1 } },
      { value: 'meals', label: 'After meals or when lying down', set: { postprandialPain: 1 } },
      { value: 'pressing', label: 'Pressing on the chest or moving the upper body', set: { chestWallTenderness: 1 } },
      { value: 'nothing', label: 'Nothing in particular' },
    ],
    next: 'chest_onset',
  },
  {
    id: 'chest_onset', section: 'Chest pain', type: 'duration', short: 'Pain began',
    text: 'When did the pain begin?', featureKey: 'durationBand',
    options: [
      { value: 'hours', label: 'Within the last few hours', score: 1, set: { acuteOnset: 1 } },
      { value: 'today', label: 'Earlier today', score: 1, set: { acuteOnset: 1 } },
      { value: 'days', label: '1–3 days ago', score: 2 },
      { value: 'week', label: '4–7 days ago', score: 3 },
      { value: 'longer', label: 'More than a week ago, or on and off', score: 4 },
    ],
    next: 'chest_score',
  },
  {
    // Also recorded as chestPainScore, so the chest-pain warning sign uses the chest's own score.
    ...painScaleQuestion('chest_score', 'Chest pain', 'chest_associated', 'How severe is the chest pain right now, on a scale of 0 to 10?', 'chest'),
    areaScoreKey: 'chestPainScore',
  },
  {
    id: 'chest_associated', section: 'Chest pain', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these along with the chest pain?',
    options: [
      { value: 'radiating', label: 'Pain spreading to the arm, jaw, neck or back', feature: 'radiatingChestPain' },
      { value: 'palpitations', label: 'Racing or irregular heartbeat', feature: 'palpitations' },
      { value: 'nausea', label: 'Nausea or vomiting', feature: 'nauseaVomiting' },
      { value: 'cough', label: 'Cough', feature: 'cough' },
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'safety_check',
  },

  /* ----- Headache branch (from Pain → Head and Neurological → Headache) ----- */
  {
    id: 'head_sudden', section: 'Headache', type: 'yesno', short: 'Sudden severe onset',
    text: 'Did the headache start suddenly and very severely, reaching its worst within a minute?',
    helpText: 'A sudden "thunderclap" headache needs urgent clinical attention.',
    featureKey: 'suddenSevereHeadache',
    next: 'head_character',
  },
  {
    id: 'head_character', section: 'Headache', type: 'single', short: 'Type of headache',
    text: 'How would you describe the headache?',
    options: [
      { value: 'throbbing', label: 'Throbbing or pulsing, often on one side', set: { throbbingHeadache: 1 } },
      { value: 'band', label: 'A tight band or pressure around the head', set: { tensionHeadache: 1 } },
      { value: 'sharp', label: 'Sharp or stabbing', set: { sharpHeadache: 1 } },
      { value: 'dull', label: 'Dull and constant', set: { dullHeadache: 1 } },
    ],
    next: 'head_associated',
  },
  {
    id: 'head_associated', section: 'Headache', type: 'multi', short: 'With the headache',
    text: 'Do any of these come with the headache?',
    options: [
      { value: 'nausea', label: 'Nausea or vomiting', feature: 'nauseaVomiting' },
      { value: 'light', label: 'Sensitivity to light or sound', feature: 'photophobia' },
      { value: 'vision', label: 'Blurred or disturbed vision', feature: 'visionChanges' },
      { value: 'numbness', label: 'Numbness or weakness in the face, an arm or a leg', feature: 'numbness' },
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'stiff_neck', label: 'Stiff neck', feature: 'stiffNeck' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'head_frequency',
  },
  {
    id: 'head_frequency', section: 'Headache', type: 'single', short: 'How often',
    text: 'How often do these headaches happen?',
    options: [
      { value: 'first', label: 'This is the first time', set: { firstHeadache: 1 } },
      { value: 'occasional', label: 'Occasionally, a few times a month', set: { recurrentHeadache: 1 } },
      { value: 'frequent', label: 'Frequently, weekly or more', set: { recurrentHeadache: 1 } },
      { value: 'daily', label: 'Every day, or constantly', set: { recurrentHeadache: 1 } },
    ],
    next: 'head_duration',
  },
  durationQuestion('head_duration', 'Headache', 'How long has the current headache lasted?', 'head_score'),
  painScaleQuestion('head_score', 'Headache', 'safety_check', 'How severe is the headache right now, on a scale of 0 to 10?', 'head'),

  /* ----- Abdominal pain / digestive branch ----- */
  {
    id: 'gi_main', section: 'Digestive', type: 'single', short: 'Main digestive problem',
    text: 'What is the main digestive problem?',
    options: [
      { value: 'pain', label: 'Stomach or abdominal pain', set: { abdominalPain: 1 } },
      { value: 'vomiting', label: 'Nausea or vomiting', set: { nauseaVomiting: 1 } },
      { value: 'diarrhoea', label: 'Loose motions (diarrhoea)', set: { diarrhoea: 1 } },
      { value: 'acidity', label: 'Acidity, heartburn or burping', set: { acidity: 1 } },
      { value: 'constipation', label: 'Constipation or bloating', set: { constipation: 1 } },
      { value: 'blood', label: 'Blood in stool or vomit', set: { giBlood: 1 } },
    ],
    next: { pain: 'abd_location', vomiting: 'gi_vomit_count', diarrhoea: 'gi_stool_count', acidity: 'abd_meals', constipation: 'gi_associated', blood: 'gi_blood_amount' },
  },
  {
    id: 'abd_location', section: 'Abdominal pain', type: 'single', short: 'Area of abdomen',
    text: 'Where in the abdomen is the pain?',
    helpText: 'Ask the patient to point to where it hurts most.',
    options: [
      { value: 'upper_middle', label: 'Upper middle, just below the chest', set: { upperAbdominal: 1 } },
      { value: 'upper_right', label: 'Upper right side', set: { rightUpperAbdominal: 1 } },
      { value: 'upper_left', label: 'Upper left side', set: { upperAbdominal: 1 } },
      { value: 'lower_right', label: 'Lower right side', set: { rightLowerAbdominal: 1 } },
      { value: 'lower', label: 'Lower abdomen or around the navel', set: { lowerAbdominal: 1 } },
      { value: 'all_over', label: 'All over the abdomen', set: { diffuseAbdominal: 1 } },
    ],
    next: 'abd_meals',
  },
  {
    id: 'abd_meals', section: 'Digestive', type: 'single', short: 'Relation to meals',
    text: 'Is the problem related to meals?',
    options: [
      { value: 'worse', label: 'Worse after eating', set: { mealRelated: 1, postprandialPain: 1 } },
      { value: 'better', label: 'Better after eating', set: { mealRelated: 1, emptyStomachPain: 1 } },
      { value: 'empty', label: 'Worse on an empty stomach', set: { mealRelated: 1, emptyStomachPain: 1 } },
      { value: 'no', label: 'No connection with meals' },
      { value: 'unsure', label: 'Not sure', unsure: true },
    ],
    next: 'gi_associated',
  },
  {
    id: 'gi_vomit_count', section: 'Digestive', type: 'single', short: 'Vomiting in 24 hours',
    text: 'How many times have you vomited in the last 24 hours?',
    options: [
      { value: 'none', label: 'Not at all, nausea only' },
      { value: 'few', label: '1–2 times' },
      { value: 'several', label: '3–5 times' },
      { value: 'many', label: 'More than 5 times, or unable to keep fluids down', set: { frequentVomiting: 1 } },
    ],
    next: 'gi_associated',
  },
  {
    id: 'gi_stool_count', section: 'Digestive', type: 'single', short: 'Loose motions in 24 hours',
    text: 'How many loose motions have you had in the last 24 hours?',
    options: [
      { value: 'few', label: '1–3' },
      { value: 'several', label: '4–6' },
      { value: 'many', label: 'More than 6', set: { frequentDiarrhoea: 1 } },
    ],
    next: 'gi_associated',
  },
  {
    id: 'gi_blood_amount', section: 'Digestive', type: 'single', short: 'Amount of blood',
    text: 'How much blood have you noticed?',
    options: [
      { value: 'small', label: 'Streaks or a small amount', set: { giBloodSmall: 1 } },
      { value: 'large', label: 'A large amount, or it keeps happening', set: { giBloodLarge: 1 } },
    ],
    next: 'gi_associated',
  },
  {
    id: 'gi_associated', section: 'Digestive', type: 'multi', short: 'Other digestive symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'nausea', label: 'Nausea or vomiting', feature: 'nauseaVomiting' },
      { value: 'diarrhoea', label: 'Loose motions', feature: 'diarrhoea' },
      { value: 'constipation', label: 'Constipation', feature: 'constipation' },
      { value: 'bloating', label: 'Bloating or gas', feature: 'bloating' },
      { value: 'acidity', label: 'Acidity or a burning sensation', feature: 'acidity' },
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'appetite', label: 'Loss of appetite', feature: 'appetiteLoss' },
      { value: 'blood', label: 'Blood in stool or vomit', feature: 'giBlood' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'gi_duration',
  },
  {
    ...durationQuestion('gi_duration', 'Digestive', 'How long has this been going on?', null),
    next: (answer, active) => (active.abd_location !== undefined ? 'abd_score' : 'safety_check'),
    lookAhead: true, // the next question depends on earlier answers only, not on this one
  },
  painScaleQuestion('abd_score', 'Abdominal pain', 'safety_check', 'How severe is the stomach (abdominal) pain right now, on a scale of 0 to 10?', 'abdomen'),

  /* ----- Joint / limb branch ----- */
  {
    id: 'joint_site', section: 'Joint / limb', type: 'single', short: 'Joint or limb',
    text: 'Which joint or limb is affected?',
    options: [
      { value: 'knee', label: 'Knee', set: { lowerLimb: 1 } },
      { value: 'hip', label: 'Hip or thigh', set: { lowerLimb: 1 } },
      { value: 'ankle', label: 'Ankle or foot', set: { lowerLimb: 1 } },
      { value: 'shoulder', label: 'Shoulder or upper arm' },
      { value: 'arm', label: 'Elbow, wrist or hand' },
      { value: 'lower_leg', label: 'Lower leg or calf', set: { lowerLimb: 1 } },
      { value: 'multiple', label: 'Several joints', set: { multipleJoints: 1 } },
    ],
    next: 'joint_swelling',
  },
  {
    id: 'joint_swelling', section: 'Joint / limb', type: 'yesno', short: 'Swelling',
    text: 'Is there swelling?', featureKey: 'jointSwelling',
    next: 'joint_injury',
  },
  {
    id: 'joint_injury', section: 'Joint / limb', type: 'yesno', short: 'Injury, fall or accident',
    text: 'Was there an injury, fall or accident?', featureKey: 'injury',
    next: 'joint_deformity',
  },
  {
    id: 'joint_deformity', section: 'Joint / limb', type: 'yesno', short: 'Deformity or cannot use it',
    text: 'Is there an obvious deformity, or are you unable to move it or put weight on it?',
    helpText: 'Asked because an injury was reported.',
    featureKey: 'suspectedFracture',
    condition: (active) => active.joint_injury === 'yes',
    next: 'joint_movement',
  },
  {
    id: 'joint_movement', section: 'Joint / limb', type: 'yesno', short: 'Restricted movement',
    text: 'Is movement restricted?', featureKey: 'restrictedMovement',
    next: 'joint_associated',
  },
  {
    id: 'joint_associated', section: 'Joint / limb', type: 'multi', short: 'Other joint symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'red_warm', label: 'Redness or warmth over the joint', feature: 'jointRedWarm' },
      { value: 'stiffness', label: 'Morning stiffness lasting more than 30 minutes', feature: 'morningStiffness' },
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'numbness', label: 'Numbness or tingling', feature: 'numbness' },
      { value: 'rash', label: 'Rash', feature: 'rash' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'joint_duration',
  },
  durationQuestion('joint_duration', 'Joint / limb', 'How long has the problem been present?', 'joint_score'),
  painScaleQuestion('joint_score', 'Joint / limb', 'safety_check', 'How severe is the joint or limb pain right now, on a scale of 0 to 10?', 'joint'),

  /* ----- Back / neck branch ----- */
  {
    id: 'back_area', section: 'Back / neck', type: 'single', short: 'Part of the back',
    text: 'Which part of the back or neck hurts?',
    options: [
      { value: 'neck', label: 'Neck', set: { neckPain: 1 } },
      { value: 'upper', label: 'Upper back' },
      { value: 'lower', label: 'Lower back', set: { lowBackPain: 1 } },
      { value: 'whole', label: 'The whole back' },
    ],
    next: 'back_radiation',
  },
  {
    id: 'back_radiation', section: 'Back / neck', type: 'yesno', short: 'Pain shooting down a limb',
    text: 'Does the pain shoot down an arm or a leg?', featureKey: 'radiatingLimbPain',
    next: 'back_injury',
  },
  {
    id: 'back_injury', section: 'Back / neck', type: 'yesno', short: 'Started after injury or lifting',
    text: 'Did it start after lifting something, a fall or an injury?', featureKey: 'injury',
    next: 'back_numbness',
  },
  {
    id: 'back_numbness', section: 'Back / neck', type: 'yesno', short: 'Numbness or weakness in limbs',
    text: 'Is there numbness, tingling or weakness in the arms or legs?', featureKey: 'numbness',
    next: 'back_bladder',
  },
  {
    id: 'back_bladder', section: 'Back / neck', type: 'yesno', short: 'New bladder or bowel problem',
    text: 'Has there been any new loss of bladder or bowel control?',
    helpText: 'Asked for lower-back pain. A "yes" needs urgent clinical attention.',
    featureKey: 'bladderBowelLoss',
    condition: (active) => active.back_area === 'lower' || active.back_area === 'whole',
    next: 'back_duration',
  },
  durationQuestion('back_duration', 'Back / neck', 'How long has the pain been present?', 'back_score'),
  painScaleQuestion('back_score', 'Back / neck', 'safety_check', 'How severe is the back or neck pain right now, on a scale of 0 to 10?', 'back'),

  /* ----- Pain elsewhere ----- */
  {
    id: 'pain_other_area', section: 'Other pain', type: 'single', short: 'Area of pain',
    text: 'Which best describes where the pain is?',
    options: [
      { value: 'throat', label: 'Throat', set: { soreThroat: 1, dentalEarThroat: 1 } },
      { value: 'ear', label: 'Ear', set: { dentalEarThroat: 1, earPain: 1 } },
      { value: 'teeth', label: 'Teeth or jaw', set: { dentalEarThroat: 1, toothPain: 1 } },
      { value: 'pelvis', label: 'Pelvis or groin', set: { pelvicPain: 1 } },
      { value: 'urine', label: 'Pain or burning while passing urine', set: { urinarySymptoms: 1 } },
      { value: 'all_over', label: 'All over the body', set: { bodyAches: 1 } },
      { value: 'unsure', label: 'Hard to say', unsure: true },
    ],
    next: 'other_pain_associated',
  },
  {
    id: 'other_pain_associated', section: 'Other pain', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'tired', label: 'Tiredness or weakness', feature: 'fatigue' },
      { value: 'cough', label: 'Cough', feature: 'cough' },
      { value: 'nausea', label: 'Nausea or vomiting', feature: 'nauseaVomiting' },
      { value: 'rash', label: 'Rash', feature: 'rash' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'other_pain_duration',
  },
  durationQuestion('other_pain_duration', 'Other pain', 'How long has the pain been present?', 'other_pain_score'),
  painScaleQuestion('other_pain_score', 'Other pain', 'safety_check', null, (answers) => ({
    throat: 'throat', ear: 'ear', teeth: 'teeth', pelvis: 'pelvis', urine: 'urine', all_over: 'body',
  }[answers.pain_other_area] || 'general')),

  /* ----- Fever branch ----- */
  durationQuestion('fever_duration', 'Fever', 'How long have you had the fever?', 'fever_measured'),
  {
    id: 'fever_measured', section: 'Fever', type: 'yesno', short: 'Temperature measured',
    text: 'Has your temperature been measured?',
    options: YES_NO_OPTIONS,
    next: 'fever_temp',
  },
  {
    id: 'fever_temp', section: 'Fever', type: 'number', short: 'Highest temperature',
    text: 'What was the highest temperature recorded?',
    helpText: 'Normal is about 98.6 °F (37 °C). 100.4 °F (38 °C) or higher is a fever. Enter the reading the patient reports, or one taken at the desk.',
    featureKey: 'temperatureC',
    units: [
      { value: 'F', label: '°F', min: 95, max: 108, step: 0.1, placeholder: 'e.g. 101.4' },
      { value: 'C', label: '°C', min: 35, max: 42, step: 0.1, placeholder: 'e.g. 38.6' },
    ],
    condition: (active) => active.fever_measured === 'yes',
    next: 'fever_cough',
  },
  {
    id: 'fever_cough', section: 'Fever', type: 'yesno', short: 'Cough',
    text: 'Do you have a cough?', featureKey: 'cough',
    next: 'fever_breathing',
  },
  {
    id: 'fever_breathing', section: 'Fever', type: 'single', short: 'Difficulty breathing',
    text: 'Is there any difficulty breathing?',
    helpText: 'Asked because a cough was reported.',
    options: BREATHING_OPTIONS, featureKey: 'breathingDifficulty',
    condition: (active) => active.fever_cough === 'yes',
    next: 'fever_chills',
  },
  {
    id: 'fever_chills', section: 'Fever', type: 'yesno', short: 'Chills',
    text: 'Do you have chills or shivering?', featureKey: 'chills',
    next: 'fever_rash',
  },
  {
    id: 'fever_rash', section: 'Fever', type: 'yesno', short: 'Rash',
    text: 'Do you have a rash?', featureKey: 'rash',
    next: 'fever_weakness',
  },
  {
    id: 'fever_weakness', section: 'Fever', type: 'yesno', short: 'Unusual weakness',
    text: 'Do you feel unusually weak?', featureKey: 'weakness',
    next: 'fever_associated',
  },
  {
    id: 'fever_associated', section: 'Fever', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'headache', label: 'Headache', feature: 'headache' },
      { value: 'body_aches', label: 'Body or joint aches', feature: 'bodyAches' },
      { value: 'sore_throat', label: 'Sore throat', feature: 'soreThroat' },
      { value: 'vomiting', label: 'Vomiting', feature: 'nauseaVomiting' },
      { value: 'loose_motions', label: 'Loose motions', feature: 'diarrhoea' },
      { value: 'urine', label: 'Burning while passing urine', feature: 'urinarySymptoms' },
      { value: 'stiff_neck', label: 'Stiff neck', feature: 'stiffNeck' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'safety_check',
  },

  /* ----- Cough / respiratory branch ----- */
  {
    id: 'resp_cough', section: 'Respiratory', type: 'yesno', short: 'Cough',
    text: 'Do you have a cough?', featureKey: 'cough',
    next: 'resp_cough_type',
  },
  {
    id: 'resp_cough_type', section: 'Respiratory', type: 'single', short: 'Type of cough',
    text: 'What kind of cough is it?',
    options: [
      { value: 'dry', label: 'Dry cough', set: { coughDry: 1 } },
      { value: 'phlegm', label: 'Cough with phlegm (mucus)', set: { coughProductive: 1 } },
      { value: 'blood', label: 'Cough with blood', set: { coughBlood: 1 } },
    ],
    condition: (active) => active.resp_cough === 'yes',
    next: 'resp_breathing',
  },
  {
    id: 'resp_breathing', section: 'Respiratory', type: 'single', short: 'Difficulty breathing',
    text: 'Are you experiencing difficulty breathing?',
    options: BREATHING_OPTIONS, featureKey: 'breathingDifficulty',
    next: 'resp_wheeze',
  },
  {
    id: 'resp_wheeze', section: 'Respiratory', type: 'yesno', short: 'Wheezing',
    text: 'Is there wheezing, or a whistling sound when you breathe?', featureKey: 'wheezing',
    next: 'resp_fever',
  },
  {
    id: 'resp_fever', section: 'Respiratory', type: 'yesno', short: 'Fever',
    text: 'Do you have a fever?', featureKey: 'fever',
    next: 'resp_chest',
  },
  {
    id: 'resp_chest', section: 'Respiratory', type: 'yesno', short: 'Chest tightness',
    text: 'Do you feel chest tightness, or pain when breathing in?', featureKey: 'chestTightness',
    next: 'resp_duration',
  },
  durationQuestion('resp_duration', 'Respiratory', 'How long have the symptoms been present?', 'resp_background'),
  {
    id: 'resp_background', section: 'Respiratory', type: 'multi', short: 'Background',
    text: 'Do any of these apply to you?',
    options: [
      { value: 'asthma', label: 'Known asthma or COPD (a long-term lung disease)', feature: 'respiratoryHistory' },
      { value: 'smoker', label: 'Smoke, or have smoked regularly', feature: 'smoker' },
      { value: 'exposure', label: 'Regular exposure to dust, smoke or fumes', feature: 'exposure' },
      { value: 'contact', label: 'Recent contact with someone with a similar illness', feature: 'sickContact' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'safety_check',
  },

  /* ----- Skin branch ----- */
  {
    id: 'skin_type', section: 'Skin', type: 'single', short: 'Type of skin issue',
    text: 'What type of skin issue are you experiencing?',
    options: [
      { value: 'rash', label: 'Rash or red patches', set: { rash: 1 } },
      { value: 'hives', label: 'Itchy bumps or hives', set: { rash: 1, hives: 1 } },
      { value: 'blisters', label: 'Blisters or fluid-filled spots', set: { skinBlisters: 1 } },
      { value: 'scaly', label: 'Dry, scaly or flaky skin', set: { skinScaly: 1 } },
      { value: 'acne', label: 'Acne or pimples', set: { skinAcne: 1 } },
      { value: 'wound', label: 'Wound, boil or infected area', set: { skinWound: 1 } },
      { value: 'pigment', label: 'Change in skin colour or patches', set: { skinPigment: 1 } },
      { value: 'hair_nail', label: 'Hair or nail problem', set: { hairNail: 1 } },
    ],
    next: 'skin_itching',
  },
  {
    id: 'skin_itching', section: 'Skin', type: 'yesno', short: 'Itching',
    text: 'Is there itching?', featureKey: 'itching',
    next: 'skin_redness',
  },
  {
    id: 'skin_redness', section: 'Skin', type: 'yesno', short: 'Redness',
    text: 'Is there redness?', featureKey: 'redness',
    next: 'skin_spreading',
  },
  {
    id: 'skin_spreading', section: 'Skin', type: 'yesno', short: 'Spreading',
    text: 'Is the affected area spreading?', featureKey: 'skinSpreading',
    next: 'skin_area',
  },
  {
    id: 'skin_area', section: 'Skin', type: 'single', short: 'Area of the body',
    text: 'Where on the body is it?',
    options: [
      { value: 'face', label: 'Face' },
      { value: 'scalp', label: 'Scalp' },
      { value: 'arms', label: 'Arms or hands' },
      { value: 'legs', label: 'Legs or feet' },
      { value: 'trunk', label: 'Chest, back or abdomen' },
      { value: 'widespread', label: 'Several areas, or widespread', set: { skinWidespread: 1 } },
    ],
    next: 'skin_duration',
  },
  durationQuestion('skin_duration', 'Skin', 'How long has it been present?', 'skin_associated'),
  {
    id: 'skin_associated', section: 'Skin', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'pain', label: 'Pain or burning', feature: 'skinPainBurning' },
      { value: 'discharge', label: 'Discharge or pus', feature: 'skinDischarge' },
      { value: 'swelling', label: 'Swelling of the lips, face or tongue', feature: 'facialSwelling' },
      { value: 'breathing', label: 'Difficulty breathing', feature: 'allergyBreathing' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'safety_check',
  },

  /* ----- Dizziness branch ----- */
  {
    id: 'dizzy_type', section: 'Dizziness', type: 'single', short: 'Type of dizziness',
    text: 'How would you describe the dizziness?',
    options: [
      { value: 'spinning', label: 'The room is spinning', set: { vertigo: 1 } },
      { value: 'faint', label: 'Light-headed, as if about to faint', set: { presyncope: 1 } },
      { value: 'unsteady', label: 'Unsteady, or losing balance', set: { imbalance: 1 } },
      { value: 'unsure', label: 'Hard to describe', unsure: true },
    ],
    next: 'dizzy_fainted',
  },
  {
    id: 'dizzy_fainted', section: 'Dizziness', type: 'yesno', short: 'Fainted',
    text: 'Have you fainted or lost consciousness?', featureKey: 'lossOfConsciousness',
    next: 'dizzy_trigger',
  },
  {
    id: 'dizzy_trigger', section: 'Dizziness', type: 'single', short: 'When it happens',
    text: 'When does the dizziness happen?',
    options: [
      { value: 'standing', label: 'When standing up quickly', set: { orthostaticDizziness: 1 } },
      { value: 'head_move', label: 'When moving the head or turning in bed', set: { positionalDizziness: 1 } },
      { value: 'exertion', label: 'During physical effort', set: { exertionalSymptoms: 1 } },
      { value: 'constant', label: 'All the time', set: { constantDizziness: 1 } },
      { value: 'random', label: 'It comes and goes with no clear trigger' },
    ],
    next: 'dizzy_associated',
  },
  {
    id: 'dizzy_associated', section: 'Dizziness', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'palpitations', label: 'Racing or irregular heartbeat', feature: 'palpitations' },
      { value: 'chest', label: 'Chest pain or discomfort', feature: 'chestDiscomfort' },
      { value: 'headache', label: 'Headache', feature: 'headache' },
      { value: 'ears', label: 'Ringing in the ears or hearing loss', feature: 'tinnitus' },
      { value: 'nausea', label: 'Nausea or vomiting', feature: 'nauseaVomiting' },
      { value: 'one_side', label: 'Weakness or numbness on one side of the body', feature: 'focalOneSided' },
      { value: 'vision', label: 'Blurred or double vision', feature: 'visionChanges' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'dizzy_duration',
  },
  durationQuestion('dizzy_duration', 'Dizziness', 'How long has the dizziness been happening?', 'safety_check'),

  /* ----- Neurological branch ----- */
  {
    id: 'neuro_main', section: 'Neurological', type: 'single', short: 'Main neurological problem',
    text: 'What is the main problem?',
    options: [
      { value: 'headache', label: 'Headache', set: { headache: 1 } },
      { value: 'numbness', label: 'Numbness or tingling', set: { numbness: 1 } },
      { value: 'weakness', label: 'Weakness in an arm, a leg or one side', set: { limbWeakness: 1 } },
      { value: 'seizure', label: 'Fits or seizures', set: { seizure: 1 } },
      { value: 'confusion', label: 'Confusion or memory problems', set: { confusion: 1 } },
      { value: 'vision', label: 'Problems with vision', set: { visionChanges: 1 } },
      { value: 'balance', label: 'Loss of balance or coordination', set: { imbalance: 1 } },
    ],
    next: { headache: 'head_sudden', numbness: 'neuro_area', weakness: 'neuro_area', seizure: 'seizure_last', default: 'neuro_sudden' },
  },
  {
    id: 'neuro_area', section: 'Neurological', type: 'single', short: 'Part of the body affected',
    text: 'Which part of the body is affected?',
    options: [
      { value: 'one_side', label: 'One side of the face or body', set: { focalOneSided: 1 } },
      { value: 'one_limb', label: 'One arm or one leg', set: { singleLimb: 1 } },
      { value: 'hands_feet', label: 'Both hands or both feet', set: { peripheralSymptoms: 1 } },
      { value: 'back_leg', label: 'Back pain shooting into an arm or a leg', set: { radiatingLimbPain: 1, backPain: 1 } },
    ],
    next: 'neuro_sudden',
  },
  {
    id: 'neuro_sudden', section: 'Neurological', type: 'yesno', short: 'Sudden onset',
    text: 'Did it start suddenly, within the last few hours?',
    helpText: 'Sudden one-sided weakness, facial drooping or speech difficulty needs emergency assessment.',
    featureKey: 'suddenOnsetNeuro',
    next: 'neuro_associated',
  },
  {
    id: 'neuro_associated', section: 'Neurological', type: 'multi', short: 'Other symptoms',
    text: 'Are any of these also present?',
    options: [
      { value: 'speech', label: 'Difficulty speaking, or slurred speech', feature: 'speechDifficulty' },
      { value: 'face', label: 'Drooping of one side of the face', feature: 'faceDroop' },
      { value: 'headache', label: 'Severe headache', feature: 'headache' },
      { value: 'vision', label: 'Blurred or double vision', feature: 'visionChanges' },
      { value: 'balance', label: 'Loss of balance or coordination', feature: 'imbalance' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'neuro_duration',
  },
  durationQuestion('neuro_duration', 'Neurological', 'How long has this been present?', 'safety_check'),
  {
    id: 'seizure_last', section: 'Neurological', type: 'single', short: 'Most recent seizure',
    text: 'When was the most recent fit or seizure?',
    options: [
      { value: 'today', label: 'Today, or within the last 24 hours', set: { seizureRecent: 1 } },
      { value: 'week', label: 'Within the past week' },
      { value: 'earlier', label: 'Earlier, with a known history of seizures' },
    ],
    next: 'seizure_first',
  },
  {
    id: 'seizure_first', section: 'Neurological', type: 'yesno', short: 'First seizure',
    text: 'Is this the first time you have had a seizure?', featureKey: 'firstSeizure',
    next: 'neuro_associated',
  },

  /* ----- Weakness / fatigue branch ----- */
  {
    id: 'weak_type', section: 'Weakness / fatigue', type: 'single', short: 'Type of weakness',
    text: 'What kind of weakness are you feeling?',
    options: [
      { value: 'general', label: 'General tiredness or low energy', set: { fatigue: 1 } },
      { value: 'one_side', label: 'Weakness in one arm, one leg or one side of the body', set: { limbWeakness: 1, focalOneSided: 1 } },
      { value: 'muscles', label: 'Muscle weakness in both arms or both legs', set: { weakness: 1, muscleWeakness: 1 } },
      { value: 'faint', label: 'Feeling faint or light-headed', set: { presyncope: 1, dizziness: 1 } },
    ],
    next: { one_side: 'neuro_sudden', default: 'weak_duration' },
  },
  durationQuestion('weak_duration', 'Weakness / fatigue', 'How long have you been feeling this way?', 'weak_associated'),
  {
    id: 'weak_associated', section: 'Weakness / fatigue', type: 'multi', short: 'Other symptoms',
    text: 'Do you have any of these as well?',
    options: [
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'weight', label: 'Weight loss without trying', feature: 'weightLoss' },
      { value: 'breathless', label: 'Breathless when walking', feature: 'exertionalBreathless' },
      { value: 'pale', label: 'Pale skin, or feeling cold', feature: 'pallor' },
      { value: 'appetite', label: 'Loss of appetite', feature: 'appetiteLoss' },
      { value: 'thirst', label: 'Excessive thirst, or passing urine often', feature: 'thirstUrination' },
      { value: 'sleep', label: 'Low mood or poor sleep', feature: 'lowMoodSleep' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'weak_impact',
  },
  {
    id: 'weak_impact', section: 'Weakness / fatigue', type: 'severity', short: 'Effect on daily activities',
    text: 'How much does it affect your daily activities?',
    options: SEVERITY_OPTIONS, featureKey: 'severity',
    next: 'safety_check',
  },

  /* ----- Other / unsure branch ----- */
  {
    id: 'other_area', section: 'Other / unsure', type: 'single', short: 'Most affected area',
    text: 'Which part of the body seems most affected?',
    helpText: 'If the patient can name one body system, the questions continue for that system. Choose "Whole body / not sure" if they cannot say.',
    options: [
      { value: 'chest', label: 'Chest or heart', set: { chestDiscomfort: 1 } },
      { value: 'breathing', label: 'Breathing or lungs', set: { breathingConcern: 1 } },
      { value: 'digestion', label: 'Stomach or digestion', set: { digestiveConcern: 1 } },
      { value: 'skin', label: 'Skin', set: { skinConcern: 1 } },
      { value: 'bones', label: 'Bones, joints or muscles', set: { mskConcern: 1 } },
      { value: 'nerves', label: 'Head, nerves or balance', set: { neuroConcern: 1 } },
      { value: 'heartbeat', label: 'Heartbeat: racing, pounding or irregular', set: { palpitations: 1 } },
      { value: 'general', label: 'Whole body (for example chills or bleeding)' },
      { value: 'whole', label: 'Whole body / not sure', unsure: true },
    ],
    next: {
      chest: 'chest_breathing', breathing: 'resp_cough', digestion: 'gi_main', skin: 'skin_type', bones: 'joint_site', nerves: 'neuro_main',
      heartbeat: 'palp_trigger', default: 'other_symptoms',
    },
  },
  {
    id: 'palp_trigger', section: 'Heartbeat', type: 'single', short: 'When it happens',
    text: 'When does the racing or pounding heartbeat happen?',
    options: [
      { value: 'rest', label: 'At rest, out of the blue' },
      { value: 'exertion', label: 'During physical effort', set: { exertionalSymptoms: 1 } },
      { value: 'random', label: 'It comes and goes with no clear trigger' },
    ],
    next: 'palp_associated',
  },
  {
    id: 'palp_associated', section: 'Heartbeat', type: 'multi', short: 'With the heartbeat',
    text: 'Do you have any of these along with it?',
    options: [
      { value: 'chest', label: 'Chest pain or discomfort', feature: 'chestDiscomfort' },
      { value: 'dizzy', label: 'Dizziness, or feeling faint', feature: 'dizziness', alsoSet: { presyncope: 1 } },
      { value: 'breathless', label: 'Breathless when walking', feature: 'exertionalBreathless' },
      { value: 'sweating', label: 'Unusual sweating', feature: 'sweating' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'palp_duration',
  },
  durationQuestion('palp_duration', 'Heartbeat', 'How long have you been noticing it?', 'safety_check'),
  {
    id: 'other_symptoms', section: 'Other / unsure', type: 'multi', short: 'Symptoms present',
    text: 'Which of these symptoms do you have?',
    options: [
      { value: 'fever', label: 'Fever', feature: 'fever' },
      { value: 'cough', label: 'Cough', feature: 'cough' },
      { value: 'stomach', label: 'Stomach pain or discomfort', feature: 'abdominalPain' },
      { value: 'rash', label: 'Rash or itching', feature: 'rash' },
      { value: 'aches', label: 'Joint or muscle aches', feature: 'bodyAches' },
      { value: 'headache', label: 'Headache', feature: 'headache' },
      { value: 'dizziness', label: 'Dizziness', feature: 'dizziness' },
      { value: 'tired', label: 'Tiredness', feature: 'fatigue' },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: 'other_duration',
  },
  durationQuestion('other_duration', 'Other / unsure', 'How long have you had these symptoms?', 'other_severity'),
  {
    id: 'other_severity', section: 'Other / unsure', type: 'severity', short: 'Overall severity',
    text: 'Overall, how severe are the symptoms?',
    options: SEVERITY_OPTIONS, featureKey: 'severity',
    next: 'safety_check',
  },

  /* ----- Warning-sign check (final question on every route) ----- */
  {
    id: 'safety_check', section: 'Warning signs', type: 'multi', short: 'Warning signs today',
    reconfirmOnRouteChange: true, // asked again whenever an earlier answer changes the route
    text: 'Before we finish: have you had any of these today?',
    helpText: 'Ask directly. Any warning sign prompts the hospital’s emergency / clinical triage protocol.',
    options: [
      { value: 'chest', label: 'Severe chest pain or pressure', feature: 'severeChestSign', alsoSet: { chestDiscomfort: 1 } },
      { value: 'faint', label: 'Fainting or loss of consciousness', feature: 'lossOfConsciousness' },
      { value: 'bleeding', label: 'Heavy or uncontrolled bleeding', feature: 'majorBleeding' },
      { value: 'one_side', label: 'Sudden weakness, numbness or drooping on one side', feature: 'suddenFocalSign', alsoSet: { focalOneSided: 1, suddenOnsetNeuro: 1 } },
      { value: 'speech', label: 'Sudden confusion or difficulty speaking', feature: 'suddenSpeechSign', alsoSet: { speechDifficulty: 1, suddenOnsetNeuro: 1 } },
      { value: 'breathing', label: 'Severe difficulty breathing', feature: 'severeBreathingSign', alsoSet: { breathingDifficulty: 3 } },
      { value: 'seizure', label: 'A fit or seizure', feature: 'seizureToday', alsoSet: { seizure: 1, seizureRecent: 1 } },
      { value: 'none', label: 'None of these', exclusive: true },
    ],
    next: null,
  },
]);

/* ---------------------------------------------------------------------
   BODY MAP — symptoms picked by clicking a part of the body
   ---------------------------------------------------------------------
   Each body-map symptom is written in plain words and linked to the
   decision tree: `complaint` is the main complaint it starts, `answers`
   are the questions it already answers, `features` are extra findings it
   records, and `pain` names the 0–10 question that takes its pain rating.
   `warning` marks symptoms that are warning signs in their own right, and
   `searchLabel` names an area-dependent symptom in search results.
   `perArea` symptoms mean different things in different places (pain in
   a knee or in a shoulder): their '@key' answers are filled in from the
   area's `context`. When several areas are picked, BODY_CONTEXT_RULES
   combine them (for example two different joints → "Several joints").
   --------------------------------------------------------------------- */

const BODY_SYMPTOMS = [
  /* Head, eyes, ears, mouth and face */
  { id: 'headache', label: 'Headache', hint: 'Pain anywhere in the head', complaint: 'neuro', answers: { neuro_main: 'headache' },
    pain: { question: 'head_score', scale: 'head' }, keywords: 'head pain migraine' },
  { id: 'dizziness', label: 'Dizziness', hint: 'Light-headed, unsteady or woozy', complaint: 'dizziness', features: { dizziness: 1 },
    keywords: 'dizzy giddy woozy' },
  { id: 'spinning', label: 'Room spinning (vertigo)', hint: 'Feels as if you or the room is moving', complaint: 'dizziness',
    answers: { dizzy_type: 'spinning' }, features: { dizziness: 1 }, keywords: 'vertigo spin spinning' },
  { id: 'faint_feeling', label: 'Feeling faint', hint: 'Light-headed, as if about to pass out', complaint: 'dizziness',
    answers: { dizzy_type: 'faint' }, features: { dizziness: 1 }, keywords: 'faint lightheaded light-headed pass out' },
  { id: 'fainted', label: 'Fainted or passed out', hint: 'Lost consciousness, even briefly', warning: true, complaint: 'dizziness',
    answers: { dizzy_type: 'faint', dizzy_fainted: 'yes' }, keywords: 'blackout fainted collapse unconscious' },
  { id: 'confusion', label: 'Confusion or memory problems', hint: 'Muddled, forgetful or not making sense', complaint: 'neuro',
    answers: { neuro_main: 'confusion' }, keywords: 'memory forgetful confused' },
  { id: 'seizure', label: 'Fit or seizure', hint: 'Uncontrolled shaking, or a blank spell', complaint: 'neuro',
    answers: { neuro_main: 'seizure' }, keywords: 'fit fits convulsion epilepsy seizure' },
  { id: 'balance', label: 'Loss of balance', hint: 'Unsteady on the feet or clumsy', complaint: 'neuro',
    answers: { neuro_main: 'balance' }, keywords: 'unsteady coordination balance' },
  { id: 'vision', label: 'Blurred or double vision', hint: 'Or any other change in eyesight', complaint: 'neuro',
    answers: { neuro_main: 'vision' }, keywords: 'eye eyes sight blurry vision' },
  { id: 'ear_pain', label: 'Earache', hint: 'Pain in or around the ear', complaint: 'pain', answers: { pain_location: 'other', pain_other_area: 'ear' },
    pain: { question: 'other_pain_score', scale: 'ear' }, keywords: 'ear pain earache' },
  { id: 'ringing', label: 'Ringing in the ears or hearing change', complaint: 'other', answers: { other_area: 'nerves' },
    features: { tinnitus: 1 }, keywords: 'tinnitus hearing deaf ringing ears' },
  { id: 'sore_throat', label: 'Sore throat', hint: 'Painful or scratchy, worse when swallowing', complaint: 'pain',
    answers: { pain_location: 'other', pain_other_area: 'throat' }, pain: { question: 'other_pain_score', scale: 'throat' },
    keywords: 'throat swallow tonsils' },
  { id: 'toothache', label: 'Toothache or jaw pain', complaint: 'pain', answers: { pain_location: 'other', pain_other_area: 'teeth' },
    pain: { question: 'other_pain_score', scale: 'teeth' }, keywords: 'tooth teeth dental jaw gums' },
  { id: 'face_droop', label: 'One side of the face drooping', warning: true, complaint: 'neuro',
    answers: { neuro_main: 'weakness', neuro_area: 'one_side' }, features: { faceDroop: 1 }, keywords: 'droop drooping stroke face' },
  { id: 'speech', label: 'Slurred speech or trouble speaking', warning: true, complaint: 'neuro',
    features: { speechDifficulty: 1 }, keywords: 'speech slurred talking words stroke' },
  { id: 'face_swelling', label: 'Swollen lips, face or tongue', warning: true, complaint: 'skin',
    features: { facialSwelling: 1 }, keywords: 'swelling swollen lips tongue allergy' },

  /* Neck and back */
  { id: 'back_pain', label: 'Pain', searchLabel: 'Back or neck pain', complaint: 'pain', perArea: 'back_area', answers: { pain_location: 'back', back_area: '@back_area' },
    pain: { question: 'back_score', scale: 'back' }, keywords: 'back pain backache neck pain' },
  { id: 'stiff_neck', label: 'Stiff neck', searchLabel: 'Stiff neck', hint: 'Hard or painful to bend the head forward', complaint: 'pain', perArea: 'back_area',
    answers: { pain_location: 'back', back_area: '@back_area' }, features: { stiffNeck: 1 }, keywords: 'stiff neck' },
  { id: 'sciatica_pain', label: 'Pain shooting down a leg', searchLabel: 'Pain shooting down a leg', hint: 'From the back or buttock into the leg', complaint: 'pain', perArea: 'back_area',
    answers: { pain_location: 'back', back_area: '@back_area', back_radiation: 'yes' }, pain: { question: 'back_score', scale: 'back' },
    keywords: 'sciatica shooting nerve leg' },
  { id: 'bladder_loss', label: 'New loss of bladder or bowel control', searchLabel: 'Loss of bladder or bowel control', warning: true, complaint: 'pain', perArea: 'back_area',
    answers: { pain_location: 'back', back_area: '@back_area', back_bladder: 'yes' }, keywords: 'bladder bowel incontinence leaking' },

  /* Chest */
  { id: 'chest_pain', label: 'Chest pain or pressure', hint: 'Including tightness or heaviness', complaint: 'pain', answers: { pain_location: 'chest' },
    pain: { question: 'chest_score', scale: 'chest' }, keywords: 'chest heart pressure heaviness' },
  { id: 'palpitations', label: 'Racing or pounding heartbeat', hint: 'Fast, irregular or skipping beats', complaint: 'other',
    answers: { other_area: 'heartbeat' }, features: { palpitations: 1 }, keywords: 'heart heartbeat palpitations racing pounding fluttering' },
  { id: 'breathless', label: 'Short of breath', hint: 'Hard to catch your breath', complaint: 'respiratory',
    features: { breathingConcern: 1 }, keywords: 'breath breathing breathless breathlessness' },
  { id: 'cough', label: 'Cough', complaint: 'respiratory', answers: { resp_cough: 'yes' }, keywords: 'cough coughing phlegm' },
  { id: 'cough_blood', label: 'Coughing up blood', hint: 'The department should see the patient promptly', complaint: 'respiratory',
    answers: { resp_cough: 'yes', resp_cough_type: 'blood' }, keywords: 'blood cough' },
  { id: 'wheezing', label: 'Wheezing', hint: 'A whistling sound when breathing', complaint: 'respiratory', answers: { resp_wheeze: 'yes' },
    keywords: 'wheeze whistling asthma' },
  { id: 'chest_tight', label: 'Tight chest when breathing', hint: 'Or pain when breathing in', complaint: 'respiratory', answers: { resp_chest: 'yes' },
    keywords: 'tight tightness breathing' },

  /* Abdomen (belly) and pelvis */
  { id: 'stomach_pain', label: 'Stomach pain', searchLabel: 'Stomach pain', hint: 'Pain or cramps in this part of the belly', complaint: 'digestive', perArea: 'abd_location',
    answers: { gi_main: 'pain', abd_location: '@abd_location' }, pain: { question: 'abd_score', scale: 'abdomen' },
    keywords: 'stomach belly abdomen abdominal tummy cramps' },
  { id: 'nausea', label: 'Nausea or vomiting', hint: 'Feeling sick, or throwing up', complaint: 'digestive', answers: { gi_main: 'vomiting' },
    keywords: 'vomit vomiting sick throwing up nausea' },
  { id: 'diarrhoea', label: 'Loose motions (diarrhoea)', complaint: 'digestive', answers: { gi_main: 'diarrhoea' },
    keywords: 'diarrhea diarrhoea loose stools motions' },
  { id: 'constipation', label: 'Constipation or bloating', hint: 'Hard to pass stool, or a swollen, gassy belly', complaint: 'digestive',
    answers: { gi_main: 'constipation' }, keywords: 'constipated bloating bloated gas' },
  { id: 'acidity', label: 'Heartburn or acidity', hint: 'Burning behind the breastbone, sour burps', complaint: 'digestive',
    answers: { gi_main: 'acidity' }, keywords: 'acid reflux heartburn burping indigestion gastric' },
  { id: 'gi_blood', label: 'Blood in stool or vomit', hint: 'The department should see the patient promptly', complaint: 'digestive', answers: { gi_main: 'blood' },
    keywords: 'blood stool vomit black' },
  { id: 'pelvic_pain', label: 'Pelvic or groin pain', complaint: 'pain', answers: { pain_location: 'other', pain_other_area: 'pelvis' },
    pain: { question: 'other_pain_score', scale: 'pelvis' }, keywords: 'pelvis pelvic groin hernia' },
  { id: 'urine_burning', label: 'Burning or pain when passing urine', complaint: 'pain', answers: { pain_location: 'other', pain_other_area: 'urine' },
    pain: { question: 'other_pain_score', scale: 'urine' }, keywords: 'urine urinary pee burning bladder' },

  /* Arms and legs */
  { id: 'limb_pain', label: 'Pain', searchLabel: 'Joint or limb pain', complaint: 'joint_limb', perArea: 'joint_site', answers: { joint_site: '@joint_site' },
    features: { jointLimbPain: 1 }, pain: { question: 'joint_score', scale: 'joint' }, keywords: 'joint pain ache sore' },
  { id: 'limb_swelling', label: 'Swelling', searchLabel: 'Swelling of a joint or limb', complaint: 'joint_limb', perArea: 'joint_site', answers: { joint_site: '@joint_site', joint_swelling: 'yes' },
    keywords: 'swelling swollen' },
  { id: 'limb_injury', label: 'Injury, fall or twist', searchLabel: 'Injury, fall or twist', complaint: 'joint_limb', perArea: 'joint_site', answers: { joint_site: '@joint_site', joint_injury: 'yes' },
    keywords: 'injury injured fall twisted twist sprain sprained hurt' },
  { id: 'limb_stiff', label: 'Stiff or hard to move', searchLabel: 'Stiff joint', complaint: 'joint_limb', perArea: 'joint_site', answers: { joint_site: '@joint_site', joint_movement: 'yes' },
    keywords: 'stiff stiffness' },
  { id: 'limb_red_warm', label: 'Red or warm to touch', searchLabel: 'Red or warm joint', complaint: 'joint_limb', perArea: 'joint_site', answers: { joint_site: '@joint_site' },
    features: { jointRedWarm: 1 }, keywords: 'red warm hot joint' },
  { id: 'limb_numb', label: 'Numbness or tingling', searchLabel: 'Numbness or tingling', hint: 'Pins and needles, or less feeling', complaint: 'neuro', perArea: 'neuro_area',
    answers: { neuro_main: 'numbness', neuro_area: '@neuro_area' }, keywords: 'numb numbness tingling pins needles' },
  { id: 'limb_weak', label: 'Weakness', searchLabel: 'Weakness in an arm or leg', hint: 'Hard to grip, lift or stand on it', complaint: 'neuro', perArea: 'neuro_area',
    answers: { neuro_main: 'weakness', neuro_area: '@neuro_area' }, keywords: 'weak weakness' },

  /* Skin */
  { id: 'skin_here', label: 'Rash, itching or skin change', searchLabel: 'Rash or skin change in one place', complaint: 'skin', perArea: 'skin_area', answers: { skin_area: '@skin_area' },
    features: { skinConcern: 1 }, keywords: 'rash itch itching skin spots' },
  { id: 'rash', label: 'Rash or red patches', complaint: 'skin', answers: { skin_type: 'rash' }, keywords: 'rash red spots patches' },
  { id: 'hives', label: 'Itchy bumps or hives', complaint: 'skin', answers: { skin_type: 'hives' }, keywords: 'hives welts bumps allergy' },
  { id: 'itching', label: 'Itching', complaint: 'skin', answers: { skin_itching: 'yes' }, keywords: 'itch itchy scratching' },
  { id: 'blisters', label: 'Blisters', hint: 'Small bubbles filled with fluid', complaint: 'skin', answers: { skin_type: 'blisters' },
    keywords: 'blister blisters bubbles' },
  { id: 'scaly', label: 'Dry, scaly or flaky skin', complaint: 'skin', answers: { skin_type: 'scaly' }, keywords: 'dry flaky scaly' },
  { id: 'acne', label: 'Acne or pimples', complaint: 'skin', answers: { skin_type: 'acne' }, keywords: 'pimples spots acne' },
  { id: 'wound', label: 'Wound, boil or infected area', complaint: 'skin', answers: { skin_type: 'wound' },
    keywords: 'wound cut boil abscess pus infected' },
  { id: 'pigment', label: 'Change in skin colour, a patch or a mole', complaint: 'skin', answers: { skin_type: 'pigment' },
    keywords: 'mole colour color patch white dark' },
  { id: 'hair_nail', label: 'Hair or nail problem', complaint: 'skin', answers: { skin_type: 'hair_nail' }, keywords: 'hair loss nails dandruff' },

  /* Whole body */
  { id: 'fever', label: 'Fever', hint: 'Feeling hot, or 100.4 °F (38 °C) or higher', complaint: 'fever', features: { fever: 1 },
    keywords: 'fever temperature hot feverish' },
  { id: 'chills', label: 'Chills or shivering', hint: 'Tick Fever as well if there is a fever', complaint: 'other',
    answers: { other_area: 'general' }, features: { chills: 1 }, keywords: 'shivering chills shaking cold' },
  { id: 'tiredness', label: 'Tiredness or low energy', complaint: 'weakness', answers: { weak_type: 'general' },
    keywords: 'tired fatigue exhausted energy' },
  { id: 'muscle_weakness', label: 'Weakness in both arms or both legs', complaint: 'weakness', answers: { weak_type: 'muscles' },
    keywords: 'weak muscles weakness' },
  { id: 'body_aches', label: 'Body aches all over', complaint: 'pain', answers: { pain_location: 'other', pain_other_area: 'all_over' },
    pain: { question: 'other_pain_score', scale: 'body' }, keywords: 'aches aching body pain muscles' },
  { id: 'weight_loss', label: 'Losing weight without trying', complaint: 'weakness', features: { weightLoss: 1 }, keywords: 'weight loss thin' },
  { id: 'appetite_loss', label: 'Loss of appetite', complaint: 'weakness', features: { appetiteLoss: 1 }, keywords: 'appetite hunger eating' },
  { id: 'thirst', label: 'Very thirsty or passing urine often', complaint: 'weakness', features: { thirstUrination: 1 },
    keywords: 'thirst thirsty urine often' },
  { id: 'pale', label: 'Pale skin, or always feeling cold', complaint: 'weakness', features: { pallor: 1 }, keywords: 'pale cold' },
  { id: 'low_mood', label: 'Low mood or poor sleep', complaint: 'weakness', features: { lowMoodSleep: 1 },
    keywords: 'sleep insomnia stress anxiety mood sad' },
  { id: 'bleeding', label: 'Heavy bleeding that will not stop', warning: true, complaint: 'other',
    answers: { other_area: 'general' }, features: { majorBleeding: 1 }, keywords: 'bleeding blood bleed' },
  { id: 'unwell', label: 'Feeling unwell, not sure why', complaint: 'other', answers: { other_area: 'whole' }, keywords: 'unwell sick ill not sure' },
];

const BODY_SYMPTOM_INDEX = Object.fromEntries(BODY_SYMPTOMS.map((symptom) => [symptom.id, symptom]));

/* Findings behind warning signs. When the body map reports one of these,
   it counts even if a questionnaire answer said "no" (for example a
   warning-sign check answered before the pick was added): staff confirm
   or remove the pick rather than the system silently dropping it. */
const BODY_WARNING_FEATURES = new Set([
  'lossOfConsciousness', 'majorBleeding', 'facialSwelling', 'allergyBreathing', 'speechDifficulty', 'faceDroop', 'focalOneSided',
  'bladderBowelLoss', 'coughBlood', 'giBlood', 'stiffNeck',
]);

/* How several picked areas combine for a perArea answer. `min` distinct
   values give `multi` (otherwise each area keeps its own value, and the
   main problem's value is used). neuro_area is worked out from the limbs
   and sides instead (one limb, one side of the body, or both sides). */
const BODY_CONTEXT_RULES = {
  joint_site: { min: 2, multi: 'multiple' },
  abd_location: { min: 3, multi: 'all_over' },
  skin_area: { min: 2, multi: 'widespread' },
  back_area: { min: 2, multi: 'whole' },
};

const LIMB_SYMPTOMS = ['limb_pain', 'limb_swelling', 'limb_injury', 'limb_stiff', 'limb_red_warm', 'limb_numb', 'limb_weak', 'skin_here'];
const BELLY_UPPER_SYMPTOMS = ['stomach_pain', 'nausea', 'acidity', 'diarrhoea', 'constipation', 'gi_blood', 'skin_here'];
const BELLY_LOWER_SYMPTOMS = ['stomach_pain', 'nausea', 'diarrhoea', 'constipation', 'gi_blood', 'skin_here'];

function limbAreas(side) {
  const Side = side === 'right' ? 'Right' : 'Left';
  const s = side === 'right' ? 'r' : 'l';
  const area = (id, label, limb, joint, skin) => ({
    id: `${id}_${s}`, label: `${Side} ${label}`, side, limb, context: { joint_site: joint, skin_area: skin }, symptoms: LIMB_SYMPTOMS,
  });
  return [
    area('shoulder', 'shoulder', 'arm', 'shoulder', 'arms'),
    area('upper_arm', 'upper arm', 'arm', 'shoulder', 'arms'),
    area('forearm', 'elbow and forearm', 'arm', 'arm', 'arms'),
    area('hand', 'wrist and hand', 'arm', 'arm', 'arms'),
    area('thigh', 'hip and thigh', 'leg', 'hip', 'legs'),
    area('knee', 'knee', 'leg', 'knee', 'legs'),
    area('lower_leg', 'calf and shin', 'leg', 'lower_leg', 'legs'),
    area('foot', 'ankle and foot', 'leg', 'ankle', 'legs'),
  ];
}

/* Body areas. `groups` split a long symptom list under small headings. */
const BODY_AREAS = [
  { id: 'head', label: 'Head and face', context: { skin_area: 'face' }, groups: [
    { label: 'Head', symptoms: ['headache', 'dizziness', 'spinning', 'faint_feeling', 'fainted', 'confusion', 'seizure', 'balance'] },
    { label: 'Eyes and ears', symptoms: ['vision', 'ear_pain', 'ringing'] },
    { label: 'Mouth and throat', symptoms: ['sore_throat', 'toothache'] },
    { label: 'Face and speech', symptoms: ['face_droop', 'speech', 'face_swelling', 'skin_here'] },
  ] },
  { id: 'neck', label: 'Neck', context: { back_area: 'neck' }, symptoms: ['back_pain', 'stiff_neck', 'sore_throat'] },
  { id: 'chest', label: 'Chest', context: { skin_area: 'trunk' },
    symptoms: ['chest_pain', 'palpitations', 'breathless', 'cough', 'cough_blood', 'wheezing', 'chest_tight', 'acidity', 'skin_here'] },
  { id: 'abd_ur', label: 'Upper right belly', group: 'Abdomen', context: { abd_location: 'upper_right', skin_area: 'trunk' }, symptoms: BELLY_UPPER_SYMPTOMS },
  { id: 'abd_um', label: 'Upper middle belly', group: 'Abdomen', context: { abd_location: 'upper_middle', skin_area: 'trunk' }, symptoms: BELLY_UPPER_SYMPTOMS },
  { id: 'abd_ul', label: 'Upper left belly', group: 'Abdomen', context: { abd_location: 'upper_left', skin_area: 'trunk' }, symptoms: BELLY_UPPER_SYMPTOMS },
  { id: 'abd_lr', label: 'Lower right belly', group: 'Abdomen', context: { abd_location: 'lower_right', skin_area: 'trunk' }, symptoms: BELLY_LOWER_SYMPTOMS },
  { id: 'abd_lm', label: 'Lower belly, around the navel', group: 'Abdomen', context: { abd_location: 'lower', skin_area: 'trunk' }, symptoms: BELLY_LOWER_SYMPTOMS },
  { id: 'abd_ll', label: 'Lower left belly', group: 'Abdomen', context: { abd_location: 'lower', skin_area: 'trunk' }, symptoms: BELLY_LOWER_SYMPTOMS },
  { id: 'pelvis', label: 'Pelvis and groin', symptoms: ['pelvic_pain', 'urine_burning'] },
  ...limbAreas('right'),
  ...limbAreas('left'),
  { id: 'upper_back', label: 'Upper back', context: { back_area: 'upper', skin_area: 'trunk' }, symptoms: ['back_pain', 'skin_here'] },
  { id: 'lower_back', label: 'Lower back', context: { back_area: 'lower', skin_area: 'trunk' }, symptoms: ['back_pain', 'sciatica_pain', 'bladder_loss', 'skin_here'] },
  { id: 'buttocks', label: 'Buttocks', context: { back_area: 'lower' }, symptoms: ['back_pain', 'sciatica_pain'] },
  { id: 'skin', label: 'Skin', lead: 'Skin problems anywhere on the body.', button: 'Rash, itching, spots', symptoms: ['rash', 'hives', 'itching', 'blisters', 'scaly', 'acne', 'wound', 'pigment', 'hair_nail'] },
  { id: 'general', label: 'Whole body', lead: 'Symptoms that are not in one place.', button: 'Fever, tiredness, aches',
    symptoms: ['fever', 'chills', 'tiredness', 'muscle_weakness', 'faint_feeling', 'body_aches', 'weight_loss', 'appetite_loss', 'thirst', 'pale', 'low_mood', 'bleeding', 'unwell'] },
];

const BODY_AREA_INDEX = Object.fromEntries(BODY_AREAS.map((area) => [area.id, area]));

/* ---------------------------------------------------------------------
   FEATURE_SCHEMA — fixed feature order used by the prediction engine.
   A production model must be trained on exactly this order.
   type: binary (0/1) | ordinal | numeric. Ordinal and numeric features
   are min–max normalised to 0–1 during preprocessing. `internal`
   features are model inputs that are not shown as symptoms.
   --------------------------------------------------------------------- */

const FEATURE_SCHEMA_VERSION = 'sdp-features-v3';

const FEATURE_SCHEMA = [
  { key: 'age', type: 'numeric', min: 0, max: 100, internal: true },
  { key: 'ageOver45', type: 'binary', internal: true },
  { key: 'ageUnder30', type: 'binary', internal: true },
  { key: 'ageOver65', type: 'binary', internal: true },
  { key: 'ageUnder16', type: 'binary', internal: true },
  { key: 'genderFemale', type: 'binary', internal: true },
  { key: 'genderMale', type: 'binary', internal: true },
  { key: 'genderOther', type: 'binary', internal: true },
  ...COMPLAINTS.map((c) => ({ key: `complaint_${c.id}`, type: 'binary', internal: true })),

  { key: 'chestPain', type: 'binary' },
  { key: 'headache', type: 'binary' },
  { key: 'abdominalPain', type: 'binary' },
  { key: 'jointLimbPain', type: 'binary' },
  { key: 'backPain', type: 'binary' },
  { key: 'otherPain', type: 'binary' },
  { key: 'painScore', type: 'ordinal', min: 0, max: 10 },
  { key: 'chestPainScore', type: 'ordinal', min: 0, max: 10, internal: true },
  { key: 'severeOtherPain', type: 'binary', internal: true },
  { key: 'severity', type: 'ordinal', min: 0, max: 3 },
  { key: 'breathingDifficulty', type: 'ordinal', min: 0, max: 3 },
  { key: 'durationBand', type: 'ordinal', min: 0, max: 5 },
  { key: 'durationShort', type: 'binary', internal: true },
  { key: 'durationOver3Days', type: 'binary', internal: true },
  { key: 'durationOverWeek', type: 'binary', internal: true },
  { key: 'durationOverMonth', type: 'binary', internal: true },
  { key: 'acuteOnset', type: 'binary' },

  { key: 'sweating', type: 'binary' },
  { key: 'radiatingChestPain', type: 'binary' },
  { key: 'exertionalSymptoms', type: 'binary' },
  { key: 'palpitations', type: 'binary' },
  { key: 'presyncope', type: 'binary' },
  { key: 'lossOfConsciousness', type: 'binary' },
  { key: 'exertionalBreathless', type: 'binary' },
  { key: 'chestDiscomfort', type: 'binary' },
  { key: 'pleuriticPain', type: 'binary' },
  { key: 'postprandialPain', type: 'binary' },
  { key: 'chestWallTenderness', type: 'binary' },

  { key: 'cough', type: 'binary' },
  { key: 'coughDry', type: 'binary' },
  { key: 'coughProductive', type: 'binary' },
  { key: 'coughBlood', type: 'binary' },
  { key: 'wheezing', type: 'binary' },
  { key: 'chestTightness', type: 'binary' },
  { key: 'respiratoryHistory', type: 'binary' },
  { key: 'smoker', type: 'binary' },
  { key: 'exposure', type: 'binary' },
  { key: 'sickContact', type: 'binary' },
  { key: 'breathingConcern', type: 'binary', internal: true },

  { key: 'fever', type: 'binary' },
  { key: 'temperatureC', type: 'numeric', min: 35, max: 42 },
  { key: 'highFever', type: 'binary' },
  { key: 'chills', type: 'binary' },
  { key: 'soreThroat', type: 'binary' },
  { key: 'bodyAches', type: 'binary' },
  { key: 'urinarySymptoms', type: 'binary' },
  { key: 'dentalEarThroat', type: 'binary' },
  { key: 'earPain', type: 'binary', internal: true },
  { key: 'toothPain', type: 'binary', internal: true },
  { key: 'pelvicPain', type: 'binary' },
  { key: 'fatigue', type: 'binary' },
  { key: 'weakness', type: 'binary' },
  { key: 'muscleWeakness', type: 'binary' },
  { key: 'weightLoss', type: 'binary' },
  { key: 'appetiteLoss', type: 'binary' },
  { key: 'pallor', type: 'binary' },
  { key: 'thirstUrination', type: 'binary' },
  { key: 'lowMoodSleep', type: 'binary' },

  { key: 'rash', type: 'binary' },
  { key: 'hives', type: 'binary' },
  { key: 'itching', type: 'binary' },
  { key: 'redness', type: 'binary' },
  { key: 'skinSpreading', type: 'binary' },
  { key: 'skinBlisters', type: 'binary' },
  { key: 'skinScaly', type: 'binary' },
  { key: 'skinAcne', type: 'binary' },
  { key: 'skinWound', type: 'binary' },
  { key: 'skinPigment', type: 'binary' },
  { key: 'hairNail', type: 'binary' },
  { key: 'skinWidespread', type: 'binary' },
  { key: 'skinPainBurning', type: 'binary' },
  { key: 'skinDischarge', type: 'binary' },
  { key: 'facialSwelling', type: 'binary' },
  { key: 'allergyBreathing', type: 'binary' },
  { key: 'skinConcern', type: 'binary', internal: true },

  { key: 'dizziness', type: 'binary' },
  { key: 'vertigo', type: 'binary' },
  { key: 'imbalance', type: 'binary' },
  { key: 'orthostaticDizziness', type: 'binary' },
  { key: 'positionalDizziness', type: 'binary' },
  { key: 'constantDizziness', type: 'binary' },
  { key: 'tinnitus', type: 'binary' },
  { key: 'suddenSevereHeadache', type: 'binary' },
  { key: 'throbbingHeadache', type: 'binary' },
  { key: 'tensionHeadache', type: 'binary' },
  { key: 'dullHeadache', type: 'binary', internal: true },
  { key: 'sharpHeadache', type: 'binary', internal: true },
  { key: 'photophobia', type: 'binary' },
  { key: 'visionChanges', type: 'binary' },
  { key: 'recurrentHeadache', type: 'binary' },
  { key: 'firstHeadache', type: 'binary', internal: true },
  { key: 'numbness', type: 'binary' },
  { key: 'focalOneSided', type: 'binary' },
  { key: 'limbWeakness', type: 'binary' },
  { key: 'singleLimb', type: 'binary' },
  { key: 'peripheralSymptoms', type: 'binary' },
  { key: 'suddenOnsetNeuro', type: 'binary' },
  { key: 'speechDifficulty', type: 'binary' },
  { key: 'faceDroop', type: 'binary' },
  { key: 'confusion', type: 'binary' },
  { key: 'seizure', type: 'binary' },
  { key: 'seizureRecent', type: 'binary' },
  { key: 'firstSeizure', type: 'binary' },
  { key: 'stiffNeck', type: 'binary' },
  { key: 'neuroConcern', type: 'binary', internal: true },

  { key: 'nauseaVomiting', type: 'binary' },
  { key: 'frequentVomiting', type: 'binary' },
  { key: 'diarrhoea', type: 'binary' },
  { key: 'frequentDiarrhoea', type: 'binary' },
  { key: 'constipation', type: 'binary' },
  { key: 'bloating', type: 'binary' },
  { key: 'acidity', type: 'binary' },
  { key: 'giBlood', type: 'binary' },
  { key: 'giBloodSmall', type: 'binary' },
  { key: 'giBloodLarge', type: 'binary' },
  { key: 'upperAbdominal', type: 'binary' },
  { key: 'rightUpperAbdominal', type: 'binary' },
  { key: 'rightLowerAbdominal', type: 'binary' },
  { key: 'lowerAbdominal', type: 'binary' },
  { key: 'diffuseAbdominal', type: 'binary' },
  { key: 'mealRelated', type: 'binary' },
  { key: 'emptyStomachPain', type: 'binary', internal: true },
  { key: 'digestiveConcern', type: 'binary', internal: true },

  { key: 'jointSwelling', type: 'binary' },
  { key: 'injury', type: 'binary' },
  { key: 'suspectedFracture', type: 'binary' },
  { key: 'restrictedMovement', type: 'binary' },
  { key: 'multipleJoints', type: 'binary' },
  { key: 'jointRedWarm', type: 'binary' },
  { key: 'morningStiffness', type: 'binary' },
  { key: 'lowerLimb', type: 'binary', internal: true },
  { key: 'neckPain', type: 'binary', internal: true },
  { key: 'lowBackPain', type: 'binary', internal: true },
  { key: 'radiatingLimbPain', type: 'binary' },
  { key: 'bladderBowelLoss', type: 'binary' },
  { key: 'mskConcern', type: 'binary', internal: true },

  { key: 'majorBleeding', type: 'binary' },
  { key: 'severeChestSign', type: 'binary', internal: true },
  { key: 'suddenFocalSign', type: 'binary', internal: true },
  { key: 'suddenSpeechSign', type: 'binary', internal: true },
  { key: 'severeBreathingSign', type: 'binary', internal: true },
  { key: 'seizureToday', type: 'binary', internal: true },
];

const FEATURE_ORDER = FEATURE_SCHEMA.map((def) => def.key);
const FEATURE_INDEX = Object.fromEntries(FEATURE_SCHEMA.map((def) => [def.key, def]));

/* Readable labels for features (used in summaries, transparency and reports). */
const SYMPTOM_LABELS = {
  age: 'Age', ageOver45: 'Age 45 or over', ageUnder30: 'Age under 30', ageOver65: 'Age 65 or over', ageUnder16: 'Age under 16', genderFemale: 'Gender: female', genderMale: 'Gender: male', genderOther: 'Gender: other',
  complaint_pain: 'Complaint: pain', complaint_fever: 'Complaint: fever', complaint_respiratory: 'Complaint: cough / respiratory',
  complaint_skin: 'Complaint: skin', complaint_dizziness: 'Complaint: dizziness', complaint_digestive: 'Complaint: digestive',
  complaint_joint_limb: 'Complaint: joint / limb pain', complaint_neuro: 'Complaint: headache / neurological',
  complaint_weakness: 'Complaint: weakness / fatigue', complaint_other: 'Complaint: other / unsure',
  chestPain: 'Chest pain', headache: 'Headache', abdominalPain: 'Abdominal pain', jointLimbPain: 'Joint or limb pain',
  backPain: 'Back or neck pain', otherPain: 'Pain in another area', painScore: 'Pain score', severity: 'Overall severity',
  chestPainScore: 'Chest pain score', severeOtherPain: 'Severe pain (7 or more) in another body area',
  breathingDifficulty: 'Difficulty breathing', durationBand: 'Duration', acuteOnset: 'Started today',
  durationShort: 'Present for 3 days or less', durationOver3Days: 'Present for more than 3 days',
  durationOverWeek: 'Present for more than a week', durationOverMonth: 'Present for more than a month',
  sweating: 'Unusual sweating', radiatingChestPain: 'Pain spreading to arm, jaw, neck or back', exertionalSymptoms: 'Worse with physical effort',
  palpitations: 'Racing or irregular heartbeat', presyncope: 'Feeling about to faint', lossOfConsciousness: 'Fainting or loss of consciousness',
  exertionalBreathless: 'Breathless when walking', chestDiscomfort: 'Chest discomfort', pleuriticPain: 'Pain worse on breathing in or coughing',
  postprandialPain: 'Worse after meals or lying down', chestWallTenderness: 'Pain on pressing the chest',
  cough: 'Cough', coughDry: 'Dry cough', coughProductive: 'Cough with phlegm', coughBlood: 'Blood in cough', wheezing: 'Wheezing',
  chestTightness: 'Chest tightness when breathing', respiratoryHistory: 'Known asthma or COPD', smoker: 'Smoker',
  exposure: 'Exposure to dust, smoke or fumes', sickContact: 'Contact with someone similarly unwell', breathingConcern: 'Breathing concern',
  fever: 'Fever', temperatureC: 'Recorded temperature', highFever: 'High temperature recorded', chills: 'Chills or shivering',
  soreThroat: 'Sore throat', bodyAches: 'Body or joint aches', urinarySymptoms: 'Burning or pain while passing urine',
  dentalEarThroat: 'Throat, ear or tooth pain', earPain: 'Ear pain', toothPain: 'Tooth or jaw pain', pelvicPain: 'Pelvic or groin pain', fatigue: 'Tiredness or low energy',
  weakness: 'Unusual weakness', muscleWeakness: 'Muscle weakness in both arms or legs', weightLoss: 'Unintentional weight loss',
  appetiteLoss: 'Loss of appetite', pallor: 'Pale skin or feeling cold', thirstUrination: 'Excessive thirst or frequent urination',
  lowMoodSleep: 'Low mood or poor sleep',
  rash: 'Rash', hives: 'Hives or itchy bumps', itching: 'Itching', redness: 'Redness', skinSpreading: 'Affected area spreading',
  skinBlisters: 'Blisters', skinScaly: 'Dry or scaly skin', skinAcne: 'Acne or pimples', skinWound: 'Wound, boil or infected area',
  skinPigment: 'Change in skin colour', hairNail: 'Hair or nail problem', skinWidespread: 'Widespread skin involvement',
  skinPainBurning: 'Skin pain or burning', skinDischarge: 'Discharge or pus', facialSwelling: 'Swelling of lips, face or tongue',
  allergyBreathing: 'Difficulty breathing with skin symptoms', skinConcern: 'Skin concern',
  dizziness: 'Dizziness or light-headedness', vertigo: 'Spinning sensation (vertigo)', imbalance: 'Loss of balance or coordination',
  orthostaticDizziness: 'Dizzy on standing up', positionalDizziness: 'Dizzy on moving the head', constantDizziness: 'Constant dizziness',
  tinnitus: 'Ringing in the ears or hearing change', suddenSevereHeadache: 'Sudden, very severe headache',
  throbbingHeadache: 'Throbbing headache', tensionHeadache: 'Band-like pressure headache',
  dullHeadache: 'Dull, constant headache', sharpHeadache: 'Sharp or stabbing headache', photophobia: 'Sensitivity to light or sound',
  visionChanges: 'Vision changes', recurrentHeadache: 'Recurring headaches', firstHeadache: 'First headache of this kind', numbness: 'Numbness or tingling',
  focalOneSided: 'Symptoms on one side of the body', limbWeakness: 'Weakness in an arm or leg', singleLimb: 'One arm or leg affected',
  peripheralSymptoms: 'Both hands or feet affected', suddenOnsetNeuro: 'Sudden onset', speechDifficulty: 'Difficulty speaking',
  faceDroop: 'Drooping of one side of the face', confusion: 'Confusion or memory problems', seizure: 'Fits or seizures',
  seizureRecent: 'Seizure in the last 24 hours', firstSeizure: 'First seizure', stiffNeck: 'Stiff neck', neuroConcern: 'Head, nerve or balance concern',
  nauseaVomiting: 'Nausea or vomiting', frequentVomiting: 'Frequent vomiting', diarrhoea: 'Loose motions',
  frequentDiarrhoea: 'More than 6 loose motions a day', constipation: 'Constipation', bloating: 'Bloating or gas',
  acidity: 'Acidity or heartburn', giBlood: 'Blood in stool or vomit', giBloodSmall: 'Small amount of blood',
  giBloodLarge: 'Large amount of blood', upperAbdominal: 'Upper abdominal pain', rightUpperAbdominal: 'Upper-right abdominal pain',
  rightLowerAbdominal: 'Lower-right abdominal pain', lowerAbdominal: 'Lower abdominal pain', diffuseAbdominal: 'Pain all over the abdomen',
  mealRelated: 'Related to meals', emptyStomachPain: 'Eased by food or worse on an empty stomach', digestiveConcern: 'Digestive concern',
  jointSwelling: 'Swelling', injury: 'Injury, fall or accident', suspectedFracture: 'Deformity, or unable to move or bear weight',
  restrictedMovement: 'Restricted movement', multipleJoints: 'Several joints affected', jointRedWarm: 'Redness or warmth over a joint',
  morningStiffness: 'Morning stiffness', lowerLimb: 'Lower limb affected', neckPain: 'Neck pain', lowBackPain: 'Lower back pain', radiatingLimbPain: 'Pain shooting down an arm or leg',
  bladderBowelLoss: 'New loss of bladder or bowel control', mskConcern: 'Bone, joint or muscle concern',
  majorBleeding: 'Heavy or uncontrolled bleeding', severeChestSign: 'Severe chest pain or pressure', suddenFocalSign: 'Sudden one-sided weakness or drooping',
  suddenSpeechSign: 'Sudden confusion or speech difficulty', severeBreathingSign: 'Severe difficulty breathing', seizureToday: 'Seizure today',
};

/* ---------------------------------------------------------------------
   Assessment categories. Each category maps to one department (see
   SPECIALIST_MAPPING). `fallbackCondition` is shown when no condition in
   the category has enough supporting answers to be named.
   --------------------------------------------------------------------- */

const CATEGORY_ORDER = ['cardiovascular', 'respiratory', 'musculoskeletal', 'dermatological', 'neurological', 'gastrointestinal', 'general'];

const CATEGORIES = {
  cardiovascular: {
    label: 'Cardiovascular', patternLabel: 'Cardiovascular symptom pattern',
    fallbackCondition: {
      id: 'cardio_unspecified', name: 'Heart-related symptoms (cause to be confirmed)', short: 'Heart-related symptoms',
      description: 'The answers point towards the heart, but no single heart condition stands out. The cardiologist will assess the cause.',
    },
  },
  respiratory: {
    label: 'Respiratory', patternLabel: 'Respiratory symptom pattern',
    fallbackCondition: {
      id: 'resp_unspecified', name: 'Respiratory symptoms (cause to be confirmed)', short: 'Respiratory symptoms',
      description: 'The answers point towards the lungs or airways, but no single respiratory condition stands out. The pulmonologist will assess the cause.',
    },
  },
  musculoskeletal: {
    label: 'Musculoskeletal', patternLabel: 'Musculoskeletal symptom pattern',
    fallbackCondition: {
      id: 'msk_unspecified', name: 'Non-specific joint or muscle pain', short: 'Joint / muscle pain',
      description: 'Pain in a joint, bone or muscle without the features of a specific injury or type of arthritis. The orthopaedic specialist will examine the area.',
    },
  },
  dermatological: {
    label: 'Dermatological', patternLabel: 'Dermatological symptom pattern',
    fallbackCondition: {
      id: 'derm_unspecified', name: 'Skin condition (type to be confirmed)', short: 'Skin condition',
      description: 'The skin problem does not clearly match one condition from the answers alone. The dermatologist will examine the skin.',
    },
  },
  neurological: {
    label: 'Neurological', patternLabel: 'Neurological symptom pattern',
    fallbackCondition: {
      id: 'neuro_unspecified', name: 'Neurological symptoms (cause to be confirmed)', short: 'Neurological symptoms',
      description: 'The answers point towards the brain, nerves or balance system, but no single condition stands out. The neurologist will assess the cause.',
    },
  },
  gastrointestinal: {
    label: 'Gastrointestinal', patternLabel: 'Gastrointestinal symptom pattern',
    fallbackCondition: {
      id: 'gi_unspecified', name: 'Non-specific abdominal or digestive complaint', short: 'Digestive complaint',
      description: 'Abdominal or digestive symptoms that do not clearly match one condition from the answers alone. The gastroenterologist will assess the cause.',
    },
  },
  general: {
    label: 'General / Non-specific', patternLabel: 'General / non-specific symptom pattern',
    fallbackCondition: {
      id: 'general_unspecified', name: 'Non-specific illness (cause to be confirmed)', short: 'Non-specific illness',
      description: 'General symptoms that do not point to one condition. The General Physician will assess the cause.',
    },
  },
};

const INCONCLUSIVE_RESULT = {
  id: 'inconclusive',
  label: 'General / Inconclusive',
  patternLabel: 'No single strong symptom pattern',
  message: 'The reported symptom pattern does not strongly match a single assessment category. General clinical evaluation is recommended.',
  conditionLabel: 'No single condition stands out',
  conditionShort: 'No single condition',
  conditionMessage: 'The answers do not point clearly to one condition, so no single disease is predicted. The conditions the system considered are listed for the General Physician.',
};

/* ---------------------------------------------------------------------
   CONDITIONS — prototype disease / condition prediction
   ---------------------------------------------------------------------
   After the category (and so the department) is chosen, the conditions
   belonging to that category are scored with the same normalised
   features:  score = Σ weight × feature  (negative weights count
   against). A condition whose `requires` test fails is not considered.
   The highest-scoring condition is the predicted condition. Its match
   strength = softmax share (against the category's other conditions plus
   a residual for conditions this prototype does not cover)
   × (1 − e^(−score / fitScale)), so a condition supported by a single
   answer never reads as a near-certain match. Close calls (top two
   within tieMargin points) name no single condition.
   Names are preliminary predictions for routing, never a confirmed
   diagnosis, and descriptions never mention medicines or treatment.
   `category` may list several categories (the first is the primary one).
   --------------------------------------------------------------------- */

const CONDITION_SETTINGS = {
  minScore: 2, // below this the category's fallback description is shown instead of a named condition
  temperature: 2, // softmax temperature for relative likelihood
  residualScore: 2, // stands for conditions the prototype does not cover
  likelihoodCap: 90,
  maxDifferentials: 3,
  minDifferentialLikelihood: 4,
  tieMargin: 5, // top two within this many points: no single condition is named
  fitScale: 4, // condition score at which match strength reaches ~63 % before competition
  consideredMinScore: 2, // inconclusive results list conditions scoring at least this
  helperText: 'Match strength shows how well the answers fit a condition compared with the other conditions checked in this category. It is not the chance that the patient has the condition.',
  cardHelp: 'How well the answers fit, compared with the other conditions checked. Not the chance that the patient has it.',
};

const CONDITIONS = [
  /* ----- Cardiovascular → Cardiology ----- */
  {
    id: 'angina', category: 'cardiovascular', name: 'Angina (heart-related chest pain)', short: 'Angina',
    description: 'Chest pain or pressure that occurs when the heart muscle does not get enough blood, typically brought on by physical effort.',
    requires: (f) => (f.chestPain || f.chestDiscomfort) && !f.ageUnder16,
    weights: {
      chestPain: 1.5, chestDiscomfort: 1.5, exertionalSymptoms: 3, radiatingChestPain: 2, sweating: 1.5, breathingDifficulty: 1,
      ageOver45: 0.8, ageUnder30: -0.8, dizziness: 0.5, pleuriticPain: -2.5, chestWallTenderness: -2.5, postprandialPain: -2, fever: -1, cough: -1,
    },
  },
  {
    id: 'nonspecific_chest_pain', category: 'cardiovascular', name: 'Non-specific chest pain', short: 'Non-specific chest pain',
    description: 'Chest pain without the typical features of heart-related pain. Heart, lung and digestive causes still need to be checked by the doctor.',
    requires: (f) => f.chestPain || f.chestDiscomfort,
    weights: {
      chestPain: 2.5, chestDiscomfort: 1.5, exertionalSymptoms: -2, radiatingChestPain: -1.5, sweating: -1, palpitations: -1,
    },
  },
  {
    id: 'arrhythmia', category: 'cardiovascular', name: 'Heart rhythm disorder (arrhythmia)', short: 'Arrhythmia',
    description: 'An irregular, unusually fast or slow heartbeat, which can cause palpitations, dizziness or fainting.',
    requires: (f) => f.palpitations,
    weights: {
      palpitations: 4, dizziness: 1.5, presyncope: 1.5, lossOfConsciousness: 1.5, breathingDifficulty: 0.5, chestDiscomfort: 0.5,
      exertionalSymptoms: 0.5, lowMoodSleep: -0.5,
    },
  },
  {
    id: 'heart_failure', category: 'cardiovascular', name: 'Heart failure (reduced pumping of the heart)', short: 'Heart failure',
    description: 'The heart does not pump as well as it should, which can cause breathlessness on effort, tiredness and swelling of the legs.',
    requires: (f) => (f.exertionalBreathless || (f.breathingDifficulty >= 0.66 && f.exertionalSymptoms)) && !f.ageUnder16,
    weights: {
      exertionalBreathless: 3, breathingDifficulty: 1.5, fatigue: 1, weakness: 0.5, ageOver45: 1.5, exertionalSymptoms: 1,
      durationOverWeek: 1, chestPain: -1, fever: -1.5, cough: -0.5, pallor: -1,
    },
  },

  /* ----- Respiratory → Pulmonology ----- */
  {
    id: 'urti', category: ['respiratory', 'general'], name: 'Common cold (upper respiratory tract infection)', short: 'Common cold',
    description: 'A viral infection of the nose and throat causing cough, sore throat, a runny or blocked nose and sometimes a mild fever.',
    requires: (f) => f.cough || f.soreThroat,
    weights: {
      cough: 1.5, soreThroat: 2, coughDry: 0.5, sickContact: 1, durationShort: 1.5, fever: 0.5,
      breathingDifficulty: -2, wheezing: -1, chestTightness: -0.5, pleuriticPain: -1, highFever: -1, durationOverWeek: -1.5, coughBlood: -2,
    },
  },
  {
    id: 'influenza', category: ['respiratory', 'general'], name: 'Influenza (flu)', short: 'Influenza (flu)',
    description: 'A viral infection causing fever, cough or sore throat, body aches, chills and tiredness, usually starting suddenly. COVID-19 and other viruses can cause a similar illness.',
    requires: (f) => f.fever && (f.cough || f.soreThroat),
    weights: {
      fever: 1.5, cough: 1.5, soreThroat: 1, bodyAches: 2, chills: 1, headache: 0.5, fatigue: 0.5, weakness: 0.5, durationShort: 1,
      sickContact: 0.5, coughDry: 0.5, breathingDifficulty: -1, durationOverWeek: -2, coughBlood: -1.5,
    },
  },
  {
    id: 'bronchitis', category: 'respiratory', name: 'Acute bronchitis (chest infection)', short: 'Acute bronchitis',
    description: 'Inflammation of the airways in the lungs, usually after a viral infection, causing a persistent cough that often brings up phlegm.',
    requires: (f) => f.cough,
    weights: {
      cough: 1.5, coughProductive: 2.5, durationOver3Days: 1.5, chestTightness: 1, breathingDifficulty: 1, wheezing: 0.5, fever: 0.5,
      smoker: 0.5, sickContact: 0.3, durationOverMonth: -1.5, highFever: -1, coughBlood: -1,
    },
  },
  {
    id: 'pneumonia', category: 'respiratory', name: 'Pneumonia (lung infection)', short: 'Pneumonia',
    description: 'An infection that inflames the air sacs in one or both lungs, typically causing fever, cough and difficulty breathing.',
    requires: (f) => f.fever && (f.cough || f.breathingDifficulty),
    weights: {
      fever: 1.5, highFever: 2, chills: 1.5, breathingDifficulty: 3, pleuriticPain: 2, chestTightness: 1, cough: 1, coughProductive: 1,
      ageOver45: 0.5, durationOver3Days: 0.5, wheezing: -0.5,
    },
  },
  {
    id: 'asthma', category: 'respiratory', name: 'Asthma', short: 'Asthma',
    description: 'A long-term condition in which the airways narrow and become inflamed, causing wheezing, chest tightness, breathlessness and cough.',
    requires: (f) => f.wheezing || f.respiratoryHistory,
    weights: {
      wheezing: 3, respiratoryHistory: 2.5, chestTightness: 1.5, breathingDifficulty: 1.5, coughDry: 1, exposure: 1, cough: 0.5,
      fever: -1.5, coughProductive: -0.5, smoker: -0.5, ageOver45: -0.5,
    },
  },
  {
    id: 'copd', category: 'respiratory', name: 'COPD (chronic obstructive pulmonary disease)', short: 'COPD',
    description: 'A long-term lung disease, usually linked to smoking or long exposure to smoke and dust, causing breathlessness and a cough with phlegm.',
    requires: (f) => (f.smoker || f.exposure) && (f.cough || f.breathingDifficulty || f.wheezing) && !f.ageUnder16,
    weights: {
      smoker: 2.5, exposure: 1.5, ageOver45: 1.5, durationOverWeek: 1.5, coughProductive: 1.5, breathingDifficulty: 1.5, wheezing: 1,
      respiratoryHistory: 1, exertionalBreathless: 1, fever: -1, durationShort: -1,
    },
  },
  {
    id: 'tuberculosis', category: 'respiratory', name: 'Tuberculosis (TB)', short: 'Tuberculosis',
    description: 'A bacterial infection that mainly affects the lungs, typically causing a cough lasting more than two weeks, fever, night sweats and weight loss.',
    requires: (f) => f.cough && (f.durationOverWeek || f.coughBlood || f.weightLoss),
    weights: {
      cough: 1, durationOverWeek: 1.5, durationOverMonth: 2, coughBlood: 2.5, fever: 1, weightLoss: 2.5, appetiteLoss: 1,
      sickContact: 0.5, coughProductive: 0.5, wheezing: -1, respiratoryHistory: -0.5, durationShort: -2.5,
    },
  },

  /* ----- Musculoskeletal → Orthopaedics ----- */
  {
    id: 'sprain', category: 'musculoskeletal', name: 'Sprain or strain (ligament or muscle injury)', short: 'Sprain / strain',
    description: 'A stretched or torn ligament (sprain) or muscle (strain), usually after a twist, fall or overuse, causing pain, swelling and difficulty moving.',
    requires: (f) => f.injury && f.jointLimbPain,
    weights: {
      injury: 3, jointSwelling: 1.5, restrictedMovement: 1, jointLimbPain: 1, durationShort: 1, lowerLimb: 0.5, ageOver65: -1.5,
      suspectedFracture: -2.5, multipleJoints: -1.5, morningStiffness: -1.5, jointRedWarm: -1, fever: -1, durationOverMonth: -1.5,
    },
  },
  {
    id: 'fracture', category: 'musculoskeletal', name: 'Fracture (broken bone)', short: 'Fracture',
    description: 'A break or crack in a bone, usually after a fall or injury, causing severe pain, swelling, deformity or inability to move or bear weight.',
    requires: (f) => f.suspectedFracture || (f.injury && f.ageOver65 && f.lowerLimb),
    weights: { suspectedFracture: 4.5, injury: 1.5, jointSwelling: 1, restrictedMovement: 1, painScore: 1.5, ageOver65: 2.5 },
  },
  {
    id: 'osteoarthritis', category: 'musculoskeletal', name: 'Osteoarthritis (wear-and-tear arthritis)', short: 'Osteoarthritis',
    description: 'Gradual wearing of the cartilage in a joint, most often the knee or hip, causing pain, stiffness and reduced movement, mainly in people over 45.',
    requires: (f) => f.jointLimbPain && f.durationOverWeek && (f.ageOver45 || (f.durationOverMonth && !f.ageUnder30)),
    weights: {
      jointLimbPain: 1, ageOver45: 2, ageUnder30: -1.5, durationOverWeek: 1.5, durationOverMonth: 1.5, restrictedMovement: 1, lowerLimb: 1, jointSwelling: 0.3,
      injury: -2.5, jointRedWarm: -1.5, fever: -1.5, multipleJoints: -0.5, morningStiffness: -0.5, durationShort: -1,
    },
  },
  {
    id: 'inflammatory_arthritis', category: 'musculoskeletal', name: 'Inflammatory arthritis (such as rheumatoid arthritis)', short: 'Inflammatory arthritis',
    description: 'Joint inflammation caused by the immune system, often affecting several joints with swelling and morning stiffness lasting more than 30 minutes.',
    requires: (f) => f.morningStiffness || f.multipleJoints,
    weights: {
      morningStiffness: 3, multipleJoints: 2.5, jointSwelling: 1.5, jointRedWarm: 0.5, durationOverWeek: 1.5, fever: 0.5, rash: 0.5,
      injury: -2.5, durationShort: -1,
    },
  },
  {
    id: 'hot_joint', category: 'musculoskeletal', name: 'Acute hot joint (joint infection or gout)', short: 'Hot swollen joint',
    description: 'A sudden, very painful, red, warm and swollen joint. Infection of the joint must be ruled out by the doctor; gout is a common cause in adults.',
    requires: (f) => f.jointRedWarm,
    weights: {
      jointRedWarm: 3, jointSwelling: 2, fever: 1.5, durationShort: 1, painScore: 1, injury: -1.5, multipleJoints: -1,
      morningStiffness: -0.5, durationOverMonth: -1,
    },
  },
  {
    id: 'back_strain', category: 'musculoskeletal', name: 'Mechanical back or neck pain (muscle strain)', short: 'Back / neck strain',
    description: 'Pain from the muscles, ligaments or joints of the spine, often after lifting, poor posture or a sudden movement, without signs of nerve involvement.',
    requires: (f) => f.backPain && !(f.ageOver65 && f.durationOverMonth),
    weights: { backPain: 2.5, injury: 1.5, durationShort: 0.5, radiatingLimbPain: -2, numbness: -1.5, durationOverMonth: -0.5, fever: -1 },
  },
  {
    id: 'cervical_spondylosis', category: 'musculoskeletal', name: 'Cervical spondylosis (neck arthritis)', short: 'Cervical spondylosis',
    description: 'Age-related wear of the discs and joints in the neck, causing neck pain and stiffness that can spread to the shoulders or arms, sometimes with tingling.',
    requires: (f) => f.neckPain && !f.ageUnder16,
    weights: {
      neckPain: 1.5, ageOver45: 2, ageUnder30: -1, durationOverWeek: 1, durationOverMonth: 0.5, radiatingLimbPain: 1, numbness: 1, injury: -1.5, durationShort: -0.5,
    },
  },
  {
    id: 'sciatica', category: 'musculoskeletal', name: 'Slipped disc with nerve pain (sciatica)', short: 'Slipped disc / sciatica',
    description: 'A slipped (herniated) disc or narrowing in the spine pressing on a nerve root, causing back pain that shoots down a leg or arm, sometimes with numbness or tingling.',
    requires: (f) => f.radiatingLimbPain,
    weights: { radiatingLimbPain: 3.5, backPain: 1.5, numbness: 1.5, lowBackPain: 1, injury: 0.5, durationOver3Days: 0.5, neckPain: -1 },
  },
  {
    id: 'chest_wall_pain', category: 'musculoskeletal', name: 'Chest-wall pain (costochondritis or muscle strain)', short: 'Chest-wall pain',
    description: 'Pain from the muscles, cartilage or ribs of the chest wall, typically worse when pressing on the chest or moving the upper body.',
    requires: (f) => f.chestWallTenderness,
    weights: { chestWallTenderness: 4, chestPain: 1, injury: 1, sweating: -1, radiatingChestPain: -1, exertionalSymptoms: -1 },
  },
  {
    id: 'myalgia', category: ['musculoskeletal', 'general'], name: 'Generalised muscle aches (myalgia)', short: 'Muscle aches',
    description: 'Aching in the muscles of several parts of the body, often after a viral illness, unusual exertion or poor sleep.',
    requires: (f) => f.bodyAches,
    weights: { bodyAches: 3, fatigue: 0.5, weakness: 0.5, durationOverWeek: 0.5, fever: -1.5 },
  },

  /* ----- Dermatological → Dermatology ----- */
  {
    id: 'fungal_infection', category: 'dermatological', name: 'Fungal skin infection (ringworm / tinea)', short: 'Fungal skin infection',
    description: 'A common skin infection caused by fungi, typically an itchy, red, ring-shaped or scaly rash that slowly spreads, often in warm, moist areas.',
    requires: (f) => f.rash || f.skinScaly || f.itching,
    weights: {
      itching: 2, rash: 1.5, redness: 1, skinSpreading: 2, skinScaly: 1, durationOverWeek: 1, durationOver3Days: 0.5,
      fever: -2, skinWidespread: -0.5, skinBlisters: -1, skinDischarge: -1, hives: -2, durationShort: -1,
    },
  },
  {
    id: 'eczema', category: 'dermatological', name: 'Eczema / dermatitis', short: 'Eczema / dermatitis',
    description: 'Inflamed, itchy, dry or red skin. It may be long-term (atopic eczema) or triggered by contact with an irritant or allergen (contact dermatitis).',
    requires: (f) => f.itching && (f.rash || f.skinScaly || f.redness || f.skinBlisters),
    weights: {
      itching: 2.5, rash: 1.5, skinScaly: 2, redness: 1, skinBlisters: 1, durationOverWeek: 1, skinWidespread: 0.5,
      skinSpreading: -0.5, fever: -1.5, skinDischarge: -0.5, hives: -2, durationShort: -0.5,
    },
  },
  {
    id: 'urticaria', category: 'dermatological', name: 'Urticaria (hives / allergic skin reaction)', short: 'Urticaria (hives)',
    description: 'Raised, itchy welts on the skin that come and go, often an allergic reaction to food, medicines, insect bites or an infection.',
    requires: (f) => f.hives,
    weights: { hives: 4, itching: 1.5, rash: 0.5, durationShort: 1.5, skinWidespread: 1, redness: 0.5, skinScaly: -1.5, durationOverMonth: -0.5 },
  },
  {
    id: 'acne', category: 'dermatological', name: 'Acne', short: 'Acne',
    description: 'Blocked and inflamed hair follicles causing pimples, blackheads or cysts, most often on the face, chest and back.',
    requires: (f) => f.skinAcne,
    weights: { skinAcne: 5, redness: 0.5, durationOverWeek: 0.5, fever: -1 },
  },
  {
    id: 'skin_infection', category: 'dermatological', name: 'Bacterial skin infection (cellulitis, boil or impetigo)', short: 'Bacterial skin infection',
    description: 'A bacterial infection of the skin causing redness, warmth, swelling, pain or pus. It can spread and should be checked promptly by the doctor.',
    requires: (f) => f.skinWound || f.skinDischarge || (f.redness && f.skinPainBurning && f.skinSpreading),
    weights: {
      skinWound: 2.5, skinDischarge: 2.5, redness: 1.5, skinSpreading: 1.5, skinPainBurning: 1.5, fever: 1.5,
      itching: -1, skinScaly: -1, durationOverMonth: -1,
    },
  },
  {
    id: 'psoriasis', category: 'dermatological', name: 'Psoriasis', short: 'Psoriasis',
    description: 'A long-term skin condition causing thick, red, scaly patches, often on the elbows, knees, scalp and lower back, which tends to come and go.',
    requires: (f) => f.skinScaly,
    weights: { skinScaly: 3, durationOverMonth: 2, durationOverWeek: 1, redness: 1, itching: 0.3, skinWidespread: 0.5, fever: -1, durationShort: -1 },
  },
  {
    id: 'viral_rash', category: 'dermatological', name: 'Viral rash illness (such as chickenpox or measles)', short: 'Viral rash',
    description: 'A rash that appears with a viral infection and fever. Chickenpox causes itchy, fluid-filled blisters; other viruses cause a red, spotty rash.',
    requires: (f) => f.fever && (f.rash || f.skinBlisters),
    weights: { fever: 2, skinBlisters: 2.5, rash: 1, skinWidespread: 1.5, itching: 0.5, durationShort: 1, skinScaly: -1, skinWound: -1, skinDischarge: -1 },
  },
  {
    id: 'shingles', category: 'dermatological', name: 'Shingles (herpes zoster)', short: 'Shingles',
    description: 'A reactivation of the chickenpox virus causing a painful, burning band of blisters on one side of the body.',
    requires: (f) => f.skinBlisters && f.skinPainBurning,
    weights: { skinBlisters: 2.5, skinPainBurning: 3, ageOver45: 1, fever: 0.3, skinWidespread: -2 },
  },
  {
    id: 'pigmentation', category: 'dermatological', name: 'Pigmentation disorder (such as vitiligo or melasma)', short: 'Pigmentation disorder',
    description: 'Patches of skin that are lighter or darker than the surrounding skin, such as vitiligo (loss of colour) or melasma (darker patches).',
    requires: (f) => f.skinPigment && !f.skinSpreading,
    weights: { skinPigment: 5, durationOverMonth: 0.5, itching: -0.5, fever: -1 },
  },
  {
    id: 'changing_skin_patch', category: 'dermatological', name: 'Changing skin patch or mole (cause to be checked)', short: 'Changing patch / mole',
    description: 'A patch or mole that is changing or spreading. Causes range from vitiligo or a fungal infection to skin cancer, so the dermatologist will examine it.',
    requires: (f) => f.skinPigment && f.skinSpreading,
    weights: { skinPigment: 3, skinSpreading: 2.5, ageOver45: 1, durationOverMonth: 0.5, itching: 0.3 },
  },
  {
    id: 'hair_nail', category: 'dermatological', name: 'Hair or nail disorder (such as hair loss or nail infection)', short: 'Hair / nail disorder',
    description: 'Conditions affecting the hair, scalp or nails, such as hair loss, dandruff or a fungal nail infection.',
    requires: (f) => f.hairNail,
    weights: { hairNail: 5, itching: 0.3, durationOverWeek: 0.5 },
  },

  /* ----- Neurological → Neurology ----- */
  {
    id: 'migraine', category: 'neurological', name: 'Migraine', short: 'Migraine',
    description: 'A recurring headache, often throbbing and on one side, that can come with nausea and sensitivity to light or sound, lasting hours to days.',
    requires: (f) => f.headache && !f.fever && !(f.ageOver45 && f.firstHeadache),
    weights: {
      headache: 1, throbbingHeadache: 3, photophobia: 2.5, nauseaVomiting: 1.5, recurrentHeadache: 1.5, visionChanges: 0.5, numbness: 0.5,
      stiffNeck: -2, tensionHeadache: -1.5, dullHeadache: -1, durationOverWeek: -1,
    },
  },
  {
    id: 'tension_headache', category: 'neurological', name: 'Tension-type headache', short: 'Tension headache',
    description: 'The most common type of headache: a dull, tight band or pressure around the head, often linked to stress, poor sleep or posture.',
    requires: (f) => f.headache && !f.fever && !(f.ageOver45 && f.firstHeadache) && !f.visionChanges && !f.numbness,
    weights: {
      headache: 1, tensionHeadache: 3.5, dullHeadache: 1.5, recurrentHeadache: 1, lowMoodSleep: 1, sharpHeadache: -1,
      throbbingHeadache: -2, photophobia: -1, nauseaVomiting: -1, stiffNeck: -2, visionChanges: -1, numbness: -2,
    },
  },
  {
    id: 'febrile_headache', category: 'neurological', name: 'Headache with fever (viral infection or sinusitis)', short: 'Headache with fever',
    description: 'A headache that comes with fever, most often caused by a viral infection or sinusitis. The doctor will rule out more serious infections.',
    requires: (f) => f.headache && f.fever && !f.photophobia && !f.confusion && !f.nauseaVomiting,
    weights: { headache: 1.5, fever: 2.5, bodyAches: 0.5, durationShort: 0.5 },
  },
  {
    id: 'febrile_headache_warning', category: 'neurological', name: 'Headache with fever and warning signs (serious infection to be ruled out)', short: 'Fever, headache and warning signs',
    description: 'A headache with fever together with light sensitivity, vomiting or confusion. Meningitis and other serious infections must be ruled out promptly by the doctor.',
    requires: (f) => f.headache && f.fever && (f.photophobia || f.nauseaVomiting || f.confusion),
    weights: { fever: 2, headache: 1.5, photophobia: 1.5, nauseaVomiting: 1, confusion: 2 },
  },
  {
    id: 'new_headache_older', category: 'neurological', name: 'New headache after middle age (cause to be determined)', short: 'New headache (age 45+)',
    description: 'A first headache of a new kind that starts after middle age needs careful assessment, because causes other than tension headache or migraine are more likely.',
    requires: (f) => f.headache && f.firstHeadache && f.ageOver45 && !f.fever,
    weights: { headache: 2, firstHeadache: 1.5, ageOver45: 0.5, visionChanges: 1, numbness: 0.5 },
  },
  {
    id: 'bppv', category: 'neurological', name: 'Benign positional vertigo (BPPV)', short: 'Positional vertigo',
    description: 'Brief spells of spinning dizziness triggered by moving the head, such as turning in bed or looking up, caused by a problem in the inner ear.',
    requires: (f) => f.vertigo || f.positionalDizziness,
    weights: { positionalDizziness: 3.5, vertigo: 2.5, nauseaVomiting: 0.5, dizziness: 0.5, tinnitus: -1.5, constantDizziness: -1.5, headache: -0.5 },
  },
  {
    id: 'inner_ear', category: 'neurological', name: 'Inner-ear disorder (labyrinthitis or Ménière’s disease)', short: 'Inner-ear disorder',
    description: 'Inflammation or fluid imbalance in the inner ear causing spinning dizziness and nausea, sometimes with ringing in the ears or hearing loss.',
    requires: (f) => f.vertigo || f.tinnitus,
    weights: { tinnitus: 3, vertigo: 2, constantDizziness: 1.5, nauseaVomiting: 1, imbalance: 1, dizziness: 0.5, positionalDizziness: -1 },
  },
  {
    id: 'neuropathy', category: 'neurological', name: 'Peripheral neuropathy (nerve damage in the hands or feet)', short: 'Peripheral neuropathy',
    description: 'Damage to the nerves of the hands or feet, often linked to diabetes or vitamin deficiency, causing numbness, tingling or burning.',
    requires: (f) => (f.peripheralSymptoms || (f.numbness && f.thirstUrination)) && !f.suddenOnsetNeuro,
    weights: {
      peripheralSymptoms: 4, numbness: 1.5, durationOverWeek: 1, durationOverMonth: 0.5, thirstUrination: 1, imbalance: 0.5, ageOver45: 0.5,
      suddenOnsetNeuro: -2,
    },
  },
  {
    id: 'nerve_compression', category: 'neurological', name: 'Pinched nerve (such as carpal tunnel syndrome)', short: 'Pinched nerve',
    description: 'Pressure on a single nerve at the wrist, elbow or spine, causing numbness, tingling or weakness in one arm, hand or leg.',
    requires: (f) => (f.singleLimb || f.radiatingLimbPain) && !f.suddenOnsetNeuro,
    weights: {
      singleLimb: 3, radiatingLimbPain: 2, numbness: 1.5, backPain: 0.5, limbWeakness: 0.5, durationOver3Days: 0.5,
      suddenOnsetNeuro: -2, focalOneSided: -1,
    },
  },
  {
    id: 'epilepsy', category: 'neurological', name: 'Seizure disorder (epilepsy)', short: 'Seizure disorder',
    description: 'A tendency to have repeated seizures (fits) caused by bursts of abnormal electrical activity in the brain. A first seizure needs full evaluation.',
    requires: (f) => f.seizure && !f.firstSeizure,
    weights: { seizure: 5, confusion: 0.5 },
  },
  {
    id: 'first_seizure', category: 'neurological', name: 'First seizure (cause to be determined)', short: 'First seizure',
    description: 'A first fit or seizure needs full evaluation to find the cause, which may include infection, low blood sugar, a head injury or epilepsy.',
    requires: (f) => f.seizure && f.firstSeizure,
    weights: { seizure: 4, firstSeizure: 1, confusion: 0.5 },
  },
  {
    id: 'cognitive_impairment', category: 'neurological', name: 'Memory or thinking disorder (cognitive impairment)', short: 'Cognitive impairment',
    description: 'Gradual problems with memory, thinking or orientation. Causes range from vitamin or thyroid problems to dementia, and need evaluation.',
    requires: (f) => f.confusion && !f.suddenOnsetNeuro && !f.ageUnder16,
    weights: { confusion: 4, ageOver45: 1, ageUnder30: -1, durationOverMonth: 1.5, durationOverWeek: 0.5 },
  },
  {
    id: 'visual_disturbance', category: 'neurological', name: 'Visual disturbance (eye or optic-nerve problem)', short: 'Visual disturbance',
    description: 'Blurred, double or reduced vision, which can come from the eye itself (such as a refractive error or cataract) or from the nerves that carry vision.',
    requires: (f) => f.visionChanges && !f.suddenOnsetNeuro,
    weights: { visionChanges: 3, durationOverWeek: 0.5, headache: -1.5, numbness: -1.5 },
  },
  {
    id: 'focal_deficit', category: 'neurological', name: 'One-sided neurological deficit (stroke or TIA to be ruled out)', short: 'One-sided weakness',
    description: 'Weakness, numbness or drooping on one side of the face or body. Even when it develops gradually or improves, stroke, mini-stroke (TIA) and other brain causes must be ruled out promptly.',
    requires: (f) => f.focalOneSided || f.faceDroop || f.speechDifficulty,
    weights: { focalOneSided: 3, faceDroop: 2, speechDifficulty: 2, limbWeakness: 1, numbness: 0.5, ageOver45: 0.5 },
  },

  /* ----- Gastrointestinal → Gastroenterology ----- */
  {
    id: 'gerd', category: 'gastrointestinal', name: 'Gastritis / acid reflux (GERD)', short: 'Gastritis / GERD',
    description: 'Irritation of the stomach lining or stomach acid flowing back into the food pipe, causing burning upper abdominal or chest pain, acidity and nausea, often related to meals.',
    requires: (f) => (f.acidity || f.upperAbdominal || f.postprandialPain) && f.painScore < 0.7,
    weights: {
      acidity: 3, upperAbdominal: 1.5, postprandialPain: 1.5, mealRelated: 0.5, nauseaVomiting: 0.5, bloating: 0.5,
      diarrhoea: -1.5, fever: -1.5, rightLowerAbdominal: -2, rightUpperAbdominal: -1, emptyStomachPain: -0.5, giBlood: -0.5,
    },
  },
  {
    id: 'peptic_ulcer', category: 'gastrointestinal', name: 'Peptic ulcer (stomach or duodenal ulcer)', short: 'Peptic ulcer',
    description: 'A sore in the lining of the stomach or the first part of the small intestine, causing burning upper abdominal pain that may ease or worsen with food.',
    requires: (f) => f.upperAbdominal || f.emptyStomachPain || f.acidity,
    weights: {
      emptyStomachPain: 3, upperAbdominal: 1.5, acidity: 1, giBlood: 2.5, nauseaVomiting: 0.5, durationOverWeek: 1, appetiteLoss: 0.5,
      diarrhoea: -1, fever: -1, rightLowerAbdominal: -2,
    },
  },
  {
    id: 'gastroenteritis', category: 'gastrointestinal', name: 'Gastroenteritis (stomach infection / food poisoning)', short: 'Gastroenteritis',
    description: 'An infection or irritation of the stomach and intestines, often from contaminated food or water, causing loose motions, vomiting, cramps and sometimes fever.',
    requires: (f) => (f.diarrhoea || f.nauseaVomiting) && f.painScore < 0.7,
    weights: {
      diarrhoea: 3, nauseaVomiting: 1.5, fever: 1, durationShort: 1.5, frequentDiarrhoea: 1, frequentVomiting: 1, diffuseAbdominal: 0.5,
      abdominalPain: 0.5, constipation: -2, acidity: -0.5, durationOverWeek: -1.5, lowerAbdominal: -1, rightLowerAbdominal: -2,
    },
  },
  {
    id: 'gallstones', category: 'gastrointestinal', name: 'Gallbladder disease (gallstones)', short: 'Gallstones',
    description: 'Stones or inflammation in the gallbladder, causing pain in the upper right abdomen, often after fatty meals, sometimes with nausea or fever.',
    requires: (f) => f.rightUpperAbdominal,
    weights: { rightUpperAbdominal: 4, postprandialPain: 1.5, nauseaVomiting: 1, fever: 0.5, ageOver45: 0.5, mealRelated: 0.5 },
  },
  {
    id: 'appendicitis', category: 'gastrointestinal', name: 'Appendicitis (inflamed appendix)', short: 'Appendicitis',
    description: 'Inflammation of the appendix, typically causing pain that settles in the lower right abdomen with loss of appetite, nausea or fever. It needs prompt medical assessment.',
    requires: (f) => f.rightLowerAbdominal,
    weights: { rightLowerAbdominal: 3.5, fever: 1.5, nauseaVomiting: 1.5, appetiteLoss: 1.5, durationShort: 1, painScore: 1, durationOverWeek: -2 },
  },
  {
    id: 'ibs', category: 'gastrointestinal', name: 'Irritable bowel syndrome (IBS)', short: 'IBS',
    description: 'A long-term disorder of bowel function causing cramping abdominal pain, bloating and constipation or loose motions, without damage to the bowel.',
    requires: (f) => (f.bloating || f.constipation || f.lowerAbdominal || f.diarrhoea) && f.painScore < 0.7 && !(f.nauseaVomiting && f.constipation),
    weights: {
      bloating: 2, lowerAbdominal: 1.5, constipation: 1, diarrhoea: 0.5, durationOverWeek: 1.5, durationOverMonth: 1, mealRelated: 0.5,
      fever: -2, giBlood: -2, weightLoss: -1.5, nauseaVomiting: -0.5, durationShort: -1.5, frequentDiarrhoea: -1,
    },
  },
  {
    id: 'constipation', category: 'gastrointestinal', name: 'Constipation', short: 'Constipation',
    description: 'Infrequent or difficult bowel movements, often with hard stools, bloating or lower abdominal discomfort.',
    requires: (f) => f.constipation && f.painScore < 0.7 && !f.nauseaVomiting && !f.giBlood,
    weights: { constipation: 3.5, bloating: 0.5, lowerAbdominal: 0.5, durationOver3Days: 0.5, fever: -1, diarrhoea: -1.5 },
  },
  {
    id: 'piles', category: 'gastrointestinal', name: 'Piles (haemorrhoids) or anal fissure', short: 'Piles / fissure',
    description: 'Swollen veins or a small tear at the anus, a common cause of bright red blood on the stool or toilet paper, often linked to constipation.',
    requires: (f) => f.giBlood && !f.giBloodLarge && !(f.ageOver45 && f.durationOverWeek) && !f.nauseaVomiting,
    weights: { giBloodSmall: 2.5, constipation: 2, giBlood: 1, upperAbdominal: -1.5, acidity: -1, fever: -1, diarrhoea: -0.5 },
  },
  {
    id: 'gi_bleeding', category: 'gastrointestinal', name: 'Bleeding from the digestive tract (cause to be determined)', short: 'Digestive tract bleeding',
    description: 'Blood in the stool or vomit has several possible causes, such as piles, an ulcer, inflammation or polyps in the bowel. The doctor will assess the cause.',
    requires: (f) => f.giBlood,
    weights: { giBlood: 3, ageOver45: 1, durationOverWeek: 1, weightLoss: 1.5, nauseaVomiting: 0.5, upperAbdominal: 0.5, giBloodLarge: 1 },
  },
  {
    id: 'acute_abdomen', category: 'gastrointestinal', name: 'Severe abdominal pain (cause to be determined)', short: 'Severe abdominal pain',
    description: 'Severe pain in the abdomen can come from many causes, such as gallstones, an ulcer, pancreatitis, appendicitis or a blocked bowel. The doctor needs to assess it promptly.',
    requires: (f) => f.abdominalPain && f.painScore >= 0.7,
    weights: { abdominalPain: 1, painScore: 3, nauseaVomiting: 1, frequentVomiting: 0.5, diffuseAbdominal: 1, fever: 0.5, ageOver65: 0.5 },
  },

  /* ----- General / non-specific → General Medicine ----- */
  {
    id: 'viral_fever', category: 'general', name: 'Viral fever', short: 'Viral fever',
    description: 'A fever caused by a viral infection, often with body aches, tiredness and headache, usually lasting a few days.',
    requires: (f) => f.fever,
    weights: {
      fever: 2, bodyAches: 1, weakness: 0.5, fatigue: 0.5, headache: 0.5, durationShort: 1.5, chills: 0.3,
      durationOverWeek: -2, urinarySymptoms: -2, highFever: -0.5,
    },
  },
  {
    id: 'dengue', category: 'general', name: 'Dengue fever', short: 'Dengue',
    description: 'A mosquito-borne viral infection causing high fever, severe body and joint aches, headache and sometimes a rash.',
    requires: (f) => f.fever && (f.bodyAches || f.rash),
    weights: {
      fever: 1.5, highFever: 2, bodyAches: 2, rash: 2, headache: 1, nauseaVomiting: 0.5, weakness: 0.5, durationShort: 0.5,
      cough: -1.5, soreThroat: -0.5, durationOverWeek: -1.5,
    },
  },
  {
    id: 'malaria', category: 'general', name: 'Malaria', short: 'Malaria',
    description: 'A mosquito-borne parasitic infection causing fever with shivering (chills), sweating, headache and body aches, often in repeated bouts.',
    requires: (f) => f.fever && f.chills,
    weights: {
      fever: 1.5, chills: 2, highFever: 1.5, headache: 0.5, nauseaVomiting: 0.5, weakness: 0.5, bodyAches: 0.3,
      cough: -1, rash: -1, soreThroat: -0.5,
    },
  },
  {
    id: 'typhoid', category: 'general', name: 'Typhoid (enteric fever)', short: 'Typhoid',
    description: 'A bacterial infection spread through contaminated food or water, causing a fever lasting several days with weakness, headache, abdominal pain and loss of appetite.',
    requires: (f) => f.fever && f.durationOver3Days && !f.durationOverMonth && !f.weightLoss,
    weights: {
      fever: 1.5, durationOver3Days: 1, durationOverWeek: 1.5, abdominalPain: 1, appetiteLoss: 1, headache: 0.5, weakness: 1,
      diarrhoea: 0.5, constipation: 0.5, chills: -0.5, cough: -1, rash: -0.5, soreThroat: -0.5,
    },
  },
  {
    id: 'prolonged_fever', category: 'general', name: 'Prolonged fever (cause to be determined)', short: 'Prolonged fever',
    description: 'A fever that has lasted for weeks, or that comes with weight loss, needs a detailed evaluation. Possible causes include tuberculosis and other long-lasting infections.',
    requires: (f) => f.fever && (f.durationOverMonth || f.weightLoss),
    weights: { fever: 1.5, durationOverMonth: 2.5, weightLoss: 2, appetiteLoss: 0.5, weakness: 0.5, fatigue: 0.5 },
  },
  {
    id: 'uti', category: 'general', name: 'Urinary tract infection (UTI)', short: 'Urinary tract infection',
    description: 'An infection of the bladder or urinary tract causing burning or pain while passing urine, frequent urination and sometimes lower abdominal pain or fever.',
    requires: (f) => f.urinarySymptoms,
    weights: { urinarySymptoms: 4.5, fever: 1, pelvicPain: 1.5, lowerAbdominal: 0.5, chills: 0.5, thirstUrination: 0.5 },
  },
  {
    id: 'pharyngitis', category: 'general', name: 'Throat infection (pharyngitis or tonsillitis)', short: 'Throat infection',
    description: 'Infection and inflammation of the throat or tonsils, usually viral and sometimes bacterial, causing a sore throat, pain on swallowing and fever.',
    requires: (f) => f.soreThroat,
    weights: { soreThroat: 4, fever: 1, dentalEarThroat: 0.5, durationShort: 0.5, cough: -0.5 },
  },
  {
    id: 'ear_infection', category: 'general', name: 'Ear infection (otitis)', short: 'Ear infection',
    description: 'Infection of the outer or middle ear, causing ear pain, sometimes with discharge, reduced hearing or fever.',
    requires: (f) => f.earPain,
    weights: { earPain: 4, fever: 1, dentalEarThroat: 0.5 },
  },
  {
    id: 'dental_problem', category: 'general', name: 'Dental problem (tooth decay or gum infection)', short: 'Dental problem',
    description: 'Tooth decay, a dental abscess or a gum infection, causing tooth or jaw pain, sometimes with swelling or fever. A dentist may need to see the patient.',
    requires: (f) => f.toothPain,
    weights: { toothPain: 4, fever: 0.5, dentalEarThroat: 0.5 },
  },
  {
    id: 'pelvic_pain', category: 'general', name: 'Pelvic or groin pain (urinary, gynaecological or hernia cause to be checked)', short: 'Pelvic / groin pain',
    description: 'Pain low in the abdomen, pelvis or groin. Common causes include urinary, gynaecological and hernia problems, which the doctor will examine for.',
    requires: (f) => f.pelvicPain,
    weights: { pelvicPain: 3, fever: 0.3, urinarySymptoms: -1 },
  },
  {
    id: 'anaemia', category: 'general', name: 'Anaemia (low haemoglobin)', short: 'Anaemia',
    description: 'A low level of haemoglobin in the blood, often due to iron deficiency, causing tiredness, weakness, pale skin and breathlessness on effort.',
    requires: (f) => f.pallor || (f.fatigue && f.exertionalBreathless),
    weights: { pallor: 3.5, fatigue: 1.5, weakness: 1, exertionalBreathless: 1.5, dizziness: 0.5, presyncope: 0.5, durationOverWeek: 1, appetiteLoss: 0.3 },
  },
  {
    id: 'diabetes', category: 'general', name: 'Diabetes (high blood sugar)', short: 'Diabetes',
    description: 'A long-term condition with high blood sugar levels, which can cause excessive thirst, frequent urination, tiredness, weight loss and tingling in the feet.',
    requires: (f) => f.thirstUrination,
    weights: { thirstUrination: 4, fatigue: 1, weightLoss: 1.5, numbness: 0.5, peripheralSymptoms: 0.5, ageOver45: 0.5, durationOverWeek: 1 },
  },
  {
    id: 'hypothyroidism', category: 'general', name: 'Underactive thyroid (hypothyroidism)', short: 'Hypothyroidism',
    description: 'The thyroid gland does not make enough hormone, which can cause tiredness, feeling cold, weight gain, dry skin and low mood.',
    requires: (f) => f.fatigue && f.durationOverWeek && (f.pallor || f.lowMoodSleep || f.durationOverMonth),
    weights: { fatigue: 1, pallor: 1, lowMoodSleep: 1, durationOverMonth: 1.5, durationOverWeek: 0.5, weightLoss: -2, fever: -2 },
  },
  {
    id: 'postural_hypotension', category: ['general', 'cardiovascular'], name: 'Low blood pressure on standing (postural hypotension)', short: 'Postural low BP',
    description: 'A drop in blood pressure on standing up, causing light-headedness or near-fainting. Dehydration is a common cause.',
    requires: (f) => f.orthostaticDizziness || f.presyncope,
    weights: {
      orthostaticDizziness: 4, presyncope: 2, dizziness: 1, lossOfConsciousness: 0.5, fatigue: 0.5, weakness: 0.5,
      vertigo: -2, positionalDizziness: -2, palpitations: -0.5, exertionalSymptoms: -2,
    },
  },
  {
    id: 'stress_sleep', category: 'general', name: 'Stress, anxiety or sleep disturbance', short: 'Stress / sleep problem',
    description: 'Ongoing stress, anxiety or poor sleep can cause tiredness, headaches, palpitations and low energy. Physical causes should still be checked by the doctor.',
    requires: (f) => f.lowMoodSleep,
    weights: { lowMoodSleep: 3.5, fatigue: 1, headache: 0.5, palpitations: 0.5, durationOverWeek: 1, fever: -1.5, weightLoss: -1 },
  },
  {
    id: 'general_fatigue', category: 'general', name: 'General weakness or fatigue (cause to be determined)', short: 'General fatigue',
    description: 'Tiredness or weakness without features that point to one cause. The doctor will assess the possible reasons.',
    requires: (f) => (f.fatigue || f.weakness) && !(f.muscleWeakness && f.durationShort),
    weights: { fatigue: 2, weakness: 2, muscleWeakness: 0.5, severity: 0.5, fever: -1.5 },
  },
  {
    id: 'acute_weakness', category: ['general', 'neurological', 'musculoskeletal'], name: 'Recent weakness of both arms or legs (cause to be determined)', short: 'Recent limb weakness',
    description: 'Weakness of both arms or both legs that has developed over days needs prompt assessment. Nerve, muscle and blood-salt (electrolyte) problems are among the possible causes.',
    requires: (f) => f.muscleWeakness && f.durationShort,
    weights: { muscleWeakness: 3, weakness: 1, severity: 1 },
  },
];

const CONDITION_INDEX = Object.fromEntries(CONDITIONS.map((condition) => [condition.id, condition]));

/* ---------------------------------------------------------------------
   PREDICTION_RULES — prototype classifier configuration
   score(category) = Σ weight × normalised feature + Σ fired rule bonuses
   Negative weights express evidence against a category.
   --------------------------------------------------------------------- */

const PREDICTION_RULES = {
  cardiovascular: {
    weights: {
      chestPain: 4, sweating: 2.5, radiatingChestPain: 3, exertionalSymptoms: 2.5, palpitations: 3,
      dizziness: 1.5, breathingDifficulty: 1.5, presyncope: 1.5, lossOfConsciousness: 1, exertionalBreathless: 1.5,
      chestDiscomfort: 2,
      pleuriticPain: -1.5, postprandialPain: -1.5, chestWallTenderness: -2.5,
    },
    rules: [
      { id: 'chest_with_cardiac_features', label: 'Chest pain together with sweating, spreading pain or effort-related pain', bonus: 2,
        when: (f) => f.chestPain && (f.sweating || f.radiatingChestPain || f.exertionalSymptoms) },
      { id: 'age_with_heart_symptoms', label: 'Age 45 or over with heart-related symptoms', bonus: 1,
        when: (f) => f.ageOver45 && (f.chestPain || f.chestDiscomfort || f.palpitations || f.exertionalBreathless || f.presyncope) },
    ],
  },
  respiratory: {
    weights: {
      cough: 4, breathingDifficulty: 3, wheezing: 3, coughProductive: 1.5, coughDry: 0.5, coughBlood: 1.5, fever: 1.5,
      chestTightness: 1.5, pleuriticPain: 2.5, soreThroat: 1, respiratoryHistory: 1.5, smoker: 0.5, exposure: 0.5,
      sickContact: 0.5, chills: 0.5, exertionalBreathless: 1, breathingConcern: 2, complaint_respiratory: 1,
    },
    rules: [
      { id: 'cough_with_fever', label: 'Cough together with fever', bonus: 1.5, when: (f) => f.cough && f.fever },
      { id: 'breathless_with_wheeze', label: 'Breathing difficulty together with wheezing', bonus: 1.5, when: (f) => f.breathingDifficulty > 0 && f.wheezing },
    ],
  },
  musculoskeletal: {
    weights: {
      jointLimbPain: 4, backPain: 3.5, jointSwelling: 2.5, injury: 2.5, restrictedMovement: 2.5, suspectedFracture: 2,
      multipleJoints: 1.5, jointRedWarm: 1, morningStiffness: 1.5, radiatingLimbPain: 1.5, chestWallTenderness: 3,
      bodyAches: 0.5, muscleWeakness: 1, mskConcern: 2, complaint_joint_limb: 1,
    },
    rules: [
      { id: 'pain_with_injury_or_restriction', label: 'Joint, limb or back pain with injury or restricted movement', bonus: 1.5,
        when: (f) => (f.jointLimbPain || f.backPain) && (f.injury || f.restrictedMovement) },
    ],
  },
  dermatological: {
    weights: {
      rash: 3.5, hives: 1, itching: 3, redness: 2.5, skinSpreading: 2, skinBlisters: 2.5, skinScaly: 3, skinAcne: 3.5,
      skinWound: 2.5, skinPigment: 3.5, hairNail: 3.5, skinWidespread: 0.5, skinPainBurning: 1, skinDischarge: 1.5,
      facialSwelling: 1, skinConcern: 2, complaint_skin: 1,
    },
    rules: [
      { id: 'itchy_rash', label: 'Rash together with itching', bonus: 1.5, when: (f) => f.rash && f.itching },
    ],
  },
  neurological: {
    weights: {
      headache: 3, throbbingHeadache: 2, tensionHeadache: 1, photophobia: 2, visionChanges: 1.5, recurrentHeadache: 1.5,
      suddenSevereHeadache: 2, numbness: 2.5, focalOneSided: 3, limbWeakness: 2.5, singleLimb: 0.5, peripheralSymptoms: 1,
      suddenOnsetNeuro: 1, speechDifficulty: 3, faceDroop: 3, confusion: 2.5, seizure: 4, vertigo: 3, imbalance: 2.5,
      positionalDizziness: 1.5, tinnitus: 1, dizziness: 1.5, radiatingLimbPain: 1, stiffNeck: 1, neuroConcern: 2, complaint_neuro: 1,
      fever: -1.5, // a headache that comes with fever usually belongs to the febrile illness
    },
    rules: [
      { id: 'headache_features', label: 'Headache with a throbbing quality or light sensitivity', bonus: 1.5,
        when: (f) => f.headache && (f.throbbingHeadache || f.photophobia) },
      { id: 'vertigo_balance', label: 'Dizziness with spinning or balance problems', bonus: 1,
        when: (f) => f.dizziness && (f.vertigo || f.imbalance) },
    ],
  },
  gastrointestinal: {
    weights: {
      abdominalPain: 4, nauseaVomiting: 2.5, frequentVomiting: 1, diarrhoea: 3, frequentDiarrhoea: 1, constipation: 2.5,
      bloating: 2, acidity: 3, giBlood: 2.5, upperAbdominal: 1, rightUpperAbdominal: 1.5, rightLowerAbdominal: 1.5,
      lowerAbdominal: 1, diffuseAbdominal: 0.5, mealRelated: 1.5, postprandialPain: 2.5, appetiteLoss: 1,
      digestiveConcern: 2, complaint_digestive: 1,
    },
    rules: [
      { id: 'abdominal_with_gi_symptoms', label: 'Abdominal pain with nausea, loose motions or acidity', bonus: 1.5,
        when: (f) => f.abdominalPain && (f.nauseaVomiting || f.diarrhoea || f.acidity) },
    ],
  },
  general: {
    weights: {
      fever: 2, chills: 1, highFever: 1, fatigue: 3, weakness: 2.5, weightLoss: 2, appetiteLoss: 1.5, bodyAches: 1.5,
      pallor: 1.5, thirstUrination: 2, lowMoodSleep: 1.5, urinarySymptoms: 2, dentalEarThroat: 2, pelvicPain: 1.5,
      otherPain: 1.5, soreThroat: 0.5, orthostaticDizziness: 1, presyncope: 0.5, complaint_weakness: 1, complaint_other: 0.5,
    },
    rules: [
      { id: 'fever_without_focus', label: 'Fever without symptoms pointing to one body system', bonus: 2,
        when: (f) => f.fever && !f.cough && !f.rash && !f.abdominalPain && !f.diarrhoea && !f.nauseaVomiting
          && !f.breathingDifficulty && !f.urinarySymptoms },
    ],
  },
};

/* ---------------------------------------------------------------------
   CONFIDENCE_THRESHOLDS — prototype presentation thresholds only.
   They are not medical standards.
   confidence = 0.45 × pattern strength × dominance
              + 0.35 × separation from the other categories
              + 0.20 × response completeness
              + 0.15 × condition fit × dominance
              − consistency penalties
   (capped at 94 %, so a strong match never reads as certainty)
   (see section 9 for each factor)
   --------------------------------------------------------------------- */

const CONFIDENCE_THRESHOLDS = {
  bands: [
    { id: 'higher', min: 75, label: 'Higher model confidence' },
    { id: 'moderate', min: 55, label: 'Moderate model confidence' },
    { id: 'low', min: 0, label: 'Low / inconclusive' },
  ],
  inconclusiveBelow: 55,
  weights: { strength: 0.45, separation: 0.35, completeness: 0.2, conditionFit: 0.15 },
  strengthScale: 5, // score at which pattern strength reaches ~63 %
  separationSmoothing: 3, // keeps sparse evidence (one weak symptom) from looking decisive
  dominanceTarget: 0.6, // top category needs 60 % of the evidence for full pattern strength
  floor: 5,
  cap: 94,
  helperText: 'Model confidence reflects the system’s preliminary classification and does not represent clinical certainty.',
};

/* ---------------------------------------------------------------------
   SPECIALIST_MAPPING — kept separate from prediction (see section 11).
   `tone` selects the department's wayfinding colour.
   --------------------------------------------------------------------- */

const SPECIALIST_MAPPING = {
  cardiovascular: { department: 'Cardiology', specialist: 'Cardiologist', code: 'CARDIO', icon: 'heart-pulse', tone: 'card' },
  respiratory: { department: 'Pulmonology', specialist: 'Pulmonologist', code: 'PULMO', icon: 'lungs', tone: 'pulm' },
  musculoskeletal: { department: 'Orthopaedics', specialist: 'Orthopaedic Specialist', code: 'ORTHO', icon: 'bone', tone: 'orth' },
  dermatological: { department: 'Dermatology', specialist: 'Dermatologist', code: 'DERMA', icon: 'skin', tone: 'derm' },
  neurological: { department: 'Neurology', specialist: 'Neurologist', code: 'NEURO', icon: 'brain', tone: 'neur' },
  gastrointestinal: { department: 'Gastroenterology', specialist: 'Gastroenterologist', code: 'GASTRO', icon: 'stomach', tone: 'gast' },
  general: { department: 'General Medicine', specialist: 'General Physician', code: 'GEN MED', icon: 'stethoscope', tone: 'gen' },
  urgent: { department: 'Emergency & Triage', specialist: 'Emergency / triage team', code: 'ER', icon: 'siren', tone: 'er' },
};

/* ---------------------------------------------------------------------
   DOCTOR_DIRECTORY — the doctor each department sends patients to,
   shown as "Doctor to see" on the result screen and the report.
   SAMPLE NAMES for the prototype: replace them with the hospital's own
   doctors, one per department key of SPECIALIST_MAPPING. Urgent patients
   are seen by whichever emergency doctor is on duty, so that department
   has no fixed name. The doctor is saved with each assessment, so later
   changes here do not alter past reports.
   --------------------------------------------------------------------- */

const DOCTOR_DIRECTORY = {
  cardiovascular: { name: 'Dr. Anjali Mehta' },
  respiratory: { name: 'Dr. Rohan Kulkarni' },
  musculoskeletal: { name: 'Dr. Sameer Deshpande' },
  dermatological: { name: 'Dr. Priya Nair' },
  neurological: { name: 'Dr. Vikram Rao' },
  gastrointestinal: { name: 'Dr. Farah Siddiqui' },
  general: { name: 'Dr. Meera Iyer' },
  urgent: null,
};

/* ---------------------------------------------------------------------
   PLAIN_LANGUAGE — wording for the "In simple words" summary on the
   result screen and the report (section 12a). Written for patients and
   families: no medical jargon, never "you have", no medicines.
   --------------------------------------------------------------------- */

const PLAIN_LANGUAGE = {
  specialists: {
    cardiovascular: 'a heart specialist', respiratory: 'a lung and breathing specialist', musculoskeletal: 'a bone and joint specialist',
    dermatological: 'a skin specialist', neurological: 'a brain and nerve specialist', gastrointestinal: 'a stomach and digestion specialist',
    general: 'a general doctor', urgent: 'the emergency team',
  },
  areas: {
    cardiovascular: 'the heart', respiratory: 'the lungs and breathing', musculoskeletal: 'the bones, joints or muscles',
    dermatological: 'the skin', neurological: 'the brain or nerves', gastrointestinal: 'the stomach and digestion', general: '',
  },
  // Match strength in words, as symptom checkers show it.
  matchBands: [
    { min: 60, label: 'strong match' },
    { min: 35, label: 'moderate match' },
    { min: 0, label: 'fair match' },
  ],
  sure: {
    higher: 'The system is fairly sure about this.',
    moderate: 'The system is somewhat sure about this.',
    low: 'The system is not sure, so a general check-up comes first.',
  },
  notDiagnosis: 'This is not a diagnosis. Only a doctor can confirm what it is.',
  waiting: 'If the symptoms get worse while waiting, tell the staff straight away.',
  urgentWaiting: 'The patient should not wait in the general queue.',
};

/* ---------------------------------------------------------------------
   RED_FLAG_RULES — conservative safety escalation.
   Evaluated on raw features, where null means "not asked / not known".
   urgent   → stop classification, follow the emergency / triage protocol
   priority → keep the routing, but ask the department to see the
              patient promptly
   --------------------------------------------------------------------- */

const RED_FLAG_RULES = [
  { id: 'severe_chest_pain', level: 'urgent', label: 'Severe chest pain or pressure',
    when: (f) => f.severeChestSign === 1
      || ((f.chestPain === 1 || f.chestDiscomfort === 1) && f.chestPainScore !== null && f.chestPainScore >= 7) },
  { id: 'severe_breathing', level: 'urgent', label: 'Severe difficulty breathing',
    when: (f) => f.breathingDifficulty === 3 },
  { id: 'loss_of_consciousness', level: 'urgent', label: 'Fainting or loss of consciousness',
    when: (f) => f.lossOfConsciousness === 1 },
  { id: 'major_bleeding', level: 'urgent', label: 'Heavy or uncontrolled bleeding',
    when: (f) => f.majorBleeding === 1 || f.giBloodLarge === 1 },
  { id: 'sudden_neurological', level: 'urgent', label: 'Sudden one-sided weakness or numbness, facial drooping or speech difficulty',
    when: (f) => (f.suddenFocalSign === 1 || f.suddenSpeechSign === 1)
      || (f.suddenOnsetNeuro !== 0 && (f.focalOneSided === 1 || f.faceDroop === 1 || f.speechDifficulty === 1))
      || (f.suddenOnsetNeuro === 1 && (f.limbWeakness === 1 || (f.numbness === 1 && f.singleLimb === 1))) },
  { id: 'sudden_confusion_vision_balance', level: 'urgent', label: 'Sudden confusion, vision change or loss of balance',
    when: (f) => f.suddenOnsetNeuro === 1 && (f.confusion === 1 || f.visionChanges === 1 || f.imbalance === 1) },
  { id: 'thunderclap_headache', level: 'urgent', label: 'Sudden, very severe headache',
    when: (f) => f.suddenSevereHeadache === 1 },
  { id: 'recent_seizure', level: 'urgent', label: 'Seizure within the last 24 hours',
    when: (f) => f.seizureToday === 1 || (f.seizureRecent === 1 && f.firstSeizure !== 0) },
  { id: 'fever_stiff_neck', level: 'urgent', label: 'Fever with a stiff neck',
    when: (f) => f.fever === 1 && f.stiffNeck === 1 },
  { id: 'allergic_swelling', level: 'urgent', label: 'Swelling of the face or lips, or skin symptoms with difficulty breathing',
    when: (f) => f.facialSwelling === 1 || f.allergyBreathing === 1 },
  { id: 'bladder_bowel_loss', level: 'urgent', label: 'Back pain with new loss of bladder or bowel control',
    when: (f) => f.bladderBowelLoss === 1 },

  { id: 'chest_pain_features', level: 'priority', label: 'Chest pain or discomfort with sweating, dizziness, palpitations, breathlessness or spreading pain',
    when: (f) => (f.chestPain === 1 || f.chestDiscomfort === 1)
      && (f.sweating === 1 || f.dizziness === 1 || f.palpitations === 1 || f.breathingDifficulty >= 2 || f.radiatingChestPain === 1) },
  { id: 'severe_pain', level: 'priority', label: 'Severe pain (7 or more out of 10)',
    when: (f) => (f.painScore !== null && f.painScore >= 7 && !(f.chestPainScore !== null && f.chestPainScore >= 7))
      || f.severeOtherPain === 1 },
  { id: 'possible_fracture', level: 'priority', label: 'Possible significant injury: deformity, or unable to move or bear weight',
    when: (f) => f.suspectedFracture === 1 },
  { id: 'high_temperature', level: 'priority', label: 'High temperature recorded (39 °C / 102.2 °F or above)',
    when: (f) => f.highFever === 1 },
  { id: 'dehydration_risk', level: 'priority', label: 'Frequent vomiting or loose motions',
    when: (f) => f.frequentVomiting === 1 || f.frequentDiarrhoea === 1 },
  { id: 'blood_reported', level: 'priority', label: 'Blood reported in cough, stool or vomit',
    when: (f) => (f.coughBlood === 1 || f.giBlood === 1) && f.giBloodLarge !== 1 },
  { id: 'gradual_neurological', level: 'priority', label: 'One-sided weakness, facial drooping or speech difficulty (not sudden)',
    when: (f) => f.suddenOnsetNeuro === 0 && (f.focalOneSided === 1 || f.faceDroop === 1 || f.speechDifficulty === 1) },
  { id: 'headache_neuro_signs', level: 'priority', label: 'Headache with numbness, weakness or vision changes',
    when: (f) => f.headache === 1 && (f.numbness === 1 || f.visionChanges === 1) && f.suddenSevereHeadache !== 1 },
  { id: 'known_seizure_recent', level: 'priority', label: 'Recent seizure in a patient with a known seizure history',
    when: (f) => f.seizureRecent === 1 && f.firstSeizure === 0 && f.seizureToday !== 1 },
  { id: 'right_lower_abdominal', level: 'priority', label: 'Lower or lower-right abdominal pain with fever or vomiting',
    when: (f) => (f.rightLowerAbdominal === 1 && (f.fever === 1 || f.nauseaVomiting === 1)) || (f.lowerAbdominal === 1 && f.fever === 1) },
  { id: 'possible_obstruction', level: 'priority', label: 'Abdominal pain with vomiting and constipation or bloating',
    when: (f) => f.abdominalPain === 1 && f.nauseaVomiting === 1 && (f.constipation === 1 || f.bloating === 1) },
  { id: 'hot_joint_fever', level: 'priority', label: 'Red, warm joint with fever',
    when: (f) => f.jointRedWarm === 1 && f.fever === 1 },
  { id: 'exertional_faintness', level: 'priority', label: 'Dizziness or near-fainting during physical effort',
    when: (f) => f.exertionalSymptoms === 1 && (f.dizziness === 1 || f.presyncope === 1) && f.chestPain !== 1 && f.chestDiscomfort !== 1 },
  { id: 'sudden_bilateral_numbness', level: 'priority', label: 'Sudden numbness or tingling in both hands or feet',
    when: (f) => f.suddenOnsetNeuro === 1 && f.peripheralSymptoms === 1 },
  { id: 'recent_limb_weakness', level: 'priority', label: 'Weakness in both arms or legs that began in the last few days',
    when: (f) => f.muscleWeakness === 1 && f.durationShort === 1 },
  { id: 'first_seizure', level: 'priority', label: 'First seizure (not in the last 24 hours)',
    when: (f) => f.seizure === 1 && f.firstSeizure === 1 && f.seizureRecent !== 1 },
  { id: 'new_headache_older', level: 'priority', label: 'First headache of a new kind in a patient aged 45 or over',
    when: (f) => f.headache === 1 && f.firstHeadache === 1 && f.ageOver45 === 1 },
  { id: 'dizziness_vision', level: 'priority', label: 'Dizziness with blurred or double vision',
    when: (f) => f.dizziness === 1 && f.visionChanges === 1 },
  { id: 'recent_constant_dizziness_older', level: 'priority', label: 'Constant dizziness that began recently in a patient aged 45 or over',
    when: (f) => f.constantDizziness === 1 && f.ageOver45 === 1 && f.durationShort === 1 },
  { id: 'older_lower_limb_injury', level: 'priority', label: 'Fall or injury to the hip or leg in a patient aged 65 or over',
    when: (f) => f.injury === 1 && f.ageOver65 === 1 && f.lowerLimb === 1 && f.suspectedFracture !== 1 },
  { id: 'pleuritic_breathless', level: 'priority', label: 'Chest pain on breathing in, with breathlessness, that started today',
    when: (f) => f.pleuriticPain === 1 && f.breathingDifficulty >= 1 && f.acuteOnset === 1 },
  { id: 'new_breathlessness_no_cough', level: 'priority', label: 'Moderate breathlessness without a cough that started within 24 hours',
    when: (f) => f.breathingDifficulty >= 2 && f.cough === 0 && f.durationBand === 1 },
  { id: 'fever_headache_signs', level: 'priority', label: 'Headache with fever and light sensitivity, vomiting or confusion',
    when: (f) => f.headache === 1 && f.fever === 1 && (f.photophobia === 1 || f.nauseaVomiting === 1 || f.confusion === 1) && f.stiffNeck !== 1 },
];

/* ---------------------------------------------------------------------
   CONSISTENCY_RULES — contradictory responses lower model confidence.
   --------------------------------------------------------------------- */

const CONSISTENCY_RULES = [
  { id: 'pain_rated_zero', severity: 'major', penalty: 0.25,
    when: (f, ctx) => ['pain', 'joint_limb'].includes(ctx.complaint) && f.painScore === 0 && !ctx.painNotReported,
    message: 'The main complaint is pain, but the pain was rated 0 out of 10 (no current pain).' },
  { id: 'headache_rated_zero', severity: 'minor', penalty: 0.12,
    when: (f, ctx) => ctx.complaint === 'neuro' && f.headache === 1 && f.painScore === 0,
    message: 'A headache was reported, but it was rated 0 out of 10.' },
  { id: 'respiratory_without_symptoms', severity: 'major', penalty: 0.25,
    when: (f, ctx) => ctx.complaint === 'respiratory' && f.cough === 0 && !f.breathingDifficulty && f.wheezing !== 1 && f.chestTightness !== 1,
    message: 'A cough / respiratory complaint was recorded, but no cough, breathing difficulty, wheezing or chest tightness was reported.' },
  { id: 'fever_normal_temperature', severity: 'minor', penalty: 0.1,
    when: (f, ctx) => ctx.complaint === 'fever' && f.temperatureC !== null && f.temperatureC < 37.5,
    message: 'Fever was reported, but the recorded temperature is within the normal range.' },
  { id: 'skin_without_findings', severity: 'minor', penalty: 0.1,
    when: (f, ctx) => ctx.complaint === 'skin' && f.itching === 0 && f.redness === 0 && f.skinSpreading === 0 && f.rash === 1,
    message: 'A rash was reported without itching, redness or spreading. Please confirm the description with the patient.' },
];

/* ---------------------------------------------------------------------
   General care information. Deliberately conservative: no medicines,
   dosages, treatment protocols or procedures.
   --------------------------------------------------------------------- */

const CARE_INFORMATION = {
  standard: [
    'General care and medication information should be provided by qualified clinical staff.',
    'This report does not contain prescriptions, medicines or dosages.',
    'Ask the patient to bring previous prescriptions, test reports and a list of current medicines to the consultation.',
    'If symptoms worsen while the patient is waiting, inform the triage or nursing staff immediately.',
  ],
  infectionControl: 'Follow the hospital’s infection-control guidance for patients with cough or fever while they wait.',
  urgent: [
    'Follow the hospital’s emergency / clinical triage protocol immediately.',
    'Do not send the patient to wait in the general outpatient queue.',
    'All assessment, medication and treatment decisions rest with the treating clinical team.',
  ],
};

const DISCLAIMERS = {
  short: 'Decision-support tool only. This preliminary assessment does not replace professional medical diagnosis or treatment. Final diagnosis, prescription and treatment must be determined by a qualified healthcare professional.',
  report: 'This system is a decision-support tool only. The generated assessment does not constitute a confirmed medical diagnosis or prescription. Final diagnosis and treatment must be confirmed by a qualified healthcare professional.',
  urgentProtocol: 'Please follow the hospital’s emergency / clinical triage protocol immediately.',
  privacy: 'Prototype assessment data is stored locally in this browser.',
};

const ANALYSIS_STEPS = [
  { id: 'validate', label: 'Patient data validated' },
  { id: 'structure', label: 'Symptoms structured' },
  { id: 'features', label: 'Assessment features prepared' },
  { id: 'predict', label: 'Evaluating symptom patterns', apiLabel: 'Running the trained ML model' },
  { id: 'route', label: 'Matching appropriate speciality' },
];

/* ---------------------------------------------------------------------
   DEMO_CASES — for presentations and testing only.
   `bodyMap` picks are pre-selected on the body map; cases without it open
   the list of complaints instead. The remaining answers are pre-selected
   question by question.
   --------------------------------------------------------------------- */

const DEMO_CASES = [
  {
    id: 'demo-cardio', group: 'Expected routing', label: 'Cardiovascular-like pattern', expect: 'Cardiology', expectCondition: 'angina',
    patient: { name: 'Rahul Sharma', age: '52', gender: 'male', contact: '98200 14567', complaint: 'pain', description: 'Chest discomfort since this morning while climbing stairs.' },
    bodyMap: { selections: [{ symptom: 'chest_pain', area: 'chest', pain: 6 }] },
    answers: {
      pain_location: 'chest', chest_breathing: 'moderate', chest_dizziness: 'yes', chest_sweating: 'yes', chest_pattern: 'exertion',
      chest_onset: 'today', chest_score: 6, chest_associated: ['radiating'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-resp', group: 'Expected routing', label: 'Respiratory pattern', expect: 'Pulmonology', expectCondition: 'bronchitis',
    patient: { name: 'Ananya Iyer', age: '34', gender: 'female', contact: '98765 43210', complaint: 'respiratory', description: 'Cough with fever for about five days.' },
    bodyMap: { selections: [{ symptom: 'cough', area: 'chest' }, { symptom: 'fever', area: 'general' }] },
    answers: {
      resp_cough: 'yes', resp_cough_type: 'phlegm', resp_breathing: 'moderate', resp_wheeze: 'no', resp_fever: 'yes',
      resp_chest: 'no', resp_duration: '4to7d', resp_background: ['contact'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-msk', group: 'Expected routing', label: 'Musculoskeletal pattern', expect: 'Orthopaedics', expectCondition: 'sprain',
    patient: { name: 'Vikram Patil', age: '41', gender: 'male', contact: '99300 11223', complaint: 'joint_limb', description: 'Twisted the right knee while playing football.' },
    bodyMap: { selections: [{ symptom: 'limb_pain', area: 'knee_r', pain: 6 }, { symptom: 'limb_swelling', area: 'knee_r' }, { symptom: 'limb_injury', area: 'knee_r' }] },
    answers: {
      joint_site: 'knee', joint_swelling: 'yes', joint_injury: 'yes', joint_deformity: 'no', joint_movement: 'yes',
      joint_associated: ['none'], joint_duration: '1to3d', joint_score: 6, safety_check: ['none'],
    },
  },
  {
    id: 'demo-derm', group: 'Expected routing', label: 'Dermatology pattern', expect: 'Dermatology', expectCondition: 'fungal_infection',
    patient: { name: 'Sneha Kulkarni', age: '27', gender: 'female', contact: '97690 55821', complaint: 'skin', description: 'Itchy red rash on both forearms.' },
    bodyMap: { selections: [{ symptom: 'rash', area: 'skin' }, { symptom: 'itching', area: 'skin' }, { symptom: 'skin_here', area: 'forearm_r' }, { symptom: 'skin_here', area: 'forearm_l' }] },
    answers: {
      skin_type: 'rash', skin_itching: 'yes', skin_redness: 'yes', skin_spreading: 'yes', skin_area: 'arms',
      skin_duration: '1to4w', skin_associated: ['none'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-gi', group: 'Expected routing', label: 'Gastrointestinal pattern', expect: 'Gastroenterology', expectCondition: 'gerd',
    patient: { name: 'Imran Shaikh', age: '38', gender: 'male', contact: '98211 70345', complaint: 'digestive', description: 'Burning upper stomach pain after meals.' },
    bodyMap: { selections: [{ symptom: 'stomach_pain', area: 'abd_um', pain: 5 }, { symptom: 'acidity', area: 'abd_um' }, { symptom: 'nausea', area: 'abd_um' }] },
    answers: {
      gi_main: 'pain', abd_location: 'upper_middle', abd_meals: 'worse', gi_associated: ['nausea', 'acidity'],
      gi_duration: '4to7d', abd_score: 5, safety_check: ['none'],
    },
  },
  {
    id: 'demo-neuro', group: 'Expected routing', label: 'Neurological pattern', expect: 'Neurology', expectCondition: 'migraine',
    patient: { name: 'Meera Joshi', age: '45', gender: 'female', contact: '99870 23456', complaint: 'neuro', description: 'Recurring one-sided headaches.' },
    bodyMap: { selections: [{ symptom: 'headache', area: 'head', pain: 6 }] },
    answers: {
      neuro_main: 'headache', head_sudden: 'no', head_character: 'throbbing', head_associated: ['nausea', 'light'],
      head_frequency: 'occasional', head_duration: 'lt24h', head_score: 6, safety_check: ['none'],
    },
  },
  {
    id: 'demo-general', group: 'Expected routing', label: 'General / inconclusive pattern', expect: 'General Medicine',
    patient: { name: 'Arjun Mehta', age: '29', gender: 'male', contact: '90040 67890', complaint: 'other', description: 'Feels generally unwell; not sure what is wrong.' },
    answers: {
      other_area: 'whole', other_symptoms: ['tired', 'headache', 'stomach'], other_duration: '1to3d', other_severity: 'mild', safety_check: ['none'],
    },
  },
  {
    id: 'demo-dengue', group: 'Condition examples', label: 'High fever with rash and body aches', expect: 'General Medicine', expectCondition: 'dengue',
    patient: { name: 'Farah Khan', age: '31', gender: 'female', contact: '98330 41276', complaint: 'fever', description: 'High fever for two days with body aches and a rash.' },
    bodyMap: { selections: [{ symptom: 'fever', area: 'general' }, { symptom: 'headache', area: 'head' }, { symptom: 'rash', area: 'skin' }] },
    answers: {
      fever_duration: '1to3d', fever_measured: 'yes', fever_temp: { value: 103, unit: 'F' }, fever_cough: 'no', fever_chills: 'no',
      fever_rash: 'yes', fever_weakness: 'yes', fever_associated: ['headache', 'body_aches'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-asthma', group: 'Condition examples', label: 'Wheeze with known asthma', expect: 'Pulmonology', expectCondition: 'asthma',
    patient: { name: 'Rohan Gupta', age: '24', gender: 'male', contact: '99201 56743', complaint: 'respiratory', description: 'Wheezing and chest tightness since last night.' },
    bodyMap: { selections: [{ symptom: 'wheezing', area: 'chest' }, { symptom: 'cough', area: 'chest' }, { symptom: 'chest_tight', area: 'chest' }] },
    answers: {
      resp_cough: 'yes', resp_cough_type: 'dry', resp_breathing: 'moderate', resp_wheeze: 'yes', resp_fever: 'no',
      resp_chest: 'yes', resp_duration: 'lt24h', resp_background: ['asthma'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-sciatica', group: 'Condition examples', label: 'Back pain shooting down the leg', expect: 'Orthopaedics', expectCondition: 'sciatica',
    patient: { name: 'Lakshmi Menon', age: '48', gender: 'female', contact: '98450 33912', complaint: 'pain', description: 'Lower back pain going down the left leg for two weeks.' },
    bodyMap: { selections: [{ symptom: 'back_pain', area: 'lower_back', pain: 6 }, { symptom: 'sciatica_pain', area: 'lower_back' }] },
    answers: {
      pain_location: 'back', back_area: 'lower', back_radiation: 'yes', back_injury: 'no', back_numbness: 'yes', back_bladder: 'no',
      back_duration: '1to4w', back_score: 6, safety_check: ['none'],
    },
  },
  {
    id: 'demo-urgent', group: 'Safety behaviour', label: 'Urgent warning signs', expect: 'Emergency & Triage',
    patient: { name: 'Suresh Nair', age: '63', gender: 'male', contact: '98190 33445', complaint: 'pain', description: 'Sudden crushing chest pain.' },
    bodyMap: { selections: [{ symptom: 'chest_pain', area: 'chest', pain: 9 }] },
    answers: {
      pain_location: 'chest', chest_breathing: 'severe', chest_dizziness: 'yes', chest_sweating: 'yes', chest_pattern: 'exertion',
      chest_onset: 'hours', chest_score: 9, chest_associated: ['radiating'], safety_check: ['none'],
    },
  },
  {
    id: 'demo-contradiction', group: 'Safety behaviour', label: 'Contradictory responses', expect: 'General Medicine',
    patient: { name: 'Kavita Rao', age: '36', gender: 'female', contact: '98670 12890', complaint: 'respiratory', description: 'Booked for a cough, but reports feeling fine now.' },
    answers: {
      resp_cough: 'no', resp_breathing: 'none', resp_wheeze: 'no', resp_fever: 'no', resp_chest: 'no',
      resp_duration: '1to3d', resp_background: ['none'], safety_check: ['none'],
    },
  },
];
