/* =====================================================================
   15. PRINT / EXPORT
   ---------------------------------------------------------------------
   Printing uses the browser's print dialog (window.print), which also
   offers "Save as PDF". The @media print rules hide the app chrome and
   lay the report out for A4 paper.
   ===================================================================== */

function printReport() {
  const assessment = state.assessment;
  if (!assessment.report) createReportForCurrentAssessment();
  if (!assessment.report) {
    showToast('Run the assessment before printing a report.', 'warning');
    return;
  }
  if (state.currentScreen !== 'report') navigateTo('report', { focus: false });
  assessment.report.lastPrintedAt = new Date().toISOString();
  AssessmentRepository.save(assessment);
  // Let the report finish rendering before the dialog opens.
  window.setTimeout(() => {
    window.print();
    if (isEmbedded()) {
      showToast('If no print dialog opened, this preview blocks printing. Open index.html directly in your browser to print or save as PDF.', 'warning');
    }
  }, 60);
}

/* True when the app runs inside another page (for example a file preview),
   where printing and browser storage may be restricted. */
function isEmbedded() {
  try {
    return window.self !== window.top;
  } catch (error) {
    return true;
  }
}
