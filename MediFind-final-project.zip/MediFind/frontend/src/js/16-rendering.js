/* =====================================================================
   16. RENDERING
   ---------------------------------------------------------------------
   Screens are rendered from state with the escaped html`` template, so
   patient-entered text is always treated as text.
   ===================================================================== */

/* ---------- Icons and brand mark ---------- */

function icon(name, className = '') {
  const body = ICONS[name] || ICONS['circle-help'];
  return raw(`<svg class="icon${className ? ` ${className}` : ''}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${body}</svg>`);
}

/* MediFind logo. The pictures live once in the page's hidden asset sprite
   (build.py); these helpers show them with <use>. The view boxes are the
   picture sizes, filled in at build time. */
const BRAND_LOGO = {
  logo: { id: 'mf-logo', viewBox: '{{LOGO_VIEWBOX}}' },
  light: { id: 'mf-logo-light', viewBox: '{{LOGO_VIEWBOX}}' }, // white wordmark, for dark screens
  mark: { id: 'mf-mark', viewBox: '{{MARK_VIEWBOX}}' },
};

function brandLogo(className = '', kind = 'logo') {
  const asset = BRAND_LOGO[kind] || BRAND_LOGO.logo;
  return raw(`<svg class="${escapeHTML(className)}" viewBox="${asset.viewBox}" role="img" aria-label="${escapeHTML(APP_CONFIG.shortName)}" focusable="false"><use href="#${asset.id}"/></svg>`);
}

/* ---------- Generic components ---------- */

function renderEmptyState({ icon: iconName, title, text, action }) {
  return html`
    <div class="empty">
      <div class="empty__icon">${icon(iconName)}</div>
      <h2 class="empty__title">${title}</h2>
      ${text ? html`<p class="empty__text">${text}</p>` : ''}
      ${action ? html`<button type="button" class="btn btn-primary" data-action="${action.action}" ${action.nav ? raw(`data-nav-target="${escapeHTML(action.nav)}"`) : ''}>${action.icon ? icon(action.icon) : ''}<span>${action.label}</span></button>` : ''}
    </div>`;
}

function showToast(message, tone = 'neutral') {
  const region = document.getElementById('toast-region');
  if (!region) return;
  const toast = document.createElement('div');
  toast.className = `toast toast--${tone}`;
  const iconName = { danger: 'siren', warning: 'triangle-alert', neutral: 'circle-check' }[tone] || 'info';
  toast.innerHTML = html`${icon(iconName)}<span>${message}</span>`.toString();
  region.appendChild(toast);
  while (region.children.length > 3) region.removeChild(region.firstElementChild);
  window.setTimeout(() => {
    toast.classList.add('is-leaving');
    window.setTimeout(() => toast.remove(), 250);
  }, tone === 'danger' ? 5000 : 3600);
}

/* ---------- Modal ---------- */

let modalState = null;

function openModal({ title, text, actions = [], tone = 'warning', icon: iconName = 'triangle-alert' }) {
  closeModal({ restoreFocus: false });
  const root = document.getElementById('modal-root');
  modalState = { actions, returnFocus: document.activeElement };
  root.innerHTML = html`
    <div class="modal-backdrop" data-modal-backdrop>
      <div class="modal modal--${tone}" role="alertdialog" aria-modal="true" aria-labelledby="modal-title" aria-describedby="modal-text">
        <div class="modal__icon">${icon(iconName)}</div>
        <h2 class="modal__title" id="modal-title">${title}</h2>
        <p class="modal__text" id="modal-text">${text}</p>
        <div class="modal__actions">
          ${actions.map((action, index) => html`<button type="button" class="btn btn-${action.variant || 'secondary'}" data-modal-action="${index}" ${action.autofocus ? raw('data-autofocus') : ''}>${action.label}</button>`)}
        </div>
      </div>
    </div>`.toString();
  document.body.classList.add('has-overlay');
  const focusTarget = root.querySelector('[data-autofocus]') || root.querySelector('button');
  if (focusTarget) focusTarget.focus();
}

function closeModal({ restoreFocus = true } = {}) {
  const root = document.getElementById('modal-root');
  if (!root || !root.innerHTML) return;
  const returnFocus = modalState && modalState.returnFocus;
  root.innerHTML = '';
  modalState = null;
  if (!document.getElementById('drawer-root').innerHTML) document.body.classList.remove('has-overlay');
  if (restoreFocus && returnFocus && document.contains(returnFocus)) returnFocus.focus();
}

function handleModalAction(index) {
  if (!modalState) return;
  const action = modalState.actions[index];
  closeModal({ restoreFocus: !(action && action.onClick) });
  if (action && typeof action.onClick === 'function') action.onClick();
}

/* ---------- Drawer: "Why was this recommended?" ---------- */

let drawerReturnFocus = null;

function openWhyDrawer() {
  const root = document.getElementById('drawer-root');
  drawerReturnFocus = document.activeElement;
  root.innerHTML = html`
    <div class="drawer-layer">
      <div class="drawer-backdrop" data-action="close-drawer"></div>
      <aside class="drawer" role="dialog" aria-modal="true" aria-labelledby="drawer-title">
        <header class="drawer__head">
          <h2 class="drawer__title" id="drawer-title">Why was this recommended?</h2>
          <button type="button" class="icon-button" data-action="close-drawer" aria-label="Close">${icon('x')}</button>
        </header>
        <div class="drawer__body">${renderWhyContent()}</div>
      </aside>
    </div>`.toString();
  document.body.classList.add('has-overlay');
  requestAnimationFrame(() => {
    const layer = root.querySelector('.drawer-layer');
    if (layer) layer.classList.add('is-open');
  });
  const close = root.querySelector('.drawer__head .icon-button');
  if (close) close.focus();
}

function closeDrawer({ restoreFocus = true } = {}) {
  const root = document.getElementById('drawer-root');
  if (!root || !root.innerHTML) return;
  root.innerHTML = '';
  if (!document.getElementById('modal-root').innerHTML) document.body.classList.remove('has-overlay');
  if (restoreFocus && drawerReturnFocus && document.contains(drawerReturnFocus)) drawerReturnFocus.focus();
  drawerReturnFocus = null;
}

function renderWhyContent() {
  const a = state.assessment;
  const p = a.prediction;
  const r = a.recommendation;
  if (!p || !r) return html`<p>Run the assessment to see how the recommendation was made.</p>`;

  if (isUrgentAssessment(a)) {
    return html`
      <section class="why-block">
        <p class="why-lead">This patient was routed to <strong>${r.department}</strong> because ${a.safety.urgent.length
          ? `the assessment recorded potential urgent symptoms${a.urgentFlag ? ', and the patient was marked for immediate clinical evaluation' : ''}`
          : 'reception flagged the patient as urgent and marked them for immediate clinical evaluation'}.</p>
        ${a.safety.urgent.length ? html`<h3 class="why-title">Warning signs reported</h3><ul class="why-list why-list--danger">${a.safety.urgent.map((flag) => html`<li>${icon('siren')}<span>${flag.label}</span></li>`)}</ul>` : ''}
        <p class="why-note">Urgent warning signs take priority. The system does not show a predicted condition or classification for urgent cases; the clinical team assesses the patient directly.</p>
      </section>
      ${renderTechnicalDetails(a)}`;
  }

  const topShares = p.categoryScores.filter((item) => item.share > 0).slice(0, 3);
  const otherShare = 100 - topShares.reduce((sum, item) => sum + item.share, 0);
  const factors = p.confidenceFactors;
  const model = isModelResult(p);
  const lead = p.isInconclusive
    ? html`<p class="why-lead">${INCONCLUSIVE_RESULT.message}</p>`
    : model
      ? html`<p class="why-lead">This recommendation was generated because the trained machine-learning model gave the <strong>${CATEGORIES[p.topCategoryId].label.toLowerCase()}</strong> category the highest probability (${p.modelFactors ? p.modelFactors.probability : p.confidence}%), which maps to <strong>${r.department}</strong> (${r.specialist}).</p>`
      : html`<p class="why-lead">This recommendation was generated because the reported symptom pattern most strongly matched the <strong>${CATEGORIES[p.topCategoryId].label.toLowerCase()}</strong> category, which maps to <strong>${r.department}</strong> (${r.specialist}).</p>`;
  const symptoms = p.isInconclusive ? p.consideredSymptoms : p.matchedSymptoms;
  const symptomsTitle = p.isInconclusive ? 'Symptoms considered' : model ? 'Answers that pushed the model towards this result' : 'Matched features';
  const noSymptoms = model && !p.isInconclusive ? 'The model weighed the answers together; no single symptom stood out.' : 'No specific symptoms were reported.';

  return html`
    <section class="why-block">
      ${lead}
      <h3 class="why-title">${symptomsTitle}</h3>
      ${symptoms.length
        ? html`<ul class="why-list">${symptoms.slice(0, 8).map((item) => html`<li>${icon('check')}<span>${item.label}</span></li>`)}</ul>`
        : html`<p class="why-note">${noSymptoms}</p>`}
      ${!p.isInconclusive && p.firedRules.length ? html`
        <h3 class="why-title">Pattern rules matched</h3>
        <ul class="why-list">${p.firedRules.map((rule) => html`<li>${icon('git-branch')}<span>${rule.label}</span></li>`)}</ul>` : ''}
    </section>

    ${renderWhyCondition(p)}

    ${topShares.length ? html`
      <section class="why-block">
        <h3 class="why-title">Category match</h3>
        <ul class="share-list">
          ${topShares.map((item) => html`
            <li class="share-row">
              <span class="share-row__label">${item.label}</span>
              <span class="share-row__bar"><span style="width: ${item.share}%"></span></span>
              <span class="share-row__value">${item.share}%</span>
            </li>`)}
          ${otherShare > 0 ? html`<li class="share-row share-row--muted"><span class="share-row__label">Other categories</span><span class="share-row__bar"><span style="width: ${otherShare}%"></span></span><span class="share-row__value">${otherShare}%</span></li>` : ''}
        </ul>
        <p class="why-note">${model
          ? `${MODEL_TEXT.shareNote} ${MODEL_TEXT.confidenceNote}`
          : `Share of the total symptom-match score. Model confidence (${p.confidence}%) also accounts for how clearly the top category leads, how complete the responses are and how well the answers fit one condition.`}</p>
      </section>` : ''}

    ${model && p.modelFactors ? renderModelFactors(p) : ''}

    ${factors ? html`
      <section class="why-block">
        <h3 class="why-title">What shaped the model confidence</h3>
        <dl class="factor-list">
          ${renderFactor('Pattern strength', factors.strength, 'How strongly the symptoms match the top category')}
          ${renderFactor('Separation', factors.separation, 'How clearly the top category leads the next one')}
          ${renderFactor('Response completeness', factors.completeness, 'Answers given with a definite response')}
          ${Number.isFinite(factors.conditionFit) ? renderFactor('Condition fit', factors.conditionFit, 'How well the answers match one specific condition') : ''}
        </dl>
        ${p.inconsistencies.length ? html`
          <div class="notice notice--warning">${icon('triangle-alert')}<div><p><strong>Confidence reduced for contradictory responses</strong></p><ul>${p.inconsistencies.map((item) => html`<li>${item.message}</li>`)}</ul></div></div>` : ''}
      </section>` : ''}

    ${renderTechnicalDetails(a)}`;
}

/* "What shaped the model confidence" for results from the trained model. */
function renderModelFactors(p) {
  const f = p.modelFactors;
  const topLabel = CATEGORIES[p.topCategoryId] ? CATEGORIES[p.topCategoryId].label.toLowerCase() : 'top';
  const notes = [];
  if (f.penalty) notes.push(`Lowered by ${f.penalty} points for contradictory answers.`);
  if (f.limitedByRules) notes.push(`Limited to ${f.rulesConfidence}%: the built-in rules found the evidence too weak or mixed to decide, and ${f.limitedBecause === 'contradictions' ? 'some answers contradict each other' : 'the model was less than 90% sure'}.`);
  if (f.capped) notes.push(`Capped at ${CONFIDENCE_THRESHOLDS.cap}%: a result is never shown as certain.`);
  if (f.noEvidence) notes.push('No symptom evidence was recorded, so no department is chosen.');
  return html`
    <section class="why-block">
      <h3 class="why-title">What shaped the model confidence</h3>
      <dl class="factor-list">
        ${renderFactor('Model probability', f.probability / 100, `The trained model’s probability for the ${topLabel} category`)}
        ${renderFactor('Confidence shown', p.confidence / 100, 'After the safeguards listed below')}
      </dl>
      ${notes.length
        ? html`<ul class="why-list">${notes.map((note) => html`<li>${icon('info')}<span>${note}</span></li>`)}</ul>`
        : html`<p class="why-note">No safeguard changed the model’s probability.</p>`}
      ${p.inconsistencies.length ? html`
        <div class="notice notice--warning">${icon('triangle-alert')}<div><p><strong>Confidence reduced for contradictory responses</strong></p><ul>${p.inconsistencies.map((item) => html`<li>${item.message}</li>`)}</ul></div></div>` : ''}
    </section>`;
}

/* "Why" section for the predicted condition (stage 2 of the engine). */
function renderWhyCondition(p) {
  if (p.isInconclusive) {
    const considered = Array.isArray(p.consideredConditions) ? p.consideredConditions : [];
    return html`
      <section class="why-block">
        <h3 class="why-title">Predicted condition</h3>
        <p class="why-text">${INCONCLUSIVE_RESULT.conditionMessage}</p>
        ${considered.length
          ? html`<ul class="why-list">${considered.map((item) => html`<li>${icon('microscope')}<span>${item.name} <span class="why-list__meta">${item.department}</span></span></li>`)}</ul>`
          : html`<p class="why-note">No condition had enough supporting answers to be listed.</p>`}
      </section>`;
  }
  if (!p.predictedConditionId) return ''; // saved before condition prediction existed
  const categoryLabel = CATEGORIES[p.topCategoryId] ? CATEGORIES[p.topCategoryId].label.toLowerCase() : 'matched';
  const evidence = Array.isArray(p.conditionEvidence) ? p.conditionEvidence : [];
  const against = Array.isArray(p.conditionAgainst) ? p.conditionAgainst : [];
  const differentials = Array.isArray(p.differentials) ? p.differentials : [];

  if (p.conditionIsFallback) {
    const tied = p.conditionTie ? differentials.filter((item) => Number.isFinite(item.likelihood)) : [];
    return html`
      <section class="why-block">
        <h3 class="why-title">Predicted condition</h3>
        <p class="why-text">${p.conditionTie
          ? `The answers fit ${tied.slice(0, 2).map((item) => item.name).join(' and ')} almost equally well, so no single condition is named.`
          : `No single ${categoryLabel} condition had enough supporting answers to be named.`} The system shows <strong>${p.predictedCondition}</strong>.</p>
        ${tied.length ? html`
          <ul class="share-list share-list--wide">${tied.map((item) => html`
            <li class="share-row share-row--muted"><span class="share-row__label">${item.short || item.name}</span><span class="share-row__bar"><span style="width: ${item.likelihood}%"></span></span><span class="share-row__value">${item.likelihood}%</span></li>`)}
          </ul>
          <p class="why-note">${CONDITION_SETTINGS.helperText}</p>`
          : differentials.length ? html`<p class="why-note">Weaker matches: ${differentials.map((item) => item.name).join(', ')}.</p>` : ''}
      </section>`;
  }

  const rows = [{ name: p.conditionShort || p.predictedCondition, likelihood: p.conditionLikelihood, top: true },
    ...differentials.map((item) => ({ name: item.short || item.name, likelihood: item.likelihood }))]
    .filter((row) => Number.isFinite(row.likelihood));
  return html`
    <section class="why-block">
      <h3 class="why-title">Predicted condition</h3>
      <p class="why-text">${conditionFromModel(p)
        ? html`Within the ${categoryLabel} conditions, the trained model gave <strong>${p.predictedCondition}</strong> the highest probability.`
        : html`Among the ${categoryLabel} conditions the system checks, the answers most closely match <strong>${p.predictedCondition}</strong>.`}</p>
      ${evidence.length ? html`
        <h3 class="why-title">Answers supporting this condition</h3>
        <ul class="why-list">${evidence.slice(0, 6).map((item) => html`<li>${icon('check')}<span>${item.label}</span></li>`)}</ul>` : ''}
      ${against.length ? html`
        <h3 class="why-title">Answers that count against it</h3>
        <ul class="why-list why-list--muted">${against.slice(0, 3).map((item) => html`<li>${icon('minus')}<span>${item.label}</span></li>`)}</ul>` : ''}
      ${rows.length > 1 ? html`
        <h3 class="why-title">Conditions compared (${conditionFromModel(p) ? 'model probability' : 'match strength'})</h3>
        <ul class="share-list share-list--wide">
          ${rows.map((row) => html`
            <li class="share-row${row.top ? '' : ' share-row--muted'}">
              <span class="share-row__label">${row.name}</span>
              <span class="share-row__bar"><span style="width: ${row.likelihood}%"></span></span>
              <span class="share-row__value">${row.likelihood}%</span>
            </li>`)}
        </ul>` : ''}
      <p class="why-note">${conditionFromModel(p) ? MODEL_TEXT.helperText : CONDITION_SETTINGS.helperText}</p>
    </section>`;
}

function renderFactor(label, value, hint) {
  const percent = Math.round(clamp(value, 0, 1) * 100);
  return html`
    <div class="factor">
      <dt>${label}<span class="factor__hint">${hint}</span></dt>
      <dd><span class="factor__bar"><span style="width: ${percent}%"></span></span><span class="factor__value">${percent}%</span></dd>
    </div>`;
}

/* Secondary, collapsed by default: for evaluators and developers. */
function renderTechnicalDetails(assessment) {
  const features = assessment.features;
  if (!features) return '';
  const active = FEATURE_SCHEMA
    .filter((definition) => features.raw[definition.key] !== null && features.raw[definition.key] !== undefined && features.raw[definition.key] !== 0)
    .map((definition) => ({ key: definition.key, label: SYMPTOM_LABELS[definition.key], raw: features.raw[definition.key], model: features.named[definition.key] }));
  const p = assessment.prediction;
  const engine = engineInfoFor(p);
  return html`
    <details class="tech">
      <summary>${icon('cpu')}<span>View assessment details (technical)</span></summary>
      <div class="tech__body">
        <dl class="tech__meta">
          <dt>Engine</dt><dd>${engine.name}</dd>
          <dt>Method</dt><dd>${engine.method}</dd>
          <dt>Feature schema</dt><dd>${features.schemaVersion}, ${features.vector.length} features in fixed order</dd>
          <dt>Non-zero features</dt><dd>${active.length}</dd>
          <dt>Completeness</dt><dd>${Math.round(features.meta.completeness * 100)}% (${features.meta.asked} answered, ${features.meta.unsure} not sure${features.meta.notAsked ? `, ${features.meta.notAsked} not asked` : ''})</dd>
          ${p && isModelResult(p) && p.modelFactors ? html`<dt>Model probability</dt><dd>${p.modelFactors.probability}% (${CATEGORIES[p.topCategoryId] ? CATEGORIES[p.topCategoryId].label : p.topCategoryId})</dd>` : ''}
          ${p && p.confidenceFactors ? html`<dt>Top / second score</dt><dd>${p.confidenceFactors.topScore} / ${p.confidenceFactors.secondScore}</dd>` : ''}
          ${p && Number.isFinite(p.conditionScore) && !p.isInconclusive && !isUrgentAssessment(assessment) ? html`<dt>Condition score</dt><dd>${p.conditionScore} (${p.predictedConditionId})</dd>` : ''}
        </dl>
        <table class="tech__table">
          <thead><tr><th scope="col">Feature</th><th scope="col">Encoded</th><th scope="col">Model input</th></tr></thead>
          <tbody>${active.map((item) => html`<tr><td>${item.label}<span class="tech__key">${item.key}</span></td><td>${item.raw}</td><td>${item.model}</td></tr>`)}</tbody>
        </table>
        <p class="why-note">${engine.note}</p>
      </div>
    </details>`;
}

/* ---------- Dashboard ---------- */

function renderDashboard() {
  const now = new Date();
  const profile = currentProfile();
  const records = AssessmentRepository.list();
  const today = records.filter((record) => isSameDay(record.createdAt, now));
  const reportsToday = records.filter((record) => record.report && isSameDay(record.report.generatedAt, now)).length;
  const urgentToday = today.filter((record) => summariseRecord(record).urgent).length;
  const recent = records.slice(0, APP_CONFIG.recentLimit);
  const routed = Object.values(today.reduce((tally, record) => {
    const s = summariseRecord(record);
    if (!tally[s.department]) tally[s.department] = { ...s, count: 0 };
    tally[s.department].count += 1;
    return tally;
  }, {})).sort((a, b) => b.count - a.count);
  const maxRouted = routed.reduce((max, item) => Math.max(max, item.count), 0);

  return html`
    <section class="screen screen--dashboard">
      ${hasUnsavedProgress() ? renderResumeBanner() : ''}
      <div class="dash-grid">
        <section class="hero" aria-labelledby="hero-title">
          <p class="hero__greeting">${greetingFor(now)}, ${profile.firstName || profile.desk.toLowerCase()}</p>
          <h1 class="hero__title" id="hero-title" tabindex="-1">Start a patient assessment</h1>
          <p class="hero__text">Record the patient’s details, mark the symptoms on the body map, ask a few follow-up questions, and get the suggested department with a printable preliminary report.</p>
          <div class="hero__actions">
            <button type="button" class="btn btn-lg btn-on-dark" data-action="new-assessment">${icon('plus')}<span>New Patient Assessment</span></button>
            <p class="hero__meta">${icon('clock')}<span>Usually 5 to 10 questions</span></p>
          </div>
          <ol class="hero__steps" aria-label="How an assessment runs">
            ${ASSESSMENT_STEPS.map((step, index) => html`<li><span class="hero__step-num">${index + 1}</span><span>${step.label}</span></li>`)}
          </ol>
        </section>

        <aside class="card today" aria-labelledby="today-title">
          <header class="today__head">
            <h2 class="today__title" id="today-title">Today at the desk</h2>
            <p class="today__date">${formatLongDate(now)}</p>
          </header>
          <dl class="stat-row">
            <div class="stat"><dt>Assessments today</dt><dd>${today.length}</dd></div>
            <div class="stat"><dt>Reports generated today</dt><dd>${reportsToday}</dd></div>
            <div class="stat${urgentToday ? ' stat--danger' : ''}"><dt>Urgent escalations</dt><dd>${urgentToday}</dd></div>
          </dl>
          <div class="routed">
            <h3 class="routed__title">Routed today</h3>
            ${routed.length
              ? html`<ul class="routed__list">${routed.map((item) => html`
                  <li class="routed__row tone-${item.tone}">
                    <span class="routed__dept">${icon(item.icon)}<span>${item.department}</span></span>
                    <span class="routed__bar" aria-hidden="true"><span style="width: ${Math.round((item.count / maxRouted) * 100)}%"></span></span>
                    <span class="routed__count">${item.count}</span>
                  </li>`)}</ul>`
              : html`<p class="routed__empty">No patients routed yet today.</p>`}
          </div>
          <div class="system-card">
            <p class="system-card__title">${icon('shield-check')}<span>Decision-support system active</span></p>
            <ul class="system-card__list">
              <li>${icon('cpu')}<span>${engineStatusText()}</span></li>
              <li>${icon('database')}<span>${SafeStorage.persistent ? 'Saved assessments stay in this browser' : 'Browser storage unavailable: data is lost on reload'}</span></li>
            </ul>
          </div>
        </aside>
      </div>

      <section class="card recent" aria-labelledby="recent-title">
        <header class="recent__head">
          <h2 class="recent__title" id="recent-title">Recent assessments</h2>
          ${records.length ? html`<button type="button" class="btn btn-ghost btn-sm" data-action="nav" data-nav-target="history"><span>View all ${records.length}</span>${icon('chevron-right')}</button>` : ''}
        </header>
        ${recent.length ? html`
          <ul class="recent-list">
            ${recent.map((record) => {
              const s = summariseRecord(record);
              return html`
                <li>
                  <button type="button" class="recent-row tone-${s.tone}" data-action="open-assessment" data-id="${s.id}" data-from="dashboard" aria-label="Open ${s.id}, ${s.name}, ${s.condition ? `${s.condition}, ` : ''}${s.department}">
                    <span class="recent-row__id"><span class="id-text">${s.id}</span><span class="cell-sub">${isSameDay(s.createdAt, now) ? formatTime(s.createdAt) : formatDateTime(s.createdAt)}</span></span>
                    <span class="recent-row__patient"><span class="cell-strong${hasLongWord(s.name) ? ' cell-break' : ''}">${s.name}</span><span class="cell-sub">${s.meta || s.complaint}</span></span>
                    <span class="recent-row__category">${s.urgent
                      ? html`<span class="badge badge--danger">${icon('siren')}<span>Urgent</span></span>`
                      : html`<span class="cell-strong">${s.condition || s.category}</span>${s.condition ? html`<span class="cell-sub">${s.category}</span>` : ''}`}</span>
                    <span class="recent-row__dept">${renderDeptTag(s)}<span class="cell-sub recent-row__specialist">${s.specialist}</span>${s.condition ? html`<span class="cell-sub recent-row__alt-condition">${s.condition}</span>` : ''}</span>
                    <span class="recent-row__conf">${s.confidence === null ? html`<span class="muted">Not applicable</span>` : `${s.confidence}%`}</span>
                    <span class="recent-row__go" aria-hidden="true">${icon('chevron-right')}</span>
                  </button>
                </li>`;
            })}
          </ul>`
          : renderEmptyState({
            icon: 'clipboard-list',
            title: 'No assessments have been completed yet.',
            text: 'Completed assessments appear here, ready to reopen with their result and report.',
            action: { label: 'Start First Assessment', action: 'new-assessment', icon: 'plus' },
          })}
      </section>

      <p class="disclaimer-strip">${icon('triangle-alert')}<span>Decision-support system only. Final diagnosis and treatment must be confirmed by a qualified doctor.</span></p>
    </section>`;
}

/* True when the assessment was started by a different staff account. */
function startedByOther(assessment) {
  const me = currentStaff();
  return Boolean(assessment.startedBy && assessment.startedBy.name && (!me || assessment.startedBy.id !== me.id));
}

function renderResumeBanner() {
  const a = state.assessment;
  const where = { intake: 'patient details', bodymap: 'body map', questionnaire: 'follow-up questions', review: 'review' }[state.ui.lastFlowScreen] || 'patient details';
  return html`
    <div class="resume-banner" role="status">
      <div class="resume-banner__text">
        ${icon('clipboard-list')}
        <p><strong>Assessment in progress${a.patient.name ? ` for ${a.patient.name}` : ''}.</strong> Last step: ${where}.${startedByOther(a) ? ` Started by ${a.startedBy.name}.` : ''}</p>
      </div>
      <div class="resume-banner__actions">
        <button type="button" class="btn btn-ghost btn-sm" data-action="cancel-assessment">Discard</button>
        <button type="button" class="btn btn-primary btn-sm" data-action="resume-assessment"><span>Resume assessment</span>${icon('chevron-right')}</button>
      </div>
    </div>`;
}

/* ---------- Review ---------- */

function reviewAssessment() {
  if (bodyMapPending()) {
    // The review must match what will be run: apply the symptoms first.
    state.ui.bmError = 'The symptoms have changed. Check them and press Continue to apply the changes.';
    navigateTo('bodymap');
    return;
  }
  const sequence = currentSequence();
  if (!sequence.complete && !state.assessment.endedEarly) {
    editSymptoms();
    return;
  }
  state.ui.returnTo = null;
  state.ui.branchNotice = null;
  navigateTo('review');
}

function renderReview() {
  const a = state.assessment;
  const sequence = currentSequence();
  if (!a.patient.complaint || (!sequence.complete && !a.endedEarly)) {
    return html`<section class="screen screen--flow">${renderEmptyState({
      icon: 'list-checks',
      title: 'The symptom questions are not finished yet',
      text: 'Complete the questionnaire to review the assessment.',
      action: { label: 'Continue the questions', action: 'edit-symptoms', icon: 'chevron-right' },
    })}</section>`;
  }
  const findings = summariseFindings(a);
  const inconsistencies = detectInconsistencies(computeRawFeatures(a), consistencyContext(a));
  const complaint = getComplaint(a.patient.complaint);
  const priority = a.safety.priority.filter(() => !isUrgentAssessment(a));
  const picks = bodyMapSummary(a);

  return html`
    <section class="screen screen--flow">
      ${renderUrgentBanner('review')}
      <div class="flow-head">
        <div>
          <h1 class="screen-title" tabindex="-1">Review assessment</h1>
          <p class="screen-lead">Read these details back to the patient before running the assessment. Mistakes are easiest to fix now.</p>
        </div>
      </div>

      ${inconsistencies.length ? html`
        <div class="notice notice--warning" role="status">
          ${icon('triangle-alert')}
          <div><p><strong>Please confirm ${inconsistencies.length === 1 ? 'this response' : 'these responses'} with the patient</strong></p>
          <ul>${inconsistencies.map((item) => html`<li>${item.message}</li>`)}</ul>
          <p>Contradictory responses lower the model confidence and may lead to a general clinical evaluation.</p></div>
        </div>` : ''}
      ${priority.length ? html`
        <div class="notice notice--info" role="status">
          ${icon('info')}
          <div><p><strong>The department may need to see this patient promptly</strong></p><ul>${priority.map((flag) => html`<li>${flag.label}</li>`)}</ul></div>
        </div>` : ''}
      ${a.endedEarly && !sequence.complete ? html`
        <div class="notice notice--info" role="status">${icon('info')}<p>The questionnaire was ended early after urgent escalation. ${pluralise(findings.notAsked, 'question was', 'questions were')} not asked.</p></div>` : ''}

      <div class="review-grid">
        <div class="review-main">
          <section class="card review-card" aria-labelledby="review-symptoms">
            <header class="review-card__head">
              <h2 class="review-card__title" id="review-symptoms">Reported symptoms</h2>
              <button type="button" class="btn btn-ghost btn-sm" data-action="edit-bodymap">${icon('person-standing')}<span>Edit body map</span></button>
            </header>
            ${picks.length ? html`
              <div class="review-block">
                <h3 class="review-block__title">Picked on the body map</h3>
                <ul class="chips">${picks.map((pick) => html`<li class="chip chip--map">${pick.label}${pick.pain !== null ? html`<span class="chip__pain" data-band="${painBand(pick.pain).level}">${pick.pain}/10</span>` : ''}</li>`)}</ul>
              </div>` : ''}
            <div class="review-block">
              <h3 class="review-block__title">Has these symptoms</h3>
              ${findings.present.length
                ? html`<ul class="chips">${findings.present.map((item) => html`<li class="chip">${item.label}</li>`)}</ul>`
                : html`<p class="muted">No specific symptoms were reported.</p>`}
            </div>
            ${findings.absent.length ? html`
              <div class="review-block">
                <h3 class="review-block__title">Does not have</h3>
                <ul class="chips">${findings.absent.map((label) => html`<li class="chip chip--absent">${label}</li>`)}</ul>
              </div>` : ''}
            ${findings.unsure.length ? html`
              <div class="review-block">
                <h3 class="review-block__title">Not sure</h3>
                <ul class="chips">${findings.unsure.map((label) => html`<li class="chip chip--unsure">${icon('circle-help')}<span>${label}</span></li>`)}</ul>
              </div>` : ''}
          </section>

          <section class="card review-card" aria-labelledby="review-responses">
            <header class="review-card__head">
              <h2 class="review-card__title" id="review-responses">Additional responses</h2>
              <p class="review-card__meta">${pluralise(findings.responses.length, 'question')} asked, in order</p>
            </header>
            <ol class="response-list">
              ${findings.responses.map((row) => html`
                <li class="response-list__item">
                  <div class="response-list__body">
                    <p class="response-list__q">${row.question}</p>
                    <p class="response-list__a">${row.answer}</p>
                  </div>
                  <button type="button" class="btn btn-ghost btn-sm" data-action="edit-question" data-question-id="${row.id}" aria-label="Change answer: ${row.short}">Change</button>
                </li>`)}
            </ol>
          </section>
        </div>

        <aside class="review-side">
          <section class="card review-card" aria-labelledby="review-patient">
            <header class="review-card__head">
              <h2 class="review-card__title" id="review-patient">Patient details</h2>
              <button type="button" class="btn btn-ghost btn-sm" data-action="edit-patient">${icon('pencil')}<span>Edit</span></button>
            </header>
            <dl class="dl">
              <dt>Name</dt><dd>${textOr(a.patient.name)}</dd>
              <dt>Age</dt><dd>${isBlank(a.patient.age) ? 'Not recorded' : `${a.patient.age} years`}</dd>
              <dt>Gender</dt><dd>${genderLabel(a.patient.gender)}</dd>
              <dt>Contact</dt><dd>${textOr(a.patient.contact)}</dd>
            </dl>
          </section>
          <section class="card review-card" aria-labelledby="review-complaint">
            <h2 class="review-card__title" id="review-complaint">Main complaint</h2>
            <p class="review-complaint">${icon(complaint ? complaint.icon : 'clipboard-list')}<span>${mainProblemLabel(a)}</span></p>
            ${a.patient.description ? html`<p class="review-quote">“${a.patient.description}”</p>` : ''}
          </section>
          <section class="card review-card" aria-labelledby="review-severity">
            <h2 class="review-card__title" id="review-severity">Duration and severity</h2>
            <dl class="dl">
              <dt>Duration</dt><dd>${findings.duration ? findings.duration.value : 'Not recorded'}</dd>
              <dt>Severity</dt><dd>${findings.severity || 'Not rated for this complaint'}</dd>
              ${findings.temperature ? html`<dt>Temperature</dt><dd>${findings.temperature}</dd>` : ''}
            </dl>
          </section>
        </aside>
      </div>

      <div class="action-bar">
        <div class="action-bar__group">
          <button type="button" class="btn btn-secondary" data-action="edit-patient">${icon('user')}<span>Edit Patient Details</span></button>
          <button type="button" class="btn btn-secondary" data-action="edit-bodymap">${icon('person-standing')}<span>Edit Body Map</span></button>
          <button type="button" class="btn btn-secondary" data-action="edit-symptoms">${icon('pencil')}<span>Edit Answers</span></button>
          <button type="button" class="btn btn-ghost" data-action="cancel-assessment">${icon('x')}<span>Cancel</span></button>
        </div>
        <button type="button" class="btn btn-primary btn-lg" data-action="run-assessment">${icon('activity')}<span>Run Assessment</span></button>
      </div>
    </section>`;
}

/* ---------- Analysis (runs the assessment pipeline) ---------- */

let analysisRunning = false;

async function runAssessment() {
  if (analysisRunning) return;
  analysisRunning = true;
  const assessment = state.assessment;
  const stepDelay = prefersReducedMotion() ? 80 : APP_CONFIG.analysisStepMs;
  state.ui.analysis = { step: 0, error: null };
  navigateTo('analysis');

  try {
    const validation = validateAssessment(assessment);
    if (!validation.valid) {
      const problem = new Error(validation.errors.join(' '));
      problem.validation = true;
      throw problem;
    }
    await advanceAnalysis(1, stepDelay);

    const encoding = encodeSymptoms(assessment.answers, assessment.patient.complaint, bodyMapExtras(assessment));
    await advanceAnalysis(2, stepDelay);

    const featureVector = constructFeatureVector(assessment.patient, encoding);
    const processed = preprocessFeatures(featureVector, encoding);
    assessment.features = processed;
    await advanceAnalysis(3, stepDelay);

    assessment.safety = detectRedFlags(featureVector.raw);
    const prediction = await runPrediction(processed, consistencyContext(assessment));
    if (prediction.engineFallback) {
      showToast(MODEL_TEXT.fallbackToast, 'warning');
      updateEngineStatus();
    }
    const urgent = isUrgentAssessment(assessment);
    prediction.withheld = urgent;
    if (urgent) withholdCondition(prediction);
    assessment.prediction = prediction;
    await advanceAnalysis(4, stepDelay);

    assessment.recommendation = mapPredictionToSpecialist(prediction, { urgent });
    assessment.prediction.recommendedSpecialist = assessment.recommendation.specialist;
    assessment.report = null;
    assessment.revision = assessment.id ? (assessment.revision || 1) + 1 : 1;
    saveAssessment();
    await advanceAnalysis(5, Math.round(stepDelay * 0.8));

    if (state.currentScreen === 'analysis') {
      state.ui.openedFrom = null;
      navigateTo('results');
    }
    showToast(`Assessment ${assessment.id} saved to history.`);
  } catch (error) {
    state.ui.analysis = {
      step: state.ui.analysis ? state.ui.analysis.step : 0,
      error: error && error.validation
        ? `The assessment could not be run yet. ${error.message}`
        : 'The assessment could not be completed. Check the responses on the review screen and try again.',
    };
    if (state.currentScreen === 'analysis') render();
  } finally {
    analysisRunning = false;
  }
}

async function advanceAnalysis(step, delay) {
  state.ui.analysis.step = step;
  const list = document.querySelector('[data-analysis-steps]');
  if (list) {
    list.querySelectorAll('[data-step-index]').forEach((item) => {
      const index = Number(item.dataset.stepIndex);
      item.classList.toggle('is-done', index < step);
      item.classList.toggle('is-active', index === step);
      const status = item.querySelector('.analysis__status');
      if (status) status.textContent = index < step ? 'Done' : index === step ? 'In progress' : 'Waiting';
    });
    const bar = document.querySelector('[data-analysis-progress]');
    if (bar) bar.style.width = `${Math.round((step / ANALYSIS_STEPS.length) * 100)}%`;
  }
  await wait(delay);
}

function renderAnalysis() {
  const analysis = state.ui.analysis || { step: 0, error: null };
  if (analysis.error) {
    return html`
      <section class="screen screen--flow">
        <div class="card analysis">
          <div class="empty__icon empty__icon--warning">${icon('triangle-alert')}</div>
          <h1 class="analysis__title" tabindex="-1">Assessment not completed</h1>
          <p class="analysis__lead">${analysis.error}</p>
          <button type="button" class="btn btn-primary" data-action="go-review">${icon('chevron-left')}<span>Back to review</span></button>
        </div>
      </section>`;
  }
  return html`
    <section class="screen screen--flow">
      <div class="card analysis" aria-live="polite">
        <h1 class="analysis__title" tabindex="-1">Analysing patient assessment</h1>
        <p class="analysis__lead">${PredictionService.mode === 'api' ? MODEL_TEXT.analysisLead : 'Structuring the responses and matching the symptom pattern to a department.'}</p>
        <div class="progress progress--thin"><span class="progress__bar" data-analysis-progress style="width: ${Math.round((analysis.step / ANALYSIS_STEPS.length) * 100)}%"></span></div>
        <ol class="analysis__steps" data-analysis-steps>
          ${ANALYSIS_STEPS.map((step, index) => {
            const status = index < analysis.step ? 'is-done' : index === analysis.step ? 'is-active' : '';
            return html`
              <li class="analysis__step ${status}" data-step-index="${index}">
                <span class="analysis__mark" aria-hidden="true">${icon('check')}</span>
                <span class="analysis__label">${PredictionService.mode === 'api' && step.apiLabel ? step.apiLabel : step.label}</span>
                <span class="visually-hidden analysis__status">${index < analysis.step ? 'Done' : index === analysis.step ? 'In progress' : 'Waiting'}</span>
              </li>`;
          })}
        </ol>
      </div>
    </section>`;
}

/* ---------- Results ---------- */

/* Predicted condition, its relative likelihood and the alternatives.
   Older saved records without condition details show what they have. */
function renderConditionSummary(p) {
  if (p.isInconclusive) {
    const considered = Array.isArray(p.consideredConditions) ? p.consideredConditions : [];
    return html`
      <p class="result-card__label">Possible disease category</p>
      <p class="result-card__big">${INCONCLUSIVE_RESULT.label}</p>
      <p class="result-card__label">Predicted condition</p>
      <p class="result-card__text result-card__text--strong">${INCONCLUSIVE_RESULT.conditionLabel}</p>
      ${considered.length ? html`
        <p class="result-card__label">Possible conditions for the doctor to consider</p>
        <ul class="diff-list">${considered.map((item) => html`<li><span class="diff-list__name">${item.short || item.name}</span><span class="diff-list__meta">${item.department}</span></li>`)}</ul>` : ''}
      <p class="notice notice--info notice--compact">${icon('info')}<span>${INCONCLUSIVE_RESULT.message}</span></p>`;
  }
  const likelihood = Number.isFinite(p.conditionLikelihood) ? p.conditionLikelihood : null;
  const differentials = Array.isArray(p.differentials) ? p.differentials : [];
  return html`
    <p class="result-card__label">Predicted condition</p>
    <p class="result-card__big" data-condition-id="${p.predictedConditionId || ''}">${textOr(p.predictedCondition, 'Not available')}</p>
    ${p.conditionDescription ? html`<p class="result-card__desc">${p.conditionDescription}</p>` : ''}
    ${likelihood !== null ? html`
      <div class="likelihood">
        <span class="likelihood__label">${conditionFromModel(p) ? MODEL_TEXT.likelihoodLabel : 'Match strength'}</span>
        <span class="likelihood__bar" aria-hidden="true"><span style="width: ${likelihood}%"></span></span>
        <span class="likelihood__value">${likelihood}%</span>
        <span class="likelihood__word">${capitalise(matchWord(likelihood))}</span>
      </div>
      <p class="result-card__help result-card__help--tight">${conditionFromModel(p) ? MODEL_TEXT.cardHelp : CONDITION_SETTINGS.cardHelp}</p>` : ''}
    ${differentials.length ? html`
      <p class="result-card__label">${p.conditionTie ? 'Closest matches (no clear leader)' : p.conditionIsFallback ? 'Also considered' : 'Other possibilities'}</p>
      <ul class="diff-chips">${differentials.map((item) => html`<li class="diff-chip"><span>${item.short || item.name}</span>${Number.isFinite(item.likelihood) ? html`<span class="diff-chip__value">${item.likelihood}%</span>` : ''}</li>`)}</ul>` : ''}
    <p class="result-card__category"><span class="result-card__label">Possible disease category</span><span class="result-card__category-value">${p.predictedPattern || p.predictedCategory}</span></p>`;
}

function renderResults() {
  const a = state.assessment;
  const p = a.prediction;
  const r = a.recommendation;
  if (!p || !r) {
    return html`<section class="screen screen--flow">${renderEmptyState({
      icon: 'activity',
      title: 'No result to show yet',
      text: 'Run the assessment from the review screen to see the recommendation.',
      action: hasAssessmentData(a) ? { label: 'Go to review', action: 'go-review', icon: 'list-checks' } : { label: 'Go to dashboard', action: 'nav', nav: 'dashboard', icon: 'layout-dashboard' },
    })}</section>`;
  }

  const urgent = isUrgentAssessment(a);
  const doctor = urgent ? null : recommendedDoctor(r);
  const findings = summariseFindings(a);
  const band = confidenceBand(p.confidence);
  const priority = urgent ? [] : a.safety.priority;
  const edited = a.updatedAt && a.createdAt && a.updatedAt !== a.createdAt && (new Date(a.updatedAt) - new Date(a.createdAt) > 60000);

  return html`
    <section class="screen screen--flow screen--results">
      ${urgent ? renderUrgentBanner('results') : ''}

      <div class="result-head">
        <div>
          <p class="result-head__status">${icon('circle-check')}<span>Assessment complete</span><span class="result-head__note">${urgent ? 'Urgent warning signs: no condition is predicted' : 'Preliminary prediction, not a confirmed diagnosis'}</span></p>
          <h1 class="screen-title" tabindex="-1">${a.patient.name ? `Routing for ${a.patient.name}` : 'Routing recommendation'}</h1>
          <p class="screen-lead"><span class="id-text">${a.id}</span>, assessed ${formatDateTime(a.createdAt)}${(a.revision || 1) > 1 ? `, revision ${a.revision} run ${formatDateTime(a.updatedAt)}` : edited ? `, edited ${formatDateTime(a.updatedAt)}` : ''}</p>
        </div>
        <button type="button" class="btn btn-secondary" data-action="open-why">${icon('circle-help')}<span>Why was this recommended?</span></button>
      </div>

      ${renderPlainCard(plainSummary(a))}

      <div class="result-grid">
        <section class="route-sign tone-${r.tone}" aria-labelledby="route-title">
          <p class="route-sign__eyebrow">${icon('signpost')}<span>Recommended department</span></p>
          <div class="route-sign__dept">
            <h2 class="route-sign__name" id="route-title">${r.department}</h2>
            <span class="route-sign__arrow" aria-hidden="true">${icon('arrow-right')}</span>
          </div>
          <div class="route-sign__meta">
            <p class="route-sign__specialist">Suggested specialist <strong>${r.specialist}</strong></p>
            <span class="route-sign__code"><span class="visually-hidden">Department code </span>${r.code}</span>
          </div>
          ${doctor ? html`
            <div class="route-sign__doctor">
              <span class="route-sign__doctor-avatar" aria-hidden="true">${doctorInitials(doctor.name)}</span>
              <p><span class="route-sign__doctor-label">Doctor to see</span><strong class="route-sign__doctor-name">${doctor.name}</strong></p>
            </div>` : ''}
          <div class="route-sign__next">
            ${icon(urgent ? 'siren' : 'arrow-up-right')}
            <div><p class="route-sign__next-title">Next step</p><p>${r.nextStep}</p></div>
          </div>
          ${priority.length ? html`
            <div class="route-sign__priority" role="status">
              ${icon('clock')}
              <div><p><strong>Inform the ${r.department} team that this patient may need to be seen promptly.</strong></p>
              <ul>${priority.map((flag) => html`<li>${flag.label}</li>`)}</ul></div>
            </div>` : ''}
          <div class="route-sign__actions">
            <button type="button" class="btn btn-primary btn-lg" data-action="generate-report">${icon('file-text')}<span>${a.report ? 'View Preliminary Report' : 'Generate Preliminary Report'}</span></button>
            <button type="button" class="btn btn-secondary" data-action="edit-assessment">${icon('pencil')}<span>Edit Assessment</span></button>
            <button type="button" class="btn btn-ghost" data-action="new-assessment">${icon('plus')}<span>Start New Assessment</span></button>
          </div>
        </section>

        <div class="result-side">
          <section class="card result-card result-card--condition" aria-labelledby="pa-title">
            <div class="result-card__head">
              <h2 class="result-card__title" id="pa-title">Preliminary assessment</h2>
              ${urgent ? '' : html`<span class="caution-tag">Not a confirmed diagnosis</span>`}
            </div>
            ${urgent
              ? html`<p class="result-card__big">Not generated</p>
                <p class="result-card__text">Urgent warning signs take priority over disease prediction and classification. The clinical team will assess the patient.</p>`
              : renderConditionSummary(p)}
          </section>

          <section class="card result-card" aria-labelledby="mc-title">
            <h2 class="result-card__title result-card__title--hint" id="mc-title">Model confidence <span>How strongly the answers point to this department</span></h2>
            ${urgent
              ? html`<p class="result-card__big">Not applicable</p><p class="result-card__text">No classification is produced for urgent cases.</p>`
              : html`
                <div class="conf">
                  <p class="conf__value">${p.confidence}<span>%</span></p>
                  <p class="level-pill level-pill--${band.id}">${icon(band.id === 'higher' ? 'circle-check' : band.id === 'moderate' ? 'circle-dot' : 'circle-alert')}<span>${band.label}</span></p>
                </div>
                <div class="conf-meter" role="img" aria-label="Model confidence ${p.confidence} percent, ${band.label.toLowerCase()}">
                  <span class="conf-meter__fill conf-meter__fill--${band.id}" style="width: ${p.confidence}%"></span>
                  <span class="conf-meter__tick" style="left: 55%"></span>
                  <span class="conf-meter__tick" style="left: 75%"></span>
                </div>
                <div class="conf-meter__legend" aria-hidden="true"><span>Low</span><span>Moderate</span><span>Higher</span></div>
                <p class="result-card__help">${CONFIDENCE_THRESHOLDS.helperText}</p>
                <p class="result-card__help result-card__engine" data-engine="${isModelResult(p) ? 'api' : 'local'}">${icon('cpu')}<span>${engineSourceText(p)}</span></p>
                ${p.inconsistencies.length ? html`<p class="notice notice--warning notice--compact">${icon('triangle-alert')}<span>Lowered because ${pluralise(p.inconsistencies.length, 'response')} contradicted the main complaint. See “Why was this recommended?”</span></p>` : ''}`}
          </section>
        </div>
      </div>

      <div class="result-lower">
        <section class="card result-card" aria-labelledby="ps-title">
          <h2 class="result-card__title" id="ps-title">Patient summary</h2>
          <dl class="dl">
            <dt>Name</dt><dd>${textOr(a.patient.name)}</dd>
            <dt>Age / gender</dt><dd>${isBlank(a.patient.age) ? 'Age not recorded' : `${a.patient.age} years`}, ${genderLabel(a.patient.gender)}</dd>
            <dt>Contact</dt><dd>${textOr(a.patient.contact)}</dd>
            <dt>Main complaint</dt><dd>${mainProblemLabel(a)}</dd>
          </dl>
        </section>
        <section class="card result-card" aria-labelledby="rs-title">
          <h2 class="result-card__title" id="rs-title">Reported symptoms</h2>
          ${findings.present.length
            ? html`<ul class="chips">${findings.present.map((item) => html`<li class="chip">${item.label}</li>`)}</ul>`
            : html`<p class="muted">No specific symptoms were reported.</p>`}
          ${findings.absent.length ? html`<p class="result-card__absent"><strong>Does not have:</strong> ${findings.absent.join(', ')}</p>` : ''}
          ${findings.unsure.length ? html`<p class="result-card__absent"><strong>Not sure:</strong> ${findings.unsure.join(', ')}</p>` : ''}
          <p class="result-card__absent"><strong>Duration:</strong> ${findings.duration ? findings.duration.value : 'Not recorded'}. <strong>Severity:</strong> ${findings.severity || 'Not rated'}.</p>
        </section>
      </div>

      <p class="disclaimer" role="note">${icon('triangle-alert')}<span>${DISCLAIMERS.short}</span></p>
    </section>`;
}

/* "In simple words" (section 12a) for the patient and family. */
function renderPlainCard(summary) {
  return html`
    <section class="card plain-card${summary.urgent ? ' plain-card--urgent' : ''}" aria-labelledby="plain-title">
      <header class="plain-card__head">
        <h2 class="plain-card__title" id="plain-title">${icon('message-square-text')}<span>In simple words</span></h2>
        <p class="plain-card__note">For the patient and family</p>
      </header>
      <dl class="plain-list">
        ${plainRows(summary).map((row) => html`
          <div class="plain-list__row plain-list__row--${row.id}">
            <dt>${icon(row.icon)}<span>${row.label}</span></dt>
            <dd>${renderPlainSegments(row.body)}</dd>
          </div>`)}
      </dl>
    </section>`;
}

/* ---------- Light and dark theme ----------
   The toggle in the top bar switches the theme and remembers the choice
   in this browser. Until someone chooses, the theme follows the
   computer's light or dark setting. The inline script in the page head
   applies it before the first paint. */

function savedTheme() {
  const value = SafeStorage.read(APP_CONFIG.storageKeys.theme, null);
  return value === 'dark' || value === 'light' ? value : null;
}

function systemTheme() {
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function currentTheme() {
  return document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';
}

function applyTheme(theme) {
  const dark = theme === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.querySelectorAll('[data-action="toggle-theme"]').forEach((button) => {
    button.setAttribute('aria-pressed', dark ? 'true' : 'false');
    button.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
  });
}

function toggleTheme() {
  const next = currentTheme() === 'dark' ? 'light' : 'dark';
  SafeStorage.write(APP_CONFIG.storageKeys.theme, next);
  applyTheme(next);
}

function initTheme() {
  applyTheme(savedTheme() || systemTheme());
  if (!window.matchMedia) return;
  const query = window.matchMedia('(prefers-color-scheme: dark)');
  const follow = () => { if (!savedTheme()) applyTheme(systemTheme()); };
  if (query.addEventListener) query.addEventListener('change', follow);
  else if (query.addListener) query.addListener(follow);
}

/* ---------- Shell status ---------- */

function updateStatusIndicators() {
  const storage = document.getElementById('storage-status');
  if (storage) {
    storage.hidden = SafeStorage.persistent;
  }
}

function updateClock() {
  const now = new Date();
  const time = document.getElementById('clock-time');
  const date = document.getElementById('clock-date');
  const clock = document.getElementById('clock');
  if (time) time.textContent = formatTime(now);
  if (date) date.textContent = formatDate(now, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  if (clock) clock.setAttribute('datetime', now.toISOString());
}

function afterRender() {
  // Keep the current question visible in the response trail.
  const current = document.querySelector('.trail__item.is-current');
  const list = current ? current.closest('.trail__list') : null;
  if (list && list.scrollHeight > list.clientHeight) {
    list.scrollTop = Math.max(0, current.parentElement.offsetTop - list.clientHeight + current.offsetHeight + 12);
  }

  // Close the demo menu when its panel is used or focus leaves it.
  const demoMenu = document.querySelector('[data-demo-menu]');
  if (demoMenu) {
    demoMenu.addEventListener('focusout', (event) => {
      if (!demoMenu.contains(event.relatedTarget)) demoMenu.open = false;
    });
  }
}
