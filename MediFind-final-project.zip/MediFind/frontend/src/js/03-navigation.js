/* =====================================================================
   3. NAVIGATION
   ===================================================================== */

const SCREENS = {
  dashboard: { title: 'Dashboard', nav: 'dashboard', render: () => renderDashboard() },
  intake: { title: 'New assessment', crumb: 'Patient details', nav: 'assessment', flow: true, render: () => renderPatientForm() },
  bodymap: { title: 'New assessment', crumb: 'Symptoms', nav: 'assessment', flow: true, render: () => renderBodyMapScreen() },
  questionnaire: { title: 'New assessment', crumb: 'Follow-up questions', nav: 'assessment', flow: true, render: () => renderQuestionnaireScreen() },
  review: { title: 'New assessment', crumb: 'Review', nav: 'assessment', flow: true, render: () => renderReview() },
  analysis: { title: 'New assessment', crumb: 'Analysis', nav: 'assessment', flow: true, render: () => renderAnalysis() },
  results: { title: 'Assessment result', crumb: 'Recommendation', nav: 'assessment', flow: true, render: () => renderResults() },
  report: { title: 'Preliminary report', crumb: 'Report', nav: 'assessment', flow: true, render: () => renderReportScreen() },
  history: { title: 'Assessment history', nav: 'history', render: () => renderHistory() },
};

/* The stages of an assessment, listed on the dashboard. */
const ASSESSMENT_STEPS = [
  { id: 'patient', label: 'Patient Details' },
  { id: 'symptoms', label: 'Symptoms' },
  { id: 'questions', label: 'Questions' },
  { id: 'review', label: 'Review' },
  { id: 'analysis', label: 'Analysis' },
  { id: 'recommendation', label: 'Recommendation' },
];

function navigateTo(screen, { focus = true } = {}) {
  const target = SCREENS[screen] ? screen : 'dashboard';
  state.currentScreen = target;
  if (SCREENS[target].flow && ['intake', 'bodymap', 'questionnaire', 'review'].includes(target)) state.ui.lastFlowScreen = target;
  closeDrawer({ restoreFocus: false });
  render({ focus, scroll: true });
  persistDraft();
}

function render({ focus = true, scroll = false } = {}) {
  const screen = SCREENS[state.currentScreen] || SCREENS.dashboard;
  const container = document.getElementById('screen');
  if (!container) return;
  container.innerHTML = String(screen.render());
  updateShell();
  if (state.currentScreen === 'questionnaire') persistDraft();
  if (scroll) window.scrollTo({ top: 0, behavior: 'auto' });
  if (focus) focusScreenHeading();
  afterRender();
}

/* Moves focus to the screen heading (or the question) so screen-reader
   users hear where they are after each step. */
function focusScreenHeading() {
  const target = document.querySelector('#screen .q-title, #screen [data-autofocus], #screen h1');
  if (target) {
    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
  }
}

function updateShell() {
  const screen = SCREENS[state.currentScreen] || SCREENS.dashboard;
  const app = document.getElementById('app');
  app.dataset.screen = state.currentScreen;
  app.dataset.flow = screen.flow ? 'true' : 'false';

  const a = state.assessment;
  const title = ['results', 'report'].includes(state.currentScreen) && a.id ? a.id : screen.title;
  document.getElementById('topbar-title').textContent = title;
  document.getElementById('topbar-crumb').textContent = screen.crumb
    ? `${state.currentScreen === 'results' || state.currentScreen === 'report' ? 'Assessment' : 'New assessment'} / ${screen.crumb}`
    : currentProfile().desk;
  document.title = `${screen.crumb || screen.title} | ${APP_CONFIG.shortName}`;

  const inProgress = hasUnsavedProgress();
  document.querySelectorAll('[data-nav]').forEach((item) => {
    const active = item.dataset.nav === screen.nav;
    item.classList.toggle('is-active', active);
    if (active) item.setAttribute('aria-current', 'page');
    else item.removeAttribute('aria-current');
  });
  document.querySelectorAll('[data-nav-badge]').forEach((badge) => { badge.hidden = !inProgress; });
  document.querySelectorAll('[data-nav-label="assessment"]').forEach((label) => {
    label.textContent = inProgress ? 'Resume Assessment' : 'New Assessment';
  });
  updateStatusIndicators();
}

/* Starts a fresh assessment, asking first if unsaved work would be lost. */
function startNewAssessment() {
  if (hasUnsavedProgress()) {
    const name = state.assessment.patient.name;
    openModal({
      tone: 'warning',
      icon: 'triangle-alert',
      title: 'An assessment is already in progress',
      text: `${name ? `The assessment for ${name}` : 'The current assessment'} has not been completed. Resume it, or discard it and start a new one.`,
      actions: [
        { label: 'Discard and start new', variant: 'secondary', onClick: () => { resetAssessment(); navigateTo('intake'); } },
        { label: 'Resume assessment', variant: 'primary', onClick: () => resumeAssessment(), autofocus: true },
      ],
    });
    return;
  }
  resetAssessment();
  navigateTo('intake');
}

function requestCancelAssessment() {
  const a = state.assessment;
  if (!hasAssessmentData(a) || !hasUnsavedProgress()) {
    const savedId = a.status === 'completed' ? a.id : null;
    resetAssessment();
    navigateTo('dashboard');
    if (savedId) showToast(`${savedId} is unchanged.`);
    return;
  }
  const editingSaved = a.status === 'completed';
  openModal({
    tone: 'danger',
    icon: 'trash-2',
    title: editingSaved ? 'Discard your changes?' : 'Discard this assessment?',
    text: editingSaved
      ? `Your changes will be lost. The saved assessment ${a.id} will stay as it was.`
      : 'Patient details and symptom responses entered during this assessment will be lost.',
    actions: [
      { label: 'Continue Assessment', variant: 'secondary', autofocus: true },
      {
        label: editingSaved ? 'Discard changes' : 'Discard Assessment',
        variant: 'urgent',
        onClick: () => {
          resetAssessment();
          navigateTo('dashboard');
          showToast(editingSaved ? 'Changes discarded.' : 'Assessment discarded.');
        },
      },
    ],
  });
}
