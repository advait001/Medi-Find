/* =====================================================================
   14. HISTORY
   ===================================================================== */

/* Display-ready summary of a saved record, with safe fallbacks. */
function summariseRecord(record) {
  const prediction = record.prediction || null;
  const recommendation = record.recommendation || SPECIALIST_MAPPING.general;
  const urgent = Boolean(record.urgentFlag || (record.safety && record.safety.urgent && record.safety.urgent.length));
  let category = 'Not available';
  if (urgent) category = 'Urgent: classification withheld';
  else if (prediction) category = prediction.isInconclusive ? INCONCLUSIVE_RESULT.label : textOr(prediction.predictedCategory, 'Not available');
  // Predicted condition (never shown for urgent cases).
  let condition = '';
  if (!urgent && prediction && !prediction.conditionWithheld) {
    if (prediction.isInconclusive) condition = INCONCLUSIVE_RESULT.conditionShort;
    else if (prediction.predictedConditionId && !prediction.conditionIsFallback) condition = `Possible: ${prediction.conditionShort || prediction.predictedCondition}`;
    else condition = String(prediction.conditionShort || prediction.predictedCondition || '');
  }
  const confidence = !urgent && prediction && Number.isFinite(prediction.confidence) ? prediction.confidence : null;
  return {
    id: record.id,
    name: textOr(record.patient.name, 'Unnamed patient'),
    meta: [isBlank(record.patient.age) ? '' : `${record.patient.age} yrs`, record.patient.gender ? genderLabel(record.patient.gender) : ''].filter(Boolean).join(', '),
    complaint: mainProblemLabel({ patient: record.patient, bodyMap: normaliseBodyMap(record.bodyMap, record.patient.complaint) }),
    category,
    condition,
    urgent,
    department: recommendation.department || 'General Medicine',
    specialist: recommendation.specialist || 'General Physician',
    tone: recommendation.tone || 'gen',
    icon: recommendation.icon || 'stethoscope',
    confidence,
    confidenceLabel: confidence === null ? '' : confidenceBand(confidence).label,
    createdAt: record.createdAt,
    hasReport: Boolean(record.report),
  };
}

/* Unusually long unbroken words (e.g. a name typed without spaces) may
   break anywhere; ordinary names never break mid-word. */
function hasLongWord(text) {
  return /\S{19,}/.test(String(text || ''));
}

function filterAssessments(records, query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return records;
  return records.filter((record) => {
    const name = String(record.patient.name || '').toLowerCase();
    const id = String(record.id || '').toLowerCase();
    return name.includes(q) || id.includes(q) || id.replace(/-/g, '').includes(q.replace(/[-\s]/g, ''));
  });
}

function renderConfidenceCell(summary) {
  if (summary.confidence === null) return html`<span class="muted">Not applicable</span>`;
  return html`<span class="conf-cell"><strong>${summary.confidence}%</strong><span class="conf-cell__label">${summary.confidenceLabel.replace(' model confidence', '')}</span></span>`;
}

function renderDeptTag(summary) {
  return html`<span class="dept-tag tone-${summary.tone}">${icon(summary.icon)}<span>${summary.department}</span></span>`;
}

function renderHistory() {
  const all = AssessmentRepository.list();
  const query = state.ui.historyQuery;
  const records = filterAssessments(all, query);

  return html`
    <section class="screen">
      <div class="page-head">
        <div>
          <h1 class="screen-title" tabindex="-1">Assessment history</h1>
          <p class="screen-lead">Every completed assessment saved in this browser, newest first.</p>
        </div>
        <button type="button" class="btn btn-primary" data-action="new-assessment">${icon('plus')}<span>New Patient Assessment</span></button>
      </div>

      ${all.length ? html`
        <div class="history-tools">
          <div class="search">
            ${icon('search')}
            <label class="visually-hidden" for="history-search">Search by patient name or assessment ID</label>
            <input class="input" id="history-search" type="search" placeholder="Search by patient name or assessment ID" value="${query}" data-history-search autocomplete="off">
          </div>
          <p class="history-count" id="history-count" aria-live="polite">${query ? `Showing ${records.length} of ${pluralise(all.length, 'assessment')}` : pluralise(all.length, 'assessment')}</p>
        </div>
        <div id="history-results">${renderHistoryResults(records, query)}</div>
        <p class="privacy-line">${icon('database')}<span>${DISCLAIMERS.privacy}</span>
          <button type="button" class="link-button" data-action="clear-history">Clear saved assessments</button></p>`
        : html`<div class="card">${renderEmptyState({
          icon: 'history',
          title: 'No assessments have been completed yet.',
          text: 'Completed assessments are saved here so you can reopen the result and the preliminary report.',
          action: { label: 'Start First Assessment', action: 'new-assessment', icon: 'plus' },
        })}</div>`}
    </section>`;
}

function renderHistoryResults(records, query) {
  if (!records.length) {
    return html`<div class="card">${renderEmptyState({
      icon: 'search',
      title: 'No assessments match your search.',
      text: query ? `Nothing matches “${query}”. Check the spelling, or search by assessment ID such as ${APP_CONFIG.idPrefix}-${new Date().getFullYear()}-0001.` : '',
      action: { label: 'Clear search', action: 'clear-search', icon: 'x' },
    })}</div>`;
  }
  return html`
    <div class="table-wrap">
      <table class="table">
        <caption class="visually-hidden">Saved assessments</caption>
        <thead>
          <tr>
            <th scope="col">Assessment ID</th>
            <th scope="col">Patient</th>
            <th scope="col">Main Complaint</th>
            <th scope="col">Assessment Category</th>
            <th scope="col">Specialist</th>
            <th scope="col">Confidence</th>
            <th scope="col">Date / Time</th>
            <th scope="col"><span class="visually-hidden">Actions</span></th>
          </tr>
        </thead>
        <tbody>
          ${records.map((record) => {
            const s = summariseRecord(record);
            return html`
              <tr>
                <td data-label="Assessment ID"><div><span class="id-text">${s.id}</span></div></td>
                <td data-label="Patient"><div><span class="cell-strong${hasLongWord(s.name) ? ' cell-break' : ''}">${s.name}</span>${s.meta ? html`<span class="cell-sub">${s.meta}</span>` : ''}</div></td>
                <td data-label="Main Complaint"><div>${s.complaint}</div></td>
                <td data-label="Assessment Category"><div>${s.urgent
                  ? html`<span class="badge badge--danger">${icon('siren')}<span>Urgent</span></span><span class="cell-sub">Classification withheld</span>`
                  : html`<span>${s.category}</span>${s.condition ? html`<span class="cell-sub cell-sub--condition">${s.condition}</span>` : ''}`}</div></td>
                <td data-label="Specialist"><div>${renderDeptTag(s)}<span class="cell-sub">${s.specialist}</span></div></td>
                <td data-label="Confidence"><div>${renderConfidenceCell(s)}</div></td>
                <td data-label="Date / Time"><div><span class="cell-strong">${formatDate(s.createdAt)}</span><span class="cell-sub">${formatTime(s.createdAt)}</span></div></td>
                <td class="table__action"><button type="button" class="btn btn-secondary btn-sm" data-action="open-assessment" data-id="${s.id}" aria-label="View assessment ${s.id} for ${s.name}">${icon('eye')}<span>View</span></button></td>
              </tr>`;
          })}
        </tbody>
      </table>
    </div>`;
}

/* Live search without re-rendering the input (keeps focus and caret). */
function updateHistorySearch(query) {
  state.ui.historyQuery = query;
  const all = AssessmentRepository.list();
  const records = filterAssessments(all, query);
  const results = document.getElementById('history-results');
  const count = document.getElementById('history-count');
  if (results) results.innerHTML = String(renderHistoryResults(records, query));
  if (count) count.textContent = query ? `Showing ${records.length} of ${pluralise(all.length, 'assessment')}` : pluralise(all.length, 'assessment');
}

/* Opens a saved assessment, protecting any unsaved work in progress. */
function openSavedAssessment(id, from = 'history') {
  const open = () => {
    if (!loadAssessment(id)) {
      showToast('That assessment could not be found in this browser.', 'danger');
      render();
      return;
    }
    state.ui.openedFrom = from;
    navigateTo('results');
  };
  if (hasUnsavedProgress()) {
    const sameRecord = state.assessment.id === id;
    openModal({
      tone: 'warning',
      icon: 'triangle-alert',
      title: sameRecord ? 'Discard your unsaved changes?' : 'Leave the assessment in progress?',
      text: sameRecord
        ? `Opening the saved copy of ${id} will discard the changes you have not run yet.`
        : `Opening ${id} will discard the unsaved assessment${state.assessment.patient.name ? ` for ${state.assessment.patient.name}` : ''}.`,
      actions: [
        { label: sameRecord ? 'Keep editing' : 'Keep working', variant: 'secondary', autofocus: true, onClick: () => resumeAssessment() },
        { label: sameRecord ? 'Discard changes' : `Discard and open ${id}`, variant: 'primary', onClick: () => { DraftStore.clear(); open(); } },
      ],
    });
    return;
  }
  open();
}

function requestClearHistory() {
  openModal({
    tone: 'danger',
    icon: 'trash-2',
    title: 'Clear all saved assessments?',
    text: 'This removes every saved assessment and report from this browser. It cannot be undone.',
    actions: [
      { label: 'Keep assessments', variant: 'secondary', autofocus: true },
      {
        label: 'Clear assessments',
        variant: 'urgent',
        onClick: () => {
          AssessmentRepository.clear();
          if (state.assessment.status === 'completed') resetAssessment();
          state.ui.historyQuery = '';
          render();
          showToast('Saved assessments cleared.');
        },
      },
    ],
  });
}
