/* =====================================================================
   3a. STAFF ACCOUNTS AND SIGN-IN
   ---------------------------------------------------------------------
   MediFind opens on a sign-in screen. Staff create an account in three
   steps (account, desk, safe use) and then log in with their email and
   password.

   No server keeps accounts (the MediFind backend, when it is used, only
   makes predictions). Accounts are stored in this browser next to the
   assessments, and a password is kept only as a salted PBKDF2-SHA-256
   hash (Web Crypto when the browser offers it, otherwise the small
   implementation below, which gives the same result). Accounts tell a
   shared desk computer who prepared each report; they are not a security
   boundary, because anyone who can open this browser's storage can read
   what MediFind keeps there.
   PRODUCTION INTEGRATION POINT: replace AccountStore and the session
   with the hospital's identity provider (single sign-on).
   ===================================================================== */

/* ---------- Password hashing ---------- */

const PasswordHash = (() => {
  const K = Uint32Array.from([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  const IV = Uint32Array.from([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const W = new Uint32Array(64);

  /* SHA-256 compression of one 16-word block into the 8-word state h. */
  function compress(h, block) {
    for (let i = 0; i < 16; i += 1) W[i] = block[i];
    for (let i = 16; i < 64; i += 1) {
      const x = W[i - 15];
      const y = W[i - 2];
      const s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
      const s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
    }
    let a = h[0]; let b = h[1]; let c = h[2]; let d = h[3];
    let e = h[4]; let f = h[5]; let g = h[6]; let hh = h[7];
    for (let i = 0; i < 64; i += 1) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const t1 = (hh + S1 + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      hh = g; g = f; f = e; e = (d + t1) | 0;
      d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
    h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
  }

  /* Hashes `tail`, continuing from a state that has already taken in
     `before` bytes (whole 64-byte blocks). Returns the 8-word state. */
  function finish(start, before, tail) {
    const h = Uint32Array.from(start);
    const size = ((tail.length + 9 + 63) >> 6) << 6;
    const padded = new Uint8Array(size);
    padded.set(tail);
    padded[tail.length] = 0x80;
    const bits = (before + tail.length) * 8;
    const view = new DataView(padded.buffer);
    view.setUint32(size - 8, Math.floor(bits / 0x100000000));
    view.setUint32(size - 4, bits >>> 0);
    const block = new Uint32Array(16);
    for (let offset = 0; offset < size; offset += 64) {
      for (let i = 0; i < 16; i += 1) block[i] = view.getUint32(offset + i * 4);
      compress(h, block);
    }
    return h;
  }

  function absorb(start, bytes64) {
    const h = Uint32Array.from(start);
    const view = new DataView(bytes64.buffer, bytes64.byteOffset, 64);
    const block = new Uint32Array(16);
    for (let i = 0; i < 16; i += 1) block[i] = view.getUint32(i * 4);
    compress(h, block);
    return h;
  }

  function wordsToBytes(words) {
    const bytes = new Uint8Array(words.length * 4);
    for (let i = 0; i < words.length; i += 1) {
      bytes[i * 4] = words[i] >>> 24;
      bytes[i * 4 + 1] = (words[i] >>> 16) & 255;
      bytes[i * 4 + 2] = (words[i] >>> 8) & 255;
      bytes[i * 4 + 3] = words[i] & 255;
    }
    return bytes;
  }

  function sha256(bytes) {
    return wordsToBytes(finish(IV, 0, bytes));
  }

  /* PBKDF2-HMAC-SHA-256 with a 32-byte result (RFC 8018). The HMAC pads
     are absorbed once, so each round costs two compressions. */
  function pbkdf2Start(passwordBytes, salt) {
    const key = passwordBytes.length > 64 ? sha256(passwordBytes) : passwordBytes;
    const ipad = new Uint8Array(64).fill(0x36);
    const opad = new Uint8Array(64).fill(0x5c);
    for (let i = 0; i < key.length; i += 1) { ipad[i] ^= key[i]; opad[i] ^= key[i]; }
    const inner = absorb(IV, ipad);
    const outer = absorb(IV, opad);
    const first = new Uint8Array(salt.length + 4);
    first.set(salt);
    first[salt.length + 3] = 1; // block number 1, big-endian
    const u = finish(outer, 64, wordsToBytes(finish(inner, 64, first)));
    // Later rounds hash a 32-byte message: fixed padding, length (64 + 32) bytes.
    const innerBlock = new Uint32Array(16);
    const outerBlock = new Uint32Array(16);
    innerBlock[8] = 0x80000000; innerBlock[15] = 768;
    outerBlock[8] = 0x80000000; outerBlock[15] = 768;
    return { inner, outer, u, result: Uint32Array.from(u), innerBlock, outerBlock, h: new Uint32Array(8) };
  }

  function pbkdf2Rounds(run, count) {
    const { inner, outer, u, result, innerBlock, outerBlock, h } = run;
    for (let round = 0; round < count; round += 1) {
      innerBlock.set(u);
      h.set(inner);
      compress(h, innerBlock);
      outerBlock.set(h);
      h.set(outer);
      compress(h, outerBlock);
      u.set(h);
      for (let j = 0; j < 8; j += 1) result[j] ^= h[j];
    }
  }

  function pbkdf2Sync(passwordBytes, salt, iterations) {
    const run = pbkdf2Start(passwordBytes, salt);
    pbkdf2Rounds(run, iterations - 1);
    return wordsToBytes(run.result);
  }

  /* Lets the page paint (for example a "Logging in…" label) before long
     work, and between its chunks. Falls back to a timer where frames do
     not run, such as a hidden tab. */
  function pause() {
    return new Promise((resolve) => {
      const timer = setTimeout(resolve, 100);
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(() => setTimeout(() => { clearTimeout(timer); resolve(); }, 0));
      }
    });
  }

  async function pbkdf2InChunks(passwordBytes, salt, iterations, chunk = 25000) {
    await pause();
    const run = pbkdf2Start(passwordBytes, salt);
    let left = iterations - 1;
    while (left > 0) {
      const count = Math.min(chunk, left);
      pbkdf2Rounds(run, count);
      left -= count;
      if (left > 0) await pause();
    }
    return wordsToBytes(run.result);
  }

  function utf8(text) {
    const value = String(text).normalize('NFC');
    const bytes = [];
    for (const char of value) {
      const code = char.codePointAt(0);
      if (code < 0x80) bytes.push(code);
      else if (code < 0x800) bytes.push(0xc0 | (code >> 6), 0x80 | (code & 63));
      else if (code < 0x10000) bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63));
      else bytes.push(0xf0 | (code >> 18), 0x80 | ((code >> 12) & 63), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63));
    }
    return Uint8Array.from(bytes);
  }

  function toHex(bytes) {
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function fromHex(text) {
    const value = String(text || '');
    const bytes = new Uint8Array(Math.floor(value.length / 2));
    for (let i = 0; i < bytes.length; i += 1) bytes[i] = parseInt(value.slice(i * 2, i * 2 + 2), 16) || 0;
    return bytes;
  }

  /* Compares two strings in time that does not depend on where they differ. */
  function sameText(a, b) {
    const x = String(a);
    const y = String(b);
    let diff = x.length ^ y.length;
    for (let i = 0; i < Math.max(x.length, y.length); i += 1) diff |= (x.charCodeAt(i) || 0) ^ (y.charCodeAt(i) || 0);
    return diff === 0;
  }

  async function derive(password, salt, iterations) {
    const bytes = utf8(password);
    const subtle = typeof crypto !== 'undefined' && crypto && crypto.subtle;
    if (subtle) {
      try {
        const key = await subtle.importKey('raw', bytes, 'PBKDF2', false, ['deriveBits']);
        const bits = await subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256);
        return new Uint8Array(bits);
      } catch (error) { /* Web Crypto unavailable here (for example an insecure context): use the code above */ }
    }
    return pbkdf2InChunks(bytes, salt, iterations);
  }

  async function hash(password, { iterations = AUTH_CONFIG.hashIterations, salt = randomBytes(16) } = {}) {
    const derived = await derive(password, salt, iterations);
    return { algorithm: 'PBKDF2-SHA-256', iterations, salt: toHex(salt), hash: toHex(derived) };
  }

  async function verify(password, record) {
    if (!record || typeof record.hash !== 'string' || typeof record.salt !== 'string') return false;
    const iterations = Number(record.iterations);
    if (!Number.isInteger(iterations) || iterations < 1) return false;
    const derived = await derive(password, fromHex(record.salt), iterations);
    return sameText(toHex(derived), record.hash);
  }

  return { sha256, pbkdf2Sync, pbkdf2InChunks, utf8, toHex, fromHex, hash, verify };
})();

/* Random bytes for salts and account IDs. Without a random source (very
   old browsers) the clock is mixed through SHA-256: unique, not secret. */
let randomFallbackCounter = 0;
function randomBytes(length) {
  const bytes = new Uint8Array(length);
  if (typeof crypto !== 'undefined' && crypto && typeof crypto.getRandomValues === 'function') {
    crypto.getRandomValues(bytes);
    return bytes;
  }
  randomFallbackCounter += 1;
  const clock = typeof performance !== 'undefined' && performance.now ? performance.now() : 0;
  let pool = PasswordHash.sha256(PasswordHash.utf8(`${Date.now()}:${clock}:${randomFallbackCounter}`));
  for (let i = 0; i < length; i += 1) {
    if (i && i % 32 === 0) pool = PasswordHash.sha256(pool);
    bytes[i] = pool[i % 32];
  }
  return bytes;
}

/* ---------- Accounts ---------- */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;

function normaliseEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function accountName(account) {
  return account ? [account.firstName, account.lastName].map((part) => String(part || '').trim()).filter(Boolean).join(' ') : '';
}

function roleLabel(value) {
  const role = AUTH_CONFIG.roles.find((item) => item.value === value);
  return role ? role.label : 'Staff';
}

function isValidAccount(account) {
  return Boolean(account && typeof account === 'object' && typeof account.id === 'string' && typeof account.email === 'string'
    && account.password && typeof account.password.hash === 'string' && typeof account.firstName === 'string');
}

const AccountStore = {
  key: APP_CONFIG.storageKeys.accounts,
  list() {
    const items = SafeStorage.read(this.key, []);
    return Array.isArray(items) ? items.filter(isValidAccount) : [];
  },
  get(id) {
    return this.list().find((account) => account.id === id) || null;
  },
  findByEmail(email) {
    const wanted = normaliseEmail(email);
    return this.list().find((account) => account.email === wanted) || null;
  },
  save(account) {
    const items = this.list();
    const index = items.findIndex((item) => item.id === account.id);
    if (index >= 0) items[index] = deepClone(account);
    else items.push(deepClone(account));
    return SafeStorage.write(this.key, items);
  },
};

/* Pure validation of one sign-up step. Returns { valid, errors }.
   `accounts` are the accounts already on this computer (for the one
   account per email rule), without the one being set up again. */
function validateSignupStep(stepId, form, accounts = []) {
  const errors = {};
  const nameError = (value, label, required) => {
    const text = String(value || '').trim();
    if (!text) return required ? `Enter your ${label}.` : '';
    if (text.length > 40) return `${capitalise(label)} must be 40 characters or fewer.`;
    if (!NAME_PATTERN.test(text)) return 'Use letters only. Spaces, full stops, apostrophes and hyphens are allowed.';
    return '';
  };
  if (stepId === 'account') {
    const first = nameError(form.firstName, 'first name', true);
    if (first) errors.firstName = first;
    const last = nameError(form.lastName, 'last name', false);
    if (last) errors.lastName = last;
    const email = normaliseEmail(form.email);
    if (!email) errors.email = 'Enter your work email.';
    else if (email.length > 120 || !EMAIL_PATTERN.test(email)) errors.email = 'Enter an email address like name@hospital.org.';
    else if (accounts.some((account) => account.email === email)) errors.email = 'An account with this email already exists on this computer. Log in instead.';
    const password = String(form.password || '');
    if (password.length < AUTH_CONFIG.passwordMin) errors.password = `Use at least ${AUTH_CONFIG.passwordMin} characters.`;
    else if (password.length > AUTH_CONFIG.passwordMax) errors.password = `Use ${AUTH_CONFIG.passwordMax} characters or fewer.`;
    else if (!password.trim()) errors.password = 'Use letters, numbers or symbols, not only spaces.';
  }
  if (stepId === 'desk') {
    const hospital = String(form.hospital || '').trim();
    if (!hospital) errors.hospital = 'Enter the hospital or clinic name.';
    else if (hospital.length > 80) errors.hospital = 'Keep the hospital name to 80 characters or fewer.';
    const desk = String(form.desk || '').trim();
    if (!desk) errors.desk = 'Enter a name for this desk, such as Reception desk.';
    else if (desk.length > 40) errors.desk = 'Keep the desk name to 40 characters or fewer.';
    if (!AUTH_CONFIG.roles.some((role) => role.value === form.role)) errors.role = 'Choose your role.';
  }
  if (stepId === 'confirm' && !form.confirmed) errors.confirmed = 'Tick the box to confirm how MediFind is used.';
  return { valid: Object.keys(errors).length === 0, errors };
}

/* Creates an account, or sets an existing one up again with a new
   password (`replaceId`), which also signs it out everywhere. */
async function createAccount(form, { replaceId = null } = {}) {
  const email = normaliseEmail(form.email);
  const clash = () => {
    const existing = AccountStore.findByEmail(email);
    return existing && existing.id !== replaceId;
  };
  if (clash()) throw new Error('An account with this email already exists.');
  const password = await PasswordHash.hash(form.password);
  if (clash()) throw new Error('An account with this email already exists.'); // set up meanwhile in another tab
  const now = new Date().toISOString();
  const previous = replaceId ? AccountStore.get(replaceId) : null;
  const account = {
    id: previous ? previous.id : `acct-${PasswordHash.toHex(randomBytes(8))}`,
    firstName: String(form.firstName).trim(),
    lastName: String(form.lastName || '').trim(),
    email,
    role: form.role,
    hospital: String(form.hospital).trim(),
    desk: String(form.desk).trim(),
    password,
    createdAt: previous ? previous.createdAt : now,
    lastSignInAt: previous ? previous.lastSignInAt : null,
    safeUseConfirmedAt: now,
    ...(previous ? { setUpAgainAt: now, signedOutAt: now } : {}),
  };
  AccountStore.save(account);
  return account;
}

/* ---------- Session ---------- */

let signedInAccount = null;

/* The session lasts for this tab (sessionStorage) unless "Keep me signed
   in" was ticked, which also keeps it in localStorage. */
const SessionStore = (() => {
  const key = APP_CONFIG.storageKeys.session;
  let memory = null;
  const tab = {
    read() {
      try {
        const text = window.sessionStorage.getItem(key);
        return text ? JSON.parse(text) : null;
      } catch (error) { return null; }
    },
    write(value) {
      try { window.sessionStorage.setItem(key, JSON.stringify(value)); } catch (error) { /* memory only */ }
    },
    remove() {
      try { window.sessionStorage.removeItem(key); } catch (error) { /* nothing stored */ }
    },
  };
  return {
    load() { return memory || tab.read() || SafeStorage.read(key, null); },
    save(session, keep) {
      memory = session;
      tab.write(session);
      if (keep) SafeStorage.write(key, session);
      else SafeStorage.remove(key);
    },
    /* Clears this tab's session, and the kept one if it is the same account's. */
    clear(accountId = null) {
      memory = null;
      tab.remove();
      const kept = SafeStorage.read(key, null);
      if (!accountId || !kept || kept.accountId === accountId) SafeStorage.remove(key);
    },
  };
})();

/* A session is valid while its account exists and has not been signed
   out (in any tab) since the session started. */
function sessionIsCurrent(session, account) {
  return Boolean(session && account && typeof session.startedAt === 'string'
    && (!account.signedOutAt || session.startedAt > account.signedOutAt));
}

function restoreSession() {
  const session = SessionStore.load();
  const account = session && typeof session.accountId === 'string' ? AccountStore.get(session.accountId) : null;
  signedInAccount = sessionIsCurrent(session, account) ? account : null;
  if (session && !signedInAccount) SessionStore.clear();
  return signedInAccount;
}

/* Signing out in one tab signs that account out in the others too. */
function watchOtherTabs() {
  window.addEventListener('storage', (event) => {
    if (event.key !== APP_CONFIG.storageKeys.accounts || !signedInAccount || isSignedOut()) return;
    const account = AccountStore.get(signedInAccount.id);
    if (sessionIsCurrent(SessionStore.load(), account)) {
      signedInAccount = account;
      return;
    }
    leaveApp('You were signed out in another tab.');
  });
}

function startSession(account, { keep = false } = {}) {
  let now = new Date().toISOString();
  if (account.signedOutAt && now <= account.signedOutAt) now = new Date(Date.parse(account.signedOutAt) + 1).toISOString();
  const updated = { ...account, lastSignInAt: now };
  AccountStore.save(updated);
  SessionStore.save({ accountId: updated.id, startedAt: now }, keep);
  signedInAccount = updated;
  return updated;
}

function isSignedOut() {
  return typeof document !== 'undefined' && document.body && document.body.dataset.auth === 'signed-out';
}

/* Who started an assessment, stored with it (section 2). */
function currentStaff() {
  const account = signedInAccount;
  return account ? { id: account.id, name: accountName(account), role: roleLabel(account.role) } : null;
}

/* Who is at the desk: used by the shell, the dashboard and new reports. */
function currentProfile() {
  const account = signedInAccount;
  return {
    signedIn: Boolean(account),
    name: accountName(account),
    firstName: account ? account.firstName : '',
    role: account ? roleLabel(account.role) : '',
    hospital: (account && account.hospital) || APP_CONFIG.hospitalName,
    desk: (account && account.desk) || APP_CONFIG.deskName,
  };
}

/* ---------- Sign-in screen state ---------- */

function emptyAuthForm() {
  return {
    firstName: '', lastName: '', email: '', password: '',
    hospital: APP_CONFIG.hospitalName, desk: APP_CONFIG.deskName, role: AUTH_CONFIG.roles[0].value, confirmed: false,
    loginEmail: '', loginPassword: '', keep: false,
  };
}

const authUi = {
  mode: 'signup', // 'signup' | 'login'
  step: 0,
  form: emptyAuthForm(),
  errors: {},
  message: '', // a problem with the whole form, such as a wrong password
  busy: false,
  run: 0, // bumped whenever the screen changes, so a late result is ignored
  replacing: null, // id of the account being set up again after a forgotten password
  showPassword: false,
  glow: true, // fade the light in once, each time the screen is shown
};

function showAuthScreen({ mode, focus = true } = {}) {
  authUi.mode = mode || (AccountStore.list().length ? 'login' : 'signup');
  authUi.glow = true;
  authUi.step = 0;
  authUi.form = emptyAuthForm();
  authUi.errors = {};
  authUi.message = '';
  authUi.busy = false;
  authUi.run += 1;
  authUi.replacing = null;
  authUi.showPassword = false;
  document.body.dataset.auth = 'signed-out';
  const skip = document.querySelector('.skip-link');
  if (skip) skip.setAttribute('href', '#auth-main');
  renderAuth({ focus });
}

function renderAuth({ focus = true, focusField = null } = {}) {
  const root = document.getElementById('auth-root');
  if (!root) return;
  root.innerHTML = String(renderAuthScreen());
  authUi.glow = false;
  const step = AUTH_CONFIG.signupSteps[authUi.step];
  document.title = `${authUi.mode === 'login' ? 'Log in' : step.title} | ${APP_CONFIG.shortName}`;
  const field = focusField ? document.getElementById(`auth-${focusField}`) : null;
  if (field) field.focus();
  else if (focus) {
    const title = document.getElementById('auth-title');
    if (title) title.focus({ preventScroll: true });
  }
}

/* While an account is created or a password checked, the main button says
   so and the other controls wait. Nothing is re-rendered, so focus stays. */
function setAuthBusy(busy, label) {
  authUi.busy = busy;
  document.querySelectorAll('.auth-card button').forEach((button) => {
    if (!button.classList.contains('auth-btn--primary')) {
      button.disabled = busy;
      return;
    }
    if (busy) {
      button.setAttribute('aria-disabled', 'true');
      button.setAttribute('aria-busy', 'true');
      if (label) button.textContent = label;
    }
  });
}

/* ---------- Sign-in screen markup ---------- */

function renderAuthScreen() {
  const signup = authUi.mode === 'signup';
  return html`
    <div class="auth" data-mode="${authUi.mode}">
      <div class="auth-hero">
        <svg class="auth-hero__glow${authUi.glow ? ' is-entering' : ''}" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><use href="#mf-glow"></use></svg>
        ${brandLogo('auth-hero__logo', 'light')}
        <div class="auth-hero__body">
          <div class="auth-hero__intro">
            <p class="auth-hero__title">${signup ? 'Get started with MediFind' : 'Welcome back'}</p>
            <p class="auth-hero__text">${signup
              ? 'Three short steps, then you can start your first patient assessment.'
              : 'Log in to pick up where the desk left off.'}</p>
          </div>
          ${signup ? renderSignupSteps() : renderTourSteps()}
        </div>
      </div>
      <main class="auth-main" id="auth-main" tabindex="-1">
        <div class="auth-card">${signup ? renderSignupForm() : renderLoginForm()}</div>
        <p class="auth-note">${icon('database')}<span>${SafeStorage.persistent
          ? 'Accounts and assessments are stored only in this browser.'
          : 'This browser is blocking storage, so accounts and assessments are lost when this page is reloaded or closed.'}</span></p>
      </main>
    </div>`;
}

function renderSignupSteps() {
  return html`
    <ol class="auth-steps" aria-label="Steps to ${authUi.replacing ? 'set up your account again' : 'create your account'}">
      ${AUTH_CONFIG.signupSteps.map((step, index) => {
        const status = index < authUi.step ? 'done' : (index === authUi.step ? 'current' : 'upcoming');
        return html`
          <li class="auth-step is-${status}" ${status === 'current' ? raw('aria-current="step"') : ''}>
            <span class="auth-step__num" aria-hidden="true">${status === 'done' ? icon('check') : index + 1}</span>
            <span class="auth-step__label">${step.label}${status === 'done' ? html`<span class="visually-hidden"> (done)</span>` : ''}</span>
          </li>`;
      })}
    </ol>`;
}

function renderTourSteps() {
  return html`
    <ol class="auth-steps auth-steps--tour" aria-label="An assessment in short">
      ${AUTH_CONFIG.tour.map((label, index) => html`
        <li class="auth-step"><span class="auth-step__num" aria-hidden="true">${index + 1}</span><span class="auth-step__label">${label}</span></li>`)}
    </ol>`;
}

function authHead(title, lead, { position = '' } = {}) {
  return html`
    <header class="auth-head">
      <h1 class="auth-head__title" id="auth-title" tabindex="-1">${position ? html`<span class="visually-hidden">${position}: </span>` : ''}${title}</h1>
      <p class="auth-head__lead">${lead}</p>
    </header>
    ${authUi.message ? html`<p class="auth-alert" role="alert" data-auth-alert>${icon('circle-alert')}<span>${authUi.message}</span></p>` : ''}`;
}

function authFieldError(id) {
  const error = authUi.errors[id];
  return html`<p class="auth-field__error" id="auth-${id}-error" data-auth-error="${id}">${error ? html`${icon('circle-alert')}<span>${error}</span>` : ''}</p>`;
}

function authInput({ id, label, type = 'text', autocomplete, placeholder = '', optional = false, inputmode = '', hint = '', password = false, readonly = false }) {
  const error = authUi.errors[id];
  const described = [hint ? `auth-${id}-hint` : '', `auth-${id}-error`].filter(Boolean).join(' ');
  const input = html`<input class="auth-input" id="auth-${id}" name="${id}" type="${password && !authUi.showPassword ? 'password' : type}"
    value="${authUi.form[id] || ''}" data-auth-field="${id}" autocomplete="${autocomplete}" placeholder="${placeholder}"
    autocapitalize="${type === 'email' || password ? 'off' : 'words'}" spellcheck="false" ${inputmode ? raw(`inputmode="${inputmode}"`) : ''}
    ${readonly ? raw('readonly') : ''} aria-describedby="${described}" ${error ? raw('aria-invalid="true"') : ''}>`;
  return html`
    <div class="auth-field${error ? ' has-error' : ''}" data-auth-wrap="${id}">
      <label class="auth-field__label" for="auth-${id}">${label}${optional ? html`<span class="auth-field__optional"> (optional)</span>` : ''}</label>
      ${password ? html`
        <div class="auth-input-wrap">
          ${input}
          <button type="button" class="auth-eye" data-action="auth-toggle-password" aria-controls="auth-${id}" aria-label="Show password" aria-pressed="${authUi.showPassword ? 'true' : 'false'}">${icon(authUi.showPassword ? 'eye-off' : 'eye')}</button>
        </div>` : input}
      ${hint ? html`<p class="auth-field__hint" id="auth-${id}-hint">${hint}</p>` : ''}
      ${authFieldError(id)}
    </div>`;
}

function authCheckbox({ id, label, small = false }) {
  const error = authUi.errors[id];
  return html`
    <div class="auth-field auth-field--check${error ? ' has-error' : ''}" data-auth-wrap="${id}">
      <label class="auth-check${small ? ' auth-check--small' : ''}">
        <input type="checkbox" id="auth-${id}" data-auth-field="${id}" ${authUi.form[id] ? raw('checked') : ''} aria-describedby="auth-${id}-error" ${error ? raw('aria-invalid="true"') : ''}>
        <span class="auth-check__box" aria-hidden="true">${icon('check')}</span>
        <span class="auth-check__label">${label}</span>
      </label>
      ${authFieldError(id)}
    </div>`;
}

function renderSignupForm() {
  const steps = AUTH_CONFIG.signupSteps;
  const step = steps[authUi.step];
  const f = authUi.form;
  const last = authUi.step === steps.length - 1;
  const again = Boolean(authUi.replacing);
  const name = [f.firstName, f.lastName].map((part) => String(part || '').trim()).filter(Boolean).join(' ');
  const title = again && step.id === 'account' ? 'Set up your account again' : step.title;
  const lead = again && step.id === 'account'
    ? `Choose a new password for ${normaliseEmail(f.email)}. The old password stops working.`
    : step.lead;
  return html`
    ${authHead(title, lead, { position: `Step ${authUi.step + 1} of ${steps.length}` })}
    <form class="auth-form" data-form="auth" novalidate>
      ${step.id === 'account' ? html`
        <div class="auth-row">
          ${authInput({ id: 'firstName', label: 'First name', autocomplete: 'given-name', placeholder: 'e.g. Priya' })}
          ${authInput({ id: 'lastName', label: 'Last name', optional: true, autocomplete: 'family-name', placeholder: 'e.g. Shah' })}
        </div>
        ${authInput({ id: 'email', label: 'Work email', type: 'email', autocomplete: again ? 'username' : 'email', inputmode: 'email', placeholder: 'e.g. priya.shah@hospital.org', readonly: again })}
        ${authInput({ id: 'password', label: again ? 'New password' : 'Password', password: true, autocomplete: 'new-password', placeholder: 'Create a password', hint: `Use at least ${AUTH_CONFIG.passwordMin} characters.` })}` : ''}
      ${step.id === 'desk' ? html`
        ${authInput({ id: 'hospital', label: 'Hospital or clinic', autocomplete: 'organization', placeholder: 'e.g. City Multispeciality Hospital' })}
        ${authInput({ id: 'desk', label: 'Desk name', autocomplete: 'off', placeholder: 'e.g. OPD counter 2', hint: 'The counter or room this computer is at.' })}
        <fieldset class="auth-field auth-roles${authUi.errors.role ? ' has-error' : ''}" data-auth-wrap="role" aria-describedby="auth-role-error">
          <legend class="auth-field__label">Your role</legend>
          <div class="auth-choice-grid">
            ${AUTH_CONFIG.roles.map((role) => html`
              <label class="auth-choice">
                <input type="radio" name="auth-role" value="${role.value}" data-auth-field="role" ${f.role === role.value ? raw('checked') : ''}>
                <span>${role.label}</span>
              </label>`)}
          </div>
          ${authFieldError('role')}
        </fieldset>` : ''}
      ${step.id === 'confirm' ? html`
        <div class="auth-summary">
          <span class="auth-avatar" aria-hidden="true">${initials(name)}</span>
          <div class="auth-summary__text">
            <p class="auth-summary__name">${name}</p>
            <p class="auth-summary__meta">${roleLabel(f.role)}, ${String(f.desk).trim()}, ${String(f.hospital).trim()}</p>
            <p class="auth-summary__meta">${normaliseEmail(f.email)}</p>
          </div>
        </div>
        <ul class="auth-safe">
          ${AUTH_CONFIG.safeUse.map((line) => html`<li>${icon('shield-check')}<span>${line}</span></li>`)}
        </ul>
        ${authCheckbox({ id: 'confirmed', label: 'I understand how MediFind should be used.' })}` : ''}
      <div class="auth-actions">
        ${authUi.step > 0 ? html`<button type="button" class="auth-btn auth-btn--ghost" data-action="auth-back">${icon('arrow-left')}<span>Back</span></button>` : ''}
        <button type="button" class="auth-btn auth-btn--primary" data-action="auth-continue">${last ? (again ? 'Save and log in' : 'Create account') : 'Continue'}</button>
      </div>
    </form>
    <p class="auth-switch">${again
      ? html`Remembered your password? <button type="button" class="auth-link" data-action="auth-mode" data-mode="login">Log in</button>`
      : html`Already have an account? <button type="button" class="auth-link" data-action="auth-mode" data-mode="login">Log in</button>`}</p>`;
}

function renderLoginForm() {
  const accounts = AccountStore.list()
    .sort((a, b) => String(b.lastSignInAt || b.createdAt || '').localeCompare(String(a.lastSignInAt || a.createdAt || '')))
    .slice(0, AUTH_CONFIG.quickPickLimit);
  const chosen = normaliseEmail(authUi.form.loginEmail);
  return html`
    ${authHead('Log in to MediFind', 'Enter your email and password to open the desk.')}
    ${accounts.length ? html`
      <div class="auth-quick" role="group" aria-labelledby="auth-quick-label">
        <p class="auth-quick__label" id="auth-quick-label">Accounts on this computer</p>
        <div class="auth-quick__list${accounts.length === 1 ? ' auth-quick__list--single' : ''}">
          ${accounts.map((account) => {
            const label = `${accountName(account)}, ${roleLabel(account.role)}, ${account.desk}`;
            return html`
              <button type="button" class="auth-account${account.email === chosen ? ' is-selected' : ''}" data-action="auth-pick-account" data-email="${account.email}"
                aria-pressed="${account.email === chosen ? 'true' : 'false'}" title="${label}">
                <span class="auth-avatar auth-avatar--sm" aria-hidden="true">${initials(accountName(account))}</span>
                <span class="auth-account__text">
                  <span class="auth-account__name">${accountName(account)}</span>
                  <span class="auth-account__meta">${roleLabel(account.role)}, ${account.desk}</span>
                </span>
              </button>`;
          })}
        </div>
      </div>` : ''}
    <form class="auth-form" data-form="auth" novalidate>
      ${authInput({ id: 'loginEmail', label: 'Email', type: 'email', autocomplete: 'username', inputmode: 'email', placeholder: 'e.g. priya.shah@hospital.org' })}
      ${authInput({ id: 'loginPassword', label: 'Password', password: true, autocomplete: 'current-password', placeholder: 'Enter your password' })}
      <div class="auth-row auth-row--between">
        ${SafeStorage.persistent ? authCheckbox({ id: 'keep', label: 'Keep me signed in', small: true }) : html`<span></span>`}
        <button type="button" class="auth-link auth-link--muted" data-action="auth-forgot">Forgot password?</button>
      </div>
      <button type="button" class="auth-btn auth-btn--primary" data-action="auth-login">Log in</button>
    </form>
    <p class="auth-switch">New to MediFind? <button type="button" class="auth-link" data-action="auth-mode" data-mode="signup">Create an account</button></p>`;
}

/* ---------- Sign-in screen behaviour ---------- */

/* Keeps typed values in state and clears the field's message as soon as
   it is being fixed, without re-rendering (focus and caret stay put). */
function updateAuthField(field, value) {
  authUi.form[field] = value;
  if (authUi.errors[field]) {
    delete authUi.errors[field];
    const wrap = document.querySelector(`[data-auth-wrap="${field}"]`);
    if (wrap) wrap.classList.remove('has-error');
    const slot = document.querySelector(`[data-auth-error="${field}"]`);
    if (slot) slot.innerHTML = '';
    const input = document.getElementById(`auth-${field}`);
    if (input) input.removeAttribute('aria-invalid');
  }
  if (authUi.message) {
    authUi.message = '';
    const alert = document.querySelector('[data-auth-alert]');
    if (alert) alert.remove();
  }
  if (field === 'loginEmail') {
    const wanted = normaliseEmail(value);
    document.querySelectorAll('[data-action="auth-pick-account"]').forEach((button) => {
      const selected = button.dataset.email === wanted;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    });
  }
}

function firstErrorField(errors, order) {
  return order.find((field) => errors[field]) || null;
}

const SIGNUP_FIELD_ORDER = ['firstName', 'lastName', 'email', 'password', 'hospital', 'desk', 'role', 'confirmed'];

/* Accounts that the one-account-per-email rule applies to. */
function otherAccounts() {
  return AccountStore.list().filter((account) => account.id !== authUi.replacing);
}

async function continueSignup() {
  if (authUi.busy) return;
  const steps = AUTH_CONFIG.signupSteps;
  const check = validateSignupStep(steps[authUi.step].id, authUi.form, otherAccounts());
  authUi.errors = check.errors;
  authUi.message = '';
  if (!check.valid) {
    renderAuth({ focusField: firstErrorField(check.errors, SIGNUP_FIELD_ORDER) });
    return;
  }
  if (authUi.step < steps.length - 1) {
    authUi.step += 1;
    authUi.showPassword = false;
    renderAuth();
    return;
  }
  // Last step: check every step again (another tab may have used the email), then save.
  for (let index = 0; index < steps.length; index += 1) {
    const result = validateSignupStep(steps[index].id, authUi.form, otherAccounts());
    if (!result.valid) {
      authUi.step = index;
      authUi.errors = result.errors;
      renderAuth({ focusField: firstErrorField(result.errors, SIGNUP_FIELD_ORDER) });
      return;
    }
  }
  const run = ++authUi.run;
  const again = Boolean(authUi.replacing);
  setAuthBusy(true, again ? 'Saving…' : 'Creating account…');
  try {
    const account = await createAccount(authUi.form, { replaceId: authUi.replacing });
    if (run !== authUi.run || !isSignedOut()) return;
    const started = startSession(account, { keep: false });
    enterApp(again ? `Account set up again. You’re signed in as ${accountName(started)}.` : `Account created. You’re signed in as ${accountName(started)}.`);
  } catch (error) {
    if (run !== authUi.run || !isSignedOut()) return;
    authUi.busy = false;
    authUi.step = 0;
    authUi.errors = validateSignupStep('account', authUi.form, otherAccounts()).errors;
    authUi.message = authUi.errors.email ? '' : 'The account could not be saved. Try again.';
    renderAuth({ focusField: authUi.errors.email ? 'email' : null });
  }
}

function backSignup() {
  if (authUi.busy || authUi.step === 0) return;
  authUi.step -= 1;
  authUi.errors = {};
  authUi.message = '';
  authUi.showPassword = false;
  renderAuth();
}

async function submitLogin() {
  if (authUi.busy) return;
  const f = authUi.form;
  const errors = {};
  if (isBlank(f.loginEmail)) errors.loginEmail = 'Enter your email.';
  if (!f.loginPassword) errors.loginPassword = 'Enter your password.';
  authUi.errors = errors;
  authUi.message = '';
  if (Object.keys(errors).length) {
    renderAuth({ focusField: firstErrorField(errors, ['loginEmail', 'loginPassword']) });
    return;
  }
  const run = ++authUi.run;
  setAuthBusy(true, 'Logging in…');
  const account = AccountStore.findByEmail(f.loginEmail);
  const ok = account ? await PasswordHash.verify(f.loginPassword, account.password) : false;
  if (run !== authUi.run || !isSignedOut()) return;
  authUi.busy = false;
  if (!ok) {
    authUi.form.loginPassword = '';
    authUi.message = 'That email and password don’t match an account on this computer. Check them and try again.';
    renderAuth({ focusField: 'loginPassword' });
    return;
  }
  const started = startSession(account, { keep: SafeStorage.persistent && Boolean(f.keep) });
  enterApp(`Signed in as ${accountName(started)}.`);
}

function switchAuthMode(mode) {
  if (authUi.busy) return;
  const typedEmail = authUi.mode === 'signup' ? authUi.form.email : authUi.form.loginEmail;
  const wasReplacing = Boolean(authUi.replacing);
  authUi.mode = mode === 'login' ? 'login' : 'signup';
  authUi.step = 0;
  authUi.errors = {};
  authUi.message = '';
  authUi.run += 1;
  authUi.replacing = null;
  authUi.showPassword = false;
  authUi.form.password = '';
  authUi.form.loginPassword = '';
  if (authUi.mode === 'login' && typedEmail) authUi.form.loginEmail = typedEmail;
  // An email that already has an account is not offered for a new one.
  if (authUi.mode === 'signup' && !wasReplacing && typedEmail && !authUi.form.email && !AccountStore.findByEmail(typedEmail)) {
    authUi.form.email = typedEmail;
  }
  renderAuth();
}

function pickAccount(email) {
  if (authUi.busy) return;
  updateAuthField('loginEmail', email);
  authUi.errors = {};
  authUi.message = '';
  renderAuth({ focusField: 'loginPassword' });
}

/* Shows or hides the password in place, so focus and caret stay put. */
function togglePasswordVisibility(button) {
  authUi.showPassword = !authUi.showPassword;
  const input = document.getElementById(button.getAttribute('aria-controls'));
  if (input) input.type = authUi.showPassword ? 'text' : 'password';
  button.setAttribute('aria-pressed', authUi.showPassword ? 'true' : 'false');
  button.innerHTML = String(icon(authUi.showPassword ? 'eye-off' : 'eye'));
}

/* No server keeps accounts or could confirm who someone is, so a forgotten
   password cannot be recovered. The account can be set up again on this computer
   with a new password instead. */
function explainPasswordReset() {
  if (authUi.busy) return;
  const account = AccountStore.findByEmail(authUi.form.loginEmail);
  const intro = 'MediFind keeps accounts only in this browser. No server holds a copy that could confirm who you are, so a forgotten password can’t be recovered.';
  openModal({
    tone: 'warning',
    icon: 'lock-keyhole',
    title: 'This password can’t be recovered',
    text: account
      ? `${intro} You can set up ${account.email} again with a new password; the old one stops working. Saved assessments stay as they are.`
      : `${intro} Enter or pick your email first to set that account up again, or create a new account.`,
    actions: account
      ? [
        { label: 'Back to log in', variant: 'secondary', autofocus: true },
        { label: 'Set up again', variant: 'primary', onClick: () => startAccountReset(account) },
      ]
      : [
        { label: 'Back to log in', variant: 'secondary', autofocus: true },
        { label: 'Create an account', variant: 'primary', onClick: () => switchAuthMode('signup') },
      ],
  });
}

function startAccountReset(account) {
  switchAuthMode('signup');
  authUi.replacing = account.id;
  Object.assign(authUi.form, {
    firstName: account.firstName, lastName: account.lastName || '', email: account.email, password: '',
    hospital: account.hospital, desk: account.desk, role: account.role, confirmed: false,
  });
  renderAuth({ focusField: 'password' });
}

/* Enter in a field moves the sign-in screen forward, like its main button. */
function handleAuthKeydown(event) {
  if (event.key !== 'Enter' || !event.target.matches('.auth input')) return;
  event.preventDefault();
  if (authUi.mode === 'login') submitLogin();
  else continueSignup();
}

/* ---------- Entering and leaving the app ---------- */

function applyAccountToShell() {
  const profile = currentProfile();
  const name = document.querySelector('[data-account-name]');
  if (name) {
    name.textContent = profile.name || profile.desk;
    name.title = name.textContent;
  }
  const meta = document.querySelector('[data-account-meta]');
  if (meta) {
    meta.textContent = profile.signedIn ? `${profile.role}, ${profile.desk}` : 'Front-desk workstation';
    meta.title = meta.textContent;
  }
  const avatar = document.querySelector('[data-account-avatar]');
  if (avatar && profile.signedIn) avatar.textContent = initials(profile.name);
  document.querySelectorAll('[data-action="sign-out"]').forEach((button) => {
    button.setAttribute('aria-label', profile.signedIn ? `Sign out ${profile.name}` : 'Sign out');
    button.title = profile.signedIn ? `Sign out ${profile.name}` : 'Sign out';
  });
}

function enterApp(message) {
  document.body.dataset.auth = 'signed-in';
  const root = document.getElementById('auth-root');
  if (root) root.innerHTML = '';
  const skip = document.querySelector('.skip-link');
  if (skip) skip.setAttribute('href', '#main');
  authUi.form = emptyAuthForm();
  authUi.errors = {};
  authUi.message = '';
  authUi.busy = false;
  authUi.replacing = null;
  authUi.run += 1;
  applyAccountToShell();
  navigateTo('dashboard');
  if (message) showToast(message);
  if (!SafeStorage.persistent) showToast(STORAGE_UNAVAILABLE_TEXT, 'warning');
}

function requestSignOut() {
  if (!signedInAccount) return;
  if (hasUnsavedProgress()) {
    const name = state.assessment.patient.name;
    openModal({
      tone: 'warning',
      icon: 'log-out',
      title: 'Sign out with an assessment in progress?',
      text: `${name ? `The assessment for ${name}` : 'The current assessment'} stays saved on this computer. Whoever logs in next can resume or discard it.`,
      actions: [
        { label: 'Stay signed in', variant: 'secondary', autofocus: true },
        { label: 'Sign out', variant: 'primary', onClick: () => signOut() },
      ],
    });
    return;
  }
  signOut();
}

/* Signs the account out here and, through its sign-out time, in every
   other tab and kept session. */
function signOut() {
  if (signedInAccount) {
    const account = AccountStore.get(signedInAccount.id);
    if (account) AccountStore.save({ ...account, signedOutAt: new Date().toISOString() });
  }
  leaveApp('Signed out.');
}

function leaveApp(message) {
  persistDraft();
  closeDrawer({ restoreFocus: false });
  closeModal({ restoreFocus: false });
  SessionStore.clear(signedInAccount ? signedInAccount.id : null);
  signedInAccount = null;
  const toasts = document.getElementById('toast-region');
  if (toasts) toasts.innerHTML = '';
  showAuthScreen({ mode: 'login' });
  showToast(message);
}
