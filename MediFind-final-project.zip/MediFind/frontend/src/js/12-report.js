/* =====================================================================
   12. REPORT GENERATION
   ---------------------------------------------------------------------
   The preliminary report is built from the live session data
   (state.assessment.patient, answers, prediction and recommendation)
   and stored with the assessment, so a reopened assessment shows the
   report exactly as it was generated.
   ===================================================================== */

function generateReport(assessment = state.assessment) {
  const findings = summariseFindings(assessment);
  const urgent = isUrgentAssessment(assessment);
  const prediction = assessment.prediction || null;
  const recommendation = assessment.recommendation || mapPredictionToSpecialist(prediction, { urgent });
  const complaint = getComplaint(assessment.patient.complaint);
  const infectionRisk = ['respiratory', 'fever'].includes(assessment.patient.complaint)
    || (prediction && prediction.topCategoryId === 'respiratory')
    || findings.present.some((item) => item.key === 'cough' || item.key === 'fever');

  const inconclusive = Boolean(prediction && prediction.isInconclusive);
  const mainProblem = mainProblemLabel(assessment);
  const profile = currentProfile();
  return {
    version: 3,
    generatedAt: new Date().toISOString(),
    assessmentId: assessment.id,
    hospital: profile.hospital,
    preparedBy: profile.signedIn ? { name: profile.name, role: profile.role, desk: profile.desk } : null,
    startedBy: startedByOther(assessment) ? { name: assessment.startedBy.name, role: assessment.startedBy.role || '' } : null,
    assessedAt: assessment.createdAt,
    revision: assessment.revision || 1,
    patient: {
      name: textOr(assessment.patient.name),
      age: isBlank(assessment.patient.age) ? 'Not recorded' : `${assessment.patient.age} years`,
      gender: genderLabel(assessment.patient.gender),
      contact: textOr(assessment.patient.contact),
    },
    complaint: {
      label: complaint ? complaint.label : 'Not recorded',
      mainProblem: complaint && mainProblem !== complaint.label ? mainProblem : '',
      description: isBlank(assessment.patient.description) ? '' : assessment.patient.description,
    },
    plain: plainSummary({ ...assessment, recommendation }),
    symptoms: {
      present: findings.present.map((item) => item.label),
      absent: findings.absent,
      unsure: findings.unsure,
      duration: findings.duration ? findings.duration.value : 'Not recorded',
      severity: findings.severity || 'Not rated for this complaint',
      temperature: findings.temperature,
      bodyMap: bodyMapSummary(assessment).map((pick) => pick.text),
      responses: findings.responses,
      notAsked: findings.notAsked,
    },
    assessment: urgent
      ? { withheld: true, category: 'Not generated', condition: 'Urgent warning signs take priority over disease prediction and classification.' }
      : {
        withheld: false,
        inconclusive,
        category: prediction ? prediction.predictedCategory : 'Not available',
        categoryLabel: prediction && CATEGORIES[prediction.topCategoryId] ? CATEGORIES[prediction.topCategoryId].label : '',
        pattern: prediction ? (prediction.predictedPattern || prediction.predictedCategory) : '',
        condition: inconclusive ? INCONCLUSIVE_RESULT.conditionLabel : (prediction ? textOr(prediction.predictedCondition, 'Not available') : 'Not available'),
        description: prediction && !inconclusive ? (prediction.conditionDescription || '') : '',
        likelihood: prediction && !inconclusive && Number.isFinite(prediction.conditionLikelihood) ? prediction.conditionLikelihood : null,
        fallback: Boolean(prediction && prediction.conditionIsFallback),
        tie: Boolean(prediction && prediction.conditionTie),
        differentials: prediction && !inconclusive && Array.isArray(prediction.differentials)
          ? prediction.differentials.map((item) => ({ name: item.name, short: item.short || item.name, likelihood: Number.isFinite(item.likelihood) ? item.likelihood : null }))
          : [],
        considered: prediction && inconclusive && Array.isArray(prediction.consideredConditions)
          ? prediction.consideredConditions.map((item) => ({ name: item.name, department: item.department }))
          : [],
        message: inconclusive ? INCONCLUSIVE_RESULT.message : '',
      },
    recommendation: {
      department: recommendation.department,
      specialist: recommendation.specialist,
      doctor: urgent ? '' : ((recommendedDoctor(recommendation) || {}).name || ''),
      code: recommendation.code,
      tone: recommendation.tone,
      nextStep: recommendation.nextStep,
    },
    safety: {
      urgent: (assessment.safety && assessment.safety.urgent) || [],
      priority: (assessment.safety && assessment.safety.priority) || [],
      marked: Boolean(assessment.urgentFlag),
      markedAt: assessment.urgentMarkedAt,
      endedEarly: Boolean(assessment.endedEarly),
      inconsistencies: (prediction && prediction.inconsistencies) || [],
    },
    care: urgent
      ? CARE_INFORMATION.urgent.slice()
      : [...CARE_INFORMATION.standard, ...(infectionRisk ? [CARE_INFORMATION.infectionControl] : [])],
    disclaimer: DISCLAIMERS.report,
    engineId: isModelResult(prediction) ? 'api' : 'local',
    conditionEngineId: conditionFromModel(prediction) ? 'api' : 'local',
    engine: isModelResult(prediction)
      ? `${engineInfoFor(prediction).name.replace(/^Trained ML model/, 'trained machine-learning model')} on the MediFind backend (trained on simulated cases; not a clinically validated model)`
      : 'prototype decision-support engine (rule-based symptom scoring, not a trained clinical model)',
  };
}

/* Generates (or refreshes) the report for the current assessment and saves it. */
function createReportForCurrentAssessment() {
  const assessment = state.assessment;
  if (!assessment.prediction && !isUrgentAssessment(assessment)) return null;
  assessment.report = generateReport(assessment);
  saveAssessment();
  return assessment.report;
}

function renderReportScreen() {
  const assessment = state.assessment;
  if (!assessment.id || (!assessment.prediction && !assessment.report)) {
    return html`<section class="screen screen--flow">
      ${renderEmptyState({
        icon: 'file-text',
        title: 'No report to show yet',
        text: 'Complete and run an assessment to generate its preliminary report.',
        action: { label: 'Go to dashboard', action: 'nav', nav: 'dashboard' },
      })}</section>`;
  }
  if (!assessment.report) createReportForCurrentAssessment();
  const report = assessment.report;

  return html`
    <section class="screen screen--flow screen--report">
      <div class="report-toolbar no-print">
        <div>
          <h1 class="screen-title" tabindex="-1">Preliminary report</h1>
          <p class="screen-lead">Generated ${formatDateTime(report.generatedAt)}. Check it with the patient, then print or save it as a PDF.</p>
        </div>
        <div class="report-toolbar__actions">
          <button type="button" class="btn btn-secondary" data-action="back-to-results">${icon('chevron-left')}<span>Back to result</span></button>
          <button type="button" class="btn btn-primary" data-action="print-report">${icon('printer')}<span>Print / Save as PDF</span></button>
        </div>
      </div>
      <p class="report-hint no-print">${icon('info')}<span>To save a PDF, choose <strong>Save as PDF</strong> as the destination in the print dialog.</span></p>
      ${renderReportDocument(report)}
      <div class="report-footer-actions no-print">
        <button type="button" class="btn btn-ghost" data-action="nav" data-nav-target="history">${icon('history')}<span>Assessment history</span></button>
        <button type="button" class="btn btn-secondary" data-action="new-assessment">${icon('plus')}<span>Start New Assessment</span></button>
      </div>
    </section>`;
}

/* "Preliminary assessment" block. Version 1 reports (saved before
   condition prediction existed) keep their original layout. */
function renderReportAssessment(report) {
  const a = report.assessment;
  if (a.withheld) return html`<p class="rpt-strong">Not generated</p><p>${a.condition}</p>`;
  if ((report.version || 1) < 2) {
    return html`
      <p class="rpt-label">Possible disease category</p>
      <p class="rpt-strong">${a.inconclusive ? a.category : a.pattern}</p>
      <p class="rpt-label">Likely classification (prototype)</p>
      <p>${a.condition}</p>
      ${a.message ? html`<p class="rpt-note">${a.message}</p>` : ''}`;
  }
  if (a.inconclusive) {
    return html`
      <p class="rpt-label">Possible disease category</p>
      <p class="rpt-strong">${a.category}</p>
      <p class="rpt-label">Predicted condition</p>
      <p>${a.condition}</p>
      ${a.considered.length ? html`<p class="rpt-note">Possible conditions for the doctor to consider: ${a.considered.map((item) => `${item.name} (${item.department})`).join('; ')}.</p>` : ''}
      <p class="rpt-note">${a.message}</p>`;
  }
  const others = a.differentials.map((item) => {
    const name = item.short || item.name;
    return item.likelihood === null ? name : `${name} ${item.likelihood}%`;
  });
  return html`
    <p class="rpt-label">Predicted condition (not confirmed)</p>
    <p class="rpt-strong">${a.condition}</p>
    ${a.description ? html`<p class="rpt-note">${a.description}</p>` : ''}
    ${a.likelihood !== null ? (report.conditionEngineId === 'api'
      ? html`<p class="rpt-note">Model probability ${a.likelihood}% (${matchWord(a.likelihood)}) from the trained model, among the 73 conditions it knows; not the chance that the patient has it.</p>`
      : html`<p class="rpt-note">Match strength ${a.likelihood}%${(report.version || 1) >= 3 ? ` (${matchWord(a.likelihood)})` : ''} against the other conditions checked; not the chance that the patient has it.</p>`) : ''}
    ${others.length ? html`<p class="rpt-note">${a.tie ? 'Closest matches (no clear leader)' : a.fallback ? 'Also considered' : 'Other possibilities'}: ${others.join(' · ')}.</p>` : ''}
    ${a.pattern ? html`<p class="rpt-label">Possible disease category</p><p class="rpt-strong rpt-strong--sm">${a.pattern}</p>` : ''}`;
}

/* The printed report is two A4 pages. The safety notice comes straight
   after the patient details and the plain-language summary, so it is on
   page 1 however long the symptom lists are. */
function renderReportDocument(report) {
  const toneClass = `tone-${report.recommendation.tone || 'gen'}`;
  const assessedAt = report.assessedAt || report.generatedAt;
  const s = report.symptoms;
  const plain = report.plain || null; // version 3 reports

  return html`
    <article class="paper" id="report-document" aria-label="Preliminary assessment report">
      <header class="rpt-head">
        <div class="rpt-brand">
          ${brandLogo('rpt-brand__logo')}
          <p class="rpt-brand__name">${APP_CONFIG.tagline}</p>
          <p class="rpt-brand__sub">${report.hospital || APP_CONFIG.hospitalName}, reception decision support</p>
        </div>
        <dl class="rpt-meta">
          <dt>Assessment ID</dt><dd>${textOr(report.assessmentId)}</dd>
          <dt>Date</dt><dd>${formatDate(assessedAt)}</dd>
          <dt>Time</dt><dd>${formatTime(assessedAt)}</dd>
          ${report.revision > 1 ? html`<dt>Revision</dt><dd>${report.revision}</dd>` : ''}
        </dl>
      </header>

      <h2 class="rpt-title">Preliminary Assessment Report</h2>
      <div class="rpt-rule"></div>
      <p class="rpt-tagline">Preliminary disease prediction and routing for decision support. Not a confirmed diagnosis.</p>

      ${report.safety.urgent.length || report.safety.marked ? html`
        <section class="rpt-urgent">
          <p class="rpt-urgent__title">${icon('siren')}<span>Potential urgent symptoms identified</span></p>
          <p>${DISCLAIMERS.urgentProtocol}</p>
          ${report.safety.urgent.length ? html`<ul>${report.safety.urgent.map((flag) => html`<li>${flag.label}</li>`)}</ul>` : ''}
          <p class="rpt-urgent__status">${report.safety.marked
            ? `Marked for immediate clinical evaluation${report.safety.markedAt ? ` at ${formatTime(report.safety.markedAt)}` : ''}.`
            : 'Not yet marked for immediate clinical evaluation at the time of this report.'}</p>
        </section>` : ''}

      <section class="rpt-section">
        <h3 class="rpt-section__title">Patient information</h3>
        <div class="rpt-panel">
          <div><p class="rpt-label">Name</p><p class="rpt-value">${report.patient.name}</p></div>
          <div><p class="rpt-label">Age</p><p class="rpt-value">${report.patient.age}</p></div>
          <div><p class="rpt-label">Gender</p><p class="rpt-value">${report.patient.gender}</p></div>
          <div><p class="rpt-label">Contact number</p><p class="rpt-value">${report.patient.contact}</p></div>
          ${plain ? html`
            <div class="rpt-panel__wide"><p class="rpt-label">Main complaint</p>
              <p class="rpt-value">${report.complaint.mainProblem ? `${report.complaint.mainProblem} (${report.complaint.label.toLowerCase()})` : report.complaint.label}${report.complaint.description ? html` <span class="rpt-quote-inline">“${report.complaint.description}”</span>` : ''}</p></div>` : ''}
        </div>
      </section>

      ${plain ? html`
        <section class="rpt-section rpt-plain" aria-label="In simple words">
          <h3 class="rpt-section__title">In simple words</h3>
          <dl class="rpt-plain__list">
            ${plainRows(plain).map((row) => html`<dt>${row.label}</dt><dd>${renderPlainSegments(row.body)}</dd>`)}
          </dl>
        </section>` : html`
        <section class="rpt-section">
          <h3 class="rpt-section__title">Main complaint</h3>
          <p class="rpt-strong">${report.complaint.label}</p>
          ${report.complaint.description ? html`<p class="rpt-quote">“${report.complaint.description}”</p>` : ''}
        </section>`}

      <section class="rpt-section rpt-disclaimer" aria-label="Safety notice">
        ${icon('triangle-alert')}
        <div>
          <p class="rpt-disclaimer__title">Safety notice</p>
          <p>${report.disclaimer}</p>
        </div>
      </section>

      <section class="rpt-section">
        <h3 class="rpt-section__title">Reported symptoms</h3>
        <dl class="rpt-dl">
          <dt>${plain ? 'Has' : 'Reported'}</dt><dd>${s.present.length ? s.present.join(', ') : 'No specific symptoms reported'}</dd>
          ${s.absent.length ? html`<dt>${plain ? 'Does not have' : 'Not present'}</dt><dd>${s.absent.join(', ')}</dd>` : ''}
          ${s.unsure.length ? html`<dt>${plain ? 'Not sure' : 'Unconfirmed'}</dt><dd>${s.unsure.join(', ')}</dd>` : ''}
          ${s.bodyMap && s.bodyMap.length ? html`<dt>Body map</dt><dd>${s.bodyMap.join('; ')}</dd>` : ''}
          <dt>Duration</dt><dd>${s.duration}</dd>
          <dt>Severity</dt><dd>${s.severity}</dd>
          ${s.temperature ? html`<dt>Temperature</dt><dd>${s.temperature}</dd>` : ''}
        </dl>
        <p class="rpt-note">Every question and response is listed in the appendix (${pluralise(s.responses.length, 'question')}).</p>
      </section>

      <section class="rpt-section">
        <h3 class="rpt-section__title">Preliminary assessment</h3>
        ${renderReportAssessment(report)}
      </section>

      <section class="rpt-section">
        <h3 class="rpt-section__title">Recommended specialist / department</h3>
        <div class="rpt-route ${toneClass}">
          <div class="rpt-route__body">
            <p class="rpt-route__dept">${report.recommendation.department}</p>
            <p>Suggested specialist: <strong>${report.recommendation.specialist}</strong></p>
            ${report.recommendation.doctor ? html`<p class="rpt-route__doctor">Doctor to see: <strong>${report.recommendation.doctor}</strong></p>` : ''}
          </div>
          <p class="rpt-route__code">${report.recommendation.code}</p>
        </div>
      </section>

      <section class="rpt-section">
        <h3 class="rpt-section__title">Next step</h3>
        <p>${report.recommendation.nextStep}</p>
        ${report.safety.priority.length && !report.safety.urgent.length ? html`
          <div class="rpt-priority">
            <p class="rpt-priority__title">Please inform the department promptly</p>
            <ul>${report.safety.priority.map((flag) => html`<li>${flag.label}</li>`)}</ul>
          </div>` : ''}
        ${report.safety.inconsistencies.length ? html`
          <div class="rpt-priority rpt-priority--note">
            <p class="rpt-priority__title">Responses to confirm</p>
            <ul>${report.safety.inconsistencies.map((item) => html`<li>${item.message}</li>`)}</ul>
          </div>` : ''}
      </section>

      <section class="rpt-section">
        <h3 class="rpt-section__title">General care information</h3>
        <ul class="rpt-list">${report.care.map((line) => html`<li>${line}</li>`)}</ul>
      </section>

      <div class="rpt-sign">
        <p class="rpt-sign__line">${report.preparedBy
          ? `Prepared at ${report.preparedBy.desk || 'reception'} by ${report.preparedBy.name}, ${report.preparedBy.role}${report.startedBy ? ` (started by ${report.startedBy.name})` : ''}`
          : 'Prepared at reception'}</p>
        <p class="rpt-sign__line">Reviewed by clinician (name, signature)</p>
      </div>

      <section class="rpt-section rpt-section--flow rpt-appendix">
        <h3 class="rpt-section__title">Appendix: questionnaire responses for ${report.assessmentId || 'this assessment'}</h3>
        <table class="rpt-table">
          <thead><tr><th scope="col">No.</th><th scope="col">Question asked</th><th scope="col">Response</th></tr></thead>
          <tbody>
            ${s.responses.map((row, index) => html`<tr><td>${String(index + 1).padStart(2, '0')}</td><td>${row.question}</td><td>${row.answer}</td></tr>`)}
          </tbody>
        </table>
        ${s.notAsked ? html`<p class="rpt-note">${pluralise(s.notAsked, 'question was', 'questions were')} not asked because the questionnaire was ended early for urgent escalation.</p>` : ''}
      </section>

      <footer class="rpt-foot">
        <p>Generated ${formatDateTime(report.generatedAt)} by the ${report.engine}. ${DISCLAIMERS.privacy}</p>
        <p class="rpt-foot__band">Preliminary decision-support report. Not a confirmed medical diagnosis or prescription.</p>
      </footer>
    </article>`;
}
