/* =====================================================================
   18. APP INITIALISATION AND EVENTS
   ---------------------------------------------------------------------
   One delegated listener per event type. Elements declare intent with
   data-action, data-form and data-* field attributes.
   ===================================================================== */

const ACTIONS = {
  nav: (el) => {
    const target = el.dataset.navTarget || el.dataset.nav;
    if (target === 'assessment') return ACTIONS['nav-assessment']();
    navigateTo(target);
  },
  'nav-assessment': () => {
    if (hasUnsavedProgress()) resumeAssessment();
    else startNewAssessment();
  },
  'new-assessment': () => startNewAssessment(),
  'resume-assessment': () => resumeAssessment(),
  'cancel-assessment': () => requestCancelAssessment(),
  'load-demo': (el) => {
    const menu = el.closest('[data-demo-menu]');
    if (menu) menu.open = false;
    requestLoadDemoCase(el.dataset.demoId);
  },
  'edit-patient': () => editPatientDetails(state.currentScreen === 'review'),
  'edit-symptoms': () => editSymptoms(state.currentScreen === 'review'),
  'edit-question': (el) => {
    const index = currentSequence().path.indexOf(el.dataset.questionId);
    state.ui.returnTo = 'review';
    state.ui.cursor = Math.max(0, index);
    state.ui.pending = undefined;
    state.ui.questionError = '';
    state.ui.branchNotice = null;
    state.ui.direction = 'forward';
    navigateTo('questionnaire');
  },
  'save-patient': () => savePatientDetails(),
  'edit-bodymap': () => {
    commitIfOnQuestionnaire();
    editBodyMap(state.currentScreen === 'review');
  },
  // A keyboard-activated button reports event.detail 0: move focus to the list.
  'bm-open-area': (el, event) => openBodyArea(el.dataset.area, { moveFocus: Boolean(event && event.detail === 0) }),
  'bm-close-area': () => closeBodyArea(),
  'bm-remove': (el) => removeBodySelection(el.dataset.key),
  'bm-search-pick': (el) => pickBodySearchResult(el.dataset.kind, el.dataset.id, el.dataset.area),
  'bm-continue': () => continueFromBodyMap(),
  'submit-answer': () => submitCurrentAnswer(),
  'question-prev': () => goToPreviousQuestion(),
  'question-jump': (el) => jumpToQuestion(Number(el.dataset.index)),
  'go-review': () => {
    commitIfOnQuestionnaire();
    reviewAssessment();
  },
  'flag-urgent': () => openModal({
    tone: 'danger',
    icon: 'siren',
    title: 'Mark for immediate clinical evaluation?',
    text: 'Use this when the patient appears seriously unwell, whatever the answers so far. The result will route to Emergency & Triage, and you can still record the remaining questions.',
    actions: [
      { label: 'Not now', variant: 'secondary', autofocus: true },
      { label: 'Mark as urgent', variant: 'urgent', onClick: () => { commitIfOnQuestionnaire(); markForImmediateEvaluation(); } },
    ],
  }),
  'mark-urgent': () => { commitIfOnQuestionnaire(); markForImmediateEvaluation(); },
  'remove-urgent': () => removeUrgentMark(),
  'finish-early': () => finishQuestionnaireEarly(),
  'run-assessment': () => runAssessment(),
  'open-why': () => openWhyDrawer(),
  'close-drawer': () => closeDrawer(),
  'generate-report': () => {
    const existed = Boolean(state.assessment.report);
    const report = existed ? state.assessment.report : createReportForCurrentAssessment();
    if (!report) {
      showToast('Run the assessment before generating a report.', 'warning');
      return;
    }
    navigateTo('report');
    if (!existed) showToast('Preliminary report generated.');
  },
  'back-to-results': () => navigateTo('results'),
  'print-report': () => printReport(),
  'edit-assessment': () => {
    state.ui.openedFrom = null;
    state.ui.returnTo = null;
    reviewAssessment();
  },
  'open-assessment': (el) => openSavedAssessment(el.dataset.id, el.dataset.from || 'history'),
  'clear-search': () => {
    state.ui.historyQuery = '';
    render({ focus: false });
    const input = document.getElementById('history-search');
    if (input) input.focus();
  },
  'clear-history': () => requestClearHistory(),
  // Sign-in screen and account (section 3a)
  'auth-continue': () => continueSignup(),
  'auth-back': () => backSignup(),
  'auth-login': () => submitLogin(),
  'auth-mode': (el) => switchAuthMode(el.dataset.mode),
  'auth-toggle-password': (el) => togglePasswordVisibility(el),
  'auth-pick-account': (el) => pickAccount(el.dataset.email),
  'auth-forgot': () => explainPasswordReset(),
  'toggle-theme': () => toggleTheme(),
  'sign-out': () => {
    commitIfOnQuestionnaire();
    requestSignOut();
  },
};

/* Saves a valid visible answer before leaving the questionnaire by other means. */
function commitIfOnQuestionnaire() {
  if (state.currentScreen !== 'questionnaire') return;
  const { removed } = commitPendingAnswer();
  if (removed.length) state.ui.branchNotice = buildBranchNotice(removed);
  state.ui.pending = undefined;
}

function handleClick(event) {
  const modalButton = event.target.closest('[data-modal-action]');
  if (modalButton) {
    handleModalAction(Number(modalButton.dataset.modalAction));
    return;
  }
  if (event.target.matches('[data-modal-backdrop]')) {
    closeModal();
    return;
  }
  const focusLink = event.target.closest('[data-focus-field]');
  if (focusLink) {
    event.preventDefault();
    const field = focusLink.dataset.focusField;
    const target = field === 'gender' ? document.querySelector('[data-patient-field="gender"]') : document.getElementById(`field-${field}`);
    if (target) target.focus();
    return;
  }
  const trigger = event.target.closest('[data-action]');
  if (!trigger || trigger.disabled) {
    closeDemoMenuIfOutside(event.target);
    return;
  }
  const action = ACTIONS[trigger.dataset.action];
  if (action) {
    event.preventDefault();
    action(trigger, event);
  }
  closeDemoMenuIfOutside(event.target);
}

function closeDemoMenuIfOutside(target) {
  const menu = document.querySelector('[data-demo-menu][open]');
  if (menu && !menu.contains(target)) menu.open = false;
}

/* Steps are driven by button clicks and the Enter key (see ACTIONS and
   handleKeydown), not by native form submission, which sandboxed previews
   block. This listener only cancels any submission that still happens. */
function handleSubmit(event) {
  if (event.target.closest('[data-form]')) event.preventDefault();
}

function handleInput(event) {
  const target = event.target;
  if (target.matches('[data-auth-field]') && !['checkbox', 'radio'].includes(target.type)) {
    updateAuthField(target.dataset.authField, target.value);
    return;
  }
  if (target.matches('[data-patient-field]') && target.type !== 'radio') {
    updatePatientField(target.dataset.patientField, target.value);
    return;
  }
  if (target.matches('[data-question-number]')) {
    trackPendingAnswer();
    return;
  }
  if (target.matches('[data-history-search]')) {
    updateHistorySearch(target.value);
    return;
  }
  if (target.matches('[data-bm-search]')) updateBodySearch(target.value);
}

function handleChange(event) {
  const target = event.target;
  if (target.matches('[data-auth-field]')) {
    if (target.type === 'checkbox') updateAuthField(target.dataset.authField, target.checked);
    else if (target.type === 'radio') updateAuthField(target.dataset.authField, target.value);
    return;
  }
  if (target.matches('[data-patient-field]') && target.type === 'radio') {
    updatePatientField(target.dataset.patientField, target.value);
    return;
  }
  if (handleBodyMapChange(target)) return;
  if (target.matches('[data-question-input]')) {
    if (target.type === 'checkbox') enforceExclusiveOption(target);
    trackPendingAnswer();
    return;
  }
  if (target.matches('[data-question-unit]')) {
    const question = getCurrentQuestion();
    const unit = question ? getUnit(question, target.value) : null;
    const input = document.querySelector('[data-question-number]');
    if (unit && input) {
      input.min = unit.min;
      input.max = unit.max;
      input.placeholder = unit.placeholder;
      const hint = document.getElementById('q-number-range');
      if (hint) hint.textContent = `Accepted range ${unit.min}–${unit.max} ${unit.label}`;
    }
    trackPendingAnswer();
  }
}

/* Body map inputs (section 5b). Returns true when the change was handled. */
function handleBodyMapChange(target) {
  if (target.matches('[data-bm-symptom]')) toggleBodySymptom(target.dataset.bmSymptom, target.dataset.bmArea, target.checked);
  else if (target.matches('[data-bm-pain]')) setBodyPain(target.dataset.bmPain, Number(target.value));
  else if (target.matches('[data-bm-primary]')) setBodyPrimary(target.value);
  else if (target.matches('[data-bm-view]')) setBodyView(target.value);
  else if (target.matches('[data-bm-mode]')) setBodyMapMode(target.value);
  else if (target.matches('[data-bm-complaint]')) setListComplaint(target.value);
  else return false;
  return true;
}

/* Marks a text field as touched once the receptionist leaves it, then
   shows any inline validation message. */
function handleFocusOut(event) {
  const target = event.target;
  if (target.matches && target.matches('[data-patient-field]') && target.type !== 'radio') {
    const field = target.dataset.patientField;
    if (!isBlank(target.value) || state.ui.intakeSubmitted) state.ui.intakeTouched[field] = true;
    refreshIntakeFieldError(field);
  }
}

function enforceExclusiveOption(checkbox) {
  if (!checkbox.checked) return;
  const group = document.querySelectorAll(`[data-question-input="${checkbox.dataset.questionInput}"]`);
  group.forEach((item) => {
    if (item === checkbox) return;
    if (checkbox.dataset.exclusive === 'true' || item.dataset.exclusive === 'true') item.checked = false;
  });
}

/* Keeps the visible selection in state so a re-render (e.g. after marking
   the patient urgent) does not lose it, and clears any error message. */
function trackPendingAnswer() {
  const question = getCurrentQuestion();
  if (!question) return;
  state.ui.pending = readQuestionInput(question);
  if (state.ui.questionError) {
    state.ui.questionError = '';
    const slot = document.getElementById('q-error');
    if (slot) slot.innerHTML = '';
  }
  if (question.type === 'scale') {
    const readout = document.getElementById('q-scale-readout');
    const value = state.ui.pending;
    if (readout && Number.isInteger(value)) {
      readout.innerHTML = painReadout(painScaleFor(question), value, question.max).toString();
    }
  }
}

function handleKeydown(event) {
  if (event.key === 'Escape') {
    if (document.getElementById('modal-root').innerHTML) { closeModal(); return; }
    if (event.target.matches('[data-bm-search]') && event.target.value) {
      event.preventDefault();
      event.target.value = '';
      updateBodySearch('');
      return;
    }
    if (event.target.matches('.bm-result')) {
      handleBodyMapKeydown(event);
      return;
    }
    if (document.getElementById('drawer-root').innerHTML) { closeDrawer(); return; }
    const menu = document.querySelector('[data-demo-menu][open]');
    if (menu) { menu.open = false; menu.querySelector('summary').focus(); }
    return;
  }
  if (event.key === 'Tab') {
    trapFocus(event);
    return;
  }
  if (event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return;
  if (document.body.classList.contains('has-overlay')) return;
  if (isSignedOut()) {
    handleAuthKeydown(event);
    return;
  }
  const target = event.target;

  if (event.key === 'Enter' && state.currentScreen === 'intake'
    && target.matches('[data-form="intake"] input')) {
    event.preventDefault();
    savePatientDetails();
    return;
  }
  if (state.currentScreen === 'bodymap') {
    handleBodyMapKeydown(event);
    return;
  }
  if (state.currentScreen !== 'questionnaire') return;
  const typing = target.matches('input[type="number"], input[type="text"], input[type="search"], input[type="tel"], textarea');

  if (event.key === 'Enter' && !target.matches('button, summary, a, textarea')) {
    event.preventDefault();
    submitCurrentAnswer();
    return;
  }
  if (!typing && /^[0-9]$/.test(event.key)) {
    const question = getCurrentQuestion();
    if (!question) return;
    let input = null;
    if (question.type === 'scale') {
      input = document.querySelector(`[data-question-input="${question.id}"][value="${event.key}"]`);
    } else if (event.key !== '0') {
      input = document.querySelector(`[data-question-input="${question.id}"][data-key="${event.key}"]`);
    }
    if (!input) return;
    event.preventDefault();
    if (input.type === 'checkbox') {
      input.checked = !input.checked;
      enforceExclusiveOption(input);
    } else {
      input.checked = true;
    }
    input.focus();
    trackPendingAnswer();
  }
}

/* Body map: Enter or Space opens a body part on the figure; in the search
   box, Enter picks the first result and the down arrow moves into the list. */
function handleBodyMapKeydown(event) {
  const target = event.target;
  if ((event.key === 'Enter' || event.key === ' ') && target.matches('[data-bm-region]')) {
    event.preventDefault();
    openBodyArea(target.dataset.bmRegion, { moveFocus: true });
    return;
  }
  const results = Array.from(document.querySelectorAll('#bm-search-results .bm-result'));
  const input = document.querySelector('[data-bm-search]');
  if (target.matches('.bm-result')) {
    const index = results.indexOf(target);
    if (event.key === 'ArrowDown' && index < results.length - 1) { event.preventDefault(); results[index + 1].focus(); }
    if (event.key === 'ArrowUp') { event.preventDefault(); (index > 0 ? results[index - 1] : input).focus(); }
    if (event.key === 'Escape' && input) { event.preventDefault(); input.value = ''; updateBodySearch(''); input.focus(); }
    return;
  }
  if (!target.matches('[data-bm-search]')) return;
  if (event.key === 'Enter') {
    // Enter adds an exact match straight away; otherwise it moves to the
    // results, so nothing (least of all a warning sign) is added by accident.
    event.preventDefault();
    const exact = results.find((item) => item.dataset.exact === 'true');
    if (exact) exact.click();
    else if (results[0]) results[0].focus();
  } else if (event.key === 'ArrowDown' && results[0]) {
    event.preventDefault();
    results[0].focus();
  }
}

/* Keeps keyboard focus inside an open modal or drawer. */
function trapFocus(event) {
  const container = document.querySelector('#modal-root .modal') || document.querySelector('#drawer-root .drawer');
  if (!container) return;
  const focusable = Array.from(container.querySelectorAll('button, [href], input, select, textarea, summary, [tabindex]:not([tabindex="-1"])'))
    .filter((el) => !el.disabled && el.offsetParent !== null);
  if (!focusable.length) return;
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (!container.contains(document.activeElement)) {
    event.preventDefault();
    first.focus();
  } else if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function bindEvents() {
  document.addEventListener('click', handleClick);
  document.addEventListener('submit', handleSubmit);
  document.addEventListener('input', handleInput);
  document.addEventListener('change', handleChange);
  document.addEventListener('focusout', handleFocusOut);
  document.addEventListener('keydown', handleKeydown);
  window.addEventListener('scroll', () => {
    const topbar = document.querySelector('.topbar');
    if (topbar) topbar.classList.toggle('is-scrolled', window.scrollY > 4);
  }, { passive: true });
  window.addEventListener('beforeprint', () => {
    if (state.currentScreen === 'report') document.body.classList.add('is-printing-report');
  });
  window.addEventListener('afterprint', () => document.body.classList.remove('is-printing-report'));
}

/* Shows which prediction engine runs the next assessment: the top bar's
   status tooltip now, the dashboard line on its next render. */
function updateEngineStatus() {
  const pill = document.querySelector('.topbar__meta .status-pill:not(#storage-status)');
  if (pill) pill.title = PredictionService.mode === 'api' ? MODEL_TEXT.statusTitle : MODEL_TEXT.localStatusTitle;
  document.body.dataset.engine = PredictionService.mode;
}

/* Looks for the MediFind backend (started with run_medifind.py). Without it,
   for example when this file is opened directly, the built-in rules are used. */
function connectPredictionBackend() {
  updateEngineStatus();
  return PredictionService.detect().then(() => {
    updateEngineStatus();
    if (state.currentScreen === 'dashboard' && document.body.dataset.auth === 'signed-in') render({ focus: false });
  });
}

function initApp() {
  bindEvents();
  watchOtherTabs();
  initTheme();
  connectPredictionBackend();
  updateClock();
  window.setInterval(updateClock, 15000);
  const draft = DraftStore.load();
  if (draft) loadDraftIntoState(draft);
  if (!(signedInAccount || restoreSession())) {
    showAuthScreen({ focus: false });
    return;
  }
  document.body.dataset.auth = 'signed-in';
  applyAccountToShell();
  navigateTo('dashboard', { focus: false });
  if (!SafeStorage.persistent) {
    showToast(STORAGE_UNAVAILABLE_TEXT, 'warning');
  }
}

/* Decide straight away whether the sign-in screen or the app shows, so the
   page never flashes the wrong one while it finishes loading. */
document.body.dataset.auth = restoreSession() ? 'signed-in' : 'signed-out';

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initApp);
else initApp();
