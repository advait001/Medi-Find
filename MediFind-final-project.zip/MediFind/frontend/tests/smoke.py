"""Smoke run: walks the main flow and saves screenshots for visual review."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
URL = (ROOT / "index.html").as_uri()
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/claude-0/shots")
OUT.mkdir(parents=True, exist_ok=True)

errors = []


def shot(page, name, full=False):
    page.wait_for_timeout(350)
    page.screenshot(path=str(OUT / f"{name}.png"), full_page=full)


with sync_playwright() as p:
    browser = p.chromium.launch()
    context = browser.new_context(viewport={"width": 1440, "height": 900})
    page = context.new_page()
    page.on("console", lambda m: errors.append(f"console.{m.type}: {m.text}") if m.type in ("error", "warning") else None)
    page.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
    page.goto(URL)
    page.evaluate("localStorage.clear(); sessionStorage.clear()")
    page.reload()
    shot(page, "00-signup")
    page.fill("#auth-firstName", "Smoke")
    page.fill("#auth-lastName", "Test")
    page.fill("#auth-email", "smoke@hospital.test")
    page.fill("#auth-password", "smoke-test-1")
    page.click("[data-action=auth-continue]")
    shot(page, "00-signup-desk")
    page.click("[data-action=auth-continue]")
    page.click("label.auth-check:has(#auth-confirmed)")
    shot(page, "00-signup-confirm")
    page.click("[data-action=auth-continue]")
    page.wait_for_selector("#hero-title", timeout=15000)
    shot(page, "01-dashboard-empty")

    page.click("text=New Patient Assessment")
    shot(page, "02-intake-empty")
    page.click("[data-action=save-patient]")
    shot(page, "03-intake-errors")

    page.fill("#field-name", "Rahul Sharma")
    page.fill("#field-age", "52")
    page.fill("#field-contact", "98200 14567")
    page.check("input[name=gender][value=male]", force=True)
    page.fill("#field-description", "Chest discomfort since morning")
    shot(page, "04-intake-filled", full=True)
    page.click("[data-action=save-patient]")
    shot(page, "05a-bodymap-empty")
    page.click("[data-bm-region=chest]")
    page.check("[data-bm-symptom=chest_pain]", force=True)
    page.check("[data-bm-pain=chest_pain][value='6']", force=True)
    page.click("[data-bm-region=knee_l]")
    page.check("[data-bm-symptom=limb_pain]", force=True)
    page.check("[data-bm-pain='limb_pain@knee_l'][value='3']", force=True)
    shot(page, "05b-bodymap-picks", full=True)
    page.click("label:has(input[data-bm-view][value=back])")
    page.click("[data-bm-region=lower_back]")
    shot(page, "05c-bodymap-back")
    page.click("label:has(input[data-bm-view][value=front])")
    page.click("[data-action=bm-continue]")
    shot(page, "05-q-first")

    def answer(value=None, values=None, scale=None):
        if values is not None:
            for v in values:
                page.check(f"[data-question-input][value='{v}']", force=True)
        elif scale is not None:
            page.check(f"[data-question-input][value='{scale}']", force=True)
        else:
            page.check(f"[data-question-input][value='{value}']", force=True)
        page.click("[data-action=submit-answer]")
        page.wait_for_timeout(120)

    shot(page, "06-q-breathing")
    answer("moderate")
    shot(page, "07-q-yesno")
    answer("yes")
    answer("yes")
    shot(page, "08-q-single")
    answer("exertion")
    shot(page, "09-q-duration")
    answer("today")
    shot(page, "11-q-multi")
    answer(values=["radiating"])
    shot(page, "12-q-safety")
    answer(values=["none"])
    shot(page, "13-review", full=True)
    page.click("[data-action=run-assessment]")
    page.wait_for_timeout(500)
    shot(page, "14-analysis")
    page.wait_for_selector(".route-sign", timeout=5000)
    shot(page, "15-results")
    shot(page, "15b-results-full", full=True)
    page.click("[data-action=open-why]")
    page.wait_for_timeout(400)
    shot(page, "16-why")
    page.keyboard.press("Escape")
    page.click("[data-action=generate-report]")
    page.wait_for_selector("#report-document")
    shot(page, "17-report", full=True)
    page.emulate_media(media="print")
    page.pdf(path=str(OUT / "report.pdf"), format="A4", print_background=True)
    page.emulate_media(media="screen")
    page.click("[data-nav=history] >> nth=0")
    shot(page, "18-history")
    page.click("[data-nav=dashboard] >> nth=0")
    shot(page, "19-dashboard-with-data")

    text = page.inner_text("body")
    for bad in ["undefined", "NaN", "[object Object]", "null"]:
        if bad in text:
            errors.append(f"visible text contains {bad!r}")
    browser.close()

print("\n".join(errors) if errors else "NO ERRORS")
