"""Runs the full assessment flow inside a sandboxed iframe (allow-scripts only),
the most restrictive kind of embedded preview: no forms, no same-origin storage,
no modals/print. Run: python3 tests/sandbox.py"""
import io
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
work = Path(tempfile.mkdtemp(prefix="sdp-sandbox-"))
shutil.copy(ROOT / "index.html", work / "app.html")
results, errors = [], []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


with sync_playwright() as p:
    browser = p.chromium.launch()
    for sandbox in ["allow-scripts", "allow-scripts allow-same-origin"]:
        (work / "wrap.html").write_text(
            f'<!doctype html><body style="margin:0"><iframe id="f" src="app.html" sandbox="{sandbox}" '
            f'style="width:1400px;height:880px;border:0"></iframe></body>')
        page = browser.new_page(viewport={"width": 1420, "height": 900})
        page.on("console", lambda m: errors.append((sandbox, m.text)) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append((sandbox, f"pageerror: {e}")))
        page.goto((work / "wrap.html").as_uri())
        page.wait_for_timeout(600)
        f = page.frame_locator("#f")
        frame = [fr for fr in page.frames if fr.url.endswith("app.html")][0]
        tag = f"[{sandbox}]"

        def qid():
            return frame.evaluate("() => { const c = document.querySelector('.q-card'); return c ? c.dataset.questionId : null; }")

        def pick(value):
            f.locator(f"label:has([data-question-input][value='{value}'])").click()

        # Sign-in screen first: create an account through the three steps.
        check(f"{tag} opens on the sign-in screen", f.locator(".auth").count() == 1 and f.locator("#auth-title").inner_text().endswith("Create your account"))
        hero = np.asarray(Image.open(io.BytesIO(f.locator(".auth-hero__logo").screenshot())).convert("RGB")).astype(int)
        check(f"{tag} light MediFind logo is painted", bool((hero.min(axis=2) > 200).any()) and bool((hero[..., 2] > hero[..., 0] + 60).any()))
        f.locator("#auth-firstName").fill("Sandbox")
        f.locator("#auth-lastName").fill("Desk")
        f.locator("#auth-email").fill("sandbox@hospital.test")
        f.locator("#auth-password").fill("sandbox-pass-1")
        f.locator("#auth-password").press("Enter")
        f.locator("#auth-hospital").wait_for()
        f.locator("[data-action=auth-continue]").click()
        f.locator("label.auth-check:has(#auth-confirmed)").click()
        f.locator("[data-action=auth-continue]").click()
        f.locator("#hero-title").wait_for(timeout=15000)
        check(f"{tag} account created, dashboard shown", "Sandbox" in f.locator(".hero__greeting").inner_text())

        f.locator("text=New Patient Assessment").first.click()
        f.locator("#field-name").fill("Sandbox Patient")
        f.locator("#field-age").fill("44")
        f.locator("#field-contact").fill("98765 43210")
        f.locator("[data-action=save-patient]").click()
        page.wait_for_timeout(300)
        check(f"{tag} Continue to Symptoms opens the body map", f.locator(".screen--bodymap").count() == 1)
        fig = np.asarray(Image.open(io.BytesIO(f.locator(".bm-figure").screenshot())).convert("RGB")).astype(int)
        greys = int(((fig.max(axis=2) - fig.min(axis=2) < 6) & (fig[..., 0] > 120) & (fig[..., 0] < 200)).sum())
        check(f"{tag} body map picture is painted", greys > 20000, str(greys))
        logo = np.asarray(Image.open(io.BytesIO(f.locator(".brand__logo").screenshot())).convert("RGB")).astype(int)
        check(f"{tag} MediFind logo is painted", bool((logo[..., 2] > logo[..., 0] + 80).any()))
        f.locator("[data-action=bm-open-area][data-area=general]").click()
        f.locator("label:has([data-bm-symptom=fever])").click()
        f.locator("[data-action=bm-continue]").click()
        page.wait_for_timeout(300)
        check(f"{tag} body map continues to the questions", qid() == "fever_duration", str(qid()))

        pick("1to3d"); f.locator("[data-action=submit-answer]").click(); page.wait_for_timeout(150)
        check(f"{tag} Continue button advances", qid() == "fever_measured", str(qid()))
        pick("yes"); page.keyboard.press("Enter"); page.wait_for_timeout(150)
        check(f"{tag} Enter key advances", qid() == "fever_temp", str(qid()))
        f.locator("#q-number-input").fill("101.6"); f.locator("#q-number-input").press("Enter"); page.wait_for_timeout(150)
        check(f"{tag} Enter in number field advances", qid() == "fever_cough", str(qid()))
        for value in ["yes", "moderate", "yes", "no", "yes"]:
            pick(value); f.locator("[data-action=submit-answer]").click(); page.wait_for_timeout(100)
        pick("none"); f.locator("[data-action=submit-answer]").click(); page.wait_for_timeout(100)   # associated
        pick("none"); f.locator("[data-action=submit-answer]").click(); page.wait_for_timeout(200)   # warning signs
        check(f"{tag} review reached", f.locator("[data-action=run-assessment]").count() == 1)
        f.locator("[data-action=run-assessment]").click()
        f.locator(".route-sign").wait_for(timeout=8000)
        dept = f.locator(".route-sign__name").inner_text()
        check(f"{tag} result shown", dept in ("Pulmonology", "General Medicine"), dept)
        f.locator("[data-action=open-why]").click(); page.wait_for_timeout(300)
        check(f"{tag} why drawer opens", f.locator(".drawer").count() == 1)
        page.keyboard.press("Escape")
        f.locator("[data-action=generate-report]").click()
        f.locator("#report-document").wait_for()
        check(f"{tag} report generated", "Sandbox Patient" in f.locator("#report-document").inner_text())
        f.locator("[data-action=print-report]").click(); page.wait_for_timeout(400)
        check(f"{tag} print guidance shown in preview", "this preview blocks printing" in f.locator("#toast-region").inner_text())
        f.locator("[data-nav=history]").first.click(); page.wait_for_timeout(200)
        check(f"{tag} history lists the assessment", "Sandbox Patient" in f.locator("#screen").inner_text())
        f.locator("[data-action=open-assessment]").first.click(); f.locator(".route-sign").wait_for()
        check(f"{tag} reopen works", "Sandbox Patient" in f.locator("#screen").inner_text())

        # Pain → Chest with a severe answer: urgent banner, mark, finish early
        f.locator("[data-action=new-assessment]").first.click()
        f.locator("#field-name").fill("Urgent Sandbox")
        f.locator("#field-age").fill("63")
        f.locator("#field-contact").press("Enter")  # Enter with errors shows the summary, does not navigate
        check(f"{tag} Enter on intake validates", f.locator("[data-error-summary]").count() == 1)
        f.locator("#field-contact").fill("9819033445")
        f.locator("#field-contact").press("Enter"); page.wait_for_timeout(200)
        check(f"{tag} Enter on intake continues", f.locator(".screen--bodymap").count() == 1)
        f.locator("[data-bm-region=chest]").click()
        f.locator("label:has([data-bm-symptom=chest_pain])").click()
        f.locator("label:has([data-bm-pain=chest_pain][value='9'])").click()
        check(f"{tag} urgent banner on the body map", f.locator(".urgent-banner").count() == 1)
        f.locator("[data-bm-region=knee_l]").focus(); page.keyboard.press("Enter"); page.wait_for_timeout(150)
        check(f"{tag} keyboard opens a body part", "Left knee" in f.locator("#bm-panel-title").inner_text())
        f.locator("[data-action=bm-continue]").click(); page.wait_for_timeout(200)
        check(f"{tag} questions start after the body map", qid() == "chest_breathing", str(qid()))
        pick("severe"); f.locator("[data-action=submit-answer]").click(); page.wait_for_timeout(150)
        check(f"{tag} urgent banner", f.locator(".urgent-banner").count() == 1)
        f.locator("[data-action=mark-urgent]").click(); page.wait_for_timeout(100)
        f.locator("[data-action=finish-early]").click(); page.wait_for_timeout(150)
        f.locator("[data-action=run-assessment]").click(); f.locator(".route-sign").wait_for(timeout=8000)
        check(f"{tag} urgent routing", f.locator(".route-sign__name").inner_text() == "Emergency & Triage")

        # Cancel modal inside the sandbox
        f.locator("[data-action=new-assessment]").first.click()
        f.locator("#field-name").fill("Cancel Me")
        f.locator("[data-action=cancel-assessment]").first.click()
        check(f"{tag} cancel confirmation shows", f.locator(".modal").count() == 1)
        f.locator(".modal >> text=Discard Assessment").click()
        check(f"{tag} discard returns to dashboard", f.locator("#hero-title").count() == 1)

        # Sign out and back in
        f.locator("[data-action=sign-out] >> visible=true").click()
        f.locator(".auth").wait_for()
        check(f"{tag} signed out to log in", f.locator("#auth-title").inner_text() == "Log in to MediFind")
        f.locator("[data-action=auth-pick-account]").click()
        f.locator("#auth-loginPassword").fill("sandbox-pass-1")
        f.locator("[data-action=auth-login]").click()
        f.locator("#hero-title").wait_for(timeout=15000)
        check(f"{tag} logged back in", f.locator(".auth").count() == 0)

        # Dark mode button, with or without storage
        f.locator("[data-action=toggle-theme]").click()
        page.wait_for_timeout(100)
        dark_bg = frame.evaluate("getComputedStyle(document.body).backgroundColor")
        check(f"{tag} dark mode button works", frame.evaluate("document.documentElement.dataset.theme") == "dark" and dark_bg == "rgb(9, 14, 26)", dark_bg)
        f.locator("[data-action=toggle-theme]").click()
        page.wait_for_timeout(100)
        check(f"{tag} and switches back to light", frame.evaluate("document.documentElement.dataset.theme") == "light")
        page.close()
    browser.close()

expected = ("Ignored call to 'print()'",)
unexpected = [e for e in errors if not any(x in e[1] for x in expected)]
passed = sum(1 for _, ok, _ in results if ok)
print(f"PASS {passed}  FAIL {len(results) - passed}  unexpected console errors {len(unexpected)}")
for name, ok, detail in results:
    if not ok:
        print(f"  FAIL {name} :: {detail}")
for e in unexpected[:10]:
    print(f"  CONSOLE {e}")
