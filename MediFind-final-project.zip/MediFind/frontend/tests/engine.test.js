// Engine tests: run with `node tests/engine.test.js`
// Loads the pure engine sections into one VM script and exercises
// the questionnaire, preprocessing, prediction, confidence and safety logic.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = path.join(__dirname, '..', 'src', 'js');
const files = ['01-config.js', '02-state.js', '03a-auth.js', '04-intake.js', '05-questionnaire.js', '05a-body-figure.js', '05b-bodymap.js', '06-branching.js', '07-preprocessing.js',
  '08-prediction.js', '09-confidence.js', '10-safety.js', '11-specialist.js', '12a-plain-language.js', '17-utils.js'];
const source = files.map((f) => fs.readFileSync(path.join(SRC, f), 'utf8')).join('\n');

const testCode = String.raw`
const results = { pass: 0, fail: 0, failures: [] };
function check(name, condition, detail) {
  if (condition) { results.pass += 1; }
  else { results.fail += 1; results.failures.push(name + (detail ? ' :: ' + detail : '')); }
}
const stubs = { persistDraft(){}, render(){}, navigateTo(){}, showToast(){} };

function runPipeline(patient, answers, extra = {}, extras = null) {
  const assessment = { ...createEmptyAssessment(), patient: { ...createEmptyAssessment().patient, ...patient }, answers: JSON.parse(JSON.stringify(answers)), ...extra };
  const encoding = encodeSymptoms(assessment.answers, patient.complaint, extras);
  const fv = constructFeatureVector(assessment.patient, encoding);
  const processed = preprocessFeatures(fv, encoding);
  const prediction = predictLocally(processed, { complaint: patient.complaint });
  const safety = detectRedFlags(fv.raw);
  const urgent = safety.urgent.length > 0 || assessment.urgentFlag;
  const recommendation = mapPredictionToSpecialist(prediction, { urgent });
  const sequence = buildQuestionSequence(assessment.answers, patient.complaint);
  return { assessment, encoding, fv, processed, prediction, safety, recommendation, sequence };
}

// ---------- 1. Configuration integrity ----------
const schemaKeys = new Set(FEATURE_ORDER);
FEATURE_ORDER.forEach((k) => check('label for ' + k, typeof SYMPTOM_LABELS[k] === 'string' && SYMPTOM_LABELS[k].length > 0));
check('feature order unique', schemaKeys.size === FEATURE_ORDER.length);
COMPLAINTS.forEach((c) => {
  check('complaint entry exists ' + c.id, !!getQuestion(c.entry));
  Object.keys(c.sets || {}).forEach((k) => check('complaint sets known feature ' + k, schemaKeys.has(k)));
});
Object.values(QUESTION_TREE).forEach((q) => {
  if (typeof q.next === 'string') check('next exists ' + q.id + ' -> ' + q.next, !!getQuestion(q.next));
  if (q.next && typeof q.next === 'object') Object.values(q.next).forEach((n) => check('mapped next exists ' + q.id + ' -> ' + n, !!getQuestion(n)));
  if (q.featureKey) check('featureKey known ' + q.id + ':' + q.featureKey, schemaKeys.has(q.featureKey));
  (q.options || []).forEach((o) => {
    Object.keys(o.set || {}).forEach((k) => check('option set known ' + q.id + '.' + o.value + ':' + k, schemaKeys.has(k)));
    Object.keys(o.alsoSet || {}).forEach((k) => check('option alsoSet known ' + q.id + '.' + o.value + ':' + k, schemaKeys.has(k)));
    if (o.feature) check('option feature known ' + q.id + '.' + o.value + ':' + o.feature, schemaKeys.has(o.feature));
  });
  if (q.next && typeof q.next === 'object') {
    (q.options || []).forEach((o) => check('map covers option ' + q.id + '.' + o.value, Object.prototype.hasOwnProperty.call(q.next, o.value) || !!q.next.default));
  }
  check('question has short label ' + q.id, typeof q.short === 'string' && q.short.length > 0);
});
Object.entries(PREDICTION_RULES).forEach(([cat, rule]) => {
  Object.keys(rule.weights).forEach((k) => check('weight feature known ' + cat + ':' + k, schemaKeys.has(k)));
  check('mapping exists ' + cat, !!SPECIALIST_MAPPING[cat]);
  check('category meta ' + cat, !!CATEGORIES[cat]);
});

// ---------- 2. Enumerate every route ----------
function answerChoices(q) {
  switch (q.type) {
    case 'multi': return [['none'], ...q.options.filter((o) => !o.exclusive).map((o) => [o.value])];
    case 'scale': return [0, 5, 9];
    case 'number': return [{ value: 98.4, unit: 'F' }, { value: 39.4, unit: 'C' }];
    default: return q.options.map((o) => o.value);
  }
}
let routeCount = 0; let maxLen = 0; let minLen = 99; const lengthsByComplaint = {}; const completedRoutes = [];
function explore(complaint, answers, depth) {
  if (depth > 40) { check('route too deep ' + complaint, false, JSON.stringify(answers)); return; }
  const seq = buildQuestionSequence(answers, complaint);
  if (seq.complete) {
    routeCount += 1; maxLen = Math.max(maxLen, seq.path.length); minLen = Math.min(minLen, seq.path.length);
    const l = lengthsByComplaint[complaint] || (lengthsByComplaint[complaint] = { min: 99, max: 0 });
    l.min = Math.min(l.min, seq.path.length); l.max = Math.max(l.max, seq.path.length);
    check('route ends with safety check ' + complaint, seq.path[seq.path.length - 1] === 'safety_check', seq.path.join('>'));
    completedRoutes.push({ complaint, answers });
    return;
  }
  const q = getQuestion(seq.path[seq.firstUnanswered]);
  check('frontier question exists', !!q);
  const choices = answerChoices(q);
  // Only branch on answers that can change the route; otherwise take the first choice
  const branching = !(q.next === null || typeof q.next === 'string') || Object.values(QUESTION_TREE).some((other) => other.condition && String(other.condition).includes(q.id));
  (branching ? choices : [choices[0]]).forEach((choice) => {
    explore(complaint, { ...answers, [q.id]: choice }, depth + 1);
  });
}
COMPLAINTS.forEach((c) => explore(c.id, {}, 0));
check('routes enumerated', routeCount > 30, String(routeCount));

// ---------- 3. Demo cases are complete and on-route ----------
DEMO_CASES.forEach((demo) => {
  const seq = buildQuestionSequence(demo.answers, demo.patient.complaint);
  check('demo complete ' + demo.id, seq.complete, 'path=' + seq.path.join('>') + ' first=' + seq.firstUnanswered);
  Object.keys(demo.answers).forEach((k) => check('demo answer on route ' + demo.id + ':' + k, seq.path.includes(k)));
});

// ---------- 4. Test cases A–G ----------
const outcomes = {};
DEMO_CASES.forEach((demo) => {
  const r = runPipeline(demo.patient, demo.answers);
  outcomes[demo.id] = r;
  check('demo routes to expected department ' + demo.id, r.recommendation.department === demo.expect,
    'got ' + r.recommendation.department + ' cat=' + r.prediction.predictedCategoryId + ' conf=' + r.prediction.confidence + ' scores=' + JSON.stringify(r.prediction.categoryScores.slice(0, 3)));
});
const A = outcomes['demo-cardio'];
check('A: cardiovascular top', A.prediction.predictedCategoryId === 'cardiovascular');
check('A: cardiologist', A.recommendation.specialist === 'Cardiologist');
check('A: higher confidence', A.prediction.confidence >= 75, String(A.prediction.confidence));
check('A: not urgent', A.safety.urgent.length === 0, JSON.stringify(A.safety.urgent));
check('A: priority note', A.safety.priority.some((f) => f.id === 'chest_pain_features'));
check('B: pulmonologist', outcomes['demo-resp'].recommendation.specialist === 'Pulmonologist');
check('C: orthopaedic', outcomes['demo-msk'].recommendation.specialist === 'Orthopaedic Specialist');
check('D: dermatologist', outcomes['demo-derm'].recommendation.specialist === 'Dermatologist');
check('E: gastroenterologist', outcomes['demo-gi'].recommendation.specialist === 'Gastroenterologist');
check('F: neurologist', outcomes['demo-neuro'].recommendation.specialist === 'Neurologist');
const G = outcomes['demo-general'];
check('G: inconclusive', G.prediction.isInconclusive && G.prediction.confidence < 55, String(G.prediction.confidence));
check('G: general physician', G.recommendation.specialist === 'General Physician');
const U = outcomes['demo-urgent'];
check('urgent: red flags', U.safety.urgent.length >= 2, JSON.stringify(U.safety.urgent));
check('urgent: emergency routing', U.recommendation.key === 'urgent');
check('urgent: no named doctor', U.recommendation.doctor === null);
check('A: doctor to see', A.recommendation.doctor && A.recommendation.doctor.name === DOCTOR_DIRECTORY.cardiovascular.name);
check('G: general doctor to see', G.recommendation.doctor && G.recommendation.doctor.name === DOCTOR_DIRECTORY.general.name);
Object.keys(SPECIALIST_MAPPING).filter((key) => key !== 'urgent').forEach((key) => {
  check('doctor named for ' + key, DOCTOR_DIRECTORY[key] && /^Dr\. \S/.test(DOCTOR_DIRECTORY[key].name));
});
check('older record without a doctor falls back to the department doctor',
  recommendedDoctor({ department: 'Dermatology', specialist: 'Dermatologist' }).name === DOCTOR_DIRECTORY.dermatological.name
  && recommendedDoctor({ key: 'urgent', department: 'Emergency & Triage' }) === null
  && recommendedDoctor({ key: 'general', doctor: null }) === null);
const X = outcomes['demo-contradiction'];
check('contradiction flagged', X.prediction.inconsistencies.some((i) => i.id === 'respiratory_without_symptoms'));
check('contradiction → inconclusive GP', X.prediction.isInconclusive && X.recommendation.specialist === 'General Physician');

// Minimal Test case A (only the three named answers positive)
const minimalA = runPipeline({ name: 'T', age: '50', gender: 'male', contact: '9999999999', complaint: 'pain' }, {
  pain_location: 'chest', chest_breathing: 'mild', chest_dizziness: 'yes', chest_sweating: 'yes', chest_pattern: 'nothing',
  chest_onset: 'days', chest_score: 5, chest_associated: ['none'], safety_check: ['none'] });
check('A-minimal → Cardiology', minimalA.recommendation.department === 'Cardiology', minimalA.prediction.confidence + ' ' + JSON.stringify(minimalA.prediction.categoryScores.slice(0,3)));

// Minimal Test case B
const minimalB = runPipeline({ name: 'T', age: '30', gender: 'female', contact: '9999999999', complaint: 'respiratory' }, {
  resp_cough: 'yes', resp_cough_type: 'dry', resp_breathing: 'mild', resp_wheeze: 'no', resp_fever: 'yes', resp_chest: 'no',
  resp_duration: '1to3d', resp_background: ['none'], safety_check: ['none'] });
check('B-minimal → Pulmonology', minimalB.recommendation.department === 'Pulmonology', String(minimalB.prediction.confidence));

// Minimal Test case C via Pain → Joint
const minimalC = runPipeline({ name: 'T', age: '30', gender: 'female', contact: '9999999999', complaint: 'pain' }, {
  pain_location: 'joint', joint_site: 'ankle', joint_swelling: 'yes', joint_injury: 'yes', joint_deformity: 'no', joint_movement: 'yes',
  joint_associated: ['none'], joint_duration: 'lt24h', joint_score: 5, safety_check: ['none'] });
check('C-minimal → Orthopaedics', minimalC.recommendation.department === 'Orthopaedics', String(minimalC.prediction.confidence));

// Fever-only → General medicine (non-specific)
const fever = runPipeline({ name: 'T', age: '30', gender: 'female', contact: '9999999999', complaint: 'fever' }, {
  fever_duration: '1to3d', fever_measured: 'yes', fever_temp: { value: 101.2, unit: 'F' }, fever_cough: 'no', fever_chills: 'yes',
  fever_rash: 'no', fever_weakness: 'yes', fever_associated: ['body_aches'], safety_check: ['none'] });
check('Fever → General Medicine', fever.recommendation.department === 'General Medicine', fever.prediction.predictedCategoryId + ' ' + fever.prediction.confidence);
check('Fever temperature converted', Math.abs(fever.fv.raw.temperatureC - 38.4) < 0.11, String(fever.fv.raw.temperatureC));

// ---------- 5. Determinism + sensitivity ----------
const again = runPipeline(DEMO_CASES[0].patient, DEMO_CASES[0].answers);
check('deterministic prediction', JSON.stringify(again.prediction) === JSON.stringify(A.prediction));
const changed = runPipeline(DEMO_CASES[0].patient, { ...DEMO_CASES[0].answers, chest_sweating: 'no', chest_associated: ['none'], chest_pattern: 'pressing' });
check('prediction changes with answers', changed.prediction.confidence !== A.prediction.confidence || changed.prediction.predictedCategoryId !== A.prediction.predictedCategoryId,
  changed.prediction.predictedCategoryId + ' ' + changed.prediction.confidence);

// ---------- 6. Test case H — branch change clears obsolete answers ----------
state.assessment = createEmptyAssessment();
state.assessment.patient = { name: 'H', age: '40', gender: 'male', contact: '9999999999', complaint: 'pain', description: '' };
Object.assign(state.assessment.answers, { pain_location: 'chest', chest_breathing: 'moderate', chest_dizziness: 'yes', chest_sweating: 'yes' });
let removed = clearObsoleteBranchAnswers();
check('H: nothing removed initially', removed.length === 0, removed.join(','));
state.assessment.answers.pain_location = 'joint';
removed = clearObsoleteBranchAnswers();
check('H: chest answers removed', ['chest_breathing', 'chest_dizziness', 'chest_sweating'].every((id) => removed.includes(id)), removed.join(','));
check('H: no chest keys left', Object.keys(state.assessment.answers).every((k) => !k.startsWith('chest_')), Object.keys(state.assessment.answers).join(','));
const hNext = getNextQuestion(state.assessment.answers, 'pain');
check('H: joint question next', hNext && hNext.id === 'joint_site', hNext && hNext.id);
const hRaw = computeRawFeatures(state.assessment);
check('H: features exclude chest', hRaw.chestPain === null && hRaw.sweating === null && hRaw.dizziness === null, JSON.stringify({ c: hRaw.chestPain, s: hRaw.sweating, d: hRaw.dizziness }));
check('H: joint feature on', hRaw.jointLimbPain === 1);

// Lookahead: adding a conditional question keeps later shared answers
state.assessment = createEmptyAssessment();
state.assessment.patient = { name: 'L', age: '40', gender: 'male', contact: '9999999999', complaint: 'fever', description: '' };
Object.assign(state.assessment.answers, { fever_duration: '1to3d', fever_measured: 'no', fever_cough: 'no', fever_chills: 'yes', fever_rash: 'no', fever_weakness: 'no', fever_associated: ['none'], safety_check: ['none'] });
check('lookahead: complete before change', currentSequence().complete);
state.assessment.answers.fever_cough = 'yes';
removed = clearObsoleteBranchAnswers();
const seqL = currentSequence();
check('lookahead: later answers kept', removed.length === 0 && state.assessment.answers.fever_chills === 'yes' && state.assessment.answers.safety_check, removed.join(','));
check('lookahead: new question is next', seqL.path[seqL.firstUnanswered] === 'fever_breathing', seqL.path.join('>'));
state.assessment.answers.fever_cough = 'no';
state.assessment.answers.fever_breathing = 'mild';
removed = clearObsoleteBranchAnswers();
check('condition-off answer pruned', removed.includes('fever_breathing'), removed.join(','));
check('route change re-asks warning signs', removed.includes('safety_check') && !state.assessment.answers.safety_check, removed.join(','));

// Complaint change clears every symptom answer
state.assessment.patient.complaint = 'skin';
removed = clearObsoleteBranchAnswers();
check('complaint change clears all answers', Object.keys(state.assessment.answers).length === 0, Object.keys(state.assessment.answers).join(','));

// ---------- 7. Safety rules ----------
const neuroSudden = runPipeline({ name: 'N', age: '60', gender: 'female', contact: '9999999999', complaint: 'neuro' }, {
  neuro_main: 'weakness', neuro_area: 'one_side', neuro_sudden: 'yes', neuro_associated: ['speech'], neuro_duration: 'lt24h', safety_check: ['none'] });
check('sudden neuro → urgent', neuroSudden.safety.urgent.some((f) => f.id === 'sudden_neurological'));
const neuroSlow = runPipeline({ name: 'N', age: '60', gender: 'female', contact: '9999999999', complaint: 'neuro' }, {
  neuro_main: 'numbness', neuro_area: 'hands_feet', neuro_sudden: 'no', neuro_associated: ['none'], neuro_duration: '1to4w', safety_check: ['none'] });
check('gradual peripheral numbness → not urgent', neuroSlow.safety.urgent.length === 0, JSON.stringify(neuroSlow.safety.urgent));
check('gradual numbness → Neurology', neuroSlow.recommendation.department === 'Neurology', neuroSlow.prediction.confidence + ' ' + neuroSlow.prediction.predictedCategoryId);
const bleed = runPipeline({ name: 'B', age: '60', gender: 'female', contact: '9999999999', complaint: 'other' }, {
  other_area: 'whole', other_symptoms: ['none'], other_duration: 'lt24h', other_severity: 'severe', safety_check: ['bleeding'] });
check('major bleeding → urgent', bleed.safety.urgent.some((f) => f.id === 'major_bleeding'));
const painZero = runPipeline({ name: 'Z', age: '40', gender: 'female', contact: '9999999999', complaint: 'pain' }, {
  pain_location: 'chest', chest_breathing: 'none', chest_dizziness: 'no', chest_sweating: 'no', chest_pattern: 'nothing',
  chest_onset: 'days', chest_score: 0, chest_associated: ['none'], safety_check: ['none'] });
check('pain 0/10 → inconsistency', painZero.prediction.inconsistencies.some((i) => i.id === 'pain_rated_zero'));
check('chest-only sparse evidence is not higher confidence', runPipeline({ name: 'S', age: '30', gender: 'female', contact: '9999999999', complaint: 'pain' }, { pain_location: 'chest', chest_breathing: 'none', chest_dizziness: 'no', chest_sweating: 'no', chest_pattern: 'nothing', chest_onset: 'days', chest_score: 3, chest_associated: ['none'], safety_check: ['none'] }).prediction.confidence < 75);
check('pain 0/10 → general evaluation', painZero.recommendation.key === 'general', painZero.prediction.confidence + ' ' + painZero.prediction.predictedCategoryId);

// Unsure answers lower completeness
const unsureA = runPipeline(DEMO_CASES[0].patient, { ...DEMO_CASES[0].answers, chest_dizziness: 'unsure', chest_sweating: 'unsure' });
check('unsure lowers confidence', unsureA.prediction.confidence < A.prediction.confidence, unsureA.prediction.confidence + ' vs ' + A.prediction.confidence);

// Feature vector shape
check('vector length matches schema', A.processed.vector.length === FEATURE_ORDER.length);
check('vector normalised 0..1', A.processed.vector.every((v) => typeof v === 'number' && v >= 0 && v <= 1));

// Summary text never contains undefined/null/NaN
DEMO_CASES.forEach((demo) => {
  const a = { ...createEmptyAssessment(), patient: { ...demo.patient }, answers: demo.answers };
  const s = JSON.stringify(summariseFindings(a));
  check('summary clean ' + demo.id, !/undefined|NaN|\[object Object\]/.test(s), s.slice(0, 200));
});


// ---------- 8. QA regressions ----------
const otherChest = runPipeline({ name: 'O', age: '50', gender: 'male', contact: '9999999999', complaint: 'other' }, {
  other_area: 'chest', chest_breathing: 'mild', chest_dizziness: 'no', chest_sweating: 'no', chest_pattern: 'nothing',
  chest_onset: 'hours', chest_score: 8, chest_associated: ['none'], safety_check: ['none'] });
check('D2: Other → Chest asks chest questions', otherChest.sequence.path.includes('chest_score'), otherChest.sequence.path.join('>'));
check('D2: Other → Chest severe pain escalates', otherChest.safety.urgent.some((f) => f.id === 'severe_chest_pain'), JSON.stringify(otherChest.safety.urgent));
const anyRouteChest = runPipeline({ name: 'W', age: '50', gender: 'male', contact: '9999999999', complaint: 'weakness' }, {
  weak_type: 'general', weak_duration: 'lt24h', weak_associated: ['none'], weak_impact: 'moderate', safety_check: ['chest'] });
check('D2: warning-sign check catches severe chest pain on any route', anyRouteChest.safety.urgent.some((f) => f.id === 'severe_chest_pain') && anyRouteChest.recommendation.key === 'urgent');
const dizzyChest = runPipeline({ name: 'D', age: '50', gender: 'male', contact: '9999999999', complaint: 'dizziness' }, {
  dizzy_type: 'faint', dizzy_fainted: 'no', dizzy_trigger: 'exertion', dizzy_associated: ['chest', 'palpitations'], dizzy_duration: 'lt24h', safety_check: ['none'] });
check('D2: dizziness + chest discomfort gets prompt-review note', dizzyChest.safety.priority.some((f) => f.id === 'chest_pain_features'), JSON.stringify(dizzyChest.safety.priority));
['breathing:resp_cough', 'digestion:gi_main', 'skin:skin_type', 'bones:joint_site', 'nerves:neuro_main', 'whole:other_symptoms'].forEach((pair) => {
  const [area, nextId] = pair.split(':');
  const seq = buildQuestionSequence({ other_area: area }, 'other');
  check('D2: Other area ' + area + ' branches to ' + nextId, seq.path[1] === nextId, seq.path.join('>'));
});
const heavyMix = runPipeline({ name: 'M', age: '30', gender: 'female', contact: '9999999999', complaint: 'other' }, {
  other_area: 'whole', other_symptoms: ['fever', 'cough', 'rash', 'aches', 'headache', 'dizziness'], other_duration: '1to3d', other_severity: 'moderate', safety_check: ['none'] });
check('D3: heavy multi-system mix is inconclusive', heavyMix.prediction.isInconclusive && heavyMix.prediction.confidence < 55, heavyMix.prediction.confidence + ' ' + heavyMix.prediction.topCategoryId);
// Sweep: mixed combinations (3+ categories scoring) should rarely clear 55 %
let mixed = 0; let confident = 0;
const pool = ['fever', 'cough', 'stomach', 'rash', 'aches', 'headache', 'dizziness', 'tired'];
for (let mask = 1; mask < (1 << pool.length); mask += 1) {
  const picks = pool.filter((_, i) => mask & (1 << i));
  if (picks.length < 3) continue;
  const r = runPipeline({ name: 'S', age: '30', gender: 'female', contact: '9999999999', complaint: 'other' }, {
    other_area: 'whole', other_symptoms: picks, other_duration: '1to3d', other_severity: 'moderate', safety_check: ['none'] });
  const scoring = r.prediction.categoryScores.filter((c) => c.score > 0).length;
  const topShare = r.prediction.categoryScores[0].share;
  if (scoring >= 3 && topShare < 45) { mixed += 1; if (r.prediction.confidence >= 55) confident += 1; }
}
check('D3: mixed combinations with top share < 45% stay below 55%', confident === 0, confident + ' of ' + mixed);

// ---------- 9. Condition (disease) prediction ----------
const conditionIds = new Set(CONDITIONS.map((c) => c.id));
check('condition ids unique', conditionIds.size === CONDITIONS.length);
check('condition count', CONDITIONS.length >= 45, String(CONDITIONS.length));
const TREATMENT_WORDS = /\b(take|takes|tablets?|capsules?|dos(e|es|age)|antibiotics?|paracetamol|ibuprofen|treat(ed|ment|ments)?|prescri\w*|surgery|operat(e|ion))\b/i;
CONDITIONS.forEach((c) => {
  conditionCategories(c).forEach((cat) => check('condition category known ' + c.id + ':' + cat, CATEGORY_ORDER.includes(cat)));
  Object.keys(c.weights).forEach((k) => check('condition weight feature known ' + c.id + ':' + k, schemaKeys.has(k)));
  check('condition text present ' + c.id, [c.name, c.short, c.description].every((t) => typeof t === 'string' && t.trim().length > 2));
  check('condition requires is a function ' + c.id, typeof c.requires === 'function');
  check('condition description gives no treatment advice ' + c.id, !TREATMENT_WORDS.test(c.description) && !TREATMENT_WORDS.test(c.name), c.description);
  check('condition never addresses the patient as "you have" ' + c.id, !/you have|the patient has/i.test(c.name + ' ' + c.description));
  check('condition never names a heart attack ' + c.id, !/heart attack/i.test(c.name + ' ' + c.description));
});
CATEGORY_ORDER.forEach((cat) => {
  const fb = CATEGORIES[cat].fallbackCondition;
  check('fallback condition ' + cat, Boolean(fb && fb.id && fb.name && fb.short && fb.description));
  check('category has conditions ' + cat, CONDITIONS.filter((c) => conditionCategories(c).includes(cat)).length >= 4);
});
DEMO_CASES.filter((d) => d.expectCondition).forEach((d) => {
  check('demo expected condition exists ' + d.id, conditionIds.has(d.expectCondition));
  check('demo predicts expected condition ' + d.id, outcomes[d.id].prediction.predictedConditionId === d.expectCondition,
    outcomes[d.id].prediction.predictedConditionId + ' ' + outcomes[d.id].prediction.conditionLikelihood + '%');
});
check('A: angina named with likelihood', A.prediction.predictedConditionId === 'angina' && A.prediction.conditionLikelihood >= 60, String(A.prediction.conditionLikelihood));
check('B: bronchitis leads, pneumonia is an alternative', outcomes['demo-resp'].prediction.differentials.some((d) => d.id === 'pneumonia'));
check('G: no single condition named', G.prediction.predictedConditionId === 'inconclusive' && G.prediction.conditionLikelihood === null);
check('G: conditions listed for the doctor', G.prediction.consideredConditions.length >= 1 && G.prediction.consideredConditions.every((c) => c.department));
check('contradiction: no single condition named', X.prediction.predictedConditionId === 'inconclusive');
check('fever-only → viral fever', fever.prediction.predictedConditionId === 'viral_fever', fever.prediction.predictedConditionId);
check('urgent prediction is still routed to Emergency & Triage', U.recommendation.key === 'urgent');

// Urgent cases carry no condition; removing a manual urgent mark predicts it again
const withheldCopy = JSON.parse(JSON.stringify(A.prediction));
withholdCondition(withheldCopy);
check('urgent: condition removed from the result', CONDITION_FIELDS.every((key) => !(key in withheldCopy)) && withheldCopy.conditionWithheld === true);
check('urgent: no condition name left anywhere in the result', !CONDITIONS.some((c) => JSON.stringify(withheldCopy).includes(c.name)));
restoreCondition({ prediction: withheldCopy, features: A.processed });
check('urgent mark removed: condition predicted again', withheldCopy.predictedConditionId === 'angina' && !withheldCopy.conditionWithheld, withheldCopy.predictedConditionId);
check('match strength reflects evidence: single-answer match stays moderate',
  (() => { const r = runPipeline({ name: 'L', age: '26', gender: 'female', contact: '9999999999', complaint: 'pain' }, { pain_location: 'abdomen', abd_location: 'lower_right', abd_meals: 'no', gi_associated: ['none'], gi_duration: '1to3d', abd_score: 4, safety_check: ['none'] });
    return r.prediction.conditionLikelihood <= 70; })());

// Invariants that must hold for any prediction
function conditionInvariants(name, r) {
  const p = r.prediction;
  const ok = (label, cond, detail) => check(name + ': ' + label, cond, detail);
  ok('condition text', typeof p.predictedCondition === 'string' && p.predictedCondition.length > 2, String(p.predictedCondition));
  ok('no undefined in condition output', !/undefined|NaN|\[object Object\]/.test(JSON.stringify([p.predictedCondition, p.conditionShort, p.conditionDescription, p.differentials, p.conditionEvidence, p.consideredConditions])));
  if (p.isInconclusive) {
    ok('inconclusive names no condition', p.predictedConditionId === 'inconclusive' && p.conditionLikelihood === null && p.differentials.length === 0);
    ok('considered conditions have departments', p.consideredConditions.every((c) => conditionIds.has(c.id) && typeof c.department === 'string'));
    return;
  }
  if (p.conditionIsFallback) {
    ok('fallback belongs to category', p.predictedConditionId === CATEGORIES[p.predictedCategoryId].fallbackCondition.id, p.predictedConditionId + ' / ' + p.predictedCategoryId);
    ok('fallback has no likelihood', p.conditionLikelihood === null);
    return;
  }
  const condition = CONDITION_INDEX[p.predictedConditionId];
  ok('named condition exists', Boolean(condition), p.predictedConditionId);
  ok('condition belongs to the routed category', condition && conditionCategories(condition).includes(p.predictedCategoryId), p.predictedConditionId + ' vs ' + p.predictedCategoryId);
  ok('likelihood within range', Number.isInteger(p.conditionLikelihood) && p.conditionLikelihood >= 1 && p.conditionLikelihood <= CONDITION_SETTINGS.likelihoodCap, String(p.conditionLikelihood));
  ok('condition score above threshold', p.conditionScore >= CONDITION_SETTINGS.minScore, String(p.conditionScore));
  ok('alternatives ordered and below the top', p.differentials.every((d, i, arr) => d.likelihood <= p.conditionLikelihood && (i === 0 || d.likelihood <= arr[i - 1].likelihood) && d.likelihood >= CONDITION_SETTINGS.minDifferentialLikelihood));
  ok('alternatives belong to the category', p.differentials.every((d) => CONDITION_INDEX[d.id] && conditionCategories(CONDITION_INDEX[d.id]).includes(p.predictedCategoryId)));
  ok('evidence explains the condition', p.conditionEvidence.length > 0 && p.conditionEvidence.every((e) => typeof e.label === 'string' && e.points > 0));
}
DEMO_CASES.forEach((d) => conditionInvariants('demo ' + d.id, outcomes[d.id]));
completedRoutes.forEach((route, i) => {
  const patient = { name: 'R', age: i % 2 ? '58' : '27', gender: i % 3 ? 'female' : 'male', contact: '9999999999', complaint: route.complaint };
  conditionInvariants('route ' + i + ' ' + route.complaint, runPipeline(patient, route.answers));
});

// Scenario regression: realistic presentations and the condition each should predict
let scenarioMisses = [];
SCENARIOS.forEach((sc) => {
  const patient = { name: 'S', age: '35', gender: 'female', contact: '9999999999', description: '', ...sc.patient };
  const r = runPipeline(patient, sc.answers);
  check('scenario complete ' + sc.id, r.sequence.complete, r.sequence.path[r.sequence.firstUnanswered]);
  conditionInvariants('scenario ' + sc.id, r);
  (sc.expectPriority || []).forEach((id) => check('scenario priority flag ' + sc.id + ':' + id, r.safety.priority.some((flag) => flag.id === id), JSON.stringify(r.safety.priority.map((flag) => flag.id))));
  if (sc.expectUrgent) {
    check('scenario urgent ' + sc.id, r.recommendation.key === 'urgent', JSON.stringify(r.safety.urgent));
  } else {
    const hit = sc.expect.split('|').includes(r.prediction.predictedConditionId);
    if (!hit) scenarioMisses.push(sc.id + '→' + r.prediction.predictedConditionId);
    check('scenario condition ' + sc.id, hit, r.prediction.predictedConditionId + ' (expected ' + sc.expect + ', conf ' + r.prediction.confidence + ')');
  }
});

// Deterministic fuzz: random answer sets on every complaint (seeded, not Math.random)
let seed = 20261015;
function rnd() { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; }
function pick(list) { return list[Math.floor(rnd() * list.length)]; }
function randomAnswer(q) {
  switch (q.type) {
    case 'multi': {
      const options = q.options.filter((o) => !o.exclusive);
      if (q.id === 'safety_check') return rnd() < 0.85 ? ['none'] : [pick(options).value];
      if (rnd() < 0.3) return ['none'];
      const chosen = options.filter(() => rnd() < 0.3).map((o) => o.value);
      return chosen.length ? chosen : [pick(options).value];
    }
    case 'scale': return Math.floor(rnd() * 11);
    case 'number': return rnd() < 0.5 ? { value: Math.round((97 + rnd() * 7) * 10) / 10, unit: 'F' } : { value: Math.round((36 + rnd() * 4) * 10) / 10, unit: 'C' };
    default: return pick(q.options).value;
  }
}
let fuzzCount = 0; let fuzzUrgent = 0; let fuzzInconclusive = 0; const fuzzConditions = new Set();
COMPLAINTS.forEach((c) => {
  for (let n = 0; n < 300; n += 1) {
    const answers = {};
    for (let guard = 0; guard < 30; guard += 1) {
      const seq = buildQuestionSequence(answers, c.id);
      if (seq.complete) break;
      const q = getQuestion(seq.path[seq.firstUnanswered]);
      answers[q.id] = randomAnswer(q);
    }
    const patient = { name: 'F', age: String(18 + Math.floor(rnd() * 70)), gender: pick(['female', 'male', 'other']), contact: '9999999999', complaint: c.id };
    let r;
    try { r = runPipeline(patient, answers); } catch (error) { check('fuzz no exception ' + c.id + ' ' + n, false, String(error)); continue; }
    fuzzCount += 1;
    if (r.recommendation.key === 'urgent') fuzzUrgent += 1;
    if (r.prediction.isInconclusive) fuzzInconclusive += 1;
    else fuzzConditions.add(r.prediction.predictedConditionId);
    conditionInvariants('fuzz ' + c.id + ' ' + n, r);
    if (n % 25 === 0) check('fuzz deterministic ' + c.id + ' ' + n, JSON.stringify(runPipeline(patient, answers).prediction) === JSON.stringify(r.prediction));
  }
});
check('fuzz ran', fuzzCount === COMPLAINTS.length * 300, String(fuzzCount));
check('fuzz reaches most conditions', fuzzConditions.size >= 40, String(fuzzConditions.size));

// ---------- 10. Body map ----------
const QUESTION_IDS = new Set(Object.keys(QUESTION_TREE));
const symptomIds = new Set(BODY_SYMPTOMS.map((d) => d.id));
check('body symptom ids unique', symptomIds.size === BODY_SYMPTOMS.length);
const areaIds = new Set(BODY_AREAS.map((a) => a.id));
check('body area ids unique', areaIds.size === BODY_AREAS.length);
BODY_SYMPTOMS.forEach((d) => {
  check('body symptom complaint ' + d.id, Boolean(getComplaint(d.complaint)), d.complaint);
  check('body symptom label ' + d.id, typeof d.label === 'string' && d.label.length > 2);
  Object.entries(d.answers || {}).forEach(([q, v]) => {
    check('body answer question exists ' + d.id + ':' + q, QUESTION_IDS.has(q));
    if (typeof v === 'string' && v.startsWith('@')) {
      check('body placeholder matches perArea ' + d.id + ':' + q, d.perArea === v.slice(1) && q === d.perArea, v);
    } else if (QUESTION_IDS.has(q)) {
      check('body answer valid ' + d.id + ':' + q + '=' + JSON.stringify(v), validateAnswer(getQuestion(q), v) === null);
    }
  });
  Object.keys(d.features || {}).forEach((k) => check('body feature known ' + d.id + ':' + k, schemaKeys.has(k)));
  if (d.pain) {
    const pq = getQuestion(d.pain.question);
    check('body pain question is a 0-10 scale ' + d.id, Boolean(pq && pq.type === 'scale'), d.pain.question);
    check('body pain scale known ' + d.id, Boolean(PAIN_SCALES[d.pain.scale]), d.pain.scale);
  }
  if (d.perArea) check('body perArea rule known ' + d.id, d.perArea === 'neuro_area' || Boolean(BODY_CONTEXT_RULES[d.perArea]), d.perArea);
  check('body symptom listed in an area ' + d.id, BODY_AREAS.some((a) => bodyAreaSymptomIds(a).includes(d.id)));
  check('body symptom gives no treatment advice ' + d.id, !TREATMENT_WORDS.test(d.label + ' ' + (d.hint || '')));
});
Object.entries(BODY_CONTEXT_RULES).forEach(([key, rule]) => {
  check('context rule question ' + key, QUESTION_IDS.has(key));
  check('context rule multi value valid ' + key, validateAnswer(getQuestion(key), rule.multi) === null, rule.multi);
});
BODY_AREAS.forEach((a) => {
  const ids = bodyAreaSymptomIds(a);
  check('body area has symptoms ' + a.id, ids.length > 0);
  ids.forEach((id) => {
    const d = BODY_SYMPTOM_INDEX[id];
    check('body area symptom exists ' + a.id + ':' + id, Boolean(d));
    if (d && d.perArea && d.perArea !== 'neuro_area') check('body area provides context ' + a.id + ':' + id, Boolean(a.context && a.context[d.perArea]), d.perArea);
    if (d && d.perArea === 'neuro_area') check('body area has side and limb ' + a.id + ':' + id, Boolean(a.side && a.limb));
  });
  Object.entries(a.context || {}).forEach(([key, value]) => {
    if (QUESTION_IDS.has(key)) check('body area context valid ' + a.id + ':' + key + '=' + value, validateAnswer(getQuestion(key), value) === null);
  });
  if (!['skin', 'general'].includes(a.id)) {
    check('body area drawn on the figure ' + a.id, BODY_FIGURE.views.front.some((r) => r.area === a.id) || BODY_FIGURE.views.back.some((r) => r.area === a.id));
  }
});
check('figure size', BODY_FIGURE.width === 528 && BODY_FIGURE.height === 1080);
['front', 'back'].forEach((view) => {
  const seen = new Set();
  BODY_FIGURE.views[view].forEach((region) => {
    check('figure area known ' + view + ':' + region.area, areaIds.has(region.area));
    check('figure area once ' + view + ':' + region.area, !seen.has(region.area));
    seen.add(region.area);
    check('figure path ' + view + ':' + region.area, /^M[\d.,LMZ]+Z$/.test(region.d) && region.d.length > 40);
    const [x, y] = region.badge || [];
    check('figure badge ' + view + ':' + region.area, x > 0 && x < BODY_FIGURE.width && y > 0 && y < BODY_FIGURE.height);
  });
  BODY_FRONT_ONLY.forEach((id) => check('front-only area ' + view + ':' + id, seen.has(id) === (view === 'front')));
  BODY_BACK_ONLY.forEach((id) => check('back-only area ' + view + ':' + id, seen.has(id) === (view === 'back')));
});
// Sides: the front view shows the patient's right side on the viewer's left; the back view the opposite.
const badgeX = (view, area) => BODY_FIGURE.views[view].find((r) => r.area === area).badge[0];
['shoulder', 'upper_arm', 'forearm', 'hand', 'thigh', 'knee', 'lower_leg', 'foot'].forEach((limb) => {
  check('figure: front view, patient right on viewer left ' + limb, badgeX('front', limb + '_r') < 263 && badgeX('front', limb + '_l') > 263);
  check('figure: back view mirrors sides ' + limb, badgeX('back', limb + '_r') > 263 && badgeX('back', limb + '_l') < 263);
});
check('figure: belly columns run right to left on the front', badgeX('front', 'abd_ur') < badgeX('front', 'abd_um') && badgeX('front', 'abd_um') < badgeX('front', 'abd_ul'));

function bodyMapOf(picks, primary) {
  return normaliseBodyMap({ mode: 'map', selections: picks.map(([symptom, area, pain]) => ({ symptom, area, pain: pain === undefined ? null : pain })), primary });
}
function runBodyMap(patient, picks, { primary = null, answers = {} } = {}) {
  const bodyMap = bodyMapOf(picks, primary ? bodySelectionKey(primary[0], primary[1]) : null);
  const derived = deriveFromBodyMap(bodyMap);
  const merged = { ...derived.answers, ...answers };
  const r = runPipeline({ ...patient, complaint: derived.complaint }, merged, {}, derived.extras);
  return { ...r, derived, bodyMap };
}
const P = { name: 'B', age: '40', gender: 'female', contact: '9999999999', description: '' };

// Every symptom on every area, alone and with a pain rating
let pairCount = 0;
BODY_AREAS.forEach((a) => bodyAreaSymptomIds(a).forEach((id) => {
  const d = BODY_SYMPTOM_INDEX[id];
  [undefined, 6].forEach((pain) => {
    if (pain !== undefined && !d.pain) return;
    pairCount += 1;
    const tag = a.id + ':' + id + (pain !== undefined ? ':' + pain : '');
    let derived;
    try { derived = deriveFromBodyMap(bodyMapOf([[id, a.id, pain]])); } catch (error) { check('body derive no exception ' + tag, false, String(error)); return; }
    check('body derive complaint ' + tag, derived && derived.complaint === d.complaint);
    const seq = buildQuestionSequence(derived.answers, derived.complaint);
    Object.entries(derived.answers).forEach(([q, v]) => {
      check('body derived answer on route ' + tag + ':' + q, seq.path.includes(q), seq.path.join('>'));
      check('body derived answer valid ' + tag + ':' + q, validateAnswer(getQuestion(q), v) === null, JSON.stringify(v));
    });
    if (pain !== undefined) check('body pain recorded ' + tag, derived.answers[d.pain.question] === pain);
    Object.keys(derived.extras).forEach((k) => check('body extra known ' + tag + ':' + k, schemaKeys.has(k) && !BODY_EXTRA_EXCLUDED.has(k) && k !== 'painScore'));
  });
}));
check('body area × symptom pairs checked', pairCount > 150, String(pairCount));

// Combining several areas
let d1 = deriveFromBodyMap(bodyMapOf([['limb_pain', 'knee_r', 5], ['limb_pain', 'shoulder_l', 8]]));
check('two joints → several joints', d1.answers.joint_site === 'multiple' && d1.answers.joint_score === 8, JSON.stringify(d1.answers));
check('several joints keeps the leg finding', d1.extras.lowerLimb === 1, JSON.stringify(d1.extras));
d1 = deriveFromBodyMap(bodyMapOf([['limb_pain', 'knee_r', 5], ['limb_pain', 'knee_l', 4], ['limb_swelling', 'knee_l']]));
check('both knees → knee', d1.answers.joint_site === 'knee' && d1.answers.joint_swelling === 'yes' && d1.answers.joint_score === 5, JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'hand_r'], ['limb_numb', 'hand_l']]));
check('both hands numb → both hands or feet', d1.answers.neuro_area === 'hands_feet', JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'hand_r'], ['limb_weak', 'foot_r']]));
check('arm and leg on one side → one-sided finding', d1.answers.neuro_area === 'one_limb' && d1.extras.focalOneSided === 1 && d1.extras.limbWeakness === 1, JSON.stringify(d1));
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'hand_r'], ['limb_numb', 'foot_r']]));
check('numbness in an arm and a leg on one side → one side of the body', d1.answers.neuro_area === 'one_side', JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'hand_r'], ['limb_weak', 'hand_l']]));
check('numb right hand + weak left hand is not "both hands"', d1.answers.neuro_area === 'one_limb' && !('focalOneSided' in d1.extras), JSON.stringify(d1));
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'forearm_l']]));
check('one limb numb → one arm or leg', d1.answers.neuro_area === 'one_limb' && d1.answers.neuro_main === 'numbness', JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['stomach_pain', 'abd_ur', 6], ['stomach_pain', 'abd_lr', 3], ['stomach_pain', 'abd_ll', 4]]));
check('three belly areas → all over', d1.answers.abd_location === 'all_over' && d1.answers.abd_score === 6, JSON.stringify(d1.answers));
check('all over keeps the right-sided findings', d1.extras.rightUpperAbdominal === 1 && d1.extras.rightLowerAbdominal === 1, JSON.stringify(d1.extras));
d1 = deriveFromBodyMap(bodyMapOf([['stomach_pain', 'abd_lr', 7], ['stomach_pain', 'abd_um', 3]]));
check('two belly areas → main one kept, other recorded', d1.answers.abd_location === 'lower_right' && d1.extras.upperAbdominal === 1 && d1.answers.abd_score === 7, JSON.stringify(d1));
d1 = deriveFromBodyMap(bodyMapOf([['back_pain', 'neck', 4], ['back_pain', 'lower_back', 6]]));
check('neck and lower back → whole back', d1.answers.back_area === 'whole' && d1.answers.back_score === 6 && d1.extras.neckPain === 1 && d1.extras.lowBackPain === 1, JSON.stringify(d1));
d1 = deriveFromBodyMap(bodyMapOf([['skin_here', 'forearm_r'], ['skin_here', 'thigh_l'], ['rash', 'skin']]));
check('skin in two places → widespread', d1.answers.skin_area === 'widespread' && d1.answers.skin_type === 'rash', JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['stomach_pain', 'abd_um', 5], ['nausea', 'abd_um'], ['acidity', 'abd_um']]));
check('conflicting digestive picks become findings', d1.answers.gi_main === 'pain' && d1.extras.nauseaVomiting === 1 && d1.extras.acidity === 1, JSON.stringify(d1));
d1 = deriveFromBodyMap(bodyMapOf([['stomach_pain', 'abd_um', 5], ['nausea', 'abd_um']], 'nausea'));
check('main problem choice decides the route', d1.complaint === 'digestive' && d1.answers.gi_main === 'vomiting' && d1.extras.abdominalPain === 1 && d1.extras.upperAbdominal === 1, JSON.stringify(d1));
check('main problem choice: secondary pain not used as the pain score', !('abd_score' in d1.answers), JSON.stringify(d1.answers));

// Other picks add their own findings, not the branch they would start
d1 = deriveFromBodyMap(bodyMapOf([['limb_pain', 'knee_r', 4], ['palpitations', 'chest'], ['body_aches', 'general', 5]]));
check('other picks: racing heartbeat is not chest discomfort', d1.extras.palpitations === 1 && !('chestDiscomfort' in d1.extras), JSON.stringify(d1.extras));
check('other picks: body aches recorded without "pain elsewhere"', d1.extras.bodyAches === 1 && !('otherPain' in d1.extras), JSON.stringify(d1.extras));

// Safety with several picks
let s1 = runBodyMap(P, [['limb_pain', 'knee_l', 3], ['chest_pain', 'chest', 8]], { primary: ['limb_pain', 'knee_l'] });
check('secondary severe chest pain → urgent', s1.safety.urgent.some((f) => f.id === 'severe_chest_pain'), JSON.stringify(s1.safety));
s1 = runBodyMap(P, [['limb_pain', 'knee_l', 8], ['palpitations', 'chest']]);
check('knee pain 8 + palpitations: not chest urgent', !s1.safety.urgent.some((f) => f.id === 'severe_chest_pain'), JSON.stringify(s1.safety.urgent));
check('knee pain 8 + palpitations: severe pain noted', s1.safety.priority.some((f) => f.id === 'severe_pain'), JSON.stringify(s1.safety.priority));
s1 = runBodyMap(P, [['chest_pain', 'chest', 3], ['limb_pain', 'knee_l', 9]]);
check('chest 3 + knee 9: no chest urgent', !s1.safety.urgent.some((f) => f.id === 'severe_chest_pain'), JSON.stringify(s1.safety.urgent));
check('chest 3 + knee 9: severe pain noted', s1.safety.priority.some((f) => f.id === 'severe_pain'), JSON.stringify(s1.safety.priority));
s1 = runBodyMap(P, [['fever', 'general'], ['headache', 'head', 8]]);
check('fever + headache 8: severe pain noted', s1.safety.priority.some((f) => f.id === 'severe_pain'), JSON.stringify(s1.safety.priority));
check('fever + headache: headache recorded', s1.fv.raw.headache === 1 && s1.fv.raw.painScore === null, JSON.stringify({ h: s1.fv.raw.headache, p: s1.fv.raw.painScore }));
s1 = runBodyMap(P, [['fainted', 'head']]);
check('fainted → urgent', s1.safety.urgent.some((f) => f.id === 'loss_of_consciousness'));
s1 = runBodyMap(P, [['limb_pain', 'knee_l', 4], ['face_droop', 'head']]);
check('face droop as a finding → urgent until confirmed not sudden', s1.safety.urgent.some((f) => f.id === 'sudden_neurological'), JSON.stringify(s1.safety.urgent));
s1 = runBodyMap(P, [['back_pain', 'lower_back', 5], ['bladder_loss', 'lower_back']]);
check('bladder loss → urgent', s1.safety.urgent.some((f) => f.id === 'bladder_bowel_loss'));
s1 = runBodyMap(P, [['fever', 'general'], ['stiff_neck', 'neck']]);
check('fever + stiff neck → urgent', s1.safety.urgent.some((f) => f.id === 'fever_stiff_neck'), JSON.stringify(s1.safety.urgent));

// Findings fill unknown features only: a questionnaire answer wins
s1 = runBodyMap(P, [['headache', 'head', 5], ['fever', 'general']], { answers: { head_associated: ['nausea'] } });
check('answer overrides a body-map finding', s1.fv.raw.fever === 0, String(s1.fv.raw.fever));
s1 = runBodyMap(P, [['headache', 'head', 5], ['fever', 'general']]);
check('finding counts while unanswered', s1.fv.raw.fever === 1, String(s1.fv.raw.fever));
const sugAssessment = { ...createEmptyAssessment(), patient: { ...P, complaint: 'neuro' } };
sugAssessment.bodyMap = bodyMapOf([['headache', 'head', 5], ['fever', 'general'], ['vision', 'head']]);
const sugDerived = deriveFromBodyMap(sugAssessment.bodyMap);
sugAssessment.bodyMap.applied = { complaint: sugDerived.complaint, answers: sugDerived.answers, extras: sugDerived.extras, signature: sugDerived.signature };
check('suggestion pre-ticks matching options', JSON.stringify(bodyMapSuggestion(getQuestion('head_associated'), sugAssessment)) === JSON.stringify(['vision', 'fever']), JSON.stringify(bodyMapSuggestion(getQuestion('head_associated'), sugAssessment)));
check('suggestion answers yes/no', bodyMapSuggestion(getQuestion('fever_rash'), { ...sugAssessment, patient: { ...sugAssessment.patient, complaint: 'neuro' } }) === undefined);

// Demo cases: body-map picks agree with the demo answers and keep the routing
DEMO_CASES.filter((demo) => demo.bodyMap).forEach((demo) => {
  const bm = normaliseBodyMap({ mode: 'map', selections: demo.bodyMap.selections, primary: demo.bodyMap.primary || null });
  const derived = deriveFromBodyMap(bm);
  check('demo body map complaint ' + demo.id, derived.complaint === demo.patient.complaint, derived.complaint);
  Object.entries(derived.answers).forEach(([q, v]) => check('demo body map answer agrees ' + demo.id + ':' + q, JSON.stringify(demo.answers[q]) === JSON.stringify(v), JSON.stringify(v) + ' vs ' + JSON.stringify(demo.answers[q])));
  const r = runPipeline(demo.patient, demo.answers, {}, derived.extras);
  check('demo with body map routes as expected ' + demo.id, r.recommendation.department === demo.expect, r.recommendation.department);
  if (demo.expectCondition) check('demo with body map predicts expected condition ' + demo.id, r.prediction.predictedConditionId === demo.expectCondition, r.prediction.predictedConditionId);
});

// Applying the body map to the working assessment
state.assessment = createEmptyAssessment();
state.assessment.patient = { ...P, complaint: '' };
state.assessment.bodyMap = bodyMapOf([['limb_pain', 'knee_r', 6], ['limb_swelling', 'knee_r'], ['fever', 'general']]);
let applied = applyBodyMap();
check('apply: complaint set', state.assessment.patient.complaint === 'joint_limb' && !applied.error);
check('apply: answers recorded', state.assessment.answers.joint_site === 'knee' && state.assessment.answers.joint_swelling === 'yes' && state.assessment.answers.joint_score === 6, JSON.stringify(state.assessment.answers));
check('apply: first question is the first unanswered', currentSequence().path[currentSequence().firstUnanswered] === 'joint_injury', currentSequence().path.join('>'));
check('apply: answered ids known', ['joint_site', 'joint_swelling', 'joint_score'].every((id) => bodyMapAnsweredIds().has(id)));
check('apply: finding becomes a suggestion', JSON.stringify(bodyMapSuggestion(getQuestion('joint_associated'))) === JSON.stringify(['fever']));
state.assessment.answers.joint_score = 7; // receptionist corrects the score in the questions
state.assessment.answers.joint_injury = 'no';
applyBodyMap();
check('apply again unchanged: corrections kept', state.assessment.answers.joint_score === 7 && state.assessment.answers.joint_injury === 'no', JSON.stringify(state.assessment.answers));
state.assessment.bodyMap.selections[0].pain = 4;
applyBodyMap();
check('apply after pain change: new score', state.assessment.answers.joint_score === 4, String(state.assessment.answers.joint_score));
state.assessment.bodyMap.selections = state.assessment.bodyMap.selections.filter((sel) => sel.symptom !== 'limb_swelling');
applyBodyMap();
check('apply after removing swelling: answer cleared', !('joint_swelling' in state.assessment.answers) && state.assessment.answers.joint_injury === 'no', JSON.stringify(state.assessment.answers));
state.assessment.bodyMap.selections.push({ key: 'cough', symptom: 'cough', area: 'chest', pain: null });
state.assessment.bodyMap.primary = 'cough';
const answeredBeforeSwitch = Object.keys(state.assessment.answers).length;
applied = applyBodyMap();
check('apply: new main problem changes the route', state.assessment.patient.complaint === 'respiratory' && state.assessment.answers.resp_cough === 'yes' && !('joint_site' in state.assessment.answers), JSON.stringify(state.assessment.answers));
check('apply: route change reported', answeredBeforeSwitch > 0 && applied.removed.includes('joint_injury'), applied.removed.join(','));
state.assessment.bodyMap.mode = 'list';
state.assessment.bodyMap.listComplaint = 'skin';
applyBodyMap();
check('list mode: complaint from the list, no findings', state.assessment.patient.complaint === 'skin' && bodyMapExtras(state.assessment) === null && Object.keys(state.assessment.answers).length === 0, JSON.stringify(state.assessment.answers));
state.assessment.bodyMap = createEmptyBodyMap();
check('apply with nothing picked → error', Boolean(applyBodyMap().error));
check('old record opens in list mode', normaliseBodyMap(undefined, 'fever').mode === 'list' && normaliseBodyMap(undefined, 'fever').listComplaint === 'fever');
check('unknown picks dropped on load', normaliseBodyMap({ mode: 'map', selections: [{ symptom: 'nope', area: 'chest' }, { symptom: 'cough', area: 'chest', pain: 99 }] }).selections.length === 1);

// Preview: warning signs are checked before the picks are applied
state.assessment = createEmptyAssessment();
state.assessment.patient = { ...P, complaint: '' };
state.assessment.bodyMap = bodyMapOf([['chest_pain', 'chest', 9]]);
refreshSafetyState();
check('preview: urgent before applying', state.assessment.safety.urgent.some((f) => f.id === 'severe_chest_pain'), JSON.stringify(state.assessment.safety));
state.assessment.bodyMap.selections[0].pain = 2;
refreshSafetyState();
check('preview: cleared when the rating drops', state.assessment.safety.urgent.length === 0, JSON.stringify(state.assessment.safety));

// Search finds symptoms and body parts
check('search: cough', bodySearch('cough').some((r) => r.kind === 'symptom' && r.id === 'cough'));
check('search: knee offers both knees', bodySearch('knee').filter((r) => r.kind === 'area').length === 2 && bodySearch('knee').every((r) => r.kind === 'area'), JSON.stringify(bodySearch('knee')));
check('search: knee pain adds pain to a knee', JSON.stringify(bodySearch('knee pain').map((r) => r.kind + ':' + r.id + '@' + r.area)) === JSON.stringify(['pair:limb_pain@knee_r', 'pair:limb_pain@knee_l']), JSON.stringify(bodySearch('knee pain')));
check('search: stomach pain lists the belly areas', bodySearch('stomach pain').some((r) => r.kind === 'pair' && r.id === 'stomach_pain' && r.area === 'abd_um'));
check('search: neck pain opens the neck', bodySearch('neck pain')[0].kind === 'pair' && bodySearch('neck pain')[0].area === 'neck', JSON.stringify(bodySearch('neck pain')));
['numbness', 'tingling', 'sprain'].forEach((q) => check('search: ' + q + ' asks where', bodySearch(q).some((r) => r.kind === 'choose'), JSON.stringify(bodySearch(q))));
['stiff neck', 'sciatica'].forEach((q) => check('search: ' + q + ' found', bodySearch(q).some((r) => r.kind === 'pair'), JSON.stringify(bodySearch(q))));
check('search: belly symptoms filed under the middle', bodySearch('nausea').find((r) => r.id === 'nausea').area === 'abd_um');
check('search: swelling lists the face warning sign but not first as exact', !bodySearch('swelling').some((r) => r.exact));
check('search: short query ignored', bodySearch('a').length === 0);

// Body-map fuzz: random picks, then random answers to the remaining questions
const allPairs = BODY_AREAS.flatMap((a) => bodyAreaSymptomIds(a).map((id) => [id, a.id]));
let bodyFuzz = 0;
for (let n = 0; n < 1500; n += 1) {
  const count = 1 + Math.floor(rnd() * 4);
  const picks = [];
  for (let k = 0; k < count; k += 1) {
    const [id, area] = pick(allPairs);
    picks.push([id, area, BODY_SYMPTOM_INDEX[id].pain && rnd() < 0.7 ? Math.floor(rnd() * 11) : undefined]);
  }
  const bm = bodyMapOf(picks, rnd() < 0.3 ? null : undefined);
  if (rnd() < 0.4 && bm.selections.length > 1) bm.primary = pick(bm.selections).key;
  let derived;
  try { derived = deriveFromBodyMap(bm); } catch (error) { check('body fuzz derive ' + n, false, String(error)); continue; }
  const answers = { ...derived.answers };
  for (let guard = 0; guard < 30; guard += 1) {
    const seq = buildQuestionSequence(answers, derived.complaint);
    if (seq.complete) break;
    const q = getQuestion(seq.path[seq.firstUnanswered]);
    answers[q.id] = randomAnswer(q);
  }
  const seq = buildQuestionSequence(answers, derived.complaint);
  check('body fuzz complete ' + n, seq.complete, JSON.stringify(picks));
  Object.keys(derived.answers).forEach((q) => check('body fuzz derived answer stays on route ' + n + ':' + q, seq.path.includes(q), JSON.stringify(picks)));
  let r;
  try { r = runPipeline({ ...P, age: String(18 + Math.floor(rnd() * 70)), complaint: derived.complaint }, answers, {}, derived.extras); } catch (error) { check('body fuzz pipeline ' + n, false, String(error)); continue; }
  bodyFuzz += 1;
  conditionInvariants('body fuzz ' + n, r);
  check('body fuzz extras never set the pain score ' + n, !('painScore' in derived.extras));
}
check('body fuzz ran', bodyFuzz === 1500, String(bodyFuzz));

// ---------- 10b. Review findings (independent QA) ----------
// A warning sign picked after the warning-sign question was answered still counts
let q1 = runBodyMap(P, [['limb_pain', 'knee_r', 5], ['fainted', 'head']], { answers: { safety_check: ['none'] } });
check('QA: fainting picked later still urgent', q1.safety.urgent.some((f) => f.id === 'loss_of_consciousness'), JSON.stringify(q1.safety.urgent));
q1 = runBodyMap(P, [['bleeding', 'general']], { answers: { other_symptoms: ['none'], other_duration: 'lt24h', other_severity: 'severe', safety_check: ['none'] } });
check('QA: heavy bleeding as the main pick is urgent', q1.safety.urgent.some((f) => f.id === 'major_bleeding'), JSON.stringify(q1.safety.urgent));
// Changing the picks asks the warning-sign question again, with the sign pre-ticked
state.assessment = createEmptyAssessment();
state.assessment.patient = { ...P, complaint: '' };
state.assessment.bodyMap = bodyMapOf([['limb_pain', 'knee_r', 5]]);
applyBodyMap();
Object.assign(state.assessment.answers, { joint_swelling: 'no', joint_injury: 'no', joint_movement: 'no', joint_associated: ['none'], joint_duration: '1to3d', safety_check: ['none'] });
check('QA: knee route complete', currentSequence().complete, currentSequence().path.join('>'));
check('QA: nothing pending after apply', !bodyMapPending());
state.assessment.bodyMap.selections.push({ key: 'fainted', symptom: 'fainted', area: 'head', pain: null });
check('QA: unapplied picks are pending', bodyMapPending() && !validateAssessment(state.assessment).valid);
refreshSafetyState();
check('QA: unapplied warning sign shows at once', state.assessment.safety.urgent.some((f) => f.id === 'loss_of_consciousness'), JSON.stringify(state.assessment.safety));
applyBodyMap();
check('QA: picked warning sign ticked in the warning-sign answer', JSON.stringify(state.assessment.answers.safety_check) === JSON.stringify(['faint']) && currentSequence().complete, JSON.stringify(state.assessment.answers.safety_check));
check('QA: fainting pre-ticked if the question is asked again', JSON.stringify(bodyMapSuggestion(getQuestion('safety_check'))) === JSON.stringify(['faint']), JSON.stringify(bodyMapSuggestion(getQuestion('safety_check'))));
check('QA: other answers kept', state.assessment.answers.joint_duration === '1to3d');
state.assessment.bodyMap.selections = state.assessment.bodyMap.selections.filter((sel) => sel.symptom !== 'fainted');
applyBodyMap();
check('QA: removing the pick unticks the sign it added, and the question is asked again', !('safety_check' in state.assessment.answers) && currentSequence().path[currentSequence().firstUnanswered] === 'safety_check', JSON.stringify(state.assessment.answers.safety_check));
state.assessment.answers.safety_check = ['faint', 'bleeding']; // ticked by the receptionist in the question
state.assessment.bodyMap.selections[0].pain = 6;
applyBodyMap();
check('QA: changing a pick keeps warning signs ticked in the question', JSON.stringify(state.assessment.answers.safety_check) === JSON.stringify(['faint', 'bleeding']), JSON.stringify(state.assessment.answers.safety_check));
state.assessment.bodyMap.selections.push({ key: 'bleeding', symptom: 'bleeding', area: 'general', pain: null });
applyBodyMap();
state.assessment.bodyMap.selections = state.assessment.bodyMap.selections.filter((sel) => sel.symptom !== 'bleeding');
applyBodyMap();
check('QA: a sign the receptionist ticked is never unticked by the body map', JSON.stringify(state.assessment.answers.safety_check) === JSON.stringify(['faint', 'bleeding']), JSON.stringify(state.assessment.answers.safety_check));
// Records applied before picks were stored with them are not treated as changed
const legacyApplied = { ...state.assessment.bodyMap.applied };
delete legacyApplied.picks;
legacyApplied.signature = 'older-format';
legacyApplied.extras = { ...legacyApplied.extras, fever: 1 };
check('QA: older applied body map is not pending', !bodyMapPending({ ...state.assessment, bodyMap: { ...state.assessment.bodyMap, applied: legacyApplied } }));
// A different main problem keeps an answered warning sign in the live check
state.assessment.answers.safety_check = ['faint'];
state.assessment.bodyMap.selections = [{ key: 'limb_pain@knee_r', symptom: 'limb_pain', area: 'knee_r', pain: 5 }, { key: 'chest_pain', symptom: 'chest_pain', area: 'chest', pain: 3 }];
state.assessment.bodyMap.primary = 'chest_pain';
refreshSafetyState();
check('QA: answered warning sign survives a change of main problem', state.assessment.safety.urgent.some((f) => f.id === 'loss_of_consciousness'), JSON.stringify(state.assessment.safety));
state.assessment.bodyMap.selections = [];
state.assessment.bodyMap.primary = null;
refreshSafetyState();
check('QA: removing every pick keeps answered warning signs', state.assessment.safety.urgent.some((f) => f.id === 'loss_of_consciousness'), JSON.stringify(state.assessment.safety));
// A conflicting pick's pain never becomes the main pain score
q1 = { derived: deriveFromBodyMap(bodyMapOf([['sore_throat', 'head', 2], ['ear_pain', 'head', 9]])) };
check('QA: sore throat keeps its own score', q1.derived.answers.other_pain_score === 2 && q1.derived.extras.severeOtherPain === 1, JSON.stringify(q1.derived));
q1 = { derived: deriveFromBodyMap(bodyMapOf([['stomach_pain', 'abd_lr', 2], ['stomach_pain', 'abd_um', 8]])) };
check('QA: first belly area keeps its own score', q1.derived.answers.abd_location === 'lower_right' && q1.derived.answers.abd_score === 2 && q1.derived.extras.severeOtherPain === 1, JSON.stringify(q1.derived));
const qaMap = bodyMapOf([['stomach_pain', 'abd_lr', 2], ['stomach_pain', 'abd_um', 8]]);
check('QA: either belly area can be the main problem', mainProblemCandidates(bodyMapEntries(qaMap), null, qaMap).length === 2);
const qaKnees = bodyMapOf([['limb_pain', 'knee_r', 2], ['limb_swelling', 'knee_r']]);
check('QA: detail picks are not offered as a main problem', mainProblemCandidates(bodyMapEntries(qaKnees), null, qaKnees).length === 1);
// Mixed limbs on both sides, and one-sided numbness leads by default
d1 = deriveFromBodyMap(bodyMapOf([['limb_numb', 'hand_r'], ['limb_numb', 'thigh_l']]));
check('QA: right hand + left thigh is not "both hands or both feet"', d1.answers.neuro_area === 'one_limb', JSON.stringify(d1.answers));
d1 = deriveFromBodyMap(bodyMapOf([['limb_pain', 'knee_r', 4], ['limb_numb', 'hand_r'], ['limb_numb', 'foot_r']]));
check('QA: one-sided numbness becomes the main problem unless chosen otherwise', d1.complaint === 'neuro' && d1.answers.neuro_area === 'one_side', JSON.stringify(d1));
q1 = runBodyMap(P, [['chills', 'general']], { answers: { other_symptoms: ['none'], other_duration: '1to3d', other_severity: 'mild', safety_check: ['none'] } });
check('QA: chills is not recorded as "not sure"', q1.encoding.unsureQuestions.length === 0, JSON.stringify(q1.encoding.unsureQuestions));

// Chills is not fever
q1 = runBodyMap(P, [['stiff_neck', 'neck'], ['chills', 'general']]);
check('QA: stiff neck + chills is not "fever with a stiff neck"', !q1.safety.urgent.some((f) => f.id === 'fever_stiff_neck') && q1.fv.raw.fever !== 1, JSON.stringify({ u: q1.safety.urgent, f: q1.fv.raw.fever }));
q1 = runBodyMap(P, [['chills', 'general']]);
check('QA: chills alone does not record fever', q1.fv.raw.fever !== 1 && q1.fv.raw.chills === 1, JSON.stringify({ f: q1.fv.raw.fever, c: q1.fv.raw.chills }));
// A main problem that is not a pain: a 0 pain score is not a contradiction
const swellingOnly = runBodyMap(P, [['limb_swelling', 'knee_r']], { answers: { joint_injury: 'no', joint_movement: 'no', joint_associated: ['none'], joint_duration: '1to3d', joint_score: 0, safety_check: ['none'] } });
const swellingAssessment = { ...swellingOnly.assessment, bodyMap: { ...swellingOnly.bodyMap, applied: { complaint: swellingOnly.derived.complaint, answers: swellingOnly.derived.answers, extras: swellingOnly.derived.extras, signature: swellingOnly.derived.signature } } };
const swellingContext = consistencyContext(swellingAssessment);
check('QA: swelling only is not "pain rated 0"', swellingContext.painNotReported === true
  && !predictLocally(swellingOnly.processed, swellingContext).inconsistencies.some((i) => i.id === 'pain_rated_zero'));
check('QA: knee pain rated 0 is still a contradiction', consistencyContext({ ...swellingAssessment, bodyMap: (() => { const bm = bodyMapOf([['limb_pain', 'knee_r', 0]]); const d = deriveFromBodyMap(bm); return { ...bm, applied: { complaint: d.complaint, answers: d.answers, extras: d.extras, signature: d.signature } }; })() }).painNotReported === false);
// A racing heartbeat asks heartbeat questions, not chest-pain questions
q1 = runBodyMap(P, [['palpitations', 'chest']], { answers: { palp_trigger: 'rest', palp_associated: ['dizzy'], palp_duration: '1to3d', safety_check: ['none'] } });
check('QA: heartbeat route', q1.sequence.complete && q1.sequence.path.includes('palp_trigger') && !q1.sequence.path.some((id) => id.startsWith('chest_')), q1.sequence.path.join('>'));
check('QA: heartbeat route does not invent chest discomfort', q1.fv.raw.chestDiscomfort !== 1 && !q1.safety.priority.some((f) => f.id === 'chest_pain_features'), JSON.stringify(q1.safety.priority));
check('QA: heartbeat route → heart rhythm disorder', q1.recommendation.department === 'Cardiology' && q1.prediction.predictedConditionId === 'arrhythmia', q1.recommendation.department + ' ' + q1.prediction.predictedConditionId + ' ' + q1.prediction.confidence);
// TB is not suggested for a cough of a few days
const tbShort = runPipeline({ ...P, complaint: 'respiratory' }, { resp_cough: 'yes', resp_cough_type: 'blood', resp_breathing: 'mild', resp_wheeze: 'no', resp_fever: 'yes', resp_chest: 'no', resp_duration: '1to3d', resp_background: ['none'], safety_check: ['none'] });
check('QA: short cough with blood is not TB', tbShort.prediction.predictedConditionId !== 'tuberculosis', tbShort.prediction.predictedConditionId);

// ---------- 11. Plain-language summary ----------
const UNSAFE_PLAIN = /\b(you have|you are having|the patient has|heart attack|diagnosed with)\b/i;
function plainFor(r, bodyMap = null) {
  const assessment = { ...r.assessment, prediction: r.prediction, recommendation: r.recommendation, safety: r.safety };
  if (bodyMap) {
    const derived = deriveFromBodyMap(bodyMap);
    assessment.bodyMap = { ...bodyMap, applied: { complaint: derived.complaint, answers: derived.answers, extras: derived.extras, signature: derived.signature } };
  }
  return plainSummary(assessment);
}
function plainChecks(name, r, summary) {
  const text = [summary.told, plainText(summary.mightBe), summary.whereToGo, summary.sure, summary.soon, summary.waiting].join(' ');
  check('plain: no unsafe wording ' + name, !UNSAFE_PLAIN.test(text), text);
  check('plain: no treatment advice ' + name, !TREATMENT_WORDS.test(text), text);
  check('plain: no undefined text ' + name, !/undefined|NaN|null|\[object Object\]/.test(text), text);
  const urgent = r.recommendation.key === 'urgent';
  if (urgent) {
    check('plain: urgent names no condition ' + name, !CONDITIONS.some((c) => text.includes(c.name) || text.includes(c.short + ' ')), text);
    check('plain: urgent sends to the emergency team ' + name, summary.whereToGo.includes('emergency team'));
  } else if (!r.prediction.isInconclusive && !r.prediction.conditionIsFallback) {
    check('plain: named condition is not called a diagnosis ' + name, plainText(summary.mightBe).includes('This is not a diagnosis'), plainText(summary.mightBe));
    check('plain: match word given ' + name, /(strong|moderate|fair) match/.test(plainText(summary.mightBe)), plainText(summary.mightBe));
  }
  check('plain: department named ' + name, summary.whereToGo.includes(r.recommendation.key === 'urgent' ? 'emergency' : r.recommendation.department), summary.whereToGo);
}
DEMO_CASES.forEach((demo) => plainChecks('demo ' + demo.id, outcomes[demo.id], plainFor(outcomes[demo.id])));
completedRoutes.slice(0, 120).forEach((route, i) => {
  const r = runPipeline({ name: 'R', age: i % 2 ? '58' : '27', gender: 'female', contact: '9999999999', complaint: route.complaint }, route.answers);
  plainChecks('route ' + i, r, plainFor(r));
});
check('plain: match words', matchWord(75) === 'strong match' && matchWord(40) === 'moderate match' && matchWord(10) === 'fair match' && matchWord(null) === '');
check('plain: abbreviations keep their capitals', lowerFirst('COPD') === 'COPD' && lowerFirst('Cough') === 'cough');
const cardioPlain = plainFor(A);
check('plain: cardio summary', cardioPlain.told.startsWith('Chest pain') && cardioPlain.told.includes('Chest pain: 6 out of 10') && plainText(cardioPlain.mightBe).startsWith('The answers fit Angina'), JSON.stringify(cardioPlain));
const bmPlainMap = bodyMapOf([['chest_pain', 'chest', 6], ['limb_pain', 'knee_r', 3]]);
const bmPlainRun = runBodyMap(P, [['chest_pain', 'chest', 6], ['limb_pain', 'knee_r', 3]], { answers: { chest_breathing: 'none', chest_dizziness: 'no', chest_sweating: 'no', chest_pattern: 'nothing', chest_onset: 'days', chest_associated: ['none'], safety_check: ['none'] } });
const bmPlain = plainFor(bmPlainRun, bmPlainMap);
check('plain: other body-map ratings listed', bmPlain.told.includes('Pain in the right knee: 3 out of 10') && bmPlain.told.includes('Chest pain: 6 out of 10'), bmPlain.told);
const manualPlain = plainSummary({ ...A.assessment, prediction: A.prediction, recommendation: mapPredictionToSpecialist(A.prediction, { urgent: true }), safety: { urgent: [], priority: [] }, urgentFlag: true });
check('plain: manual urgent mark is not called a warning sign', plainText(manualPlain.mightBe).includes('Reception marked the patient') && !plainText(manualPlain.mightBe).includes('warning signs'), plainText(manualPlain.mightBe));
const zeroPlain = plainFor(painZero);
check('plain: pain rated 0 reads as no pain', zeroPlain.told.includes('Chest pain: none right now (0 out of 10)') && !zeroPlain.told.startsWith('Chest pain,'), zeroPlain.told);
const zeroKneeMap = bodyMapOf([['limb_swelling', 'knee_r'], ['chest_pain', 'chest', 4]]);
const zeroKnee = runBodyMap(P, [['limb_swelling', 'knee_r'], ['chest_pain', 'chest', 4]], { answers: { joint_injury: 'no', joint_movement: 'no', joint_associated: ['none'], joint_duration: '1to3d', joint_score: 0, safety_check: ['none'] } });
const zeroKneePlain = plainFor(zeroKnee, zeroKneeMap);
check('plain: other pains stay listed when the main pain is 0', zeroKneePlain.told.startsWith('Chest pain and swelling') && zeroKneePlain.told.includes('Joint or limb pain: none right now') && zeroKneePlain.told.includes('Chest pain or pressure: 4 out of 10'), zeroKneePlain.told);
plainChecks('body map run', bmPlainRun, bmPlain);

// ---------- Staff accounts (section 3a) ----------
const hex = (bytes) => PasswordHash.toHex(bytes);
check('sha256 of "abc"', hex(PasswordHash.sha256(PasswordHash.utf8('abc'))) === 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
check('sha256 of an empty string', hex(PasswordHash.sha256(new Uint8Array(0))) === 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
const rfc = (password, salt, iterations) => hex(PasswordHash.pbkdf2Sync(PasswordHash.utf8(password), PasswordHash.utf8(salt), iterations));
check('pbkdf2 RFC 7914 vector, 1 round', rfc('password', 'salt', 1) === '120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b');
check('pbkdf2 RFC 7914 vector, 2 rounds', rfc('password', 'salt', 2) === 'ae4d0c95af6b46d32d0adff928f06dd02a303f8ef3c251dfd6e2d85a95474c43');
check('pbkdf2 RFC 7914 vector, 4096 rounds', rfc('password', 'salt', 4096) === 'c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a');
NODE_PBKDF2_CASES.forEach(([password, saltHex, iterations, expected], index) => {
  const got = hex(PasswordHash.pbkdf2Sync(PasswordHash.utf8(password), PasswordHash.fromHex(saltHex), iterations));
  check('pbkdf2 matches Node crypto, case ' + index, got === expected, password.length + ' chars: ' + got + ' vs ' + expected);
});
check('utf8 encodes like Node', NODE_UTF8_CASES.every(([text, expected]) => hex(PasswordHash.utf8(text)) === expected));
check('hex round trip', hex(PasswordHash.fromHex('00ff10a7')) === '00ff10a7');
check('email normalised', normaliseEmail('  Priya.Shah@Hospital.ORG ') === 'priya.shah@hospital.org');
['priya@hospital.org', 'a.b-c@x.co.in', 'desk+2@clinic.health'].forEach((email) => check('email accepted ' + email, EMAIL_PATTERN.test(email)));
['priya', 'priya@', '@hospital.org', 'priya@hospital', 'pri ya@hospital.org', 'priya@hospital..org'].forEach((email) => check('email rejected ' + email, !EMAIL_PATTERN.test(email)));
const goodForm = { ...emptyAuthForm(), firstName: 'Priya', lastName: 'Shah', email: 'Priya@Hospital.org', password: 'desk-pass-1', confirmed: true };
AUTH_CONFIG.signupSteps.forEach((step) => check('sign-up step valid: ' + step.id, validateSignupStep(step.id, goodForm, []).valid));
const emptyAccount = validateSignupStep('account', emptyAuthForm(), []);
check('sign-up: empty account step lists name, email, password', !emptyAccount.valid && emptyAccount.errors.firstName && emptyAccount.errors.email && emptyAccount.errors.password && !emptyAccount.errors.lastName);
check('sign-up: last name is optional', validateSignupStep('account', { ...goodForm, lastName: '' }, []).valid);
check('sign-up: names use letters', validateSignupStep('account', { ...goodForm, firstName: 'R2D2' }, []).errors.firstName.startsWith('Use letters only'));
check('sign-up: short password refused', validateSignupStep('account', { ...goodForm, password: 'short' }, []).errors.password === 'Use at least 8 characters.');
check('sign-up: blank password refused', Boolean(validateSignupStep('account', { ...goodForm, password: '          ' }, []).errors.password));
check('sign-up: email used on this computer refused', /already exists/.test(validateSignupStep('account', goodForm, [{ email: 'priya@hospital.org' }]).errors.email || ''));
check('sign-up: bad email refused', validateSignupStep('account', { ...goodForm, email: 'priya@hospital' }, []).errors.email === 'Enter an email address like name@hospital.org.');
const emptyDesk = validateSignupStep('desk', { ...goodForm, hospital: ' ', desk: '', role: 'pilot' }, []);
check('sign-up: desk step needs hospital, desk and a known role', emptyDesk.errors.hospital && emptyDesk.errors.desk && emptyDesk.errors.role);
check('sign-up: safe use must be confirmed', validateSignupStep('confirm', { ...goodForm, confirmed: false }, []).errors.confirmed === 'Tick the box to confirm how MediFind is used.');
check('account name joins first and last', accountName({ firstName: 'Priya', lastName: '' }) === 'Priya' && accountName({ firstName: 'Priya', lastName: 'Shah' }) === 'Priya Shah');
check('role labels', roleLabel('nurse') === 'Nurse' && roleLabel('unknown') === 'Staff');
check('signed-out profile falls back to the desk defaults', currentProfile().signedIn === false && currentProfile().desk === APP_CONFIG.deskName && currentProfile().hospital === APP_CONFIG.hospitalName);
check('safe-use statements do not claim diagnosis', AUTH_CONFIG.safeUse.every((line) => !/\b(diagnoses|will diagnose|cures?)\b/i.test(line)) && AUTH_CONFIG.safeUse[0].includes('does not diagnose'));

const table = DEMO_CASES.map((d) => {
  const r = outcomes[d.id];
  return [d.id.padEnd(20), r.recommendation.department.padEnd(20), String(r.prediction.confidence).padStart(3) + '%', r.prediction.predictedCondition, r.safety.urgent.map((f)=>f.id).join(',')].join(' | ');
}).join('\n');
// ---------- 12. Results from the trained model (backend) ----------
const demoById = Object.fromEntries(DEMO_CASES.map((demo) => [demo.id, demo]));
const scenarioById = Object.fromEntries(SCENARIOS.map((s) => [s.id, s]));
function apiResponse(category, probability, disease, extra = {}) {
  const probabilities = Object.fromEntries(CATEGORY_ORDER.map((id) => [id, id === category ? probability : (1 - probability) / (CATEGORY_ORDER.length - 1)]));
  const condition = CONDITION_INDEX[disease];
  return { category, probabilities, disease: condition.name, diseaseId: disease, diseaseProbability: probability * 0.8,
    differentials: [{ disease: 'Migraine', diseaseId: 'migraine', probability: 0.05 }, { disease: 'Asthma', diseaseId: 'asthma', probability: 0.03 }],
    model: { name: 'Logistic Regression', version: '1.0.0' }, ...extra };
}
function viaModel(patient, answers, response) {
  const run = runPipeline(patient, answers);
  return { run, p: normaliseApiPrediction(response, run.processed, { complaint: patient.complaint }) };
}

// A clear case: the model's probability becomes the confidence, capped at 94%.
const cardio = demoById['demo-cardio'];
const clear = viaModel(cardio.patient, cardio.answers, apiResponse('cardiovascular', 0.995, 'angina', {
  evidence: { supporting: [{ feature: 'exertionalSymptoms', contribution: 2.6 }, { feature: 'genderMale', contribution: 0.4 }, { feature: 'chestPain', contribution: 2.4 }],
              against: [{ feature: 'durationBand', contribution: -0.3 }] } }));
check('model: engine recorded', clear.p.engine === 'api' && isModelResult(clear.p) && clear.p.model.name === 'Logistic Regression');
check('model: confidence capped at 94', clear.p.confidence === CONFIDENCE_THRESHOLDS.cap && clear.p.modelFactors.capped && clear.p.modelFactors.probability === 99, clear.p.confidence);
check('model: department from the model', clear.p.predictedCategoryId === 'cardiovascular' && !clear.p.isInconclusive);
check('model: condition from the model', clear.p.predictedConditionId === 'angina' && clear.p.conditionLikelihood === 80 && !clear.p.conditionIsFallback);
check('model: condition probability shown up to 90%', viaModel(cardio.patient, cardio.answers, apiResponse('cardiovascular', 0.995, 'angina', { diseaseProbability: 0.9999 })).p.conditionLikelihood === CONDITION_SETTINGS.likelihoodCap);
check('model: alternatives from the model', clear.p.differentials.length === 2 && clear.p.differentials[0].id === 'migraine' && clear.p.differentials[0].likelihood === 5);
check('model: explanation keeps listed symptoms only', clear.p.matchedSymptoms.map((s) => s.key).join() === 'exertionalSymptoms,chestPain', JSON.stringify(clear.p.matchedSymptoms));
check('model: answers against it shown', clear.p.conditionAgainst.length === 1 && clear.p.conditionAgainst[0].points < 0);
check('model: category shares add to about 100, none shown as 100%', Math.abs(clear.p.categoryScores.reduce((s, c) => s + c.share, 0) - 100) <= 2 && clear.p.categoryScores.every((c) => c.share <= 99));
check('model: specialist mapping unchanged', mapPredictionToSpecialist(clear.p, { urgent: false }).department === 'Cardiology');
check('model: engine text', /trained ML model \(Logistic Regression v1\.0\.0\)/.test(engineSourceText(clear.p)) && engineInfoFor(clear.p).id === 'api');
check('local result engine text', engineSourceText(clear.run.prediction) === 'Calculated by the built-in rules in this browser.' && engineInfoFor(clear.run.prediction).id === ENGINE_INFO.id);

// Vague answers: the rules see weak evidence and the model is under 90% sure -> inconclusive.
const vague = demoById['demo-general'];
const weak = viaModel(vague.patient, vague.answers, apiResponse('neurological', 0.76, 'migraine'));
check('model: weak evidence limits the confidence', weak.p.modelFactors.limitedByRules && weak.p.modelFactors.limitedBecause === 'uncertain-model' && weak.p.confidence === weak.run.prediction.confidence && weak.p.confidence < 55, JSON.stringify(weak.p.modelFactors));
check('model: weak evidence -> inconclusive', weak.p.isInconclusive && weak.p.predictedCategoryId === 'inconclusive' && mapPredictionToSpecialist(weak.p, { urgent: false }).department === 'General Medicine');
check('model: inconclusive lists the model candidates', weak.p.consideredConditions.length === 3 && weak.p.consideredConditions[0].id === 'migraine' && weak.p.consideredConditions[0].department === 'Neurology', JSON.stringify(weak.p.consideredConditions));
check('model: inconclusive lists symptoms considered', Array.isArray(weak.p.consideredSymptoms) && weak.p.consideredSymptoms.length > 0);
const sure = viaModel(vague.patient, vague.answers, apiResponse('neurological', 0.95, 'migraine'));
check('model: 90%+ model confidence is not limited', !sure.p.modelFactors.limitedByRules && !sure.p.isInconclusive && sure.p.confidence === 94);

// Contradictory answers lower the model's confidence by the same penalties.
const fractureCase = { patient: { age: '84', gender: 'male', complaint: 'joint_limb' },
  answers: { joint_site: 'arm', joint_swelling: 'yes', joint_injury: 'yes', joint_deformity: 'yes', joint_movement: 'yes', joint_associated: ['none'], joint_duration: 'gt1m', joint_score: 0, safety_check: ['none'] } };
const contra = viaModel(fractureCase.patient, fractureCase.answers, apiResponse('musculoskeletal', 0.95, 'fracture'));
check('model: contradiction penalty applied', !contra.run.prediction.isInconclusive && contra.p.modelFactors.penalty === 25 && contra.p.confidence === 70 && !contra.p.modelFactors.limitedByRules && !contra.p.isInconclusive, JSON.stringify(contra.p.modelFactors));
// Contradictions + rules unable to decide: limited even when the model is 90%+ sure.
const zero = scenarioById['r40-joint-pain-zero'];
const contraWeak = viaModel(zero.patient, zero.answers, apiResponse('musculoskeletal', 0.92, 'osteoarthritis'));
check('model: contradictions with weak evidence -> inconclusive', contraWeak.p.modelFactors.limitedByRules && contraWeak.p.modelFactors.limitedBecause === 'contradictions'
  && contraWeak.p.confidence === contraWeak.run.prediction.confidence && contraWeak.p.isInconclusive, JSON.stringify(contraWeak.p.modelFactors));

// Below 55% from the model alone.
const clearLow = viaModel(cardio.patient, cardio.answers, apiResponse('cardiovascular', 0.5, 'angina'));
check('model: below 55% -> inconclusive', clearLow.p.isInconclusive && clearLow.p.confidence === 50);

// Unknown or missing fields from the backend do not break the result.
const odd = viaModel(cardio.patient, cardio.answers, { probabilities: { cardiovascular: 0.9, respiratory: 0.1 } });
check('model: no condition named -> category fallback', odd.p.conditionIsFallback && odd.p.predictedConditionId === CATEGORIES.cardiovascular.fallbackCondition.id && odd.p.confidence === 90);
check('model: bad evidence ignored', viaModel(cardio.patient, cardio.answers, apiResponse('cardiovascular', 0.9, 'angina', { evidence: { supporting: [{ feature: 'nope', contribution: 3 }, null] } })).p.matchedSymptoms.length === 0);

// Urgent cases: the condition is still withheld from model results.
const urgentDemo = demoById['demo-urgent'];
const urgentRun = viaModel(urgentDemo.patient, urgentDemo.answers, apiResponse('cardiovascular', 0.99, 'angina'));
check('model: urgent warning signs still detected', urgentRun.run.safety.urgent.length > 0);
withholdCondition(urgentRun.p);
check('model: urgent result withholds the condition', urgentRun.p.conditionWithheld && !('predictedCondition' in urgentRun.p) && mapPredictionToSpecialist(urgentRun.p, { urgent: true }).department === 'Emergency & Triage');

// Urgent mark added, then removed: the condition is worked out again by the rules, and the result says so.
const marked = viaModel(cardio.patient, cardio.answers, apiResponse('cardiovascular', 0.99, 'angina'));
const markedAssessment = { prediction: marked.p, features: marked.run.processed };
withholdCondition(marked.p);
restoreCondition(markedAssessment);
check('model: restored condition marked as from the rules', marked.p.conditionByRules && !conditionFromModel(marked.p) && isModelResult(marked.p) && !!marked.p.predictedConditionId);
check('model: restored condition explained', /worked out again by the built-in rules/.test(engineSourceText(marked.p)));
check('model: normal result condition from the model', conditionFromModel(clear.p));

// Asynchronous parts: detecting the backend, calling it, and falling back.
async function runAsyncTests() {
  const health = { status: 'ok', model: 'Logistic Regression', version: '1.0.0', schemaVersion: FEATURE_SCHEMA_VERSION, conditions: 73 };
  const reply = (body, ok = true) => async () => ({ ok, status: ok ? 200 : 500, json: async () => body });
  check('detect: file page keeps the rules', (await PredictionService.detect()) === 'local');
  globalThis.window = { location: { protocol: 'http:' } };
  try {
    globalThis.fetch = reply(health);
    check('detect: backend found', (await PredictionService.detect()) === 'api' && PredictionService.backend.model === 'Logistic Regression');
    check('dashboard line names the model', /trained ML model \(Logistic Regression v1\.0\.0\)/.test(engineStatusText()));
    globalThis.fetch = reply(apiResponse('cardiovascular', 0.99, 'angina'));
    const viaApi = await PredictionService.predict(clear.run.processed, { complaint: cardio.patient.complaint });
    check('predict: uses the backend', viaApi.engine === 'api' && viaApi.predictedConditionId === 'angina' && !viaApi.engineFallback);
    let sentBody = null;
    globalThis.fetch = async (url, options) => { sentBody = JSON.parse(options.body); return { ok: true, status: 200, json: async () => apiResponse('cardiovascular', 0.99, 'angina') }; };
    await PredictionService.predict(clear.run.processed, { complaint: cardio.patient.complaint });
    check('predict: sends only the encoded answers', sentBody && sentBody.schemaVersion === FEATURE_SCHEMA_VERSION && sentBody.features.length === FEATURE_ORDER.length
      && !JSON.stringify(sentBody).includes(String(cardio.patient.name || 'no-name-set')) && !('patient' in sentBody), JSON.stringify(Object.keys(sentBody || {})));
    globalThis.fetch = async () => { throw new Error('connection refused'); };
    const fallback = await PredictionService.predict(clear.run.processed, { complaint: cardio.patient.complaint });
    check('predict: falls back to the rules when the backend is down', fallback.engineFallback === true && fallback.engine === ENGINE_INFO.id && PredictionService.mode === 'local');
    check('dashboard line back to the rules', engineStatusText() === 'Prediction engine: local prototype, runs in this browser');
    globalThis.fetch = reply({ ...health, schemaVersion: 'sdp-features-v2' });
    check('detect: different schema keeps the rules', (await PredictionService.detect()) === 'local');
    globalThis.fetch = reply(health, false);
    check('detect: error keeps the rules', (await PredictionService.detect()) === 'local');
  } finally {
    delete globalThis.window;
    delete globalThis.fetch;
    PredictionService.useLocal();
  }
}

({ asyncDone: runAsyncTests(), results, table, routeCount, minLen, maxLen, lengthsByComplaint,
   fuzz: { count: fuzzCount, urgent: fuzzUrgent, inconclusive: fuzzInconclusive, conditions: fuzzConditions.size, scenarioMisses },
   extras: { minimalA: minimalA.prediction.confidence, minimalB: minimalB.prediction.confidence, minimalC: minimalC.prediction.confidence, fever: fever.prediction.confidence + ' ' + fever.prediction.predictedCondition, painZero: painZero.prediction.confidence, unsureA: unsureA.prediction.confidence, neuroSlow: neuroSlow.prediction.confidence } });
`;

const SCENARIOS = JSON.parse(fs.readFileSync(path.join(__dirname, 'condition-scenarios.json'), 'utf8'));
// Reference values for the password hashing, computed with Node's own crypto.
const nodeCrypto = require('crypto');
const NODE_PBKDF2_CASES = [
  ['clinic-desk-42', '00112233445566778899aabbccddeeff', 1000],
  ['pässwörd ✓ नमस्ते 🩺', 'ffeeddccbbaa99887766554433221100', 777],
  ['x'.repeat(65), '0102030405060708', 300],
  ['correct horse battery staple', '', 50],
].map(([password, saltHex, iterations]) => [password, saltHex, iterations,
  nodeCrypto.pbkdf2Sync(Buffer.from(password.normalize('NFC'), 'utf8'), Buffer.from(saltHex, 'hex'), iterations, 32, 'sha256').toString('hex')]);
const NODE_UTF8_CASES = ['abc', 'pässwörd', 'नमस्ते', '🩺 ok', ''].map((text) => [text, Buffer.from(text.normalize('NFC'), 'utf8').toString('hex')]);
const context = vm.createContext({ console, Math, JSON, Date, Number, String, Object, Array, Set, Map, Promise, setTimeout, clearTimeout, SCENARIOS, NODE_PBKDF2_CASES, NODE_UTF8_CASES });
const out = vm.runInContext(source + '\n' + testCode, context, { filename: 'engine-under-test.js' });
(async () => {
await out.asyncDone;
console.log(out.table);
console.log('routes:', out.routeCount, 'min/max length:', out.minLen, out.maxLen);
console.log('lengths by complaint:', JSON.stringify(out.lengthsByComplaint));
console.log('extras:', JSON.stringify(out.extras));
console.log('conditions:', JSON.stringify(out.fuzz));
if (/Math\.random/.test(source)) { out.results.fail += 1; out.results.failures.push('Math.random used in engine'); } else { out.results.pass += 1; }
console.log(`\nPASS ${out.results.pass}  FAIL ${out.results.fail}`);
if (out.results.fail) {
  console.log(out.results.failures.slice(0, 60).join('\n'));
  process.exitCode = 1;
}
})();
