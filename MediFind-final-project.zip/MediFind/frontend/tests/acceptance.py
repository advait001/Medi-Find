"""Acceptance tests for index.html — test cases A–J plus the functional acceptance criteria.

Run: python3 tests/acceptance.py [screenshot_dir]
"""
import io
import json
import re
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
URL = (ROOT / "index.html").as_uri()
SHOTS = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/claude-0/acceptance")
SHOTS.mkdir(parents=True, exist_ok=True)

results = []
console_errors = []
BAD_TEXT = ["undefined", "NaN", "[object Object]", "null"]


def check(name, condition, detail=""):
    results.append((name, bool(condition), detail))


def visible_text_ok(page, where):
    text = page.inner_text("body")
    bad = [b for b in BAD_TEXT if re.search(r"\b" + re.escape(b) + r"\b", text)]
    check(f"no undefined/null/NaN text on {where}", not bad, ",".join(bad))


# A staff account and a signed-in session, set up before the app loads, so
# the flow tests start on the dashboard. The sign-in screen itself is tested
# in its own section with fresh browser contexts.
TEST_PASSWORD = "desk-test-2026"
SEED_ACCOUNT = {
    "id": "acct-test", "firstName": "Asha", "lastName": "Verma", "email": "asha.verma@hospital.test", "role": "receptionist",
    "hospital": "Multispeciality Hospital", "desk": "Reception desk", "createdAt": "2026-01-05T09:00:00.000Z", "lastSignInAt": None,
    "safeUseConfirmedAt": "2026-01-05T09:00:00.000Z",
    "password": {"algorithm": "PBKDF2-SHA-256", "iterations": 1000, "salt": "5eed5eed5eed5eed5eed5eed5eed5eed",
                 "hash": "1e4e7cf3e33b9a355ab810c9ab246da119c3ce15ae2b785e255ea5e959f36c7e"},
}
SEED_SCRIPT = """(() => { try {
  const account = %s;
  const accounts = JSON.parse(localStorage.getItem('medifind.accounts.v1') || '[]');
  if (!accounts.some((item) => item.id === account.id)) { accounts.push(account); localStorage.setItem('medifind.accounts.v1', JSON.stringify(accounts)); }
  if (!sessionStorage.getItem('medifind.session.v1')) sessionStorage.setItem('medifind.session.v1', JSON.stringify({ accountId: account.id, startedAt: new Date().toISOString() }));
} catch (error) { /* storage blocked: the test signs up through the screen */ } })();""" % json.dumps(SEED_ACCOUNT)


def new_page(browser, width=1440, height=900, clear=True, signed_in=True):
    context = browser.new_context(viewport={"width": width, "height": height})
    if signed_in:
        context.add_init_script(SEED_SCRIPT)
    page = context.new_page()
    page.on("console", lambda m: console_errors.append(f"{m.type}: {m.text}") if m.type == "error" else None)
    page.on("pageerror", lambda e: console_errors.append(f"pageerror: {e}"))
    page.goto(URL)
    if clear:
        page.evaluate("localStorage.clear()")
        page.reload()
    return page


def pg_text(page, selector):
    """Visible text of the first match, whitespace collapsed ('' when absent)."""
    el = page.query_selector(selector)
    return " ".join(el.inner_text().split()) if el else ""


def state(page, expr):
    return page.evaluate(f"() => JSON.parse(JSON.stringify({expr}))")


def sign_up(page, first, last, email, password, desk=None, role=None, hospital=None):
    """Creates an account through the three sign-up steps and waits for the dashboard."""
    page.fill("#auth-firstName", first)
    page.fill("#auth-lastName", last)
    page.fill("#auth-email", email)
    page.fill("#auth-password", password)
    page.click("[data-action=auth-continue]")
    page.wait_for_selector("#auth-hospital")
    if hospital:
        page.fill("#auth-hospital", hospital)
    if desk:
        page.fill("#auth-desk", desk)
    if role:
        page.click(f"label.auth-choice:has(input[value={role}])")
    page.click("[data-action=auth-continue]")
    page.wait_for_selector("#auth-confirmed", state="attached")
    page.click("label.auth-check:has(#auth-confirmed)")
    page.click("[data-action=auth-continue]")
    page.wait_for_selector("#hero-title", timeout=15000)


def sign_out(page):
    page.click("[data-action=sign-out] >> visible=true")
    if page.query_selector(".modal"):
        page.click(".modal button:has-text('Sign out')")
    page.wait_for_selector(".auth")


def auth_title(page):
    """The sign-in screen heading without its "Step n of 3:" prefix for screen readers."""
    return re.sub(r"^Step \d of \d:\s*", "", page.inner_text("#auth-title").strip())


def overflow_x(page):
    return page.evaluate("document.documentElement.scrollWidth") > page.viewport_size["width"] + 1


def luminance(css_colour):
    """Relative luminance (0 black to 1 white) of a computed rgb()/rgba() colour."""
    values = [float(v) for v in re.split(r"[\s,/]+", re.search(r"rgba?\(([^)]+)\)", css_colour).group(1).strip())[:3]]
    linear = [v / 255 / 12.92 if v / 255 <= 0.03928 else ((v / 255 + 0.055) / 1.055) ** 2.4 for v in values]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def figure_pixel(page, area, dx=0, dy=-40):
    """Screen colour of the body map near a body part's badge point (figure units offset)."""
    point = page.evaluate("""([area, dx, dy]) => {
      const svg = document.querySelector('.bm-svg');
      const view = state.ui.bmView === 'back' ? 'back' : 'front';
      const region = BODY_FIGURE.views[view].find((r) => r.area === area);
      const pt = svg.createSVGPoint(); pt.x = region.badge[0] + dx; pt.y = region.badge[1] + dy;
      const p = pt.matrixTransform(svg.getScreenCTM());
      return [Math.round(p.x), Math.round(p.y)];
    }""", [area, dx, dy])
    shot = Image.open(io.BytesIO(page.screenshot())).convert("RGB")
    return shot.getpixel(tuple(point))


def start_new(page):
    page.click("[data-action=new-assessment] >> nth=0")
    if page.query_selector(".modal"):
        page.click("text=Discard and start new")
    page.wait_for_selector("[data-form=intake]")


def fill_intake(page, name, age, contact, gender="female", description=""):
    page.fill("#field-name", name)
    page.fill("#field-age", str(age))
    page.fill("#field-contact", contact)
    if gender:
        page.click(f"label:has(input[name=gender][value={gender}])")
    if description:
        page.fill("#field-description", description)
    page.click("[data-action=save-patient]")
    page.wait_for_selector(".screen--bodymap")


def choose_list_complaint(page, complaint):
    """Symptoms step, "Choose from a list" mode: pick the main complaint and continue."""
    page.wait_for_selector(".screen--bodymap")
    if not page.query_selector("[data-bm-complaint]"):
        page.click("label:has(input[data-bm-mode][value=list])")
    page.click(f"label:has(input[name=complaint][value={complaint}]) .q-option__face")
    page.click("[data-action=bm-continue]")
    page.wait_for_selector(".q-card")


def fill_patient(page, name, age, contact, complaint, gender="female", description=""):
    fill_intake(page, name, age, contact, gender=gender, description=description)
    choose_list_complaint(page, complaint)


def current_qid(page):
    card = page.query_selector(".q-card")
    return card.get_attribute("data-question-id") if card else None


def click_option(page, value):
    page.click(f"label:has([data-question-input][value='{value}']) >> .q-option__face, .q-scale__face >> nth=0"
               if False else f"label:has([data-question-input][value='{value}'])")


def select_answer(page, value):
    if isinstance(value, list):
        checked = [el.get_attribute("value") for el in page.query_selector_all("[data-question-input]:checked")]
        for v in checked:
            if v not in value:
                click_option(page, v)
        for v in value:
            if not page.is_checked(f"[data-question-input][value='{v}']"):
                click_option(page, v)
    elif isinstance(value, dict):
        page.fill("#q-number-input", str(value["value"]))
        page.click(f"label:has([data-question-unit][value='{value['unit']}'])")
    else:
        click_option(page, value)


def answer_route(page, answers, stop_before=None, max_steps=20):
    """Answers questions by id until the review screen appears (or stop_before is reached)."""
    asked = []
    for _ in range(max_steps):
        if page.query_selector("[data-action=run-assessment]"):
            return asked
        qid = current_qid(page)
        if qid is None:
            return asked
        if stop_before and qid == stop_before:
            return asked
        if qid not in answers:
            raise AssertionError(f"No answer configured for {qid}; asked so far {asked}")
        select_answer(page, answers[qid])
        page.click("[data-action=submit-answer]")
        page.wait_for_timeout(60)
        asked.append(qid)
    return asked


def run_and_wait_results(page):
    page.click("[data-action=run-assessment]")
    page.wait_for_selector(".analysis__steps")
    page.wait_for_selector(".route-sign", timeout=8000)


def result_summary(page):
    return {
        "department": page.inner_text(".route-sign__name"),
        "specialist": page.inner_text(".route-sign__specialist strong"),
        "text": page.inner_text("#screen"),
    }


with sync_playwright() as p:
    browser = p.chromium.launch()

    # ------------------------------------------------------------------
    # Dashboard + empty states
    # ------------------------------------------------------------------
    page = new_page(browser)
    check("dashboard primary CTA visible", page.is_visible("text=New Patient Assessment"))
    check("dashboard shows date/time", bool(page.inner_text("#clock-time").strip()) and bool(page.inner_text("#clock-date").strip()))
    check("dashboard shows system status", "Decision support active" in page.inner_text(".topbar"))
    check("dashboard empty recent state", "No assessments have been completed yet." in page.inner_text("#screen"))
    check("privacy note present", "Prototype assessment data is stored locally in this browser." in page.inner_text("body"))
    check("brand: MediFind logo in the sidebar", page.is_visible(".brand__logo")
          and page.get_attribute(".brand__logo", "aria-label") == "MediFind"
          and page.evaluate("() => document.querySelector('.brand__logo use').getAttribute('href') === '#mf-logo' && document.querySelector('#mf-logo image').getAttribute('href').startsWith('data:image/png;base64,')"))
    check("brand: descriptor under the logo", "Smart disease prediction & doctor recommendation" in page.inner_text(".brand"))
    check("brand: page title uses the MediFind name", page.title().endswith("| MediFind"), page.title())
    check("brand: favicon is the MediFind mark", (page.get_attribute("link[rel=icon]", "href") or "").startswith("data:image/png;base64,"))
    check("brand: old name no longer shown", "Smart Disease Prediction &" not in page.inner_text("body"))
    logo_px = np.asarray(Image.open(io.BytesIO(page.locator(".brand__logo").screenshot())).convert("RGB")).astype(int)
    check("brand: logo picture is painted (blue cross, dark wordmark)",
          bool((logo_px[..., 2] > logo_px[..., 0] + 80).any()) and bool((logo_px.max(axis=2) < 40).any()))
    page.click("[data-nav=history] >> nth=0")
    check("history empty state", "No assessments have been completed yet." in page.inner_text("#screen") and page.is_visible("text=Start First Assessment"))
    visible_text_ok(page, "history empty")

    # ------------------------------------------------------------------
    # Intake validation
    # ------------------------------------------------------------------
    page.click("text=Start First Assessment")
    page.click("[data-action=save-patient]")
    summary = page.inner_text("[data-error-summary]")
    check("intake: error summary lists 3 problems", summary.count("\n") >= 3 and "complaint" not in summary.lower(), summary)
    check("intake: no complaint list on patient details", not page.query_selector("input[name=complaint]"))
    check("intake: inline name error", "Enter the patient’s name." in page.inner_text("#err-name"))
    page.fill("#field-name", "R2D2")
    page.fill("#field-age", "150")
    page.fill("#field-contact", "12345")
    page.click("[data-action=save-patient]")
    check("intake: invalid name rejected", "letters only" in page.inner_text("#err-name"))
    check("intake: age range enforced", "0 to 120" in page.inner_text("#err-age"))
    check("intake: contact format enforced", "valid contact number" in page.inner_text("#err-contact"))
    page.fill("#field-age", "4.5")
    page.click("[data-action=save-patient]")
    check("intake: decimal age rejected with message (no silent rewrite)", page.input_value("#field-age") == "4.5" and "whole number" in page.inner_text("#err-age"))
    check("intake: no browser alert used", True)
    page.screenshot(path=str(SHOTS / "intake-errors.png"))

    # Cancel with data → modal
    page.click("[data-action=cancel-assessment]")
    check("cancel: confirmation modal shown", page.is_visible(".modal") and "Discard this assessment?" in page.inner_text(".modal"))
    page.screenshot(path=str(SHOTS / "cancel-modal.png"))
    page.click("text=Continue Assessment")
    check("cancel: continue keeps data", page.input_value("#field-name") == "R2D2")
    page.click("[data-action=cancel-assessment]")
    page.click(".modal >> text=Discard Assessment")
    check("cancel: discard returns to dashboard", page.is_visible("#hero-title"))
    check("cancel: working copy cleared", state(page, "state.assessment.patient.name") == "")

    # ------------------------------------------------------------------
    # Test case A — Pain → Chest → cardiovascular
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Rahul Sharma", 52, "98200 14567", "pain", gender="male", description="Chest discomfort")
    check("A: first question is pain location", current_qid(page) == "pain_location")
    check("A: one question at a time", len(page.query_selector_all(".q-card")) == 1)
    check("A: adaptive context text", "Questions adapt based on previous responses." in page.inner_text(".q-card"))
    asked = answer_route(page, {
        "pain_location": "chest", "chest_breathing": "moderate", "chest_dizziness": "yes", "chest_sweating": "yes",
        "chest_pattern": "nothing", "chest_onset": "days", "chest_score": 5, "chest_associated": ["none"], "safety_check": ["none"],
    })
    check("A: chest branch asked breathing next", asked[:2] == ["pain_location", "chest_breathing"], ",".join(asked))
    check("A: review reached", page.is_visible("text=Review assessment"))
    review_text = page.inner_text("#screen")
    for section in ["Patient details", "Main complaint", "Reported symptoms", "Duration", "Severity", "Additional responses"]:
        check(f"review shows {section}", section in review_text)
    visible_text_ok(page, "review")
    run_and_wait_results(page)
    r = result_summary(page)
    check("A: Cardiology recommended", r["department"] == "Cardiology", r["department"])
    check("A: Cardiologist", r["specialist"] == "Cardiologist")
    check("A: Cardiovascular category shown", "Cardiovascular symptom pattern" in r["text"])
    check("A: predicted condition shown", "Predicted condition" in r["text"] and "Angina (heart-related chest pain)" in r["text"], r["text"][:400])
    check("A: condition description shown", "heart muscle does not get enough blood" in r["text"])
    check("A: match strength shown with its meaning", "Match strength" in r["text"] and "Not the chance that the patient has it" in r["text"] and state(page, "state.assessment.prediction.conditionLikelihood") >= 50)
    check("A: marked as not a confirmed diagnosis", "Not a confirmed diagnosis" in r["text"])
    conf_a = state(page, "state.assessment.prediction.confidence")
    check("A: strong confidence", conf_a >= 75, str(conf_a))
    check("results: model confidence label", "Model confidence" in r["text"] and "does not represent clinical certainty" in r["text"])
    check("results: disclaimer visible", "Decision-support tool only." in r["text"])
    check("results: assessment ID format", re.match(r"MF-\d{4}-\d{4}$", state(page, "state.assessment.id") or "") is not None)
    check("results: never says diagnosis label", "Diagnostic Accuracy" not in r["text"] and "You have" not in r["text"])
    plain = page.inner_text(".plain-card")
    check("results: plain-language summary", all(t.lower() in plain.lower() for t in ["In simple words", "What the patient told us", "What it might be", "Where to go", "While waiting"]), plain)
    check("results: plain summary names the condition carefully", "The answers fit Angina (heart-related chest pain) best" in plain and "This is not a diagnosis" in plain, plain)
    check("results: plain department name with the doctor", "See Dr. Anjali Mehta, a heart specialist (Cardiology department)" in plain, plain)
    check("results: doctor to see on the department card", pg_text(page, ".route-sign__doctor") == "AM Doctor to see Dr. Anjali Mehta", pg_text(page, ".route-sign__doctor"))
    check("results: doctor saved with the assessment", state(page, "AssessmentRepository.get(state.assessment.id).recommendation.doctor") == {"name": "Dr. Anjali Mehta"})
    check("results: match strength in words", re.search(r"(Strong|Moderate|Fair) match", page.inner_text(".likelihood")) is not None, page.inner_text(".likelihood"))
    visible_text_ok(page, "results A")
    page.screenshot(path=str(SHOTS / "A-results.png"))
    # Why drawer
    page.click("[data-action=open-why]")
    page.wait_for_selector(".drawer")
    why = page.inner_text(".drawer")
    check("why: explains category", "most strongly matched the cardiovascular category" in why)
    check("why: matched features", "Chest pain" in why and "Unusual sweating" in why)
    check("why: category match shares", "Category match" in why and "%" in why)
    why_condition = why.split("Predicted condition", 1)[-1]
    check("why: explains predicted condition", "most closely match" in why_condition and "Answers supporting this condition" in why_condition and "Unusual sweating" in why_condition, why_condition[:300])
    check("why: condition fit factor", "Condition fit" in why)
    page.keyboard.press("Escape")
    check("why: Escape closes drawer", not page.query_selector(".drawer"))
    # Report
    page.evaluate("() => { window.__printCalls = 0; window.print = () => { window.__printCalls += 1; }; }")
    page.click("[data-action=generate-report]")
    page.wait_for_selector("#report-document")
    report = page.inner_text("#report-document")
    for part in ["PRELIMINARY ASSESSMENT REPORT", "Rahul Sharma", "52 years", "98200 14567", "Main complaint".upper(), "Cardiology", "Cardiologist",
                 "SAFETY NOTICE", "This system is a decision-support tool only.", state(page, "state.assessment.id")]:
        check(f"report contains {part!r}", part.lower() in report.lower())
    check("report: no prescriptions", "dosage" not in report.lower().replace("medicines or dosages", ""))
    check("report: predicted condition", "predicted condition (not confirmed)" in report.lower() and "Angina (heart-related chest pain)" in report)
    check("report: match strength explained", "Match strength" in report and "not the chance that the patient has it" in report)
    check("report: no model confidence section", "model confidence" not in report.lower() and "does not represent clinical certainty" not in report)
    check("report: disease category kept under the preliminary assessment", re.search(r"possible disease category\s+cardiovascular symptom pattern", report, re.I) is not None, report[report.find("PRELIMINARY ASSESSMENT\n"):][:500])
    check("report: no step progress bar on the report screen", page.query_selector(".stepper, .stepper-wrap") is None)
    check("report: in simple words", "IN SIMPLE WORDS" in report.upper() and "What the patient told us" in report and "See Dr. Anjali Mehta, a heart specialist" in report, report[:600])
    check("report: doctor to see with the department", "Cardiology Suggested specialist: Cardiologist Doctor to see: Dr. Anjali Mehta" in pg_text(page, "#report-document .rpt-route"),
          pg_text(page, "#report-document .rpt-route"))
    check("report: plain symptom labels", "\nHas\n" in report and "Unconfirmed" not in report and "Not present" not in report, report[:900])
    check("report: MediFind logo and descriptor in the header", page.is_visible("#report-document .rpt-brand__logo")
          and "Smart disease prediction & doctor recommendation" in report and "Smart Disease Prediction &" not in report)
    page.click("[data-action=print-report]")
    page.wait_for_timeout(300)
    check("print: window.print called", page.evaluate("window.__printCalls") == 1)
    page.emulate_media(media="print")
    pdf_path = SHOTS / "A-report.pdf"
    page.pdf(path=str(pdf_path), format="A4", print_background=True)
    page.emulate_media(media="screen")
    info = subprocess.run(["pdfinfo", str(pdf_path)], capture_output=True, text=True).stdout
    pdf_text = subprocess.run(["pdftotext", "-layout", str(pdf_path), "-"], capture_output=True, text=True).stdout
    check("print: A4 page size", "595" in info and "842" in info, info)
    check("print: chrome hidden", "Assessment History" not in pdf_text and "Back to result" not in pdf_text and "Decision support active" not in pdf_text)
    check("print: disclaimer on page 1", "SAFETY NOTICE" in pdf_text.split("\f")[0])
    check("print: predicted condition on page 1", "Angina" in pdf_text.split("\f")[0])
    check("print: doctor to see on page 1", "Doctor to see: Dr. Anjali Mehta" in pdf_text.split("\f")[0])
    check("print: two pages", "Pages:           2" in info, info)
    id_a = state(page, "state.assessment.id")

    # ------------------------------------------------------------------
    # Start another assessment resets temporary state, keeps history
    # ------------------------------------------------------------------
    page.click("[data-action=new-assessment] >> nth=0")
    check("new: intake is empty", page.input_value("#field-name") == "" and not page.query_selector("input[name=complaint]:checked"))
    check("new: answers cleared", state(page, "Object.keys(state.assessment.answers).length") == 0)
    check("new: prediction cleared", state(page, "state.assessment.prediction") is None)
    check("new: history intact", state(page, "AssessmentRepository.list().length") == 1)

    # ------------------------------------------------------------------
    # Test case B — respiratory
    # ------------------------------------------------------------------
    fill_patient(page, "Ananya Iyer", 34, "+91 98765 43210", "respiratory")
    answer_route(page, {"resp_cough": "yes", "resp_cough_type": "dry", "resp_breathing": "mild", "resp_wheeze": "no", "resp_fever": "yes",
                        "resp_chest": "no", "resp_duration": "1to3d", "resp_background": ["none"], "safety_check": ["none"]})
    run_and_wait_results(page)
    r = result_summary(page)
    check("B: Pulmonology", r["department"] == "Pulmonology" and r["specialist"] == "Pulmonologist", r["department"])
    check("B: respiratory pattern", "Respiratory symptom pattern" in r["text"])
    cond_b = state(page, "state.assessment.prediction.predictedConditionId")
    check("B: respiratory condition predicted", cond_b in ("influenza", "urti") and state(page, "state.assessment.prediction.predictedCondition") in r["text"], cond_b)

    # ------------------------------------------------------------------
    # Test case C — joint pain
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Vikram Patil", 41, "9930011223", "joint_limb", gender="male")
    asked = answer_route(page, {"joint_site": "knee", "joint_swelling": "yes", "joint_injury": "yes", "joint_deformity": "no", "joint_movement": "yes",
                                "joint_associated": ["none"], "joint_duration": "1to3d", "joint_score": 6, "safety_check": ["none"]})
    check("C: conditional deformity question asked after injury", "joint_deformity" in asked, ",".join(asked))
    run_and_wait_results(page)
    r = result_summary(page)
    check("C: Orthopaedics", r["department"] == "Orthopaedics" and r["specialist"] == "Orthopaedic Specialist", r["department"])
    check("C: sprain predicted", "Sprain or strain" in r["text"])

    # ------------------------------------------------------------------
    # Test case D — skin
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Sneha Kulkarni", 27, "97690 55821", "skin")
    answer_route(page, {"skin_type": "rash", "skin_itching": "yes", "skin_redness": "yes", "skin_spreading": "yes", "skin_area": "arms",
                        "skin_duration": "1to4w", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(page)
    r = result_summary(page)
    check("D: Dermatology", r["department"] == "Dermatology" and r["specialist"] == "Dermatologist", r["department"])
    check("D: fungal infection predicted", "Fungal skin infection" in r["text"])

    # ------------------------------------------------------------------
    # Test case E — digestive
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Imran Shaikh", 38, "98211 70345", "digestive", gender="male")
    answer_route(page, {"gi_main": "pain", "abd_location": "upper_middle", "abd_meals": "worse", "gi_associated": ["nausea", "acidity"],
                        "gi_duration": "4to7d", "abd_score": 5, "safety_check": ["none"]})
    run_and_wait_results(page)
    r = result_summary(page)
    check("E: Gastroenterology", r["department"] == "Gastroenterology" and r["specialist"] == "Gastroenterologist", r["department"])
    check("E: gastritis / GERD predicted", "Gastritis / acid reflux (GERD)" in r["text"])

    # ------------------------------------------------------------------
    # Test case F — neurological
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Meera Joshi", 45, "99870 23456", "neuro")
    answer_route(page, {"neuro_main": "headache", "head_sudden": "no", "head_character": "throbbing", "head_associated": ["nausea", "light"],
                        "head_frequency": "occasional", "head_duration": "lt24h", "head_score": 6, "safety_check": ["none"]})
    run_and_wait_results(page)
    r = result_summary(page)
    check("F: Neurology", r["department"] == "Neurology" and r["specialist"] == "Neurologist", r["department"])
    check("F: migraine predicted", "Migraine" in r["text"])

    # ------------------------------------------------------------------
    # Test case G — weak / mixed data
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Arjun Mehta", 29, "90040 67890", "other", gender="male")
    answer_route(page, {"other_area": "whole", "other_symptoms": ["tired", "headache", "stomach"], "other_duration": "1to3d",
                        "other_severity": "mild", "safety_check": ["none"]})
    run_and_wait_results(page)
    r = result_summary(page)
    conf_g = state(page, "state.assessment.prediction.confidence")
    check("G: General Physician", r["specialist"] == "General Physician", r["specialist"])
    check("G: general doctor to see", "Dr. Meera Iyer" in pg_text(page, ".route-sign__doctor") and "See Dr. Meera Iyer, a general doctor (General Medicine department) for a general check-up." in r["text"])
    check("G: low confidence", conf_g < 55, str(conf_g))
    check("G: General / Inconclusive label", "General / Inconclusive" in r["text"])
    check("G: inconclusive message", "does not strongly match a single assessment category" in r["text"])
    check("G: low band label", "Low / inconclusive" in r["text"])
    check("G: no single condition named", "No single condition stands out" in r["text"])
    check("G: conditions listed for the doctor", "Possible conditions for the doctor to consider" in r["text"])
    page.screenshot(path=str(SHOTS / "G-results.png"))

    # ------------------------------------------------------------------
    # Test case H — backward branching clears obsolete answers
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Branch Test", 40, "9000000001", "pain", gender="male")
    answer_route(page, {"pain_location": "chest", "chest_breathing": "moderate", "chest_dizziness": "yes", "chest_sweating": "yes"}, stop_before="chest_pattern")
    check("H: chest answers recorded", all(k in state(page, "state.assessment.answers") for k in ["chest_breathing", "chest_dizziness", "chest_sweating"]))
    for _ in range(4):
        page.click("[data-action=question-prev]")
        page.wait_for_timeout(60)
    check("H: back at location question", current_qid(page) == "pain_location", current_qid(page))
    check("H: previous answer preselected", page.is_checked("[data-question-input][value=chest]"))
    select_answer(page, "joint")
    page.click("[data-action=submit-answer]")
    page.wait_for_timeout(100)
    answers_h = state(page, "state.assessment.answers")
    check("H: chest answers removed from state", not any(k.startswith("chest_") for k in answers_h), json.dumps(answers_h))
    check("H: joint question appears", current_qid(page) == "joint_site", current_qid(page))
    check("H: route-change notice shown", "Route updated" in page.inner_text(".q-card"))
    trail = page.inner_text(".trail")
    check("H: trail has no chest answers", "Difficulty breathing" not in trail and "Unusual sweating" not in trail, trail)
    page.screenshot(path=str(SHOTS / "H-branch-notice.png"))
    answer_route(page, {"joint_site": "ankle", "joint_swelling": "yes", "joint_injury": "no", "joint_movement": "yes",
                        "joint_associated": ["none"], "joint_duration": "1to3d", "joint_score": 4, "safety_check": ["none"]})
    review_h = page.inner_text("#screen")
    check("H: review excludes chest responses", "difficulty breathing" not in review_h.lower() and "sweating" not in review_h.lower())
    run_and_wait_results(page)
    raw_h = state(page, "state.assessment.features.raw")
    check("H: feature vector excludes chest branch", raw_h["chestPain"] in (None, 0) and raw_h["sweating"] in (None, 0) and raw_h["dizziness"] in (None, 0), json.dumps({k: raw_h[k] for k in ['chestPain', 'sweating', 'dizziness']}))
    check("H: prediction uses joint branch", result_summary(page)["department"] == "Orthopaedics")
    page.click("[data-action=generate-report]")
    rep_h = page.inner_text("#report-document").lower()
    check("H: report excludes chest branch", "sweating" not in rep_h and "difficulty breathing" not in rep_h)

    # ------------------------------------------------------------------
    # Red flags / urgent escalation
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Suresh Nair", 63, "98190 33445", "pain", gender="male")
    answer_route(page, {"pain_location": "chest", "chest_breathing": "severe"}, stop_before="chest_dizziness")
    banner = page.inner_text(".urgent-banner") if page.query_selector(".urgent-banner") else ""
    check("urgent: banner appears after severe breathing", "POTENTIAL URGENT SYMPTOMS IDENTIFIED" in banner.upper() and "triage protocol" in banner, banner)
    page.screenshot(path=str(SHOTS / "urgent-banner.png"))
    page.click("[data-action=mark-urgent]")
    page.wait_for_timeout(100)
    check("urgent: marked status", "Marked for immediate clinical evaluation" in page.inner_text(".urgent-banner"))
    check("urgent: flag in state", state(page, "state.assessment.urgentFlag") is True)
    page.click("[data-action=finish-early]")
    page.wait_for_selector("[data-action=run-assessment]")
    check("urgent: early finish reaches review", "ended early" in page.inner_text("#screen"))
    run_and_wait_results(page)
    r = result_summary(page)
    check("urgent: routed to Emergency & Triage", r["department"] == "Emergency & Triage", r["department"])
    check("urgent: no diagnosis shown", "Not generated" in r["text"] and "Not applicable" in r["text"] and "Cardiovascular symptom pattern" not in r["text"])
    check("urgent: no named doctor on the result", page.query_selector(".route-sign__doctor") is None and "Dr. " not in page.inner_text(".route-sign"))
    condition_names = page.evaluate("() => CONDITIONS.map((c) => c.name).concat(CONDITIONS.map((c) => c.short))")
    def names_in(text):
        return [n for n in condition_names if n in text]
    check("urgent: no condition stored in the result", state(page, "state.assessment.prediction.predictedCondition ?? null") is None and state(page, "state.assessment.prediction.conditionWithheld") is True)
    check("urgent: predicted condition withheld on results", not names_in(r["text"]) and "Predicted condition" not in r["text"], ",".join(names_in(r["text"])))
    check("urgent: header says no condition is predicted", "no condition is predicted" in r["text"])
    page.click("[data-action=open-why]")
    page.wait_for_selector(".drawer")
    page.click(".drawer summary")
    check("urgent: drawer withholds condition", not names_in(page.inner_text(".drawer")) and "Condition score" not in page.inner_text(".drawer"))
    page.keyboard.press("Escape")
    check("urgent: protocol text", "emergency / clinical triage protocol" in r["text"])
    page.screenshot(path=str(SHOTS / "urgent-results.png"))
    page.click("[data-action=generate-report]")
    rep_u = page.inner_text("#report-document")
    check("urgent: report withholds classification", "Not generated" in rep_u and "Emergency & Triage" in rep_u)
    check("urgent: no named doctor in the report", "Doctor to see" not in rep_u and "Dr. " not in rep_u)
    check("urgent: report has no model confidence section", "model confidence" not in rep_u.lower() and "Not applicable" not in rep_u)
    check("urgent: report withholds condition", not names_in(rep_u) and "predicted condition" not in rep_u.lower(), ",".join(names_in(rep_u)))
    check("urgent: report records marking", "Marked for immediate clinical evaluation" in rep_u)

    # Manual flag (patient looks unwell) without red-flag answers
    start_new(page)
    fill_patient(page, "Manual Flag", 70, "9000000002", "weakness")
    page.click("[data-action=flag-urgent]")
    page.click(".modal >> text=Mark as urgent")
    check("manual flag: banner shown", "flagged as urgent" in page.inner_text(".urgent-banner").lower())
    page.click("[data-action=remove-urgent]")
    check("manual flag: can be removed", not page.query_selector(".urgent-banner"))
    page.click("[data-action=cancel-assessment]")
    page.click(".modal >> text=Discard Assessment")

    # ------------------------------------------------------------------
    # Contradictory data
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Kavita Rao", 36, "98670 12890", "pain")
    answer_route(page, {"pain_location": "chest", "chest_breathing": "none", "chest_dizziness": "no", "chest_sweating": "no", "chest_pattern": "nothing",
                        "chest_onset": "days", "chest_score": 0, "chest_associated": ["none"], "safety_check": ["none"]})
    check("contradiction: flagged on review", "rated 0 out of 10" in page.inner_text("#screen"))
    run_and_wait_results(page)
    r = result_summary(page)
    check("contradiction: general evaluation", r["specialist"] == "General Physician", r["specialist"])
    check("contradiction: confidence reduced note", "contradicted the main complaint" in r["text"])

    # ------------------------------------------------------------------
    # Determinism and sensitivity
    # ------------------------------------------------------------------
    def demo_confidence(demo_id, tweak=None):
        start_new(page)
        page.click("summary:has-text('Load demo case')")
        page.click(f"[data-demo-id={demo_id}]")
        page.click("[data-action=save-patient]")
        page.wait_for_selector(".screen--bodymap")
        page.click("[data-action=bm-continue]")
        page.wait_for_selector(".q-card")
        for _ in range(14):
            if page.query_selector("[data-action=run-assessment]"):
                break
            qid = current_qid(page)
            if tweak and qid in tweak:
                select_answer(page, tweak[qid])
            page.click("[data-action=submit-answer]")
            page.wait_for_timeout(50)
        run_and_wait_results(page)
        return state(page, "state.assessment.prediction")

    p1 = demo_confidence("demo-resp")
    p2 = demo_confidence("demo-resp")
    check("deterministic: same answers same prediction", (p1["confidence"], p1["predictedCategoryId"], p1["categoryScores"]) == (p2["confidence"], p2["predictedCategoryId"], p2["categoryScores"]))
    p3 = demo_confidence("demo-resp", {"resp_fever": "no", "resp_breathing": "none", "resp_background": ["none"]})
    check("prediction changes when answers change", p3["confidence"] != p1["confidence"], f"{p1['confidence']} vs {p3['confidence']}")
    check("no Math.random in source", "Math.random" not in (ROOT / "index.html").read_text())
    for demo_id, expected in [("demo-dengue", "dengue"), ("demo-asthma", "asthma"), ("demo-sciatica", "sciatica")]:
        pd = demo_confidence(demo_id)
        check(f"demo {demo_id}: predicts {expected}", pd["predictedConditionId"] == expected and pd["predictedCondition"] in page.inner_text("#screen"), pd["predictedConditionId"])
        visible_text_ok(page, f"results {demo_id}")

    # ------------------------------------------------------------------
    # Keyboard: number keys + Enter
    # ------------------------------------------------------------------
    start_new(page)
    fill_patient(page, "Keyboard User", 30, "9000000003", "fever")
    page.keyboard.press("2")
    check("keyboard: number key selects option", page.is_checked("[data-question-input][value='1to3d']"))
    page.keyboard.press("Enter")
    page.wait_for_timeout(100)
    check("keyboard: Enter continues", current_qid(page) == "fever_measured", current_qid(page))
    page.keyboard.press("1")
    page.keyboard.press("Enter")
    page.wait_for_timeout(100)
    check("conditional: temperature asked when measured", current_qid(page) == "fever_temp", current_qid(page))
    page.fill("#q-number-input", "150")
    page.click("[data-action=submit-answer]")
    check("number: range validated", "between 95 and 108" in page.inner_text("#q-error"))
    page.fill("#q-number-input", "101.4")
    page.click("[data-action=submit-answer]")
    page.wait_for_timeout(100)
    check("number: accepted", current_qid(page) == "fever_cough")
    page.click("[data-action=submit-answer]")
    check("validation: must choose an answer", "Select an option" in page.inner_text("#q-error"))

    # Draft survives refresh
    page.reload()
    check("draft: resume banner after refresh", page.is_visible("text=Resume assessment"))
    page.click("[data-action=resume-assessment]")
    check("draft: resumes with data", current_qid(page) is not None and state(page, "state.assessment.patient.name") == "Keyboard User")
    page.click("[data-action=cancel-assessment]")
    page.click(".modal >> text=Discard Assessment")

    # ------------------------------------------------------------------
    # Test case I — history survives refresh; J — reopen restores everything
    # ------------------------------------------------------------------
    page.click("[data-nav=dashboard] >> nth=0")
    count_before = state(page, "AssessmentRepository.list().length")
    page.reload()
    check("I: history survives refresh", state(page, "AssessmentRepository.list().length") == count_before and count_before >= 10, str(count_before))
    recent_text = page.inner_text(".recent")
    check("I: recent assessments listed on dashboard", "MF-" in recent_text)
    check("I: dashboard shows predicted conditions", "Asthma" in recent_text and "Dengue" in recent_text, recent_text[:300].replace("\n", " | "))
    stats = page.inner_text(".stat-row")
    check("dashboard: today counts", re.search(r"\b1[0-9]\b|\b[1-9]\b", stats) is not None, stats)
    page.screenshot(path=str(SHOTS / "dashboard-data.png"))
    visible_text_ok(page, "dashboard")

    page.click("[data-nav=history] >> nth=0")
    page.fill("#history-search", "rahul")
    page.wait_for_timeout(100)
    rows = page.query_selector_all(".table tbody tr")
    check("history: search by name", len(rows) == 1 and "Rahul Sharma" in rows[0].inner_text(), str(len(rows)))
    check("history: predicted condition in row", "Angina" in rows[0].inner_text(), rows[0].inner_text())
    page.fill("#history-search", id_a)
    rows = page.query_selector_all(".table tbody tr")
    check("history: search by ID", len(rows) == 1 and id_a in rows[0].inner_text())
    page.fill("#history-search", "zzz-nobody")
    check("history: no-match empty state", "No assessments match your search." in page.inner_text("#history-results"))
    page.click("[data-action=clear-search]")
    headers = page.inner_text(".table thead")
    for col in ["Assessment ID", "Patient", "Main Complaint", "Assessment Category", "Specialist", "Confidence", "Date / Time"]:
        check(f"history column {col}", col in headers)
    page.screenshot(path=str(SHOTS / "history.png"))
    visible_text_ok(page, "history")

    page.fill("#history-search", id_a)
    page.click(f"[data-action=open-assessment][data-id='{id_a}']")
    page.wait_for_selector(".route-sign")
    r = result_summary(page)
    check("J: reopened patient details", "Rahul Sharma" in r["text"] and "98200 14567" in r["text"] and "52 years" in r["text"])
    check("J: reopened symptoms", "Chest pain" in r["text"])
    check("J: reopened prediction + confidence", "Cardiovascular symptom pattern" in r["text"] and f"{conf_a}" in r["text"])
    check("J: reopened specialist", r["department"] == "Cardiology" and r["specialist"] == "Cardiologist")
    check("J: reopened predicted condition", "Angina (heart-related chest pain)" in r["text"])
    page.click("[data-action=generate-report]")
    rep_j = page.inner_text("#report-document")
    check("J: report restored", "Rahul Sharma" in rep_j and id_a in rep_j and "Cardiology" in rep_j)
    visible_text_ok(page, "reopened report")

    # Clear history
    page.click("[data-nav=history] >> nth=0")
    page.click("[data-action=clear-history]")
    page.click(".modal >> text=Keep assessments")
    check("clear history: cancel keeps data", state(page, "AssessmentRepository.list().length") == count_before)
    page.close()

    # ------------------------------------------------------------------
    # Body map (Symptoms step)
    # ------------------------------------------------------------------
    pb = new_page(browser)
    start_new(pb)
    fill_intake(pb, "Body Map Test", 52, "9000000020", gender="male")
    check("bodymap: shown after patient details", pb.is_visible("text=Where are the symptoms?"))
    check("bodymap: no step progress bar; the top bar names the step", pb.query_selector(".stepper, .stepper-wrap") is None
          and pb.inner_text("#topbar-crumb") == "New assessment / Symptoms", pb.inner_text("#topbar-crumb"))
    check("bodymap: figure has clickable body parts", len(pb.query_selector_all(".bm-region")) >= 26)
    check("bodymap: sides labelled on the figure", "RIGHT" in pb.inner_text(".bm-figure").upper() and "LEFT" in pb.inner_text(".bm-figure").upper())
    check("bodymap: figure shows the supplied body map picture",
          pb.evaluate("() => document.querySelector('.bm-svg use').getAttribute('href') === '#bm-art-front' && document.getElementById('bm-art-front').getAttribute('href').startsWith('data:image/png;base64,')"))
    fig_px = np.asarray(Image.open(io.BytesIO(pb.locator(".bm-figure").screenshot())).convert("RGB")).astype(int)
    greys = int(((fig_px.max(axis=2) - fig_px.min(axis=2) < 6) & (fig_px[..., 0] > 120) & (fig_px[..., 0] < 200)).sum())
    check("bodymap: the drawing is painted (grey anatomy pixels)", greys > 20000, str(greys))
    chest_before = figure_pixel(pb, "chest", dx=-45, dy=0)
    check("bodymap: untouched body part shows the plain grey drawing", abs(chest_before[0] - chest_before[2]) < 8, str(chest_before))
    pb.click("[data-action=bm-continue]")
    check("bodymap: nothing picked → message", "Select at least one symptom" in pb.inner_text("#bm-error"))
    pb.click("[data-bm-region=chest]")
    check("bodymap: chest panel opens", pb.inner_text("#bm-panel-title") == "Chest")
    pb.click("label:has([data-bm-symptom=chest_pain])")
    panel = pb.inner_text("#bm-panel")
    check("bodymap: chest pain scale end labels", "Barely there, like a light pressure" in panel and "Crushing, the worst pain you can imagine" in panel, panel[:500])
    pb.click("label:has([data-bm-pain='chest_pain'][value='6'])")
    check("bodymap: pain readout", "Selected 6 out of 10" in pb.inner_text("#bm-panel"))
    pb.click("[data-bm-region=knee_r]")
    check("bodymap: right knee panel opens", pb.inner_text("#bm-panel-title") == "Right knee")
    pb.click("label:has([data-bm-symptom=limb_pain])")
    panel = pb.inner_text("#bm-panel")
    check("bodymap: joint scale reads 1 = pinched, 10 = bone breaking", "Like someone pinched you" in panel and "Like a bone breaking" in panel, panel[:500])
    pb.click("label:has([data-bm-pain='limb_pain@knee_r'][value='3'])")
    pb.click("label:has([data-bm-symptom=limb_swelling])")
    pb.fill("#bm-search-input", "cough")
    check("bodymap: search finds a symptom", "Cough" in pb.inner_text("#bm-search-results"))
    pb.keyboard.press("Enter")
    picks = state(pb, "state.assessment.bodyMap.selections.map((s) => s.key)")
    check("bodymap: picks recorded", picks == ["chest_pain", "limb_pain@knee_r", "limb_swelling@knee_r", "cough"], json.dumps(picks))
    badges = pb.evaluate("() => Array.from(document.querySelectorAll('.bm-badge text')).map((el) => el.textContent)")
    check("bodymap: counts shown on the figure (chest 2, right knee 2)", sorted(badges) == ["2", "2"], json.dumps(badges))
    pb.mouse.move(5, 5)
    chest_after = figure_pixel(pb, "chest", dx=-45, dy=0)
    check("bodymap: picked body part is tinted blue on the drawing", chest_after[2] > chest_after[0] + 40, str(chest_after))
    knee_x = pb.evaluate("() => { const r = document.querySelector('[data-bm-region=knee_r]').getBoundingClientRect(); const f = document.querySelector('.bm-svg').getBoundingClientRect(); return [(r.left + r.right) / 2 - f.left, f.width]; }")
    check("bodymap: patient's right knee is on the viewer's left in the front view", knee_x[0] < knee_x[1] / 2, json.dumps(knee_x))
    check("bodymap: main problem can be chosen", pb.is_visible(".bm-primary") and "Which is the main problem today?" in pb.inner_text(".bm-selected"))
    selected = pb.inner_text(".bm-selected")
    check("bodymap: symptom list with pain scores", "Right knee: pain" in selected and "Pain 3/10" in selected and "Pain 6/10" in selected, selected)
    visible_text_ok(pb, "body map")
    pb.screenshot(path=str(SHOTS / "bodymap-picks.png"), full_page=True)
    pb.click("[data-action=bm-remove][data-key='limb_swelling@knee_r']")
    check("bodymap: a pick can be removed", "swelling" not in pb.inner_text(".bm-selected").lower())
    pb.click("label:has(input[data-bm-view][value=back])")
    check("bodymap: back view shows the back", pb.query_selector("[data-bm-region=lower_back]") is not None and pb.query_selector("[data-bm-region=chest]") is None)
    check("bodymap: back view uses the back of the picture", pb.evaluate("() => document.querySelector('.bm-svg use').getAttribute('href')") == "#bm-art-back")
    knee_back = pb.evaluate("() => { const r = document.querySelector('[data-bm-region=knee_r]').getBoundingClientRect(); const f = document.querySelector('.bm-svg').getBoundingClientRect(); return [(r.left + r.right) / 2 - f.left, f.width]; }")
    check("bodymap: back view puts the patient's right knee on the viewer's right", knee_back[0] > knee_back[1] / 2, json.dumps(knee_back))
    pb.click("[data-bm-region=lower_back]")
    check("bodymap: lower back panel", pb.inner_text("#bm-panel-title") == "Lower back")
    pb.click("label:has(input[data-bm-view][value=front])")
    pb.focus("[data-bm-region=abd_lr]")
    pb.keyboard.press("Enter")
    check("bodymap: keyboard opens a body part", pb.inner_text("#bm-panel-title") == "Lower right belly" and pb.evaluate("document.activeElement.id") == "bm-panel-title")
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector(".q-card")
    check("bodymap: questions skip what the body map answered", current_qid(pb) == "chest_breathing", current_qid(pb))
    answers_bm = state(pb, "state.assessment.answers")
    check("bodymap: answers taken from the map", answers_bm.get("pain_location") == "chest" and answers_bm.get("chest_score") == 6, json.dumps(answers_bm))
    check("bodymap: first question is numbered 1", pb.inner_text(".q-card__count") == "Question 1", pb.inner_text(".q-card__count"))
    check("bodymap: response trail marks body-map answers", "Body map" in pb.inner_text(".trail"))
    aside = pb.inner_text(".q-aside")
    check("bodymap: side panel lists the picks", "On the body map" in aside and "Right knee: pain" in aside and "Chest pain or pressure" in aside, aside)
    pb.click("[data-action=question-prev]")
    check("bodymap: Previous on the first question returns to the body map", pb.is_visible(".screen--bodymap"))
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector(".q-card")
    check("bodymap: continuing again keeps the answers", current_qid(pb) == "chest_breathing" and state(pb, "state.assessment.answers.chest_score") == 6)
    asked = answer_route(pb, {"chest_breathing": "mild", "chest_dizziness": "no", "chest_sweating": "yes", "chest_pattern": "exertion",
                              "chest_onset": "today"}, stop_before="chest_associated")
    check("bodymap: pain score not asked again", "chest_score" not in asked, ",".join(asked))
    check("bodymap: other picks pre-tick a later question", pb.is_checked("[data-question-input][value=cough]")
          and "Pre-selected from the symptoms on the body map" in pb.inner_text(".q-card"))
    answer_route(pb, {"chest_associated": ["cough"], "safety_check": ["none"]})
    review_bm = pb.inner_text("#screen")
    check("bodymap: review lists the body-map picks", "Picked on the body map" in review_bm and "Right knee: pain" in review_bm and "Chest pain or pressure" in review_bm)
    check("bodymap: review shows the main problem", "Chest pain or pressure" in pb.inner_text(".review-complaint"))
    run_and_wait_results(pb)
    r = result_summary(pb)
    check("bodymap: routed by the main problem", r["department"] == "Cardiology", r["department"])
    check("bodymap: other picks counted as symptoms", "Joint or limb pain" in r["text"] and "Cough" in r["text"], r["text"][:600])
    check("bodymap: no condition is stated as fact", "You have" not in r["text"] and "The patient has" not in r["text"])
    pb.screenshot(path=str(SHOTS / "bodymap-results.png"), full_page=True)
    pb.click("[data-action=generate-report]")
    rep_bm = pb.inner_text("#report-document")
    check("bodymap: report lists body areas", "Body map" in rep_bm and "Right knee: pain (3/10)" in rep_bm and "Chest pain or pressure (6/10)" in rep_bm, rep_bm[:1200])
    check("bodymap: report main complaint names the main problem", "Chest pain or pressure (pain)" in rep_bm)
    pb.emulate_media(media="print")
    pdf_bm = SHOTS / "bodymap-report.pdf"
    pb.pdf(path=str(pdf_bm), format="A4", print_background=True)
    pb.emulate_media(media="screen")
    info_bm = subprocess.run(["pdfinfo", str(pdf_bm)], capture_output=True, text=True).stdout
    text_bm = subprocess.run(["pdftotext", "-layout", str(pdf_bm), "-"], capture_output=True, text=True).stdout
    check("bodymap: report still two pages", "Pages:           2" in info_bm, info_bm)
    check("bodymap: safety notice and simple summary on page 1", "SAFETY NOTICE" in text_bm.split("\f")[0] and "IN SIMPLE WORDS" in text_bm.split("\f")[0])
    # Editing the body map from the review changes the route
    pb.click("[data-action=back-to-results]")
    pb.click("[data-action=edit-assessment]")
    pb.click("[data-action=edit-bodymap] >> nth=0")
    pb.wait_for_selector(".screen--bodymap")
    pb.click("label:has(input[data-bm-primary][value='limb_pain@knee_r'])")
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector(".q-card")
    answers_bm = state(pb, "state.assessment.answers")
    check("bodymap: new main problem changes the route", state(pb, "state.assessment.patient.complaint") == "joint_limb"
          and answers_bm.get("joint_site") == "knee" and answers_bm.get("joint_score") == 3 and "chest_breathing" not in answers_bm, json.dumps(answers_bm))
    check("bodymap: route change explained", "Route updated" in pb.inner_text(".q-card"))
    pb.click("[data-action=cancel-assessment]")
    pb.click(".modal >> text=Discard changes")
    # A warning sign added from the review is checked again before running
    start_new(pb)
    fill_intake(pb, "Late Warning", 45, "9000000023")
    pb.click("[data-bm-region=knee_r]")
    pb.click("label:has([data-bm-symptom=limb_pain])")
    pb.click("label:has([data-bm-pain='limb_pain@knee_r'][value='5'])")
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector(".q-card")
    answer_route(pb, {"joint_swelling": "no", "joint_injury": "no", "joint_movement": "no", "joint_associated": ["none"],
                      "joint_duration": "1to3d", "safety_check": ["none"]})
    check("late warning: review reached", pb.is_visible("[data-action=run-assessment]"))
    pb.click("[data-action=edit-bodymap] >> nth=0")
    pb.wait_for_selector(".screen--bodymap")
    pb.click("[data-bm-region=head]")
    pb.click("label:has([data-bm-symptom=fainted])")
    check("late warning: banner on the body map at once", pb.is_visible(".urgent-banner") and "Fainting or loss of consciousness" in pb.inner_text(".urgent-banner"))
    # leaving without Continue cannot reach the review with unapplied picks
    pb.click("[data-action=edit-patient]")
    pb.click("[data-action=save-patient]")
    pb.wait_for_selector(".screen--bodymap")
    check("late warning: review waits for the body map changes", "press Continue to apply" in pb.inner_text("#bm-error"), pb.inner_text("#bm-error"))
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector("[data-action=run-assessment]")
    review_late = pb.inner_text("#screen")
    check("late warning: back on the review with the warning sign recorded", "Fainting or loss of consciousness" in pb.inner_text(".urgent-banner")
          and "Fainting or loss of consciousness" in pb.inner_text(".response-list"), review_late[:600])
    run_and_wait_results(pb)
    r = result_summary(pb)
    check("late warning: routed to Emergency & Triage without a condition", r["department"] == "Emergency & Triage"
          and state(pb, "state.assessment.prediction.predictedCondition ?? null") is None, r["department"])
    # Choosing the list instead asks first when symptoms are picked
    start_new(pb)
    fill_intake(pb, "List Switch", 45, "9000000024")
    pb.click("[data-bm-region=head]")
    pb.click("label:has([data-bm-symptom=fainted])")
    pb.click("label:has(input[data-bm-mode][value=list])")
    check("list switch: asks before dropping the picks", pb.is_visible(".modal") and "warning sign" in pb.inner_text(".modal"), pb.inner_text(".modal") if pb.is_visible(".modal") else "")
    pb.click(".modal >> text=Keep the body map")
    check("list switch: keeping the body map keeps the picks", state(pb, "state.assessment.bodyMap.mode") == "map" and pb.is_visible(".urgent-banner"))
    pb.click("label:has([data-bm-symptom=fainted])")
    # Search: a body part plus a symptom, and symptoms that need a body part
    pb.fill("#bm-search-input", "knee pain")
    check("search: knee pain offers each knee", "Right knee: pain" in pb.inner_text("#bm-search-results") and "Left knee: pain" in pb.inner_text("#bm-search-results"))
    pb.keyboard.press("Enter")
    check("search: Enter without an exact match moves to the results", pb.evaluate("document.activeElement.classList.contains('bm-result')") and state(pb, "state.assessment.bodyMap.selections.length") == 0)
    pb.keyboard.press("ArrowDown")
    pb.keyboard.press("Enter")
    check("search: picking a result adds it", state(pb, "state.assessment.bodyMap.selections.map((s) => s.key)") == ["limb_pain@knee_l"])
    pb.fill("#bm-search-input", "numbness")
    pb.keyboard.press("Enter")
    pb.keyboard.press("Enter")
    check("search: numbness highlights where it can be picked", len(pb.query_selector_all(".bm-region.is-hinted")) >= 8 and "Where is the numbness or tingling?" in pb.inner_text("#bm-panel"))
    pb.click("[data-action=cancel-assessment]")
    pb.click(".modal >> text=Discard Assessment")

    # Warning-sign symptoms show the urgent banner straight away
    start_new(pb)
    fill_intake(pb, "Urgent Map", 60, "9000000021")
    pb.click("[data-bm-region=head]")
    pb.click("label:has([data-bm-symptom=fainted])")
    check("bodymap: warning-sign symptom shows the urgent banner", pb.is_visible(".urgent-banner") and "Fainting or loss of consciousness" in pb.inner_text(".urgent-banner"))
    check("bodymap: warning sign marked in the list", "Warning sign" in pb.inner_text("#bm-panel"))
    pb.click("label:has([data-bm-symptom=fainted])")
    check("bodymap: banner clears when unticked", not pb.query_selector(".urgent-banner"))
    pb.click("label:has([data-bm-symptom=headache])")
    pb.click("label:has([data-bm-pain='headache'][value='8'])")
    pb.click("[data-action=bm-open-area][data-area=general]")
    pb.click("label:has([data-bm-symptom=fever])")
    pb.click("[data-bm-region=neck]")
    pb.click("label:has([data-bm-symptom=stiff_neck])")
    check("bodymap: fever with a stiff neck is urgent", "Fever with a stiff neck" in pb.inner_text(".urgent-banner"))
    pb.click("label:has([data-bm-symptom=stiff_neck])")
    # list mode keeps working and the draft keeps the picks
    pb.reload()
    pb.click("[data-action=resume-assessment]")
    pb.wait_for_selector(".screen--bodymap")
    check("bodymap: draft keeps the picks after a refresh", state(pb, "state.assessment.bodyMap.selections.length") == 2)
    pb.click("label:has(input[data-bm-mode][value=list])")
    pb.click(".modal >> text=Use the list")
    check("bodymap: list mode shows the complaint list", len(pb.query_selector_all("[data-bm-complaint]")) == 10)
    pb.click("label:has(input[data-bm-mode][value=map])")
    check("bodymap: switching back keeps the picks", state(pb, "state.assessment.bodyMap.selections.length") == 2)
    pb.click("[data-action=bm-continue]")
    pb.wait_for_selector(".q-card")
    check("bodymap: headache route starts after the answered question", current_qid(pb) == "head_sudden", current_qid(pb))
    pb.close()

    # Saved records from before the body map still open, with their report
    pl = new_page(browser)
    start_new(pl)
    fill_patient(pl, "Legacy Record", 33, "9000000022", "fever")
    answer_route(pl, {"fever_duration": "1to3d", "fever_measured": "no", "fever_cough": "no", "fever_chills": "yes", "fever_rash": "no",
                      "fever_weakness": "yes", "fever_associated": ["body_aches"], "safety_check": ["none"]})
    run_and_wait_results(pl)
    pl.click("[data-action=generate-report]")
    pl.wait_for_selector("#report-document")
    legacy_id = state(pl, "state.assessment.id")
    pl.evaluate("""(id) => { const key = APP_CONFIG.storageKeys.assessments; const items = JSON.parse(localStorage.getItem(key));
      const r = items.find((x) => x.id === id); delete r.bodyMap; r.report.version = 2; r.report.confidence = { value: 71, label: 'Moderate confidence', helper: 'Saved before the section was removed.' }; delete r.recommendation.doctor; delete r.report.recommendation.doctor; delete r.report.plain; delete r.report.complaint.mainProblem; delete r.report.symptoms.bodyMap;
      localStorage.setItem(key, JSON.stringify(items)); }""", legacy_id)
    pl.reload()
    pl.click("[data-nav=history] >> nth=0")
    pl.click(f"[data-action=open-assessment][data-id='{legacy_id}']")
    pl.wait_for_selector(".route-sign")
    visible_text_ok(pl, "legacy results")
    check("legacy: result shows the department's doctor for a record saved before doctors were added", "Dr. Meera Iyer" in pg_text(pl, ".route-sign__doctor"), pg_text(pl, ".route-sign"))
    pl.click("[data-action=generate-report]")
    rep_l = pl.inner_text("#report-document")
    check("legacy: old report opens as it was saved", "Legacy Record" in rep_l and "MAIN COMPLAINT" in rep_l.upper() and "IN SIMPLE WORDS" not in rep_l.upper())
    check("legacy: the saved report keeps its routing as saved", "Doctor to see" not in rep_l and "General Medicine" in rep_l)
    check("legacy: a saved report with a confidence figure no longer shows it", "model confidence" not in rep_l.lower() and "possible disease category" in rep_l.lower(), rep_l[rep_l.upper().find("PRELIMINARY ASSESSMENT\n"):][:400])
    visible_text_ok(pl, "legacy report")
    pl.click("[data-action=back-to-results]")
    pl.click("[data-action=edit-assessment]")
    pl.click("[data-action=edit-bodymap] >> nth=0")
    pl.wait_for_selector(".screen--bodymap")
    check("legacy: symptoms step opens the list with the saved complaint", pl.is_checked("input[data-bm-complaint][value=fever]"))
    pl.close()

    # ------------------------------------------------------------------
    # Storage unavailable → app still works from memory
    # ------------------------------------------------------------------
    ctx = browser.new_context(viewport={"width": 1366, "height": 768})
    ctx.add_init_script("Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } });")
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: console_errors.append(f"pageerror (no storage): {e}"))
    pg.goto(URL)
    check("no storage: sign-in screen explains that accounts last for this tab",
          pg.is_visible(".auth") and "blocking storage" in pg.inner_text(".auth-note"))
    sign_up(pg, "Memory", "Desk", "memory@hospital.test", "memory-only-1")
    check("no storage: app renders after signing up", pg.is_visible("#hero-title"))
    check("no storage: wording says data is lost on reload", "lost when this page is reloaded or closed" in pg.inner_text("#toast-region"))
    sign_out(pg)
    check("no storage: no Keep me signed in option", pg.query_selector("#auth-keep") is None)
    pg.click("[data-action=auth-pick-account]")
    pg.fill("#auth-loginPassword", "memory-only-1")
    pg.click("[data-action=auth-login]")
    pg.wait_for_selector("#hero-title", timeout=15000)
    check("no storage: warning shown", "Temporary storage" in pg.inner_text(".topbar") or "storage is unavailable" in pg.inner_text("body").lower())
    pg.click("[data-action=new-assessment] >> nth=0")
    fill_patient(pg, "Memory Only", 33, "9000000009", "skin")
    answer_route(pg, {"skin_type": "acne", "skin_itching": "no", "skin_redness": "yes", "skin_spreading": "no", "skin_area": "face",
                      "skin_duration": "gt1m", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pg)
    check("no storage: assessment completes", result_summary(pg)["department"] == "Dermatology")
    ctx.close()


    # ------------------------------------------------------------------
    # QA regressions (independent review findings)
    # ------------------------------------------------------------------
    pq = new_page(browser)
    # D1: marking urgent on Results keeps the result and saves the mark
    start_new(pq)
    fill_patient(pq, "Urgent Results", 58, "9000000011", "pain", gender="male")
    answer_route(pq, {"pain_location": "chest", "chest_breathing": "mild", "chest_dizziness": "no", "chest_sweating": "no", "chest_pattern": "nothing",
                      "chest_onset": "hours", "chest_score": 8, "chest_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pq)
    rid = state(pq, "state.assessment.id")
    pq.click("[data-action=mark-urgent]")
    pq.wait_for_timeout(200)
    check("D1: result stays on screen after marking", pq.query_selector(".route-sign") is not None and "Emergency & Triage" in pq.inner_text(".route-sign"))
    check("D1: mark saved to history", state(pq, f"AssessmentRepository.get('{rid}').urgentFlag") is True)
    check("D1: no unsaved-progress state", state(pq, "hasUnsavedProgress()") is False)
    # D2: Other / Unsure → Chest or heart asks chest questions and escalates severe pain
    start_new(pq)
    fill_patient(pq, "Other Chest", 50, "9000000012", "other", gender="male")
    asked = answer_route(pq, {"other_area": "chest", "chest_breathing": "none"}, stop_before="chest_dizziness")
    check("D2: Other → Chest or heart continues with chest questions", asked == ["other_area", "chest_breathing"], ",".join(asked))
    pq.click("[data-action=cancel-assessment]"); pq.click(".modal >> text=Discard Assessment")
    # D4: reopening the same record while editing asks first
    pq.click("[data-nav=history] >> nth=0")
    pq.click(f"[data-action=open-assessment][data-id='{rid}']")
    pq.wait_for_selector(".route-sign")
    pq.click("[data-action=edit-assessment]")
    pq.click("[data-action=edit-patient]")
    pq.fill("#field-name", "Urgent Results Edited")
    pq.click("[data-nav=history] >> nth=0")
    pq.click(f"[data-action=open-assessment][data-id='{rid}']")
    check("D4: same-record reopen asks before discarding edits", pq.is_visible(".modal") and "Discard your unsaved changes?" in pq.inner_text(".modal"))
    pq.click(".modal >> text=Discard changes")
    pq.wait_for_selector(".route-sign")
    check("D4: saved copy shown after discarding", "Urgent Results" in pq.inner_text("#screen") and "Edited" not in pq.inner_text(".result-head"))
    # D9: sidebar New Assessment on an unchanged saved assessment's review starts a new one
    pq.click("[data-action=edit-assessment]")
    pq.click("[data-nav=assessment] >> nth=0")
    check("D9: New Assessment from unchanged review opens a blank intake", pq.is_visible("[data-form=intake]") and pq.input_value("#field-name") == "")
    # D5: demo case asks before replacing typed details
    pq.fill("#field-name", "Typed Patient")
    pq.click("summary:has-text('Load demo case')")
    pq.click("[data-demo-id=demo-derm]")
    check("D5: demo load asks before replacing details", pq.is_visible(".modal") and "Replace the details" in pq.inner_text(".modal"))
    pq.click(".modal >> text=Keep current details")
    check("D5: keeping details keeps them", pq.input_value("#field-name") == "Typed Patient")
    # D11: resume after refresh returns to the visible question
    pq.fill("#field-age", "40"); pq.fill("#field-contact", "9000000013")
    pq.click("[data-action=save-patient]")
    choose_list_complaint(pq, "skin")
    answer_route(pq, {"skin_type": "rash", "skin_itching": "yes", "skin_redness": "yes"}, stop_before="skin_spreading")
    before = current_qid(pq)
    pq.reload()
    pq.click("[data-action=resume-assessment]")
    pq.wait_for_selector(".q-card")
    check("D11: resume lands on the same question", current_qid(pq) == before, f"{before} vs {current_qid(pq)}")
    pq.click("[data-action=cancel-assessment]"); pq.click(".modal >> text=Discard Assessment")
    # Manual urgent flag: condition withheld, then predicted again when the mark is removed
    start_new(pq)
    fill_patient(pq, "Flag Then Clear", 30, "9000000015", "skin")
    pq.click("[data-action=flag-urgent]")
    pq.click(".modal >> text=Mark as urgent")
    answer_route(pq, {"skin_type": "rash", "skin_itching": "yes", "skin_redness": "yes", "skin_spreading": "yes", "skin_area": "arms",
                      "skin_duration": "1to4w", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pq)
    check("manual flag: urgent routing without a condition", "Emergency & Triage" in pq.inner_text(".route-sign") and state(pq, "state.assessment.prediction.predictedCondition ?? null") is None)
    pq.click("[data-action=remove-urgent]")
    pq.wait_for_timeout(250)
    check("manual flag removed: condition shown again", "Fungal skin infection" in pq.inner_text("#screen") and "Dermatology" in pq.inner_text(".route-sign"))
    check("manual flag removed: saved with the condition", state(pq, "AssessmentRepository.get(state.assessment.id).prediction.predictedConditionId") == "fungal_infection")
    # D6: toasts never intercept clicks
    check("D6: toasts ignore pointer", pq.evaluate("getComputedStyle(document.querySelector('.toast-region')).pointerEvents") == "none")
    pq.close()

    # D7 + D10 at tablet / phone widths
    for (w, h) in [(1280, 800), (1366, 768), (1024, 768), (768, 1024)]:
        pt = new_page(browser, w, h)
        pt.evaluate("""() => { const a = { ...createEmptyAssessment(), id: 'SDP-2026-0099', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), status: 'completed',
          patient: { name: 'Venkatanarasimharajuvaripeta Subrahmanyam', age: '52', gender: 'male', contact: '98200 14567', complaint: 'pain', description: '' },
          answers: { pain_location: 'chest' }, recommendation: { ...SPECIALIST_MAPPING.cardiovascular }, prediction: { confidence: 88, predictedCategory: 'Cardiovascular', isInconclusive: false } };
          AssessmentRepository.save(a); }""")
        pt.click("[data-nav=history] >> nth=0")
        box = pt.query_selector("[data-action=open-assessment]").bounding_box()
        check(f"D7: View button visible at {w}px", box and box["x"] + box["width"] <= w, str(box))
        check(f"D7: no page overflow at {w}px", pt.evaluate("document.documentElement.scrollWidth") <= w)
        pt.close()
    pm = new_page(browser, 390, 844)
    start_new(pm)
    fill_patient(pm, "Phone Nav", 30, "9000000014", "skin")
    answer_route(pm, {"skin_type": "rash", "skin_itching": "yes", "skin_redness": "yes", "skin_spreading": "yes", "skin_area": "arms",
                      "skin_duration": "1to4w", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pm)
    check("D10: phone bottom navigation on results", pm.is_visible(".bottom-nav"))
    pm.fill  # noqa
    pm.close()

    # ------------------------------------------------------------------
    # Sign-in screen: create an account, log in, log out
    # ------------------------------------------------------------------
    pa = new_page(browser, signed_in=False)
    check("auth: first run opens on sign-up", pa.is_visible(".auth") and not pa.is_visible("#app")
          and auth_title(pa) == "Create your account", pa.inner_text("body")[:200])
    check("auth: page title", pa.title() == "Create your account | MediFind", pa.title())
    check("auth: MediFind logo for dark screens", pa.evaluate("() => document.querySelector('.auth-hero__logo use').getAttribute('href')") == "#mf-logo-light"
          and pa.get_attribute(".auth-hero__logo", "aria-label") == "MediFind")
    check("auth: three steps, first is current", pa.locator(".auth-step").count() == 3
          and pa.inner_text(".auth-step.is-current") .endswith("Create your account")
          and pa.get_attribute(".auth-step.is-current", "aria-current") == "step")
    check("auth: no social sign-in buttons that cannot work offline", "Google" not in pa.inner_text(".auth") and "Github" not in pa.inner_text(".auth").title())
    check("auth: storage note", "stored only in this browser" in pa.inner_text(".auth-note"))
    labels_ok = pa.evaluate("""() => Array.from(document.querySelectorAll('.auth input.auth-input')).every((input) => document.querySelector(`label[for="${input.id}"]`))""")
    check("auth: every field has a label", labels_ok)
    pa.click("[data-action=auth-continue]")
    errors_text = pa.inner_text(".auth-form")
    check("auth: empty step 1 shows what to fix", "Enter your first name." in errors_text and "Enter your work email." in errors_text and "Use at least 8 characters." in errors_text, errors_text)
    check("auth: last name is optional", "last name" not in errors_text.lower().replace("last name (optional)", ""))
    check("auth: focus goes to the first problem", pa.evaluate("document.activeElement.id") == "auth-firstName")
    check("auth: errors linked to their fields", pa.get_attribute("#auth-email", "aria-invalid") == "true"
          and "auth-email-error" in (pa.get_attribute("#auth-email", "aria-describedby") or ""))
    pa.fill("#auth-firstName", "Priya")
    check("auth: an error clears while it is being fixed", pa.inner_text("[data-auth-error=firstName]") == "" and pa.get_attribute("#auth-firstName", "aria-invalid") is None)
    pa.fill("#auth-lastName", "Shah")
    pa.fill("#auth-email", "priya@hospital")
    pa.fill("#auth-password", "short")
    pa.click("[data-action=auth-continue]")
    check("auth: email format checked", "Enter an email address like name@hospital.org." in pa.inner_text("[data-auth-error=email]"))
    check("auth: password length checked", "Use at least 8 characters." in pa.inner_text("[data-auth-error=password]"))
    pa.fill("#auth-email", "Priya.Shah@Hospital.org")
    pa.fill("#auth-password", "clinic-desk-42")
    pa.click("[data-action=auth-toggle-password]")
    check("auth: show password", pa.get_attribute("#auth-password", "type") == "text" and pa.get_attribute("[data-action=auth-toggle-password]", "aria-pressed") == "true")
    pa.click("[data-action=auth-toggle-password]")
    check("auth: hide password", pa.get_attribute("#auth-password", "type") == "password")
    pa.screenshot(path=str(SHOTS / "auth-signup.png"))
    pa.focus("#auth-password")
    pa.keyboard.press("Enter")
    pa.wait_for_selector("#auth-hospital")
    check("auth: heading tells screen readers the step", pa.inner_text("#auth-title").startswith("Step 2 of 3"))
    check("auth: Enter moves to step 2", auth_title(pa) == "Set up your desk"
          and "(done)" in pa.inner_text(".auth-step.is-done") and pa.inner_text(".auth-step.is-current").endswith("Set up your desk"))
    check("auth: desk defaults filled in", pa.input_value("#auth-hospital") == "Multispeciality Hospital" and pa.input_value("#auth-desk") == "Reception desk"
          and pa.is_checked("input[data-auth-field=role][value=receptionist]"))
    pa.fill("#auth-hospital", "")
    pa.click("[data-action=auth-continue]")
    check("auth: hospital required", "Enter the hospital or clinic name." in pa.inner_text("[data-auth-error=hospital]"))
    pa.fill("#auth-hospital", "City Care Hospital")
    pa.fill("#auth-desk", "OPD counter 2")
    pa.click("label.auth-choice:has(input[value=nurse])")
    pa.click("[data-action=auth-back]")
    check("auth: Back keeps what was typed", pa.input_value("#auth-email") == "Priya.Shah@Hospital.org" and pa.input_value("#auth-password") == "clinic-desk-42")
    pa.click("[data-action=auth-continue]")
    pa.wait_for_selector("#auth-hospital")
    check("auth: step 2 values kept", pa.input_value("#auth-desk") == "OPD counter 2" and pa.is_checked("input[data-auth-field=role][value=nurse]"))
    pa.click("[data-action=auth-continue]")
    pa.wait_for_selector("#auth-confirmed", state="attached")
    summary = pa.inner_text(".auth-summary")
    check("auth: step 3 summarises the account", "Priya Shah" in summary and "Nurse, OPD counter 2, City Care Hospital" in summary and "priya.shah@hospital.org" in summary, summary)
    safe = pa.inner_text(".auth-safe")
    check("auth: safe use says it does not diagnose or prescribe", "does not diagnose" in safe and "never prescribes" in safe and "clinician" in safe, safe)
    pa.click("[data-action=auth-continue]")
    check("auth: safe use must be confirmed", "Tick the box to confirm how MediFind is used." in pa.inner_text("[data-auth-error=confirmed]"))
    pa.screenshot(path=str(SHOTS / "auth-confirm.png"))
    pa.click("label.auth-check:has(#auth-confirmed)")
    pa.click("[data-action=auth-continue]")
    pa.wait_for_selector("#hero-title", timeout=15000)
    check("auth: account created and signed in", pa.is_visible("#app") and not pa.is_visible(".auth")
          and "Account created. You’re signed in as Priya Shah." in pa.inner_text("#toast-region"))
    check("auth: greeting uses the first name", pa.inner_text(".hero__greeting").endswith(", Priya"), pa.inner_text(".hero__greeting"))
    check("auth: sidebar shows who is signed in", pa.inner_text("[data-account-name]") == "Priya Shah" and pa.inner_text("[data-account-meta]") == "Nurse, OPD counter 2"
          and pa.inner_text("[data-account-avatar]") == "PS")
    check("auth: top bar names the desk", pa.inner_text("#topbar-crumb") == "OPD counter 2")
    stored = pa.evaluate("() => localStorage.getItem('medifind.accounts.v1')")
    acct = json.loads(stored)[0]
    check("auth: password kept only as a salted hash", "clinic-desk-42" not in stored and re.fullmatch(r"[0-9a-f]{64}", acct["password"]["hash"]) is not None
          and re.fullmatch(r"[0-9a-f]{32}", acct["password"]["salt"]) is not None and acct["password"]["iterations"] == 600000
          and acct["password"]["algorithm"] == "PBKDF2-SHA-256" and acct["email"] == "priya.shah@hospital.org")
    check("auth: session lasts for this tab only by default", pa.evaluate("() => Boolean(sessionStorage.getItem('medifind.session.v1')) && !localStorage.getItem('medifind.session.v1')"))
    same = pa.evaluate("""async () => {
      const salt = PasswordHash.fromHex('0123456789abcdef0123456789abcdef');
      const viaBrowser = await PasswordHash.hash('pässwörd ✓ नमस्ते', { iterations: 2048, salt });
      const viaScript = PasswordHash.toHex(PasswordHash.pbkdf2Sync(PasswordHash.utf8('pässwörd ✓ नमस्ते'), salt, 2048));
      return Boolean(crypto.subtle) && viaBrowser.hash === viaScript;
    }""")
    check("auth: Web Crypto and the built-in hash give the same result", same)

    # Reports name the hospital and who prepared them
    start_new(pa)
    fill_patient(pa, "Report Owner", 41, "9000000031", "skin")
    answer_route(pa, {"skin_type": "acne", "skin_itching": "no", "skin_redness": "yes", "skin_spreading": "no", "skin_area": "face",
                      "skin_duration": "gt1m", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pa)
    pa.click("[data-action=generate-report]")
    pa.wait_for_selector("#report-document")
    rep = pa.inner_text("#report-document")
    check("auth: report names the hospital from the account", "City Care Hospital, reception decision support" in rep)
    check("auth: report says where and by whom it was prepared", "Prepared at OPD counter 2 by Priya Shah, Nurse" in rep and "started by" not in rep)

    # Signing out mid-assessment keeps the assessment for later
    start_new(pa)
    fill_intake(pa, "Halfway Patient", 30, "9000000032")
    pa.click("[data-action=sign-out] >> visible=true")
    check("auth: sign-out warns about the assessment in progress", pa.is_visible(".modal") and "Halfway Patient" in pa.inner_text(".modal"))
    pa.click(".modal button:has-text('Stay signed in')")
    check("auth: Stay signed in keeps working", pa.is_visible(".screen--bodymap"))
    pa.click("[data-action=sign-out] >> visible=true")
    pa.click(".modal button:has-text('Sign out')")
    pa.wait_for_selector(".auth")
    check("auth: signed out to the log-in screen", auth_title(pa) == "Log in to MediFind" and not pa.is_visible("#app")
          and "Signed out." in pa.inner_text("#toast-region"))
    check("auth: session cleared", pa.evaluate("() => !sessionStorage.getItem('medifind.session.v1') && !localStorage.getItem('medifind.session.v1')"))
    check("auth: accounts on this computer offered", "Priya Shah" in pa.inner_text(".auth-quick") and "Nurse, OPD counter 2" in pa.inner_text(".auth-quick"))
    check("auth: log-in hero shows how an assessment runs", "Mark the symptoms on the body map" in pa.inner_text(".auth-steps"))
    pa.screenshot(path=str(SHOTS / "auth-login.png"))
    pa.click("[data-action=auth-login]")
    check("auth: empty log-in shows what to fill in", "Enter your email." in pa.inner_text(".auth-form") and "Enter your password." in pa.inner_text(".auth-form"))
    pa.click("[data-action=auth-pick-account]")
    check("auth: picking an account fills the email and moves to the password",
          pa.input_value("#auth-loginEmail") == "priya.shah@hospital.org" and pa.evaluate("document.activeElement.id") == "auth-loginPassword"
          and pa.get_attribute("[data-action=auth-pick-account]", "aria-pressed") == "true")
    pa.fill("#auth-loginPassword", "not-the-password")
    pa.keyboard.press("Enter")
    pa.wait_for_selector("[data-auth-alert]", timeout=15000)
    check("auth: wrong password refused without saying which part is wrong",
          "That email and password don’t match an account on this computer." in pa.inner_text("[data-auth-alert]")
          and pa.input_value("#auth-loginPassword") == "" and pa.evaluate("document.activeElement.id") == "auth-loginPassword")
    pa.click("[data-action=auth-forgot]")
    check("auth: forgotten password explained honestly", pa.is_visible(".modal") and "can’t be recovered" in pa.inner_text(".modal"))
    pa.click(".modal button:has-text('Back to log in')")
    pa.fill("#auth-loginEmail", "PRIYA.SHAH@hospital.org ")
    pa.fill("#auth-loginPassword", "clinic-desk-42")
    pa.click("label.auth-check:has(#auth-keep)")
    pa.click("[data-action=auth-login]")
    pa.wait_for_selector("#hero-title", timeout=15000)
    check("auth: log in (email in any case) and see the dashboard", "Signed in as Priya Shah." in pa.inner_text("#toast-region"))
    check("auth: work in progress offered after logging back in", "Halfway Patient" in pa.inner_text("#screen") and pa.is_visible("[data-action=resume-assessment]"))
    check("auth: Keep me signed in stores the session", pa.evaluate("() => Boolean(localStorage.getItem('medifind.session.v1'))"))
    second = pa.context.new_page()
    second.goto(URL)
    second.wait_for_timeout(300)
    check("auth: kept session opens a new tab signed in", second.is_visible("#hero-title") and not second.is_visible(".auth"))
    second.close()
    pa.reload()
    check("auth: reload stays signed in", pa.is_visible("#hero-title"))
    sign_out(pa)
    pa.click("[data-action=auth-mode][data-mode=signup]")
    check("auth: switch to sign-up", auth_title(pa) == "Create your account")
    pa.fill("#auth-firstName", "Priya")
    pa.fill("#auth-email", "priya.shah@hospital.org")
    pa.fill("#auth-password", "another-pass-1")
    pa.click("[data-action=auth-continue]")
    check("auth: one account per email on this computer", "already exists on this computer" in pa.inner_text("[data-auth-error=email]"))
    pa.click("[data-action=auth-mode][data-mode=login]")
    check("auth: typed email carried to log in", pa.input_value("#auth-loginEmail") == "priya.shah@hospital.org")
    visible_text_ok(pa, "log-in screen")
    pa.close()

    # Signing out in one tab signs the account out in the others
    px = new_page(browser, signed_in=False)
    sign_up(px, "Tara", "Iyer", "tara@hospital.test", "tara-desk-pass")
    sign_out(px)
    px.click("[data-action=auth-pick-account]")
    px.fill("#auth-loginPassword", "tara-desk-pass")
    px.click("label.auth-check:has(#auth-keep)")
    px.click("[data-action=auth-login]")
    px.wait_for_selector("#hero-title", timeout=15000)
    tab2 = px.context.new_page()
    tab2.goto(URL)
    tab2.wait_for_selector("#hero-title", timeout=15000)
    tab2_session = tab2.evaluate("() => sessionStorage.getItem('medifind.session.v1') || localStorage.getItem('medifind.session.v1')")
    sign_out(px)
    tab2.wait_for_selector(".auth", timeout=5000)
    check("auth: other open tabs are signed out too", tab2.is_visible(".auth") and "You were signed out in another tab." in tab2.inner_text("#toast-region"))
    tab3 = px.context.new_page()
    tab3.add_init_script(f"sessionStorage.setItem('medifind.session.v1', {json.dumps(tab2_session)});")
    tab3.goto(URL)
    tab3.wait_for_timeout(300)
    check("auth: an old session copy is refused after signing out", tab3.is_visible(".auth") and not tab3.is_visible("#app"))
    tab3.close()
    tab2.close()

    # Forgotten password: set the account up again with a new password
    px.click("[data-action=auth-pick-account]")
    px.click("[data-action=auth-forgot]")
    check("auth: forgotten password offers to set the account up again", "set up tara@hospital.test again" in px.inner_text(".modal"))
    px.click(".modal button:has-text('Set up again')")
    check("auth: setting up again keeps the email and asks for a new password",
          auth_title(px) == "Set up your account again" and px.input_value("#auth-email") == "tara@hospital.test"
          and px.get_attribute("#auth-email", "readonly") is not None and px.evaluate("document.activeElement.id") == "auth-password")
    px.fill("#auth-password", "tara-new-pass-2")
    px.click("[data-action=auth-continue]")
    px.click("[data-action=auth-continue]")
    px.click("label.auth-check:has(#auth-confirmed)")
    check("auth: last step saves and logs in", px.inner_text("[data-action=auth-continue]") == "Save and log in")
    px.click("[data-action=auth-continue]")
    px.wait_for_selector("#hero-title", timeout=15000)
    check("auth: account set up again and signed in", "Account set up again." in px.inner_text("#toast-region")
          and px.evaluate("() => JSON.parse(localStorage.getItem('medifind.accounts.v1')).filter((a) => a.email === 'tara@hospital.test').length") == 1)
    sign_out(px)
    px.click("[data-action=auth-pick-account]")
    px.fill("#auth-loginPassword", "tara-desk-pass")
    px.click("[data-action=auth-login]")
    px.wait_for_selector("[data-auth-alert]", timeout=15000)
    check("auth: the old password stops working", px.is_visible("[data-auth-alert]"))

    # An assessment started by one person and finished by another says so
    px.fill("#auth-loginPassword", "tara-new-pass-2")
    px.click("[data-action=auth-login]")
    px.wait_for_selector("#hero-title", timeout=15000)
    start_new(px)
    fill_patient(px, "Meera Joshi", 36, "9000000041", "skin")
    sign_out(px)
    px.click("[data-action=auth-mode][data-mode=signup]")
    sign_up(px, "Ravi", "Kumar", "ravi@hospital.test", "ravi-desk-pass", desk="Front desk")
    check("auth: next person sees who started the assessment in progress", "Meera Joshi" in px.inner_text(".resume-banner") and "Started by Tara Iyer." in px.inner_text(".resume-banner"))
    px.click("[data-action=resume-assessment]")
    px.wait_for_selector(".q-card")
    answer_route(px, {"skin_type": "acne", "skin_itching": "no", "skin_redness": "yes", "skin_spreading": "no", "skin_area": "face",
                      "skin_duration": "gt1m", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(px)
    px.click("[data-action=generate-report]")
    px.wait_for_selector("#report-document")
    check("auth: report credits both people", "Prepared at Front desk by Ravi Kumar, Receptionist (started by Tara Iyer)" in px.inner_text("#report-document"))
    px.close()

    # A session without "Keep me signed in" ends with the tab
    pt = new_page(browser, signed_in=False)
    sign_up(pt, "Tab", "Only", "tab.only@hospital.test", "tab-only-pass")
    other = pt.context.new_page()
    other.goto(URL)
    other.wait_for_timeout(300)
    check("auth: new tab asks to log in when the session was not kept", other.is_visible(".auth") and auth_title(other) == "Log in to MediFind")
    other.close()
    pt.close()

    for (w, h, label) in [(390, 844, "mobile"), (1024, 768, "tablet")]:
        pr = new_page(browser, w, h, signed_in=False)
        check(f"auth {label}: no horizontal scroll on sign-up", not overflow_x(pr))
        pr.screenshot(path=str(SHOTS / f"auth-{label}-signup.png"), full_page=True)
        sign_up(pr, "Ravi", "Kumar", f"ravi.{label}@hospital.test", "ravi-desk-123", desk="Front desk")
        sign_out(pr)
        check(f"auth {label}: sign-out reachable and log-in fits", not overflow_x(pr) and auth_title(pr) == "Log in to MediFind")
        pr.screenshot(path=str(SHOTS / f"auth-{label}-login.png"), full_page=True)
        pr.close()

    # ------------------------------------------------------------------
    # Dark mode: the top-bar button, the saved choice, the computer's
    # setting, and a report that stays black on white
    # ------------------------------------------------------------------
    TOGGLE = "[data-action=toggle-theme]"
    BEFORE_BODY = """new MutationObserver((list, observer) => {
      if (document.body) { window.__themeAtBody = document.documentElement.getAttribute('data-theme'); observer.disconnect(); }
    }).observe(document, { childList: true, subtree: true });"""
    PRINT_LOOK = """() => [...document.querySelectorAll('body *')].filter((el) => el.getClientRects().length)
      .map((el) => { const cs = getComputedStyle(el); return `${el.tagName}.${el.className}|${cs.color}|${cs.backgroundColor}|${cs.borderTopColor}`; }).join(';')"""

    def theme(pg):
        return pg.evaluate("document.documentElement.dataset.theme")

    def theme_state(pg):
        return pg.evaluate("""JSON.stringify({ theme: document.documentElement.dataset.theme, atBody: window.__themeAtBody, saved: localStorage.getItem('medifind.theme.v1'),
          pressed: document.querySelector('[data-action=toggle-theme]').getAttribute('aria-pressed'), body: getComputedStyle(document.body).backgroundColor,
          dark: matchMedia('(prefers-color-scheme: dark)').matches, url: location.href.slice(-20) })""")

    def colour_of(pg, selector, prop):
        return pg.evaluate(f"getComputedStyle(document.querySelector({json.dumps(selector)})).{prop}")

    def themed_page(scheme, signed_in=True, width=1440, height=900):
        context = browser.new_context(viewport={"width": width, "height": height}, color_scheme=scheme)
        if signed_in:
            context.add_init_script(SEED_SCRIPT)
        context.add_init_script(BEFORE_BODY)
        page = context.new_page()
        page.on("console", lambda m: console_errors.append(f"{m.type}: {m.text}") if m.type == "error" else None)
        page.on("pageerror", lambda e: console_errors.append(f"pageerror: {e}"))
        page.goto(URL)
        # A brand-new test browser context can drop what the very first page
        # it opens writes to storage when that page reloads (about 1 run in
        # 12 under load, for any write, not only the theme). Reloading once
        # first, as new_page() does, keeps these checks about the app.
        page.reload()
        page.wait_for_selector("#hero-title" if signed_in else ".auth")
        return page

    pd = themed_page("light")
    check("theme: light when nothing is saved and the computer is in light mode", theme(pd) == "light")
    check("theme: dark mode button in the top bar", pd.is_visible(f".topbar {TOGGLE}") and pd.get_attribute(TOGGLE, "aria-pressed") == "false"
          and pd.get_attribute(TOGGLE, "aria-label") == "Dark mode" and pd.get_attribute(TOGGLE, "title") == "Switch to dark mode")
    light_body = colour_of(pd, "body", "backgroundColor")
    pd.click(TOGGLE)
    check("theme: the button switches to dark", theme(pd) == "dark" and pd.get_attribute(TOGGLE, "aria-pressed") == "true"
          and pd.get_attribute(TOGGLE, "title") == "Switch to light mode"
          and luminance(colour_of(pd, "body", "backgroundColor")) < 0.02 and luminance(colour_of(pd, ".today__title", "color")) > 0.6,
          f"{light_body} -> {colour_of(pd, 'body', 'backgroundColor')}")
    check("theme: the choice is saved", pd.evaluate("localStorage.getItem('medifind.theme.v1')") == '"dark"')
    check("theme: light logo in the dark sidebar", pd.evaluate("""getComputedStyle(document.querySelector('.brand__logo .logo-on-dark')).display !== 'none'
          && getComputedStyle(document.querySelector('.brand__logo .logo-on-light')).display === 'none'"""))
    pd.reload()
    pd.wait_for_selector("#hero-title")
    check("theme: dark is kept after a reload", theme(pd) == "dark" and pd.get_attribute(TOGGLE, "aria-pressed") == "true", theme_state(pd))
    check("theme: applied before the page is drawn", pd.evaluate("window.__themeAtBody") == "dark", theme_state(pd))
    pd.emulate_media(color_scheme="dark")
    pd.emulate_media(color_scheme="light")
    pd.wait_for_timeout(100)
    check("theme: a saved choice is not overridden by the computer's setting", theme(pd) == "dark", theme_state(pd))
    start_new(pd)
    fill_patient(pd, "Dark Mode", 41, "9000000021", "skin")
    answer_route(pd, {"skin_type": "rash", "skin_itching": "yes", "skin_redness": "yes", "skin_spreading": "yes", "skin_area": "arms",
                      "skin_duration": "1to4w", "skin_associated": ["none"], "safety_check": ["none"]})
    run_and_wait_results(pd)
    visible_text_ok(pd, "dark results")
    pd.click("[data-action=generate-report]")
    pd.wait_for_selector("#report-document")
    check("theme: the report stays a white page in dark mode", colour_of(pd, "#report-document", "backgroundColor") == "rgb(255, 255, 255)"
          and luminance(colour_of(pd, "#report-document .rpt-title", "color")) < 0.05 and luminance(colour_of(pd, "body", "backgroundColor")) < 0.02, theme_state(pd))
    pd.screenshot(path=str(SHOTS / "dark-report.png"))
    pd.emulate_media(media="print")
    dark_print = pd.evaluate(PRINT_LOOK)
    pd.evaluate("document.documentElement.dataset.theme = 'light'")
    light_print = pd.evaluate(PRINT_LOOK)
    pd.evaluate("document.documentElement.dataset.theme = 'dark'")
    pd.emulate_media(media="screen")
    check("theme: the report prints the same in dark mode as in light", dark_print == light_print and dark_print.count(";") > 100,
          next((f"{a} != {b}" for a, b in zip(dark_print.split(";"), light_print.split(";")) if a != b), ""))
    pd.click(TOGGLE)
    check("theme: the button switches back to light", theme(pd) == "light" and pd.evaluate("localStorage.getItem('medifind.theme.v1')") == '"light"'
          and colour_of(pd, "body", "backgroundColor") == light_body)
    pd.close()

    ps = themed_page("dark")
    check("theme: follows the computer's dark setting when nothing is saved", theme(ps) == "dark" and ps.evaluate("window.__themeAtBody") == "dark"
          and ps.get_attribute(TOGGLE, "aria-pressed") == "true")
    ps.emulate_media(color_scheme="light")
    ps.wait_for_timeout(100)
    check("theme: follows the setting when it changes", theme(ps) == "light" and ps.get_attribute(TOGGLE, "aria-pressed") == "false")
    ps.emulate_media(color_scheme="dark")
    ps.wait_for_timeout(100)
    ps.click(TOGGLE)
    ps.reload()
    ps.wait_for_selector("#hero-title")
    check("theme: a saved light choice wins over a dark computer", theme(ps) == "light" and ps.evaluate("window.__themeAtBody") == "light", theme_state(ps))
    ps.close()

    auth_look = []
    for scheme in ["light", "dark"]:
        pz = themed_page(scheme, signed_in=False)
        pz.evaluate(f"localStorage.setItem('medifind.theme.v1', {json.dumps(json.dumps(scheme))})")
        pz.reload()
        pz.wait_for_selector(".auth")
        auth_look.append(pz.evaluate("(() => { const cs = getComputedStyle(document.querySelector('.auth')); return [cs.backgroundColor, cs.backgroundImage, cs.color].join('|'); })()"))
        check(f"theme {scheme}: no theme button on the sign-in screen", not pz.is_visible(TOGGLE))
        pz.close()
    check("theme: the sign-in screen looks the same in both themes", auth_look[0] == auth_look[1], " vs ".join(auth_look))

    pp = themed_page("dark", width=390, height=844)
    check("theme mobile: button in the phone top bar", pp.is_visible(f".topbar {TOGGLE}") and pp.is_visible(".topbar [data-action=sign-out]"))
    check("theme mobile: page title fits next to the buttons", pp.evaluate("(() => { const t = document.getElementById('topbar-title'); return t.scrollWidth <= t.clientWidth; })()"))
    check("theme mobile: no horizontal scroll", not overflow_x(pp))
    pp.click(TOGGLE)
    check("theme mobile: the button works on a phone", theme(pp) == "light")
    pp.close()

    # ------------------------------------------------------------------
    # Responsive layouts — no horizontal scroll, key screens screenshotted
    # ------------------------------------------------------------------
    for (w, h, label) in [(1366, 768, "1366"), (1920, 1080, "1920"), (1024, 768, "tablet-land"), (768, 1024, "tablet"), (390, 844, "mobile")]:
        pg = new_page(browser, w, h)
        overflow = []

        def no_overflow(where):
            sw = pg.evaluate("document.documentElement.scrollWidth")
            if sw > w + 1:
                overflow.append(f"{where}:{sw}")

        no_overflow("dashboard")
        pg.screenshot(path=str(SHOTS / f"{label}-dashboard.png"))
        if w > 760:
            wide = w > 1100
            check(f"responsive {label}: {'full logo' if wide else 'logo mark'} in the sidebar",
                  pg.is_visible(".brand__logo") == wide and pg.is_visible(".brand__mark") == (not wide) and not pg.is_visible(".topbar__mark"))
        else:
            check(f"responsive {label}: logo mark in the top bar", pg.is_visible(".topbar__mark") and not pg.is_visible(".sidebar"))
        start_new(pg)
        no_overflow("intake")
        pg.screenshot(path=str(SHOTS / f"{label}-intake.png"), full_page=(label == "mobile"))
        fill_intake(pg, "Responsive Check", 44, "9000000004")
        pg.click("[data-bm-region=knee_r]")
        pg.click("label:has([data-bm-symptom=limb_pain])")
        pg.click("label:has([data-bm-pain='limb_pain@knee_r'][value='4'])")
        no_overflow("bodymap")
        pg.screenshot(path=str(SHOTS / f"{label}-bodymap.png"), full_page=True)
        pg.click("[data-action=bm-remove][data-key='limb_pain@knee_r']")
        choose_list_complaint(pg, "pain")
        no_overflow("question")
        pg.screenshot(path=str(SHOTS / f"{label}-question.png"))
        answer_route(pg, {"pain_location": "chest", "chest_breathing": "moderate", "chest_dizziness": "yes", "chest_sweating": "yes",
                          "chest_pattern": "exertion", "chest_onset": "today"}, stop_before="chest_score")
        no_overflow("scale")
        pg.screenshot(path=str(SHOTS / f"{label}-scale.png"))
        answer_route(pg, {"chest_score": 6, "chest_associated": ["radiating"], "safety_check": ["none"]})
        no_overflow("review")
        run_and_wait_results(pg)
        no_overflow("results")
        pg.screenshot(path=str(SHOTS / f"{label}-results.png"), full_page=(label == "mobile"))
        pg.click("[data-action=generate-report]")
        pg.wait_for_selector("#report-document")
        no_overflow("report")
        pg.click("[data-nav=history] >> nth=0") if pg.is_visible("[data-nav=history] >> nth=0") else pg.click(".bottom-nav [data-nav=history]") if pg.is_visible(".bottom-nav [data-nav=history]") else pg.click("[data-action=nav][data-nav-target=history]")
        pg.wait_for_selector(".table, .empty")
        no_overflow("history")
        pg.screenshot(path=str(SHOTS / f"{label}-history.png"))
        check(f"responsive {label}: no horizontal scroll", not overflow, ",".join(overflow))
        pg.close()

    browser.close()

passed = sum(1 for _, ok, _ in results if ok)
failed = [(n, d) for n, ok, d in results if not ok]
print(f"PASS {passed}  FAIL {len(failed)}  console errors {len(console_errors)}")
for name, detail in failed:
    print(f"  FAIL {name} :: {detail[:300]}")
for err in console_errors[:20]:
    print(f"  CONSOLE {err[:300]}")
