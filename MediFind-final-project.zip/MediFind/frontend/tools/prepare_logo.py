#!/usr/bin/env python3
"""Prepares the MediFind logo supplied by the client for the app.

Input : assets/source/medifind-logo.png (logo on a white canvas)
Output: assets/generated/medifind-logo.png  full logo (mark + wordmark), transparent
        assets/generated/medifind-logo-light.png  for dark screens: white wordmark, solid cross
        assets/generated/medifind-mark.png  the cross mark only (solid), transparent, square
        assets/generated/medifind-glow.png  tiny solid cross, blurred into the sign-in screen's light
        assets/generated/favicon.png        64 x 64 mark for the browser tab

White is turned into transparency with the colour-to-alpha method, so the
logo looks exactly the same on white and keeps its translucent light-blue
arm on tinted backgrounds. Run: python3 tools/prepare_logo.py
"""
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets" / "source" / "medifind-logo.png"
OUT = ROOT / "assets" / "generated"


def white_to_alpha(rgb: np.ndarray) -> np.ndarray:
    """GIMP-style colour-to-alpha against pure white. Returns RGBA uint8."""
    p = rgb.astype(np.float64) / 255.0
    alpha = (1.0 - p).max(axis=2)
    alpha[alpha < 0.035] = 0.0                     # compression noise in the white canvas
    safe = np.where(alpha > 0, alpha, 1.0)[..., None]
    colour = 1.0 - (1.0 - p) / safe
    colour = np.clip(colour, 0.0, 1.0)
    rgba = np.dstack([colour, alpha]) * 255.0
    rgba[alpha == 0] = 0
    return np.round(rgba).astype(np.uint8)


def white_to_solid(rgb: np.ndarray, shape_at: int = 25, edge: int = 2) -> np.ndarray:
    """The cross as it looks on white, on a transparent background. Unlike
    colour-to-alpha this keeps the light-blue arm opaque, so the mark still
    reads on dark backgrounds. The outermost pixels of the shape are a blend
    of its colour and the white canvas: they take the colour of the nearest
    pixel further in, and an alpha equal to how much of that colour they
    hold, so no white fringe is left around the shape."""
    darkness = (255 - rgb.astype(np.int32)).max(axis=2)
    shape = darkness > shape_at
    labels, count = ndi.label(shape)                # drop compression specks around the shape
    if count > 1:
        sizes = ndi.sum(shape, labels, range(1, count + 1))
        shape = np.isin(labels, 1 + np.flatnonzero(sizes >= 40))
    core = ndi.binary_erosion(shape, iterations=edge)
    distance, (iy, ix) = ndi.distance_transform_edt(~core, return_indices=True)
    solid = rgb[iy, ix].astype(np.int32)
    solid_darkness = np.maximum((255 - solid).max(axis=2), 1)
    alpha = np.clip(darkness / solid_darkness, 0, 1)
    alpha[core] = 1
    alpha[(darkness < 9) | (distance > edge + 2.5)] = 0   # canvas noise, and anything away from the edge
    out = np.dstack([np.where(core[..., None], rgb, solid), np.round(alpha * 255)]).astype(np.uint8)
    out[alpha == 0] = 0
    return out


def bbox(alpha: np.ndarray, threshold: int = 10):
    ys, xs = np.where(alpha > threshold)
    return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rgb = np.asarray(Image.open(SOURCE).convert("RGB"))
    rgba = white_to_alpha(rgb)
    alpha = rgba[..., 3]

    x0, y0, x1, y1 = bbox(alpha)
    # The mark and the wordmark are separated by the widest empty column gap.
    cols = (alpha[y0:y1, x0:x1] > 10).any(axis=0)
    gaps, run_start = [], None
    for i, filled in enumerate(cols):
        if not filled and run_start is None:
            run_start = i
        if filled and run_start is not None:
            gaps.append((i - run_start, run_start, i))
            run_start = None
    _, gap_start, gap_end = max(gaps)
    mark_x1 = x0 + gap_start

    pad = 4
    crop = rgba[y0 - pad:y1 + pad, x0 - pad:x1 + pad]
    full = Image.fromarray(crop, "RGBA")
    full.save(OUT / "medifind-logo.png", optimize=True)

    # Light version for dark backgrounds (the sign-in screen): a solid
    # cross, and the black wordmark turned white (alpha kept, so the letter
    # edges stay smooth).
    light = crop.copy()
    word_x = x0 + gap_end - (x0 - pad)
    light[:, word_x:, :3] = 255
    solid = white_to_solid(rgb[y0 - pad:y1 + pad, x0 - pad:x1 + pad])
    light[:, :word_x] = solid[:, :word_x]
    Image.fromarray(light, "RGBA").save(OUT / "medifind-logo-light.png", optimize=True)
    glow = Image.fromarray(solid[:, :word_x], "RGBA")
    glow.crop(glow.getbbox()).resize((48, 48), Image.LANCZOS).save(OUT / "medifind-glow.png", optimize=True)

    # The mark on its own (narrow sidebar, phone top bar, browser tab) uses
    # the solid cross, so it reads on light and dark backgrounds alike.
    mx0, my0, mx1, my1 = bbox(alpha[:, :mark_x1])
    side = max(mx1 - mx0, my1 - my0) + 2 * pad
    mark = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    solid_mark = white_to_solid(rgb[my0 - pad:my1 + pad, mx0 - pad:mx1 + pad])[pad:-pad, pad:-pad]
    crop = Image.fromarray(np.ascontiguousarray(solid_mark), "RGBA")
    mark.paste(crop, ((side - crop.width) // 2, (side - crop.height) // 2))
    mark.save(OUT / "medifind-mark.png", optimize=True)
    mark.resize((64, 64), Image.LANCZOS).save(OUT / "favicon.png", optimize=True)

    print(f"logo {full.size}, mark {mark.size}, wordmark starts at x={x0 + gap_end}")


if __name__ == "__main__":
    main()
