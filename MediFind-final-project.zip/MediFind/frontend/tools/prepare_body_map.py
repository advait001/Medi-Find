#!/usr/bin/env python3
"""Turns the client's body map picture into the clickable body figure.

Input : assets/source/body-map.png  (front view on the left, back view on the right)
Output: assets/generated/body-front.png, body-back.png   each view, transparent background
        src/js/05a-body-figure.js                          region outlines for the app
        (and, with --debug DIR, coloured check images of the regions)

How the regions are made
  * The silhouette of each view is taken from the picture (pixels darker
    than the white canvas), so highlights follow the drawing exactly.
  * Each body part is a simple polygon drawn over the anatomy (cut lines at
    the chin, collarbones, elbows, wrists, groin, knees and ankles). The
    polygon is intersected with the silhouette and the result is traced into
    the outline the app draws, so the polygons only need to agree with each
    other along the cut lines, not with the body outline.
  * Polygons are written for the viewer's left half of the figure and
    mirrored for the right half. In the front view the viewer's left is the
    patient's right side; in the back view it is the patient's left side.
  * The check below makes sure every pixel of the body belongs to exactly
    one body part.

Run: python3 tools/prepare_body_map.py [--debug DIR]
"""
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets" / "source" / "body-map.png"
OUT_DIR = ROOT / "assets" / "generated"
OUT_JS = ROOT / "src" / "js" / "05a-body-figure.js"

WIDTH, HEIGHT = 528, 1080          # each view is cropped to this size
VIEW_X = {"front": 0, "back": 552}  # left edge of each view in the source picture
MID = 263                           # vertical centre line of both figures
MIRROR = 2 * MID                    # x' = MIRROR - x


# ---------------------------------------------------------------------------
# Body part polygons, in view coordinates (0..528 x 0..1080), for the
# viewer's LEFT half. "A" shapes are mirrored to make the viewer's right half.
# ---------------------------------------------------------------------------

def head(chin):
    return [(120, 0), (406, 0), (406, chin), (120, chin)]


def neck(chin):
    return [(120, chin), (406, chin), (406, 178), (337, 184), (331, 201), (MID, 205),
            (195, 201), (189, 184), (120, 178)]


# Shoulder / chest cut, running from the collarbone down the front of the armpit.
ARMPIT_CUT = [(195, 201), (186, 214), (176, 236), (170, 262), (167, 292)]

LIMBS_A = {
    "shoulder": [(40, 130), (120, 178), (189, 184), *ARMPIT_CUT, (40, 268)],
    "upper_arm": [(40, 268), (167, 292), (168, 318), (168, 345), (90, 330), (20, 318)],
    "forearm": [(20, 318), (90, 330), (168, 345), (150, 440), (100, 500), (40, 488), (0, 470)],
    "hand": [(0, 470), (40, 488), (100, 500), (125, 560), (115, 660), (0, 660)],
    "knee": [(140, 700), (MID, 700), (MID, 795), (140, 795)],
    "lower_leg": [(140, 795), (MID, 795), (MID, 935), (140, 935)],
    "foot": [(120, 935), (MID, 935), (MID, 1080), (120, 1080)],
}
# Front: the groin crease (inguinal line) separates the belly and pelvis from the thigh.
THIGH_FRONT_A = [(150, 452), (168, 470), (256, 562), (MID, 580), (MID, 700), (140, 700), (140, 452)]
# Back: the buttock crease separates the buttock from the thigh.
THIGH_BACK_A = [(140, 552), (256, 584), (MID, 592), (MID, 700), (140, 700)]

# Front torso
CHEST = [*ARMPIT_CUT, (167, 303), (MIRROR - 167, 303),
         *[(MIRROR - x, y) for x, y in reversed(ARMPIT_CUT)], (MID, 205)]
BELLY_TOP, BELLY_SPLIT, BELLY_BOTTOM = 303, 396, 488
COL_A, COL_B = 233, MIRROR - 233
SIDE = 168   # below the armpit the torso's outer edge is right of this line, the arm left of it
BELLY = {
    "abd_upper_A": [(SIDE, BELLY_TOP), (COL_A, BELLY_TOP), (COL_A, BELLY_SPLIT), (SIDE, BELLY_SPLIT)],
    "abd_upper_mid": [(COL_A, BELLY_TOP), (COL_B, BELLY_TOP), (COL_B, BELLY_SPLIT), (COL_A, BELLY_SPLIT)],
    "abd_lower_A": [(SIDE, BELLY_SPLIT), (COL_A, BELLY_SPLIT), (COL_A, BELLY_BOTTOM), (185, BELLY_BOTTOM), (SIDE, 470)],
    "abd_lower_mid": [(COL_A, BELLY_SPLIT), (COL_B, BELLY_SPLIT), (COL_B, BELLY_BOTTOM), (COL_A, BELLY_BOTTOM)],
}
PELVIS = [(185, BELLY_BOTTOM), (MIRROR - 185, BELLY_BOTTOM), (MIRROR - 256, 562), (MID, 580), (256, 562)]

# Back torso
UPPER_BACK = [*ARMPIT_CUT, (SIDE, 318), (SIDE, 400), (MIRROR - SIDE, 400), (MIRROR - SIDE, 318),
              *[(MIRROR - x, y) for x, y in reversed(ARMPIT_CUT)], (MID, 205)]
LOWER_BACK = [(SIDE, 400), (MIRROR - SIDE, 400), (MIRROR - 150, 462), (150, 462)]
BUTTOCKS = [(150, 462), (MIRROR - 150, 462), (MIRROR - 140, 552), (MIRROR - 256, 584), (MID, 592),
            (256, 584), (140, 552)]


def mirror(points):
    return [(MIRROR - x, y) for x, y in reversed(points)]


def view_regions(view):
    """[(area id, polygon)] for one view."""
    near, far = ("r", "l") if view == "front" else ("l", "r")   # viewer's left / right
    chin = 139 if view == "front" else 123
    regions = [("head", head(chin)), ("neck", neck(chin))]
    limbs = dict(LIMBS_A, thigh=THIGH_FRONT_A if view == "front" else THIGH_BACK_A)
    for limb in ["shoulder", "upper_arm", "forearm", "hand", "thigh", "knee", "lower_leg", "foot"]:
        regions.append((f"{limb}_{near}", limbs[limb]))
        regions.append((f"{limb}_{far}", mirror(limbs[limb])))
    if view == "front":
        regions += [
            ("chest", CHEST),
            ("abd_ur", BELLY["abd_upper_A"]), ("abd_um", BELLY["abd_upper_mid"]), ("abd_ul", mirror(BELLY["abd_upper_A"])),
            ("abd_lr", BELLY["abd_lower_A"]), ("abd_lm", BELLY["abd_lower_mid"]), ("abd_ll", mirror(BELLY["abd_lower_A"])),
            ("pelvis", PELVIS),
        ]
    else:
        regions += [("upper_back", UPPER_BACK), ("lower_back", LOWER_BACK), ("buttocks", BUTTOCKS)]
    return regions


# ---------------------------------------------------------------------------

def silhouette(gray):
    mask = gray < 235
    mask = ndi.binary_fill_holes(mask)
    labels, count = ndi.label(mask)
    if count > 1:  # keep the figure, drop compression specks
        sizes = ndi.sum(mask, labels, range(1, count + 1))
        mask = labels == (int(np.argmax(sizes)) + 1)
    return mask


def polygon_mask(points, scale=1):
    img = Image.new("L", (WIDTH * scale, HEIGHT * scale), 0)
    ImageDraw.Draw(img).polygon([(x * scale, y * scale) for x, y in points], fill=255)
    return np.asarray(img) > 0


def trace_path(mask, epsilon=0.6):
    """SVG path data for a binary mask, following pixel edges (traced at 4x)."""
    scale = 4
    big = cv2.resize(mask.astype(np.uint8), (mask.shape[1] * scale, mask.shape[0] * scale),
                     interpolation=cv2.INTER_NEAREST)
    contours, _ = cv2.findContours(big, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    parts = []
    for contour in contours:
        if cv2.contourArea(contour) < 4 * scale * scale:
            continue
        approx = cv2.approxPolyDP(contour, epsilon * scale, True)[:, 0, :].astype(float)
        pts = (approx + 0.5) / scale
        parts.append("M" + "L".join(f"{fmt(x)},{fmt(y)}" for x, y in pts) + "Z")
    return "".join(parts)


def fmt(value):
    text = f"{value:.1f}"
    return text[:-2] if text.endswith(".0") else text


CENTRAL = {"head", "neck", "chest", "abd_um", "abd_lm", "pelvis", "upper_back", "lower_back", "buttocks"}


def badge_point(region_mask, central=False):
    """The point deepest inside the region, so a count badge sits on it.
    Parts that span the middle of the body keep their badge on the midline."""
    dist = ndi.distance_transform_edt(np.pad(region_mask, 1))[1:-1, 1:-1]
    if central:
        column = dist[:, MID]
        return MID, int(np.argmax(column))
    y, x = np.unravel_index(int(np.argmax(dist)), dist.shape)
    return int(x), int(y)


def save_drawing(gray, body, path, levels=16, low=128, high=216):
    """The drawing with a transparent background, as a 16-grey palette PNG
    (the picture only uses flat greys, so this is visually lossless)."""
    step = (high - low) / (levels - 1)
    index = np.clip(np.round((gray.astype(float) - low) / step), 0, levels - 1).astype(np.uint8) + 1
    index[~body] = 0
    image = Image.fromarray(index, "P")
    palette = [255, 255, 255]
    for i in range(levels):
        palette += [int(round(low + i * step))] * 3
    image.putpalette(palette + [0] * (768 - len(palette)))
    image.save(path, optimize=True, transparency=0)


def main():
    debug_dir = Path(sys.argv[sys.argv.index("--debug") + 1]) if "--debug" in sys.argv else None
    gray_all = np.asarray(Image.open(SOURCE).convert("L"))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    figure = {"width": WIDTH, "height": HEIGHT, "views": {}}

    for view, x0 in VIEW_X.items():
        gray = gray_all[:, x0:x0 + WIDTH]
        body = silhouette(gray)

        save_drawing(gray, body, OUT_DIR / f"body-{view}.png")

        coverage = np.zeros(body.shape, dtype=np.int32)
        entries = []
        for area, points in view_regions(view):
            poly = polygon_mask(points)
            region = poly & body
            if not region.any():
                raise SystemExit(f"{view}: {area} does not touch the body")
            coverage += poly.astype(np.int32)
            bx, by = badge_point(region, central=area in CENTRAL)
            entries.append({"area": area, "points": points, "region": region, "badge": [bx, by]})

        # Every body pixel must belong to exactly one part. Pixels on a shared
        # polygon edge are drawn by both neighbours, so count interior pixels only.
        edge = np.zeros(body.shape, dtype=bool)
        for entry in entries:
            outline = Image.new("L", (WIDTH, HEIGHT), 0)
            ImageDraw.Draw(outline).line(entry["points"] + [entry["points"][0]], fill=255, width=3)
            edge |= np.asarray(outline) > 0
        uncovered = body & (coverage == 0) & ~edge
        doubled = body & (coverage > 1) & ~edge
        if uncovered.any() or doubled.any():
            ys, xs = np.where(uncovered | doubled)
            raise SystemExit(f"{view}: {uncovered.sum()} uncovered and {doubled.sum()} doubled body pixels, "
                             f"e.g. at {list(zip(xs[:8].tolist(), ys[:8].tolist()))}")

        figure["views"][view] = [{"area": e["area"], "d": trace_path(e["region"]), "badge": e["badge"]}
                                 for e in entries]

        if debug_dir:
            debug_dir.mkdir(parents=True, exist_ok=True)
            rng = np.random.default_rng(7)
            rgb = np.dstack([gray] * 3).astype(np.float64)
            for entry in entries:
                colour = rng.integers(60, 255, 3)
                region = entry["region"]
                rgb[region] = rgb[region] * 0.45 + colour * 0.55
            out = Image.fromarray(rgb.astype(np.uint8))
            draw = ImageDraw.Draw(out)
            for entry in entries:
                bx, by = entry["badge"]
                draw.ellipse([bx - 6, by - 6, bx + 6, by + 6], fill=(0, 0, 0))
                draw.text((bx + 8, by - 6), entry["area"], fill=(0, 0, 0))
            out.save(debug_dir / f"regions-{view}.png")

    write_js(figure)
    sizes = {v: sum(len(r["d"]) for r in figure["views"][v]) for v in figure["views"]}
    print(f"wrote {OUT_JS.relative_to(ROOT)} (path chars {sizes}) and body-front/back.png")


def write_js(figure):
    lines = [
        "/* =====================================================================",
        "   5a. BODY FIGURE GEOMETRY  (generated by tools/prepare_body_map.py,",
        "   do not edit by hand)",
        "   ---------------------------------------------------------------------",
        "   The body map picture supplied for MediFind, front and back view, each",
        "   528 x 1080. Each region's `d` is traced from the drawing, so a",
        "   highlight covers exactly that body part of the picture. `badge` is",
        "   where the count of picked symptoms is shown. In the front view the",
        "   patient's right side is on the viewer's left; in the back view it is",
        "   on the viewer's right.",
        "   ===================================================================== */",
        "",
        f"const BODY_FIGURE = {json.dumps(figure, separators=(',', ':'))};",
    ]
    OUT_JS.write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
