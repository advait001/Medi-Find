"""Checks for the MediFind ML package.

Run after generating the data and training:
    python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "ml"))

import medifind_ml as mm  # noqa: E402

FIXTURE = ROOT / "tests" / "fixtures" / "js_preprocessed_sample.csv"


class DatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema = mm.load_schema()
        cls.conditions = mm.load_conditions()
        cls.index = mm.condition_index(cls.conditions)
        cls.df = mm.load_dataset()

    def test_feature_columns_follow_the_schema_order(self):
        order = self.schema["order"]
        self.assertEqual([c for c in self.df.columns if c in set(order)], order)
        self.assertEqual(len(order), 160)

    def test_every_condition_has_the_same_number_of_cases(self):
        counts = self.df[mm.LABEL_COLUMN].value_counts()
        self.assertEqual(set(counts.index), set(self.index))
        self.assertEqual(counts.nunique(), 1)

    def test_case_ids_are_unique(self):
        self.assertTrue(self.df["case_id"].is_unique)

    def test_values_stay_within_the_schema(self):
        for feature in self.schema["features"]:
            values = pd.to_numeric(self.df[feature["key"]], errors="coerce").dropna()
            if feature["type"] == "binary":
                self.assertTrue(values.isin([0, 1]).all(), feature["key"])
            else:
                self.assertTrue(((values >= feature["min"]) & (values <= feature["max"])).all(), feature["key"])

    def test_labels_match_the_condition_table(self):
        expected = self.df[mm.LABEL_COLUMN].map(lambda c: self.index[c]["department"])
        self.assertTrue((expected == self.df["department"]).all())
        expected = self.df[mm.LABEL_COLUMN].map(lambda c: self.index[c]["category"])
        self.assertTrue((expected == self.df["category"]).all())


class PreprocessingParityTests(unittest.TestCase):
    """Python preprocessing must give exactly what MediFind's browser code gives."""

    def test_matches_the_app_on_the_exported_sample(self):
        schema = mm.load_schema()
        fixture = pd.read_csv(FIXTURE)
        df = mm.load_dataset().set_index("case_id").loc[fixture["case_id"]]
        X = mm.preprocess(df, schema)
        self.assertGreaterEqual(len(fixture), 900)
        np.testing.assert_allclose(X, fixture[schema["order"]].to_numpy(dtype=float), atol=1e-9)


@unittest.skipUnless(mm.MODEL_PATH.exists(), "train the model first: python ml/train_models.py")
class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bundle = joblib.load(mm.MODEL_PATH)
        cls.schema = mm.load_schema()
        cls.df = mm.load_dataset().sample(400, random_state=7)
        cls.X = mm.preprocess(cls.df, cls.schema)

    def test_model_matches_the_schema_and_conditions(self):
        self.assertEqual(self.bundle["feature_order"], self.schema["order"])
        self.assertEqual(self.bundle["schema_version"], self.schema["schemaVersion"])
        self.assertEqual(set(self.bundle["classes"]), set(self.bundle["condition_index"]))

    def test_probabilities_add_up(self):
        proba = self.bundle["model"].predict_proba(self.X)
        np.testing.assert_allclose(proba.sum(1), 1, atol=1e-6)
        cat = mm.category_probabilities(proba, self.bundle["classes"], self.bundle["condition_index"], self.bundle["category_order"])
        np.testing.assert_allclose(cat.sum(1), 1, atol=1e-6)

    def test_prediction_names_a_condition_in_the_predicted_department(self):
        proba = self.bundle["model"].predict_proba(self.X[:50])
        for row in proba:
            result = mm.build_prediction(row, self.bundle)
            self.assertEqual(self.bundle["condition_index"][result["diseaseId"]]["category"], result["category"])
            self.assertEqual(len(result["differentials"]), 3)
            self.assertEqual(set(result["probabilities"]), set(self.bundle["category_order"]))

    def test_app_demo_cases_reach_the_expected_department(self):
        vig = pd.read_csv(mm.VIGNETTES_PATH, low_memory=False)
        demos = vig[(vig["source"] == "app demo case") & vig["expected_condition"].notna() & (vig["expected_urgent"] == 0)]
        self.assertGreater(len(demos), 3)
        proba = self.bundle["model"].predict_proba(mm.preprocess(demos, self.schema))
        index = self.bundle["condition_index"]
        for (_, demo), row in zip(demos.iterrows(), proba):
            result = mm.build_prediction(row, self.bundle)
            expected = index[demo["expected_condition"].split("|")[0]]["category"]
            self.assertEqual(result["category"], expected, demo["vignette_id"])


@unittest.skipUnless(mm.MODEL_PATH.exists(), "train the model first: python ml/train_models.py")
class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from api import create_app

        cls.bundle = joblib.load(mm.MODEL_PATH)
        cls.client = create_app(cls.bundle).test_client()
        cls.schema = mm.load_schema()
        cls.fixture = pd.read_csv(FIXTURE).head(5)

    def app_payload(self, i=0, **changes):
        """The body MediFind's buildPredictionPayload() sends."""
        payload = {
            "schemaVersion": self.schema["schemaVersion"],
            "featureOrder": self.schema["order"],
            "features": self.fixture.loc[i, self.schema["order"]].astype(float).tolist(),
            "completeness": 0.9,
            "complaint": "pain",
        }
        payload.update(changes)
        return payload

    def test_health(self):
        body = self.client.get("/api/health").get_json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["schemaVersion"], self.schema["schemaVersion"])

    def test_predict_with_the_app_payload(self):
        response = self.client.post("/api/predict", json=self.app_payload())
        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        for key in ("category", "probabilities", "disease", "diseaseProbability", "differentials"):
            self.assertIn(key, body)
        self.assertAlmostEqual(sum(body["probabilities"].values()), 1, places=3)
        self.assertIn(body["category"], self.bundle["category_order"])

    def test_prediction_lists_the_answers_behind_it(self):
        payload = self.app_payload()
        body = self.client.post("/api/predict", json=payload).get_json()
        evidence = body["evidence"]
        internal = {f["key"] for f in self.schema["features"] if f.get("internal")}
        values = dict(zip(self.schema["order"], payload["features"]))
        supporting = evidence["supporting"]
        self.assertGreater(len(supporting), 0)
        for item in supporting + evidence["against"]:
            self.assertGreater(values[item["feature"]], 0, item)  # only answers the patient gave
            self.assertNotIn(item["feature"], internal)
        contributions = [item["contribution"] for item in supporting]
        self.assertEqual(contributions, sorted(contributions, reverse=True))
        self.assertTrue(all(c > 0 for c in contributions))
        self.assertTrue(all(item["contribution"] < 0 for item in evidence["against"]))

    def test_raw_features_give_the_same_answer(self):
        case_id = self.fixture.loc[0, "case_id"]
        row = mm.load_dataset().set_index("case_id").loc[case_id]
        raw = {k: (None if pd.isna(row[k]) else float(row[k])) for k in self.schema["order"]}
        from_raw = self.client.post("/api/predict", json={"features": raw}).get_json()
        from_vector = self.client.post("/api/predict", json=self.app_payload()).get_json()
        self.assertEqual(from_raw["diseaseId"], from_vector["diseaseId"])
        self.assertEqual(from_raw["probabilities"], from_vector["probabilities"])

    def test_rejects_a_different_schema(self):
        response = self.client.post("/api/predict", json=self.app_payload(schemaVersion="sdp-features-v2"))
        self.assertEqual(response.status_code, 400)

    def test_rejects_a_short_vector(self):
        payload = self.app_payload()
        payload["features"] = payload["features"][:-1]
        payload.pop("featureOrder")
        self.assertEqual(self.client.post("/api/predict", json=payload).status_code, 400)

    def test_rejects_values_outside_0_to_1(self):
        payload = self.app_payload()
        payload["features"][0] = 52
        self.assertEqual(self.client.post("/api/predict", json=payload).status_code, 400)

    def test_rejects_values_that_are_not_numbers(self):
        payload = self.app_payload()
        payload["features"][3] = {"chestPain": 1}
        response = self.client.post("/api/predict", json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("numbers", response.get_json()["error"])

    def test_rejects_a_body_that_is_not_json(self):
        response = self.client.post("/api/predict", data="hello", content_type="text/plain")
        self.assertEqual(response.status_code, 400)


if __name__ == "__main__":
    unittest.main()
