/* =====================================================================
   4. PATIENT INTAKE
   ===================================================================== */

const NAME_PATTERN = /^[\p{L}][\p{L}\p{M}\s.'’-]*$/u;

/* Pure validation of the patient details. Returns { valid, errors }. */
function validatePatientDetails(patient) {
  const errors = {};
  const name = String(patient.name || '').trim();
  if (!name) errors.name = 'Enter the patient’s name.';
  else if (name.length < 2) errors.name = 'Enter the patient’s full name.';
  else if (name.length > 80) errors.name = 'Name must be 80 characters or fewer.';
  else if (!NAME_PATTERN.test(name)) errors.name = 'Use letters only. Spaces, full stops, apostrophes and hyphens are allowed.';

  const ageText = String(patient.age ?? '').trim();
  if (!ageText) errors.age = 'Enter the patient’s age in years.';
  else if (!/^\d{1,3}$/.test(ageText) || Number(ageText) > 120) errors.age = 'Age must be a whole number from 0 to 120.';

  const contactText = String(patient.contact || '').trim();
  const digits = contactText.replace(/[\s()-]/g, '');
  if (!contactText) errors.contact = 'Enter a contact number.';
  else if (!/^\+?\d{10,13}$/.test(digits)) errors.contact = 'Enter a valid contact number: 10 digits, with an optional country code such as +91.';

  if (String(patient.description || '').length > 500) errors.description = 'Keep the description to 500 characters or fewer.';

  return { valid: Object.keys(errors).length === 0, errors };
}

/* Validates the form against the working copy and returns the errors to show. */
function validatePatientForm({ showAll = false } = {}) {
  const { valid, errors } = validatePatientDetails(state.assessment.patient);
  const visible = {};
  Object.entries(errors).forEach(([field, message]) => {
    if (showAll || state.ui.intakeTouched[field]) visible[field] = message;
  });
  return { valid, errors, visible };
}

const INTAKE_FIELDS = [
  { id: 'name', label: 'Patient name' },
  { id: 'age', label: 'Age' },
  { id: 'gender', label: 'Gender' },
  { id: 'contact', label: 'Contact number' },
  { id: 'description', label: 'Reason for the visit' },
];

function renderPatientForm() {
  const p = state.assessment.patient;
  const { visible } = validatePatientForm({ showAll: state.ui.intakeSubmitted });
  const errorEntries = Object.entries(visible);
  const editingSaved = state.assessment.status === 'completed';
  const returningToReview = state.ui.returnTo === 'review';

  const fieldError = (field) => (visible[field]
    ? html`<p class="field__error" id="err-${field}">${icon('circle-alert')}<span>${visible[field]}</span></p>`
    : html`<p class="field__error" id="err-${field}"></p>`);
  const fieldClass = (field) => `field${visible[field] ? ' has-error' : ''}`;

  return html`
    <section class="screen screen--flow">
      ${renderUrgentBanner('intake')}
      <div class="flow-head">
        <div>
          <h1 class="screen-title" tabindex="-1">${editingSaved ? `Edit patient details for ${state.assessment.id}` : 'Patient details'}</h1>
          <p class="screen-lead">Record the patient’s basic information. The symptoms come next, on the body map.</p>
        </div>
        ${editingSaved ? '' : renderDemoMenu()}
      </div>

      <form class="card intake" data-form="intake" novalidate>
        ${state.ui.intakeSubmitted && errorEntries.length ? html`
          <div class="error-summary" role="alert" tabindex="-1" data-error-summary>
            <h2 class="error-summary__title">${icon('circle-alert')}<span>Check ${errorEntries.length === 1 ? 'this field' : `these ${errorEntries.length} fields`} before continuing</span></h2>
            <ul>${errorEntries.map(([field, message]) => html`<li><a href="#field-${field}" data-focus-field="${field}">${message}</a></li>`)}</ul>
          </div>` : ''}

        <fieldset class="intake__section">
          <legend class="intake__legend">Patient information</legend>
          <div class="form-grid">
            <div class="${fieldClass('name')} form-grid__wide">
              <label class="field__label" for="field-name">Patient name <span class="field__req">Required</span></label>
              <input class="input" id="field-name" name="name" type="text" autocomplete="off" maxlength="80"
                value="${p.name}" data-patient-field="name" aria-describedby="err-name" ${visible.name ? raw('aria-invalid="true"') : ''}>
              ${fieldError('name')}
            </div>
            <div class="${fieldClass('age')}">
              <label class="field__label" for="field-age">Age <span class="field__req">Required, in years</span></label>
              <input class="input input--short" id="field-age" name="age" type="text" inputmode="numeric" maxlength="3" autocomplete="off"
                value="${p.age}" data-patient-field="age" aria-describedby="err-age" ${visible.age ? raw('aria-invalid="true"') : ''}>
              ${fieldError('age')}
            </div>
            <div class="${fieldClass('contact')}">
              <label class="field__label" for="field-contact">Contact number <span class="field__req">Required</span></label>
              <input class="input" id="field-contact" name="contact" type="tel" inputmode="tel" autocomplete="off" maxlength="20" placeholder="e.g. 98200 12345"
                value="${p.contact}" data-patient-field="contact" aria-describedby="err-contact hint-contact" ${visible.contact ? raw('aria-invalid="true"') : ''}>
              <p class="field__hint" id="hint-contact">10 digits; add a country code such as +91 if needed.</p>
              ${fieldError('contact')}
            </div>
            <div class="field form-grid__wide" role="radiogroup" aria-labelledby="label-gender">
              <span class="field__label" id="label-gender">Gender <span class="field__req">Optional</span></span>
              <div class="segmented segmented--wrap" id="field-gender">
                ${GENDER_OPTIONS.map((option) => html`
                  <label class="segmented__item">
                    <input type="radio" name="gender" value="${option.value}" data-patient-field="gender" ${p.gender === option.value ? raw('checked') : ''}>
                    <span>${option.label}</span>
                  </label>`)}
              </div>
            </div>
          </div>
        </fieldset>

        <div class="${fieldClass('description')} intake__section">
          <label class="field__label" for="field-description">Reason for the visit, in the patient’s words <span class="field__req">Optional</span></label>
          <textarea class="input textarea" id="field-description" name="description" rows="3" maxlength="500"
            placeholder="For example: “Chest discomfort since this morning”"
            data-patient-field="description" aria-describedby="err-description">${p.description}</textarea>
          ${fieldError('description')}
        </div>

        <footer class="form-actions">
          <button type="button" class="btn btn-ghost" data-action="cancel-assessment">${icon('x')}<span>${editingSaved ? 'Discard changes' : 'Cancel Assessment'}</span></button>
          <button type="button" class="btn btn-primary btn-lg" data-action="save-patient">
            <span>${returningToReview && currentSequence().complete ? 'Save and return to review' : 'Continue to Symptoms'}</span>${icon('chevron-right')}
          </button>
        </footer>
      </form>
    </section>`;
}

function renderDemoMenu() {
  const groups = uniqueBy(DEMO_CASES.map((demo) => demo.group), (g) => g);
  return html`
    <details class="demo-menu" data-demo-menu>
      <summary class="btn btn-ghost btn-sm">${icon('list-checks')}<span>Load demo case</span>${icon('chevron-down')}</summary>
      <div class="demo-menu__panel">
        <p class="demo-menu__note">For presentations and testing. Fills the form and the questionnaire answers.</p>
        ${groups.map((group) => html`
          <p class="demo-menu__group">${group}</p>
          ${DEMO_CASES.filter((demo) => demo.group === group).map((demo) => html`
            <button type="button" class="demo-menu__item" data-action="load-demo" data-demo-id="${demo.id}">
              <span class="demo-menu__label">${demo.label}</span>
              <span class="demo-menu__expect">Expected: ${demo.expect}${demo.expectCondition && CONDITION_INDEX[demo.expectCondition] ? ` · ${CONDITION_INDEX[demo.expectCondition].short}` : ''}</span>
            </button>`)}`)}
      </div>
    </details>`;
}

/* Live update of the working copy as the receptionist types. */
function updatePatientField(field, value) {
  const patient = state.assessment.patient;
  patient[field] = value;
  if (field === 'gender') state.ui.intakeTouched[field] = true;
  refreshIntakeFieldError(field);
  persistDraft();
}

function refreshIntakeFieldError(field) {
  const { visible } = validatePatientForm({ showAll: state.ui.intakeSubmitted });
  const slot = document.getElementById(`err-${field}`);
  if (!slot) return;
  slot.innerHTML = visible[field] ? html`${icon('circle-alert')}<span>${visible[field]}</span>`.toString() : '';
  const wrapper = slot.closest('.field');
  if (wrapper) wrapper.classList.toggle('has-error', Boolean(visible[field]));
  const input = document.getElementById(`field-${field}`);
  if (input && input.tagName !== 'DIV' && input.tagName !== 'FIELDSET') {
    if (visible[field]) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }
}

function savePatientDetails() {
  state.ui.intakeSubmitted = true;
  const patient = state.assessment.patient;
  patient.name = patient.name.trim().replace(/\s+/g, ' ');
  patient.contact = patient.contact.trim();
  patient.description = patient.description.trim();
  const { valid } = validatePatientForm({ showAll: true });
  if (!valid) {
    render({ focus: false });
    const summary = document.querySelector('[data-error-summary]');
    if (summary) summary.focus();
    return;
  }

  // Age and gender can change which warning signs apply.
  refreshSafetyState();
  persistDraft();

  if (state.ui.returnTo === 'review' && state.assessment.patient.complaint && currentSequence().complete) {
    reviewAssessment();
    return;
  }
  state.ui.bmError = '';
  navigateTo('bodymap');
}

function editPatientDetails(fromReview = false) {
  state.ui.returnTo = fromReview ? 'review' : state.ui.returnTo;
  state.ui.intakeSubmitted = false;
  state.ui.intakeTouched = {};
  navigateTo('intake');
}

function requestLoadDemoCase(demoId) {
  if (!hasAssessmentData()) {
    loadDemoCase(demoId);
    return;
  }
  openModal({
    tone: 'warning',
    icon: 'triangle-alert',
    title: 'Replace the details entered so far?',
    text: 'Loading a demo case replaces the patient details and any symptom answers in this assessment.',
    actions: [
      { label: 'Keep current details', variant: 'secondary', autofocus: true },
      { label: 'Load demo case', variant: 'primary', onClick: () => loadDemoCase(demoId) },
    ],
  });
}

/* Demo answers are pre-selected on each question rather than saved up
   front, so the presenter still steps through the decision tree and sees
   branching and safety prompts happen as they would at the desk. */
function loadDemoCase(demoId) {
  const demo = DEMO_CASES.find((item) => item.id === demoId);
  if (!demo) return;
  resetAssessment();
  const a = state.assessment;
  a.patient = { ...a.patient, ...deepClone(demo.patient), complaint: '' };
  // The demo's symptoms are pre-selected on the body map (or in the list),
  // and the remaining answers are pre-selected question by question.
  a.bodyMap = demo.bodyMap
    ? normaliseBodyMap({ mode: 'map', selections: deepClone(demo.bodyMap.selections), primary: demo.bodyMap.primary || null })
    : normaliseBodyMap({ mode: 'list', listComplaint: demo.patient.complaint });
  a.demoCaseId = demo.id;
  const firstPick = a.bodyMap.selections[0];
  state.ui.bmArea = firstPick ? firstPick.area : null;
  state.ui.bmView = firstPick && BODY_BACK_ONLY.has(firstPick.area) ? 'back' : 'front';
  state.ui.demoAnswers = deepClone(demo.answers);
  state.ui.intakeTouched = {};
  navigateTo('intake');
  showToast(`Demo case loaded: ${demo.label}. The symptoms are ready on the next step, and each question shows the demo answer pre-selected.`);
}
