/* =====================================================================
   9. CONFIDENCE CALCULATION
   ---------------------------------------------------------------------
   Model confidence combines five factors (settings in CONFIDENCE_THRESHOLDS):
     strength      how strongly the symptoms match the top category
                   1 − e^(−top / strengthScale)
     dominance     how much of all the evidence the top category holds
                   min(1, share / dominanceTarget); it scales strength and
                   condition fit, so symptoms spread over several body
                   systems stay low
     separation    how clearly the top category leads the others
                   (top − second) / (total + smoothing)
     completeness  share of questions answered with a definite response
     condition fit how well the answers match one specific condition in
                   the top category: its match strength (0 when no single
                   condition stands out)
   minus penalties for contradictory responses. The result is the
   prototype classifier's confidence, never a probability that the
   patient has a condition.
   ===================================================================== */

function calculateConfidence(ranked, completeness, inconsistencies = [], conditionFit = 0) {
  const settings = CONFIDENCE_THRESHOLDS;
  const top = ranked[0] ? ranked[0].score : 0;
  const second = ranked[1] ? ranked[1].score : 0;
  const total = ranked.reduce((sum, item) => sum + item.score, 0);
  const strength = top > 0 ? 1 - Math.exp(-top / settings.strengthScale) : 0;
  const share = total > 0 ? top / total : 0;
  const dominance = clamp(share / settings.dominanceTarget, 0, 1);
  const separation = top > 0 ? (top - second) / (total + settings.separationSmoothing) : 0;
  const fit = top > 0 ? clamp(conditionFit, 0, 1) : 0;
  const penalty = inconsistencies.reduce((sum, item) => sum + item.penalty, 0);
  const combined = settings.weights.strength * strength * dominance
    + settings.weights.separation * separation
    + settings.weights.completeness * clamp(completeness, 0, 1)
    + settings.weights.conditionFit * fit * dominance
    - penalty;
  const value = Math.round(clamp(combined * 100, settings.floor, settings.cap));
  return {
    value,
    factors: {
      strength: round(strength * dominance, 3),
      rawStrength: round(strength, 3),
      dominance: round(dominance, 3),
      separation: round(separation, 3),
      completeness: round(clamp(completeness, 0, 1), 3),
      conditionFit: round(fit * dominance, 3),
      rawConditionFit: round(fit, 3),
      penalty: round(penalty, 3),
      topScore: round(top, 2),
      secondScore: round(second, 2),
    },
  };
}

/* Condition fit for the confidence: a clearly leading, well-supported
   condition counts; no single condition (fallback or tie) counts as 0. */
function conditionFitFor(condition) {
  if (!condition || condition.conditionIsFallback || !Number.isFinite(condition.conditionLikelihood)) return 0;
  return clamp(condition.conditionLikelihood / 100, 0, 1);
}

function confidenceBand(value) {
  return CONFIDENCE_THRESHOLDS.bands.find((band) => value >= band.min) || CONFIDENCE_THRESHOLDS.bands[CONFIDENCE_THRESHOLDS.bands.length - 1];
}

/* Contradictory responses (e.g. a pain complaint rated 0 out of 10). */
function detectInconsistencies(rawFeatures, context = {}) {
  return CONSISTENCY_RULES
    .filter((rule) => {
      try { return Boolean(rule.when(rawFeatures, context)); } catch (error) { return false; }
    })
    .map(({ id, severity, penalty, message }) => ({ id, severity, penalty, message }));
}
