/* =====================================================================
   10. SAFETY / RED FLAGS
   ---------------------------------------------------------------------
   Red flags are re-evaluated after every saved answer. Urgent flags stop
   the system from classifying: the result routes to Emergency & Triage
   and asks staff to follow the hospital's protocol. The system never
   names a condition for an urgent case: the predicted condition is
   removed from the result (see withholdCondition in section 8).
   ===================================================================== */

function detectRedFlags(rawFeatures) {
  const urgent = [];
  const priority = [];
  RED_FLAG_RULES.forEach((rule) => {
    let matched = false;
    try { matched = Boolean(rule.when(rawFeatures)); } catch (error) { matched = false; }
    if (!matched) return;
    (rule.level === 'urgent' ? urgent : priority).push({ id: rule.id, label: rule.label });
  });
  return { urgent, priority };
}

/* Updates state.assessment.safety from the current answers and records
   whether a newly detected urgent flag still has to be announced. */
function refreshSafetyState({ announce = true } = {}) {
  const assessment = state.assessment;
  // Body-map picks not yet applied are checked straight away (section 5b).
  const preview = bodyMapPreview(assessment);
  const source = preview ? preview.source : (assessment.patient.complaint ? assessment : null);
  if (!source) {
    assessment.safety = { urgent: [], priority: [] };
    return assessment.safety;
  }
  const safety = detectRedFlags(computeRawFeatures(source));
  assessment.safety = safety;
  if (!announce) state.ui.urgentAlertIds = safety.urgent.map((flag) => flag.id);
  return safety;
}

function isUrgentAssessment(assessment = state.assessment) {
  return Boolean(assessment.urgentFlag || (assessment.safety && assessment.safety.urgent.length));
}

function markForImmediateEvaluation() {
  const assessment = state.assessment;
  assessment.urgentFlag = true;
  assessment.urgentMarkedAt = new Date().toISOString();
  applyUrgentMarkChange();
  showToast('Marked for immediate clinical evaluation. Follow the hospital’s triage protocol.', 'danger');
  render({ focus: false });
}

function removeUrgentMark() {
  const assessment = state.assessment;
  if (assessment.safety.urgent.length) return; // warning signs still present
  assessment.urgentFlag = false;
  assessment.urgentMarkedAt = null;
  applyUrgentMarkChange();
  showToast('Urgent mark removed.');
  render({ focus: false });
}

/* Keeps a finished result consistent with the urgent mark: the routing is
   re-derived from the stored prediction, the report (if any) is refreshed
   and the saved record updated. Before the assessment has been run there
   is no result yet, so nothing needs re-deriving. */
function applyUrgentMarkChange() {
  const assessment = state.assessment;
  if (assessment.prediction && assessment.recommendation) {
    const urgent = isUrgentAssessment(assessment);
    assessment.prediction.withheld = urgent;
    if (urgent) withholdCondition(assessment.prediction);
    else restoreCondition(assessment);
    assessment.recommendation = mapPredictionToSpecialist(assessment.prediction, { urgent });
    assessment.prediction.recommendedSpecialist = assessment.recommendation.specialist;
    if (assessment.report) assessment.report = generateReport(assessment);
    if (assessment.id) saveAssessment();
  }
  persistDraft();
}

/* Banner shown on assessment screens whenever urgent signs exist or the
   patient has been marked for immediate evaluation. */
function renderUrgentBanner(context) {
  const assessment = state.assessment;
  const flags = assessment.safety ? assessment.safety.urgent : [];
  if (!flags.length && !assessment.urgentFlag) return '';

  const marked = assessment.urgentFlag;
  const markedAt = marked && assessment.urgentMarkedAt ? formatTime(assessment.urgentMarkedAt) : '';
  const canFinishEarly = context === 'questionnaire' && marked && !currentSequence().complete;

  return html`
    <section class="urgent-banner${marked ? ' is-marked' : ''}" role="alert" aria-labelledby="urgent-title">
      <div class="urgent-banner__icon">${icon('siren')}</div>
      <div class="urgent-banner__body">
        <h2 class="urgent-banner__title" id="urgent-title">${flags.length ? 'Potential urgent symptoms identified' : 'Patient flagged as urgent by reception'}</h2>
        <p class="urgent-banner__text">${DISCLAIMERS.urgentProtocol}</p>
        ${flags.length ? html`<ul class="urgent-banner__list">${flags.map((flag) => html`<li>${flag.label}</li>`)}</ul>` : ''}
        ${marked ? html`<p class="urgent-banner__status">${icon('check')}<span>Marked for immediate clinical evaluation${markedAt ? ` at ${markedAt}` : ''}.${context === 'questionnaire' ? ' You can keep recording the remaining questions.' : ''}</span></p>` : ''}
      </div>
      <div class="urgent-banner__actions">
        ${marked
          ? html`${canFinishEarly ? html`<button type="button" class="btn btn-secondary btn-sm" data-action="finish-early">${icon('list-checks')}<span>Finish now and review</span></button>` : ''}
            ${!flags.length ? html`<button type="button" class="btn btn-ghost btn-sm" data-action="remove-urgent">${icon('undo-2')}<span>Remove mark</span></button>` : ''}`
          : html`<button type="button" class="btn btn-urgent" data-action="mark-urgent">${icon('siren')}<span>Mark for Immediate Clinical Evaluation</span></button>`}
      </div>
    </section>`;
}
