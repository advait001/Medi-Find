/* =====================================================================
   11. SPECIALIST MAPPING
   ---------------------------------------------------------------------
   Kept separate from prediction: the classifier outputs a category; this
   module maps it to a department through SPECIALIST_MAPPING, mirroring
   the "disease-to-speciality table" in the algorithm document.
   ===================================================================== */

function mapPredictionToSpecialist(prediction, { urgent = false } = {}) {
  let key = 'general';
  let reason = 'inconclusive';
  if (urgent) {
    key = 'urgent';
    reason = 'urgent';
  } else if (prediction && !prediction.isInconclusive && SPECIALIST_MAPPING[prediction.predictedCategoryId]) {
    key = prediction.predictedCategoryId;
    reason = 'category';
  } else if (prediction && prediction.predictedCategoryId === 'general') {
    reason = 'category';
  }
  const mapping = SPECIALIST_MAPPING[key];
  return { key, reason, ...mapping, doctor: doctorForKey(key), nextStep: nextStepFor(key, reason, mapping) };
}

/* The doctor a department sends patients to (DOCTOR_DIRECTORY), or null
   when the department has no fixed doctor (the emergency team). */
function doctorForKey(key) {
  const entry = DOCTOR_DIRECTORY[key];
  return entry && entry.name ? { name: entry.name } : null;
}

/* The doctor to show for a saved recommendation. Assessments saved before
   doctors were added have none recorded, so they show the department's
   doctor from the directory. */
function recommendedDoctor(recommendation) {
  if (!recommendation) return null;
  if (recommendation.doctor !== undefined) return recommendation.doctor && recommendation.doctor.name ? recommendation.doctor : null;
  const key = recommendation.key
    || Object.keys(SPECIALIST_MAPPING).find((id) => SPECIALIST_MAPPING[id].department === recommendation.department);
  return key ? doctorForKey(key) : null;
}

/* "AM" for "Dr. Anjali Mehta". */
function doctorInitials(name) {
  return initials(String(name || '').replace(/^dr\.?\s+/i, ''));
}

function nextStepFor(key, reason, mapping) {
  if (key === 'urgent') {
    return 'Follow the hospital’s emergency / clinical triage protocol immediately. Alert the triage team and do not send the patient to the general outpatient queue.';
  }
  if (key === 'general' && reason === 'inconclusive') {
    return 'Guide the patient to a General Physician for a general clinical evaluation.';
  }
  if (key === 'general') {
    return 'Guide the patient to the General Medicine department for professional clinical evaluation.';
  }
  return `Guide the patient to the ${mapping.department} Department for professional clinical evaluation.`;
}
