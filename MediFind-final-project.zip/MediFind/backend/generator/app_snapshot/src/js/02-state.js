/* =====================================================================
   2. STATE MANAGEMENT
   ---------------------------------------------------------------------
   `state.assessment` is the working copy of the assessment in progress.
   Saved assessments live in the repository (section 13); opening one
   from history loads a deep copy into `state.assessment`.
   ===================================================================== */

const state = {
  currentScreen: 'dashboard',
  assessment: createEmptyAssessment(),
  ui: createEmptyUiState(),
};

function createEmptyAssessment() {
  return {
    id: null,
    createdAt: null,
    updatedAt: null,
    status: 'draft', // draft → completed
    patient: { name: '', age: '', gender: '', contact: '', complaint: '', description: '' },
    bodyMap: createEmptyBodyMap(), // symptoms picked on the body map (section 5b)
    answers: {},
    questionHistory: [], // active route: answered question ids in the order asked
    features: null, // processed feature vector (section 7)
    prediction: null, // classifier output (section 8)
    recommendation: null, // specialist / department (section 11)
    report: null, // generated report snapshot (section 12)
    safety: { urgent: [], priority: [] }, // red-flag evaluation (section 10)
    urgentFlag: false, // receptionist marked the patient for immediate clinical evaluation
    urgentMarkedAt: null,
    endedEarly: false, // questionnaire stopped early after urgent escalation
    revision: 0, // times the assessment has been run (re-runs after edits keep the same ID)
    demoCaseId: null,
    startedBy: null, // staff account that started it: { id, name, role } (section 3a)
  };
}

function createEmptyUiState() {
  return {
    cursor: 0, // position in the active question route
    pending: undefined, // answer being edited on the current question
    questionError: '',
    branchNotice: null,
    direction: 'forward',
    urgentAlertIds: [], // urgent flags already announced to the receptionist
    intakeTouched: {},
    intakeSubmitted: false,
    returnTo: null, // 'review' when editing from the review screen
    lastFlowScreen: null, // where "Resume assessment" returns to
    demoAnswers: null, // answers pre-selected by "Load demo case"
    bmView: 'front', // body map: front or back of the figure
    bmArea: null, // body map: body part whose symptoms are listed
    bmQuery: '', // body map: symptom search text
    bmHint: null, // body map: symptom whose possible body parts are highlighted
    bmError: '',
    historyQuery: '',
    analysis: null,
    openedFrom: null, // 'history' | 'dashboard' when viewing a saved assessment
  };
}

function hasAssessmentData(assessment = state.assessment) {
  const p = assessment.patient;
  const picked = assessment.bodyMap && Array.isArray(assessment.bodyMap.selections) && assessment.bodyMap.selections.length;
  return Boolean(
    !isBlank(p.name) || !isBlank(p.age) || !isBlank(p.contact) || !isBlank(p.complaint)
    || !isBlank(p.description) || Object.keys(assessment.answers).length || picked,
  );
}

/* True while the working copy holds unsaved work: a new assessment that
   has not been run yet, or edits to a saved assessment. */
function hasUnsavedProgress() {
  const a = state.assessment;
  if (!hasAssessmentData(a)) return false;
  if (a.status !== 'completed') return true;
  const saved = AssessmentRepository.get(a.id);
  return !saved || !answersEqual(stripVolatile(saved), stripVolatile(a));
}

function stripVolatile(assessment) {
  const { patient, answers, urgentFlag } = assessment;
  return { patient, answers, urgentFlag, bodyMap: bodyMapSnapshot(assessment.bodyMap) };
}

function isFlowScreen(screen = state.currentScreen) {
  return Boolean(SCREENS[screen] && SCREENS[screen].flow);
}

function invalidateDerivedResults() {
  const a = state.assessment;
  a.features = null;
  a.prediction = null;
  a.recommendation = null;
  a.report = null;
}

function resetAssessment() {
  state.assessment = createEmptyAssessment();
  state.assessment.startedBy = currentStaff();
  state.ui = { ...createEmptyUiState(), historyQuery: state.ui.historyQuery };
  DraftStore.clear();
}

/* Keeps an in-progress assessment across an accidental refresh. */
function persistDraft() {
  const a = state.assessment;
  if (!a.startedBy && hasAssessmentData(a)) a.startedBy = currentStaff();
  const inProgress = isFlowScreen() && hasAssessmentData(a) && hasUnsavedProgress();
  if (!inProgress) {
    if (!hasUnsavedProgress()) DraftStore.clear();
    return;
  }
  DraftStore.save({
    assessment: a,
    screen: ['analysis', 'results', 'report'].includes(state.currentScreen) ? 'review' : state.currentScreen,
    cursor: state.ui.cursor,
    returnTo: state.ui.returnTo,
    savedAt: new Date().toISOString(),
  });
}

/* Loads a stored draft into the working copy without leaving the
   dashboard; the dashboard then offers "Resume assessment". */
function loadDraftIntoState(draft) {
  if (!draft || !draft.assessment || typeof draft.assessment !== 'object') return false;
  const empty = createEmptyAssessment();
  state.assessment = {
    ...empty,
    ...draft.assessment,
    patient: { ...empty.patient, ...(draft.assessment.patient || {}) },
    answers: { ...(draft.assessment.answers || {}) },
  };
  state.assessment.bodyMap = normaliseBodyMap(draft.assessment.bodyMap, state.assessment.patient.complaint);
  state.ui.cursor = Number(draft.cursor) || 0;
  state.ui.returnTo = draft.returnTo || null;
  state.ui.lastFlowScreen = SCREENS[draft.screen] && SCREENS[draft.screen].flow ? draft.screen : 'intake';
  if (state.assessment.patient.complaint) clearObsoleteBranchAnswers();
  refreshSafetyState({ announce: false });
  return hasAssessmentData(state.assessment);
}

function resumeAssessment() {
  const target = state.ui.lastFlowScreen;
  const resumable = ['intake', 'bodymap', 'questionnaire', 'review'];
  navigateTo(resumable.includes(target) ? target : 'intake');
}
