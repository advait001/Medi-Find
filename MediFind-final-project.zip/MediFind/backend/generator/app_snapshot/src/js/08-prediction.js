/* =====================================================================
   8. PREDICTION ENGINE
   ---------------------------------------------------------------------
   The prototype classifier is deterministic and works in two stages,
   mirroring the algorithm document ("predict the disease, then map it to
   the specialist"):
     1. Category: weighted symptom scoring plus decision rules,
        normalised into category scores. The category decides the
        department and the model confidence.
     2. Condition: the conditions belonging to that category (CONDITIONS)
        are scored with the same features; the best match becomes the
        predicted condition, with a relative likelihood and the next
        most likely alternatives.
   No randomness is used, so the same assessment always produces the
   same result.

   PRODUCTION INTEGRATION POINT
   The documented production design trains Random Forest, Decision Tree
   and Logistic Regression models (Python / scikit-learn) on a labelled
   symptom dataset and serves the selected model from a Flask or Django
   backend. To switch over, set PredictionService.mode = 'api' and make
   POST /api/predict accept the payload from buildPredictionPayload()
   (schema version, feature order and the normalised vector) and return
   { category, probabilities: { [category]: p }, disease, diseaseProbability,
     differentials: [{ disease, probability }] }.
   normaliseApiPrediction() maps that response onto the same output shape
   used here, so the screens, report and history need no changes.
   ===================================================================== */

const PredictionService = {
  mode: 'local', // 'local' (this prototype) | 'api' (trained model on the backend)
  endpoint: '/api/predict',

  async predict(processed, context) {
    if (this.mode === 'api') {
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildPredictionPayload(processed, context)),
      });
      if (!response.ok) throw new Error(`Prediction service responded with ${response.status}`);
      return normaliseApiPrediction(await response.json(), processed, context);
    }
    return predictLocally(processed, context);
  },
};

async function runPrediction(featureVector, context = {}) {
  return PredictionService.predict(featureVector, context);
}

function buildPredictionPayload(processed, context) {
  return {
    schemaVersion: processed.schemaVersion,
    featureOrder: processed.order,
    features: processed.vector,
    completeness: processed.meta.completeness,
    complaint: context.complaint || null,
  };
}

/* Maps a backend model response onto the local output shape. The model's
   class probability becomes the confidence ("probability of the selected
   class", as described in the algorithm document). */
function normaliseApiPrediction(response, processed, context) {
  const probabilities = response.probabilities || {};
  const ranked = CATEGORY_ORDER
    .map((id) => ({ id, label: CATEGORIES[id].label, score: Number(probabilities[id]) || 0 }))
    .sort((a, b) => b.score - a.score);
  const total = ranked.reduce((sum, item) => sum + item.score, 0) || 1;
  ranked.forEach((item) => { item.share = round((item.score / total) * 100); });
  const top = ranked[0];
  const confidence = Math.round(clamp((Number(probabilities[top.id]) || 0) * 100, 0, 100));
  const inconsistencies = detectInconsistencies(processed.raw, context);
  const isInconclusive = confidence < CONFIDENCE_THRESHOLDS.inconclusiveBelow;
  const toPercent = (value) => (Number.isFinite(Number(value)) && value !== null ? Math.round(clamp(Number(value) * 100, 0, 100)) : null);
  const describe = (name) => findConditionByName(name) || { id: slugify(name), name, short: name, description: '' };

  let condition;
  if (isInconclusive) {
    condition = inconclusiveCondition([]);
  } else {
    const disease = response.disease || response.condition || null;
    const known = disease ? describe(disease) : CATEGORIES[top.id].fallbackCondition;
    condition = {
      predictedConditionId: known.id,
      predictedCondition: known.name,
      conditionShort: known.short || known.name,
      conditionDescription: known.description || '',
      conditionLikelihood: disease ? toPercent(response.diseaseProbability) : null,
      conditionIsFallback: !disease,
      differentials: (Array.isArray(response.differentials) ? response.differentials : [])
        .map((item) => {
          const name = item && (item.disease || item.condition || item.name);
          if (!name) return null;
          const info = describe(name);
          return { id: info.id, name: info.name, short: info.short || info.name, likelihood: toPercent(item.probability) };
        })
        .filter(Boolean)
        .slice(0, CONDITION_SETTINGS.maxDifferentials),
      conditionEvidence: [],
      conditionAgainst: [],
      consideredConditions: [],
    };
  }

  return {
    engine: 'api',
    predictedCategoryId: isInconclusive ? INCONCLUSIVE_RESULT.id : top.id,
    predictedCategory: isInconclusive ? INCONCLUSIVE_RESULT.label : top.label,
    predictedPattern: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].patternLabel,
    ...condition,
    topCategoryId: top.id,
    categoryScores: ranked,
    confidence,
    confidenceLevel: confidenceBand(confidence).id,
    confidenceLabel: confidenceBand(confidence).label,
    confidenceFactors: null,
    matchedSymptoms: [],
    consideredSymptoms: [],
    firedRules: [],
    inconsistencies,
    isInconclusive,
  };
}

function predictLocally(processed, context) {
  const f = processed.named;
  const scored = calculateCategoryScores(f);
  const ranked = rankCategories(scored);
  const top = ranked[0];
  const inconsistencies = detectInconsistencies(processed.raw, context);
  const topCondition = predictCondition(f, processed.raw, top.score > 0 ? top.id : null);
  const confidence = calculateConfidence(ranked, processed.meta.completeness, inconsistencies, conditionFitFor(topCondition));
  const isInconclusive = top.score <= 0 || confidence.value < CONFIDENCE_THRESHOLDS.inconclusiveBelow;
  const band = confidenceBand(confidence.value);
  const condition = isInconclusive ? predictCondition(f, processed.raw, null) : topCondition;

  return {
    engine: ENGINE_INFO.id,
    predictedCategoryId: isInconclusive ? INCONCLUSIVE_RESULT.id : top.id,
    predictedCategory: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].label,
    predictedPattern: isInconclusive ? INCONCLUSIVE_RESULT.label : CATEGORIES[top.id].patternLabel,
    ...condition,
    topCategoryId: top.id,
    categoryScores: ranked.map(({ id, label, score, share }) => ({ id, label, score: round(score, 2), share })),
    confidence: confidence.value,
    confidenceLevel: band.id,
    confidenceLabel: band.label,
    confidenceFactors: confidence.factors,
    matchedSymptoms: matchedSymptomsFor(top, processed.raw),
    consideredSymptoms: consideredSymptoms(processed.raw),
    firedRules: top.firedRules,
    inconsistencies,
    isInconclusive,
  };
}

/* Weighted score for every category. Negative totals are floored at 0. */
function calculateCategoryScores(f) {
  return CATEGORY_ORDER.map((id) => {
    const rule = PREDICTION_RULES[id];
    let score = 0;
    const contributions = [];
    Object.entries(rule.weights).forEach(([key, weight]) => {
      const value = f[key] || 0;
      if (!value) return;
      const points = weight * value;
      score += points;
      contributions.push({ key, weight, value, points: round(points, 2) });
    });
    const firedRules = [];
    (rule.rules || []).forEach((decision) => {
      let fired = false;
      try { fired = Boolean(decision.when(f)); } catch (error) { fired = false; }
      if (fired) {
        score += decision.bonus;
        firedRules.push({ id: decision.id, label: decision.label, bonus: decision.bonus });
      }
    });
    return { id, label: CATEGORIES[id].label, score: Math.max(0, score), contributions, firedRules };
  });
}

/* Sorts by score; ties resolve by the fixed CATEGORY_ORDER, keeping the
   result deterministic. Adds each category's share of the total score. */
function rankCategories(scored) {
  const total = scored.reduce((sum, item) => sum + item.score, 0);
  const ranked = scored
    .map((item) => ({ ...item, share: total > 0 ? (item.score / total) * 100 : 0 }))
    .sort((a, b) => (b.score - a.score) || (CATEGORY_ORDER.indexOf(a.id) - CATEGORY_ORDER.indexOf(b.id)));
  // Round shares so they add up to exactly 100.
  if (total > 0) {
    const floors = ranked.map((item) => Math.floor(item.share));
    let remainder = 100 - floors.reduce((sum, v) => sum + v, 0);
    const order = ranked
      .map((item, index) => ({ index, fraction: item.share - Math.floor(item.share) }))
      .sort((a, b) => b.fraction - a.fraction);
    order.forEach(({ index }) => { if (remainder > 0) { floors[index] += 1; remainder -= 1; } });
    ranked.forEach((item, index) => { item.share = floors[index]; });
  }
  return ranked;
}

/* ---------- Stage 2: condition prediction ---------- */

function conditionCategories(condition) {
  return Array.isArray(condition.category) ? condition.category : [condition.category];
}

/* Scores one condition. A condition whose `requires` test fails is not
   considered (score 0), because its defining symptom is missing. */
function scoreCondition(condition, f) {
  let met = true;
  if (typeof condition.requires === 'function') {
    try { met = Boolean(condition.requires(f)); } catch (error) { met = false; }
  }
  if (!met) return { condition, score: 0, met: false, contributions: [] };
  let score = 0;
  const contributions = [];
  Object.entries(condition.weights).forEach(([key, weight]) => {
    const value = f[key] || 0;
    if (!value) return;
    const points = weight * value;
    score += points;
    contributions.push({ key, weight, value, points: round(points, 2) });
  });
  return { condition, score: Math.max(0, round(score, 3)), met: true, contributions };
}

/* Highest score first; ties keep the configuration order (deterministic). */
function rankConditions(scored) {
  return scored
    .map((item, index) => ({ ...item, index: CONDITIONS.indexOf(item.condition) >= 0 ? CONDITIONS.indexOf(item.condition) : index }))
    .sort((a, b) => (b.score - a.score) || (a.index - b.index));
}

/* Match strength: softmax share against the candidate conditions plus a
   residual standing for conditions the prototype does not cover, scaled
   by how much evidence supports the condition, so a condition backed by
   a single answer never reads as a near-certain match. */
function conditionLikelihoods(ranked) {
  const settings = CONDITION_SETTINGS;
  const candidates = ranked.filter((item) => item.score > 0);
  const weights = candidates.map((item) => Math.exp(item.score / settings.temperature));
  const total = weights.reduce((sum, w) => sum + w, 0) + Math.exp(settings.residualScore / settings.temperature);
  return candidates.map((item, i) => {
    const support = 1 - Math.exp(-item.score / settings.fitScale);
    return { ...item, likelihood: Math.round(clamp((weights[i] / total) * support * 100, 0, settings.likelihoodCap)) };
  });
}

function conditionEvidence(contributions, rawFeatures, sign) {
  return contributions
    .filter((item) => (sign > 0 ? item.points > 0 : item.points < 0))
    .sort((a, b) => (sign > 0 ? b.points - a.points : a.points - b.points))
    .map((item) => ({ key: item.key, label: describeFeature(item.key, rawFeatures), points: item.points }));
}

function primaryCategory(condition) {
  return conditionCategories(condition)[0];
}

function inconclusiveCondition(considered) {
  return {
    predictedConditionId: INCONCLUSIVE_RESULT.id,
    predictedCondition: INCONCLUSIVE_RESULT.conditionLabel,
    conditionShort: INCONCLUSIVE_RESULT.conditionShort,
    conditionDescription: INCONCLUSIVE_RESULT.conditionMessage,
    conditionLikelihood: null,
    conditionScore: null,
    conditionIsFallback: true,
    differentials: [],
    conditionEvidence: [],
    conditionAgainst: [],
    consideredConditions: considered,
  };
}

/* Predicts the condition within the chosen category. With no category
   (inconclusive result) no condition is named; the strongest candidates
   from any category are listed for the General Physician instead. */
function predictCondition(f, rawFeatures, categoryId) {
  const settings = CONDITION_SETTINGS;
  const scored = CONDITIONS.map((condition) => scoreCondition(condition, f));

  if (!categoryId || !CATEGORIES[categoryId]) {
    const considered = rankConditions(scored)
      .filter((item) => item.score >= settings.consideredMinScore)
      .slice(0, settings.maxDifferentials)
      .map((item) => {
        const categoryKey = primaryCategory(item.condition);
        return {
          id: item.condition.id,
          name: item.condition.name,
          short: item.condition.short,
          categoryId: categoryKey,
          department: SPECIALIST_MAPPING[categoryKey].department,
        };
      });
    return inconclusiveCondition(considered);
  }

  const eligible = rankConditions(scored.filter((item) => conditionCategories(item.condition).includes(categoryId)));
  const candidates = conditionLikelihoods(eligible);
  const best = candidates[0];
  const runnerUp = candidates[1];
  const weak = !best || best.score < settings.minScore;
  const tie = !weak && runnerUp && runnerUp.score >= settings.minScore && best.likelihood - runnerUp.likelihood < settings.tieMargin;

  if (weak || tie) {
    // No single condition stands out within the category: describe the
    // category instead and list the closest matches.
    const fallback = CATEGORIES[categoryId].fallbackCondition;
    return {
      predictedConditionId: fallback.id,
      predictedCondition: fallback.name,
      conditionShort: fallback.short,
      conditionDescription: fallback.description,
      conditionLikelihood: null,
      conditionScore: best ? round(best.score, 2) : 0,
      conditionIsFallback: true,
      conditionTie: Boolean(tie),
      differentials: candidates.slice(0, settings.maxDifferentials)
        .map((item) => ({ id: item.condition.id, name: item.condition.name, short: item.condition.short, likelihood: tie ? item.likelihood : null })),
      conditionEvidence: [],
      conditionAgainst: [],
      consideredConditions: [],
    };
  }

  return {
    predictedConditionId: best.condition.id,
    predictedCondition: best.condition.name,
    conditionShort: best.condition.short,
    conditionDescription: best.condition.description,
    conditionLikelihood: best.likelihood,
    conditionScore: round(best.score, 2),
    conditionIsFallback: false,
    differentials: candidates.slice(1)
      .filter((item) => item.likelihood >= settings.minDifferentialLikelihood)
      .slice(0, settings.maxDifferentials)
      .map((item) => ({ id: item.condition.id, name: item.condition.name, short: item.condition.short, likelihood: item.likelihood })),
    conditionEvidence: conditionEvidence(best.contributions, rawFeatures, 1),
    conditionAgainst: conditionEvidence(best.contributions, rawFeatures, -1),
    consideredConditions: [],
  };
}

/* ---------- Urgent cases: no condition is kept ---------- */

const CONDITION_FIELDS = ['predictedConditionId', 'predictedCondition', 'conditionShort', 'conditionDescription', 'conditionLikelihood',
  'conditionScore', 'conditionIsFallback', 'conditionTie', 'differentials', 'conditionEvidence', 'conditionAgainst', 'consideredConditions'];

/* Urgent cases are not diagnosed: the condition is removed from the
   result itself, so it is never shown, printed or stored. */
function withholdCondition(prediction) {
  if (!prediction) return;
  CONDITION_FIELDS.forEach((key) => { delete prediction[key]; });
  prediction.conditionWithheld = true;
}

/* When reception removes an urgent mark (and no warning signs remain),
   the condition is predicted again from the stored features. This uses
   the local condition model, also when categories came from the API. */
function restoreCondition(assessment) {
  const prediction = assessment.prediction;
  if (!prediction || !prediction.conditionWithheld || !assessment.features) return;
  const categoryId = prediction.isInconclusive ? null : prediction.predictedCategoryId;
  Object.assign(prediction, predictCondition(assessment.features.named, assessment.features.raw, categoryId));
  delete prediction.conditionWithheld;
}

function findConditionByName(name) {
  const key = String(name || '').trim().toLowerCase();
  if (!key) return null;
  return CONDITIONS.find((condition) => condition.id === key || condition.name.toLowerCase() === key || condition.short.toLowerCase() === key) || null;
}

function slugify(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'condition';
}

/* ---------- Explanations ---------- */

function describeFeature(key, rawFeatures) {
  const label = SYMPTOM_LABELS[key] || key;
  const value = rawFeatures[key];
  if (key === 'breathingDifficulty' && value > 0) return `${label} (${BREATHING_OPTIONS[value].label.toLowerCase()})`;
  if (key === 'painScore' && value !== null) return `Pain ${value}/10`;
  if (key === 'severity' && value) {
    const option = SEVERITY_OPTIONS.find((item) => item.score === value);
    return option ? `${label}: ${option.label.toLowerCase()}` : label;
  }
  return label;
}

function matchedSymptomsFor(category, rawFeatures) {
  return category.contributions
    .filter((item) => item.points > 0 && !(FEATURE_INDEX[item.key] || {}).internal)
    .sort((a, b) => b.points - a.points)
    .map((item) => ({ key: item.key, label: describeFeature(item.key, rawFeatures), points: item.points }));
}

function consideredSymptoms(rawFeatures) {
  return FEATURE_SCHEMA
    .filter((definition) => !definition.internal && definition.type === 'binary' && rawFeatures[definition.key] === 1)
    .map((definition) => ({ key: definition.key, label: SYMPTOM_LABELS[definition.key] }));
}
