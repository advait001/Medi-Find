/* =====================================================================
   17. UTILITY FUNCTIONS
   ===================================================================== */

/* Safe HTML templating. Every interpolated value is escaped unless it is
   itself the output of html`` or raw(). null, undefined, false and
   non-finite numbers render as an empty string, so values such as
   "undefined", "null" or "NaN" never reach the screen. */
class SafeHTML {
  constructor(value) { this.value = value; }
  toString() { return this.value; }
}

function raw(value) {
  return new SafeHTML(value == null ? '' : String(value));
}

function escapeHTML(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderValue(value) {
  if (value === null || value === undefined || value === false || value === true) return '';
  if (value instanceof SafeHTML) return value.value;
  if (Array.isArray(value)) return value.map(renderValue).join('');
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : '';
  if (typeof value === 'object') return '';
  return escapeHTML(value);
}

function html(strings, ...values) {
  let out = '';
  strings.forEach((chunk, i) => {
    out += chunk;
    if (i < values.length) out += renderValue(values[i]);
  });
  return new SafeHTML(out);
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function round(value, decimals = 0) {
  const factor = 10 ** decimals;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}

function deepClone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function hasOwn(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function answersEqual(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function isBlank(value) {
  return value === undefined || value === null || String(value).trim() === '';
}

function textOr(value, fallback = 'Not recorded') {
  return isBlank(value) ? fallback : String(value);
}

function capitalise(text) {
  const value = String(text || '');
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function pluralise(count, singular, plural = `${singular}s`) {
  return `${count} ${count === 1 ? singular : plural}`;
}

function formatNumber(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return '';
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

function toDate(value) {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatDate(value, options = { day: 'numeric', month: 'short', year: 'numeric' }) {
  const date = toDate(value);
  return date ? date.toLocaleDateString('en-GB', options) : '';
}

function formatLongDate(value) {
  return formatDate(value, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function formatTime(value) {
  const date = toDate(value);
  if (!date) return '';
  return date.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(/\s?(am|pm)$/i, (m) => ` ${m.trim().toLowerCase()}`);
}

function formatDateTime(value) {
  const date = toDate(value);
  return date ? `${formatDate(date)}, ${formatTime(date)}` : '';
}

function isSameDay(a, b) {
  const x = toDate(a);
  const y = toDate(b);
  return Boolean(x && y && x.getFullYear() === y.getFullYear() && x.getMonth() === y.getMonth() && x.getDate() === y.getDate());
}

function greetingFor(date) {
  const hour = date.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function genderLabel(value) {
  const option = GENDER_OPTIONS.find((g) => g.value === value);
  return option ? option.label : 'Not recorded';
}

function complaintLabel(id) {
  const complaint = getComplaint(id);
  return complaint ? complaint.label : 'Not recorded';
}

function painBand(score) {
  return PAIN_BANDS.find((band) => score >= band.min && score <= band.max) || PAIN_BANDS[0];
}

function initials(name) {
  return String(name || '')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('') || '–';
}

function debounce(fn, wait = 150) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function prefersReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
    : false;
}

function uniqueBy(items, keyFn) {
  const seen = new Set();
  return items.filter((item) => {
    const key = keyFn(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
