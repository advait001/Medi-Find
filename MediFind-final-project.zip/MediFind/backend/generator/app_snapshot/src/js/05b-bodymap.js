/* =====================================================================
   5b. BODY MAP (Symptoms step)
   ---------------------------------------------------------------------
   The receptionist clicks the part of the body that is affected and
   ticks what the patient feels there, with a 0–10 pain rating where it
   applies (the same plain end labels as the questionnaire's pain
   scales). deriveFromBodyMap() turns the picks into the main complaint
   and the decision-tree answers they already give, so the follow-up
   questions only ask what is still unknown. Picks that belong to another
   complaint than the main problem become extra findings (bodyMapExtras):
   they count as reported symptoms and pre-select matching answers later.
   A "Choose from a list" mode keeps the plain complaint list.
   The figure is the MediFind body map picture (front and back views);
   its clickable outlines come from 05a-body-figure.js.
   ===================================================================== */

const BODY_FRONT_ONLY = new Set(['chest', 'abd_ur', 'abd_um', 'abd_ul', 'abd_lr', 'abd_lm', 'abd_ll', 'pelvis']);
const BODY_BACK_ONLY = new Set(['upper_back', 'lower_back', 'buttocks']);

/* Extra search words for body parts. */
const BODY_AREA_KEYWORDS = {
  abd_ur: 'belly stomach abdomen tummy liver', abd_um: 'belly stomach abdomen tummy', abd_ul: 'belly stomach abdomen tummy',
  abd_lr: 'belly stomach abdomen tummy appendix', abd_lm: 'belly stomach abdomen tummy navel', abd_ll: 'belly stomach abdomen tummy',
  shoulder: 'joint', upper_arm: 'biceps', forearm: 'elbow joint', hand: 'wrist fingers joint', thigh: 'hip joint',
  knee: 'joint', lower_leg: 'calf shin', foot: 'ankle toes heel joint',
  head: 'head face eyes ears nose mouth jaw',
  neck: 'neck throat',
  chest: 'chest heart lungs ribs breast',
  pelvis: 'groin pelvis bladder hip',
  upper_back: 'back spine shoulder blades',
  lower_back: 'back spine waist',
  buttocks: 'buttock bottom hip',
  skin: 'skin rash itch',
  general: 'whole body general all over',
};

/* Features never taken from extra findings: they describe the main
   problem only (its pain score, severity and duration). */
const BODY_EXTRA_EXCLUDED = new Set(['painScore', 'severity', 'durationBand', 'temperatureC', 'chestPainScore']);

/* Features that only record which branch of the questions a pick starts
   ("pain elsewhere", "chest or heart"). They are kept for the main
   problem, whose questions follow, but not for the other picks: there
   they would add a finding the patient did not report (for example chest
   discomfort for a racing heartbeat). A pick's own `features` still count. */
const BODY_ROUTING_FEATURES = new Set(['otherPain', 'chestDiscomfort', 'breathingConcern', 'digestiveConcern', 'skinConcern', 'mskConcern', 'neuroConcern']);

/* ---------- State ---------- */

function createEmptyBodyMap(mode = 'map') {
  return { mode, selections: [], primary: null, listComplaint: '', applied: null };
}

function bodySelectionKey(symptomId, areaId) {
  const def = BODY_SYMPTOM_INDEX[symptomId];
  return def && def.perArea ? `${symptomId}@${areaId}` : symptomId;
}

/* Repairs a stored body map (drafts, saved records). Records saved before
   the body map existed open in list mode with their recorded complaint. */
function normaliseBodyMap(value, complaint = '') {
  if (!value || typeof value !== 'object') {
    return complaint ? { ...createEmptyBodyMap('list'), listComplaint: complaint } : createEmptyBodyMap();
  }
  const selections = (Array.isArray(value.selections) ? value.selections : [])
    .filter((sel) => sel && BODY_SYMPTOM_INDEX[sel.symptom] && BODY_AREA_INDEX[sel.area])
    .map((sel) => ({
      key: bodySelectionKey(sel.symptom, sel.area),
      symptom: sel.symptom,
      area: sel.area,
      pain: Number.isInteger(sel.pain) && sel.pain >= 0 && sel.pain <= 10 ? sel.pain : null,
    }));
  const unique = uniqueBy(selections, (sel) => sel.key);
  return {
    mode: value.mode === 'list' ? 'list' : 'map',
    selections: unique,
    primary: unique.some((sel) => sel.key === value.primary) ? value.primary : null,
    listComplaint: getComplaint(value.listComplaint) ? value.listComplaint : (getComplaint(complaint) ? complaint : ''),
    applied: value.applied && typeof value.applied === 'object' && value.applied.answers ? value.applied : null,
  };
}

/* What counts as a change to the body map when checking for unsaved work. */
function bodyMapSnapshot(bodyMap) {
  if (!bodyMap || bodyMap.mode !== 'map') return null;
  return { selections: (bodyMap.selections || []).map((sel) => [sel.key, sel.pain]), primary: bodyMap.primary || null };
}

function bodyMapEntries(bodyMap) {
  if (!bodyMap || !Array.isArray(bodyMap.selections)) return [];
  return bodyMap.selections
    .map((sel) => ({ sel, key: sel.key, def: BODY_SYMPTOM_INDEX[sel.symptom], area: BODY_AREA_INDEX[sel.area] }))
    .filter((entry) => entry.def && entry.area);
}

/* "Right knee: pain" for symptoms that depend on the area, "Cough" otherwise. */
function bodyEntryLabel(entry) {
  return entry.def.perArea ? `${entry.area.label}: ${entry.def.label.toLowerCase()}` : entry.def.label;
}

/* ---------- Deriving the complaint, answers and extra findings ---------- */

/* Numbness or weakness in an arm and a leg on the same side of the body. */
function hasOneSidedNeuroPicks(entries) {
  const neuro = entries.filter((entry) => entry.def.perArea === 'neuro_area');
  return ['right', 'left'].some((side) => uniqueBy(neuro.filter((entry) => entry.area.side === side).map((entry) => entry.area.limb), (item) => item).length > 1);
}

/* Unless the receptionist chooses, the first pick is the main problem;
   one-sided numbness or weakness comes first, because only its own
   questions can show whether it started suddenly. */
function defaultMainPick(entries) {
  if (hasOneSidedNeuroPicks(entries)) return entries.find((entry) => entry.def.perArea === 'neuro_area');
  return entries[0];
}

function combineBodyContext(key, entries) {
  if (key === 'neuro_area') {
    const limbs = uniqueBy(entries.map((entry) => `${entry.area.side}-${entry.area.limb}`), (item) => item);
    const sides = uniqueBy(entries.map((entry) => entry.area.side), (item) => item);
    if (limbs.length <= 1) return 'one_limb';
    if (sides.length === 1) return 'one_side';
    // Both sides: "both hands or both feet" only when the same kind of limb
    // is affected on each side; otherwise the main pick's own limb is used.
    return uniqueBy(entries.map((entry) => entry.area.limb), (item) => item).length === 1 ? 'hands_feet' : 'one_limb';
  }
  const rule = BODY_CONTEXT_RULES[key];
  const values = uniqueBy(entries.map((entry) => (entry.area.context || {})[key]).filter(Boolean), (item) => item);
  return rule && values.length >= rule.min ? rule.multi : null;
}

/* The answers one picked symptom gives, with '@key' filled in from the
   combined value (if any) or the area's own context. */
function resolveBodyAnswers(entry, combined = {}) {
  const answers = {};
  Object.entries(entry.def.answers || {}).forEach(([questionId, value]) => {
    if (typeof value === 'string' && value.startsWith('@')) {
      const key = value.slice(1);
      let resolved = hasOwn(combined, key) ? combined[key] : (entry.area.context || {})[key];
      if (key === 'neuro_area' && resolved === undefined) resolved = 'one_limb';
      if (resolved !== undefined && resolved !== null) answers[questionId] = resolved;
    } else {
      answers[questionId] = value;
    }
  });
  return answers;
}

function positiveFeatures(question, value) {
  const { features } = encodeAnswer(question, value);
  return Object.entries(features)
    .filter(([key, v]) => typeof v === 'number' && v > 0 && !BODY_EXTRA_EXCLUDED.has(key) && !key.startsWith('complaint_'));
}

/**
 * Turns body-map picks into
 *   complaint   the main complaint (the main problem's complaint)
 *   answers     decision-tree answers given by the picks of that complaint
 *               (picks that would contradict an earlier pick are kept as
 *               extra findings instead), plus their pain rating
 *   extras      features recorded by the other picks; they fill features
 *               the questionnaire leaves unknown, and only warning-sign
 *               findings (BODY_WARNING_FEATURES) override a "no" answer
 * Returns null when nothing is picked (or in list mode).
 */
function deriveFromBodyMap(bodyMap) {
  if (!bodyMap || bodyMap.mode !== 'map') return null;
  const entries = bodyMapEntries(bodyMap);
  if (!entries.length) return null;
  const primary = entries.find((entry) => entry.key === bodyMap.primary) || defaultMainPick(entries);
  const complaint = primary.def.complaint;
  const group = [primary, ...entries.filter((entry) => entry !== primary && entry.def.complaint === complaint)];

  // Combined area answers. Numbness and weakness are combined per symptom
  // (numbness in both hands is "both hands"; numbness in one hand with
  // weakness in the other is not), with a separate one-side check below.
  const combined = {};
  uniqueBy(group.map((entry) => entry.def.perArea).filter(Boolean), (key) => key).forEach((key) => {
    const members = group.filter((entry) => entry.def.perArea === key);
    const lead = key === 'neuro_area' ? members[0].def.id : null;
    const value = combineBodyContext(key, lead ? members.filter((entry) => entry.def.id === lead) : members);
    if (value) combined[key] = value;
  });

  const answers = {};
  const merged = [];
  const secondary = entries.filter((entry) => !group.includes(entry));
  group.forEach((entry) => {
    const resolved = resolveBodyAnswers(entry, combined);
    const conflict = Object.entries(resolved).some(([id, value]) => hasOwn(answers, id) && !answersEqual(answers[id], value));
    if (conflict) {
      secondary.push(entry);
      return;
    }
    Object.assign(answers, resolved);
    merged.push(entry);
  });

  // Pain: the worst rating among the picks merged into the main problem
  // (for example both knees). Other picks never set the main pain score.
  merged.forEach((entry) => {
    const pain = entry.def.pain;
    if (!pain || !Number.isInteger(entry.sel.pain)) return;
    const current = answers[pain.question];
    answers[pain.question] = Number.isInteger(current) ? Math.max(current, entry.sel.pain) : entry.sel.pain;
  });

  const extras = {};
  const put = (key, value) => {
    if (value === null || value === undefined || !FEATURE_INDEX[key]) return;
    extras[key] = hasOwn(extras, key) ? Math.max(extras[key], value) : value;
  };
  entries.forEach((entry) => Object.entries(entry.def.features || {}).forEach(([key, value]) => put(key, value)));

  // Symptoms in an arm and a leg on the same side of the body count as
  // one-sided symptoms (a warning sign until the questions show otherwise).
  if (hasOneSidedNeuroPicks(entries)) put('focalOneSided', 1);

  // A combined answer (such as "Several joints") replaces each area's own
  // value; keep what those values record (for example a leg joint).
  merged.forEach((entry) => {
    const key = entry.def.perArea;
    if (!key || key === 'neuro_area' || !hasOwn(combined, key)) return;
    const question = getQuestion(key);
    const own = (entry.area.context || {})[key];
    if (question && own) positiveFeatures(question, own).forEach(([feature, value]) => put(feature, value));
  });

  secondary.forEach((entry) => {
    Object.entries(resolveBodyAnswers(entry)).forEach(([id, value]) => {
      const question = getQuestion(id);
      if (!question) return;
      positiveFeatures(question, value)
        .filter(([feature]) => !BODY_ROUTING_FEATURES.has(feature))
        .forEach(([feature, v]) => put(feature, v));
    });
    // The complaint's own presets (such as "fever" for the fever questions)
    // are not added for other picks: a pick records only what it says.
    const pain = entry.def.pain;
    if (pain && Number.isInteger(entry.sel.pain)) {
      if (pain.scale === 'chest') put('chestPainScore', entry.sel.pain);
      else if (entry.sel.pain >= 7) put('severeOtherPain', 1);
    }
  });

  return {
    complaint,
    answers,
    extras,
    primaryKey: primary.key,
    mergedKeys: merged.map((entry) => entry.key),
    secondaryKeys: secondary.map((entry) => entry.key),
    signature: JSON.stringify({ complaint, answers, extras }),
  };
}

/* Extra findings from the applied body map (null when not in use). */
function bodyMapExtras(assessment) {
  const bm = assessment && assessment.bodyMap;
  if (!bm || bm.mode !== 'map' || !bm.applied || !bm.applied.extras) return null;
  if (!assessment.patient || bm.applied.complaint !== assessment.patient.complaint) return null;
  return bm.applied.extras;
}

/* Question ids whose current answer came from the body map. */
function bodyMapAnsweredIds(assessment = state.assessment) {
  const bm = assessment.bodyMap;
  const ids = new Set();
  if (!bm || bm.mode !== 'map' || !bm.applied || bm.applied.complaint !== assessment.patient.complaint) return ids;
  Object.entries(bm.applied.answers || {}).forEach(([id, value]) => {
    if (hasOwn(assessment.answers, id) && answersEqual(assessment.answers[id], value)) ids.add(id);
  });
  return ids;
}

/* Pre-selection for a question from the body map's extra findings: "Yes"
   for a yes/no question, ticked options for a multi-select question. */
function bodyMapSuggestion(question, assessment = state.assessment) {
  const extras = bodyMapExtras(assessment);
  if (!extras || !question) return undefined;
  if (question.type === 'yesno' && question.featureKey && extras[question.featureKey] === 1) return 'yes';
  if (question.type === 'multi') {
    const ticked = question.options
      .filter((option) => !option.exclusive && option.feature && extras[option.feature] === 1)
      .map((option) => option.value);
    return ticked.length ? ticked : undefined;
  }
  return undefined;
}

/* While body-map changes are not applied yet, warning signs are checked
   against what applying them would record. Returns null when nothing is
   pending, or { source } where source may be null (nothing picked). */
function bodyMapPreview(assessment) {
  const bm = assessment.bodyMap;
  if (!bm || bm.mode !== 'map' || !bodyMapPending(assessment)) return null;
  const derived = deriveFromBodyMap(bm);
  if (!derived) {
    // Nothing picked any more: keep checking the answers already given.
    if (!bm.applied || bm.applied.complaint !== assessment.patient.complaint) return null;
    return { source: { patient: assessment.patient, answers: assessment.answers, bodyMap: { ...bm, applied: null } } };
  }
  // The warning-sign check is the last question on every route, so its
  // answer still counts while the main problem changes.
  const kept = hasOwn(assessment.answers, 'safety_check') ? { safety_check: assessment.answers.safety_check } : {};
  const answers = derived.complaint === assessment.patient.complaint
    ? { ...assessment.answers, ...derived.answers }
    : { ...kept, ...derived.answers };
  return {
    source: {
      patient: { ...assessment.patient, complaint: derived.complaint },
      answers,
      bodyMap: { ...bm, applied: { complaint: derived.complaint, answers: derived.answers, extras: derived.extras, signature: derived.signature } },
    },
  };
}

/* Applies the body map (or the list choice): sets the main complaint,
   records the answers it gives and drops answers that no longer apply.
   Answers the receptionist changed later are kept unless the body-map
   pick behind them changed. */
function applyBodyMap() {
  const a = state.assessment;
  const bm = a.bodyMap;
  let complaint = '';
  let derived = null;
  if (bm.mode === 'list') {
    complaint = getComplaint(bm.listComplaint) ? bm.listComplaint : '';
    if (!complaint) return { error: 'Choose the patient’s main complaint to continue.' };
  } else {
    derived = deriveFromBodyMap(bm);
    if (!derived) return { error: 'Select at least one symptom on the body map, or choose from a list instead.' };
    complaint = derived.complaint;
  }

  const before = JSON.stringify({ complaint: a.patient.complaint, answers: a.answers, extras: bodyMapExtras(a) });
  const previous = bm.applied && bm.applied.complaint === a.patient.complaint ? bm.applied : null;
  const complaintChanged = a.patient.complaint !== complaint;

  if (derived) {
    if (previous) {
      Object.entries(previous.answers || {}).forEach(([id, value]) => {
        if (!hasOwn(derived.answers, id) && answersEqual(a.answers[id], value)) delete a.answers[id];
      });
    }
    Object.entries(derived.answers).forEach(([id, value]) => {
      const pickChanged = !previous || !answersEqual(previous.answers[id], value);
      if (complaintChanged || pickChanged || !hasOwn(a.answers, id)) a.answers[id] = deepClone(value);
    });
    bm.applied = {
      complaint,
      answers: deepClone(derived.answers),
      extras: deepClone(derived.extras),
      signature: derived.signature,
      picks: bodyMapPicksKey(bm),
      addedWarnings: previous && Array.isArray(previous.addedWarnings) ? previous.addedWarnings.slice() : [],
    };
  } else {
    bm.applied = null;
  }

  a.patient.complaint = complaint;
  const removed = clearObsoleteBranchAnswers()
    .filter((id) => !(previous && hasOwn(previous.answers || {}, id)));
  syncWarningAnswer(a);
  const after = JSON.stringify({ complaint: a.patient.complaint, answers: a.answers, extras: bodyMapExtras(a) });
  if (before !== after) {
    invalidateDerivedResults();
    if (a.endedEarly && currentSequence().complete) a.endedEarly = false;
  }
  return { removed, changed: before !== after };
}

function continueFromBodyMap() {
  const answeredBefore = Object.keys(state.assessment.answers).length;
  const result = applyBodyMap();
  if (result.error) {
    state.ui.bmError = result.error;
    rerenderBodyMap('bm-error');
    return;
  }
  state.ui.bmError = '';
  state.ui.branchNotice = result.removed.length && answeredBefore ? buildBranchNotice(result.removed) : null;
  refreshSafetyState();
  persistDraft();

  const sequence = currentSequence();
  if (state.ui.returnTo === 'review' && sequence.complete) {
    reviewAssessment();
    return;
  }
  state.ui.cursor = sequence.firstUnanswered >= 0 ? sequence.firstUnanswered : firstQuestionToShow(sequence);
  state.ui.pending = undefined;
  state.ui.questionError = '';
  state.ui.direction = 'forward';
  navigateTo('questionnaire');
}

/* What the receptionist picked (symptoms, pain ratings, main problem). */
function bodyMapPicksKey(bodyMap) {
  return JSON.stringify(bodyMapSnapshot({ ...bodyMap, mode: 'map' }));
}

/* Keeps the final warning-sign answer in step with warning signs picked on
   the body map: a picked sign (fainting, heavy bleeding) is ticked there
   too, and a sign that was ticked only because of the body map is
   unticked again when the pick is removed. Signs the receptionist ticked
   in the question are never removed. If nothing is left ticked, the
   question is asked again rather than assumed to be "None of these". */
function syncWarningAnswer(assessment) {
  const bm = assessment.bodyMap;
  if (!bm || !bm.applied) return;
  if (!hasOwn(assessment.answers, 'safety_check')) {
    bm.applied.addedWarnings = [];
    return;
  }
  const question = getQuestion('safety_check');
  const extras = bm.applied.extras || {};
  const implied = question.options.filter((option) => !option.exclusive && option.feature && extras[option.feature] === 1).map((option) => option.value);
  const added = Array.isArray(bm.applied.addedWarnings) ? bm.applied.addedWarnings : [];
  let answer = (Array.isArray(assessment.answers.safety_check) ? assessment.answers.safety_check : [])
    .filter((value) => !(added.includes(value) && !implied.includes(value)));
  const toAdd = implied.filter((value) => !answer.includes(value));
  if (toAdd.length) answer = answer.filter((value) => value !== 'none').concat(toAdd);
  bm.applied.addedWarnings = uniqueBy([...added.filter((value) => implied.includes(value)), ...toAdd], (value) => value);
  if (!answer.length) {
    delete assessment.answers.safety_check;
    return;
  }
  assessment.answers.safety_check = question.options.map((option) => option.value).filter((value) => answer.includes(value));
}

/* True when the Symptoms step has changes that were not applied with
   Continue (different picks, or a different complaint chosen from the
   list). Review and Run wait until they are applied, so the result always
   matches what the screens show. */
function bodyMapPending(assessment = state.assessment) {
  const bm = assessment.bodyMap;
  if (!bm) return false;
  if (bm.mode === 'list') return Boolean(getComplaint(bm.listComplaint)) && bm.listComplaint !== assessment.patient.complaint;
  const derived = deriveFromBodyMap(bm);
  if (!derived) return Boolean(bm.applied);
  if (!bm.applied || bm.applied.complaint !== derived.complaint || assessment.patient.complaint !== derived.complaint) return true;
  if (bm.applied.picks) return bm.applied.picks !== bodyMapPicksKey(bm);
  // Applied before picks were recorded with it: compare the answers given.
  return !answersEqual(bm.applied.answers, derived.answers);
}

/* A "0 out of 10" pain answer is expected, not a contradiction, when the
   main problem picked on the body map is not a pain (swelling, a stiff
   neck, a racing heartbeat...). */
function bodyMapPainNotReported(assessment) {
  const bm = assessment.bodyMap;
  if (!bm || bm.mode !== 'map' || !bm.applied || bm.applied.complaint !== assessment.patient.complaint) return false;
  const derived = deriveFromBodyMap(bm);
  if (!derived) return false;
  const merged = bodyMapEntries(bm).filter((entry) => derived.mergedKeys.includes(entry.key));
  return merged.length > 0 && merged.every((entry) => !entry.def.pain);
}

function consistencyContext(assessment) {
  return { complaint: assessment.patient.complaint, painNotReported: bodyMapPainNotReported(assessment) };
}

/* First question on the route that the body map did not answer. */
function firstQuestionToShow(sequence = currentSequence()) {
  const fromMap = bodyMapAnsweredIds();
  const index = sequence.path.findIndex((id) => !fromMap.has(id));
  return index >= 0 ? index : 0;
}

/* ---------- Changes made on the screen ---------- */

function afterBodyMapChange(focusKey) {
  state.ui.bmError = '';
  refreshSafetyState();
  rerenderBodyMap(focusKey);
  persistDraft();
}

function toggleBodySymptom(symptomId, areaId, checked) {
  const bm = state.assessment.bodyMap;
  if (!BODY_SYMPTOM_INDEX[symptomId] || !BODY_AREA_INDEX[areaId]) return;
  const key = bodySelectionKey(symptomId, areaId);
  if (checked) {
    if (!bm.selections.some((sel) => sel.key === key)) bm.selections.push({ key, symptom: symptomId, area: areaId, pain: null });
    state.ui.bmHint = null;
  } else {
    bm.selections = bm.selections.filter((sel) => sel.key !== key);
    if (bm.primary === key) bm.primary = null;
  }
  afterBodyMapChange();
}

function removeBodySelection(key) {
  const bm = state.assessment.bodyMap;
  const index = bm.selections.findIndex((sel) => sel.key === key);
  if (index < 0) return;
  bm.selections.splice(index, 1);
  if (bm.primary === key) bm.primary = null;
  const next = bm.selections[index] || bm.selections[index - 1];
  afterBodyMapChange(next ? `bm-remove-${next.key}` : 'bm-selected-title');
}

function setBodyPain(key, value) {
  const sel = state.assessment.bodyMap.selections.find((item) => item.key === key);
  if (!sel || !Number.isInteger(value) || value < 0 || value > 10) return;
  sel.pain = value;
  afterBodyMapChange();
}

function setBodyPrimary(key) {
  const bm = state.assessment.bodyMap;
  if (!bm.selections.some((sel) => sel.key === key)) return;
  bm.primary = key;
  afterBodyMapChange();
}

function setBodyMapMode(mode, { confirmed = false } = {}) {
  const a = state.assessment;
  const bm = a.bodyMap;
  const picks = bodyMapEntries(bm);
  if (mode === 'list' && bm.mode === 'map' && picks.length && !confirmed) {
    const warnings = picks.filter((entry) => entry.def.warning).map((entry) => bodyEntryLabel(entry));
    rerenderBodyMap('bm-mode-map'); // put the switch back first, so focus returns there
    openModal({
      tone: 'warning',
      icon: 'triangle-alert',
      title: 'Choose from the list instead?',
      text: `The ${pluralise(picks.length, 'symptom')} picked on the body map will not be used while the list is chosen${warnings.length ? `, including the warning sign “${warnings.join('”, “')}”` : ''}. They stay saved, so switching back to the body map keeps them.`,
      actions: [
        { label: 'Keep the body map', variant: 'secondary', autofocus: true, onClick: () => rerenderBodyMap('bm-mode-map') },
        { label: 'Use the list', variant: 'primary', onClick: () => setBodyMapMode('list', { confirmed: true }) },
      ],
    });
    return;
  }
  bm.mode = mode === 'list' ? 'list' : 'map';
  if (bm.mode === 'list' && !bm.listComplaint && getComplaint(a.patient.complaint)) bm.listComplaint = a.patient.complaint;
  state.ui.bmQuery = '';
  afterBodyMapChange(`bm-mode-${bm.mode}`);
}

function setListComplaint(id) {
  if (!getComplaint(id)) return;
  state.assessment.bodyMap.listComplaint = id;
  state.ui.bmError = '';
  const slot = document.getElementById('bm-error');
  if (slot) slot.innerHTML = '';
  persistDraft();
}

function setBodyView(view) {
  state.ui.bmView = view === 'back' ? 'back' : 'front';
  const area = state.ui.bmArea;
  if (area && ((state.ui.bmView === 'back' && BODY_FRONT_ONLY.has(area)) || (state.ui.bmView === 'front' && BODY_BACK_ONLY.has(area)))) {
    state.ui.bmArea = null;
  }
  rerenderBodyMap();
}

/* Opens a body part's symptom list. Keyboard and search users are taken
   to the list; pointer users keep their place on the figure. */
function openBodyArea(areaId, { moveFocus = false } = {}) {
  if (!BODY_AREA_INDEX[areaId]) return;
  state.ui.bmArea = areaId;
  if (BODY_BACK_ONLY.has(areaId)) state.ui.bmView = 'back';
  if (BODY_FRONT_ONLY.has(areaId)) state.ui.bmView = 'front';
  rerenderBodyMap(moveFocus ? 'bm-panel-title' : undefined);
  const panel = document.getElementById('bm-panel');
  if (panel && window.matchMedia && window.matchMedia('(max-width: 1100px)').matches) {
    panel.scrollIntoView({ block: 'start', behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
  }
}

function closeBodyArea() {
  const areaId = state.ui.bmArea;
  state.ui.bmArea = null;
  rerenderBodyMap(areaId ? `bm-region-${areaId}` : undefined);
}

function editBodyMap(fromReview = false) {
  if (fromReview) state.ui.returnTo = 'review';
  state.ui.bmError = '';
  state.ui.bmQuery = '';
  navigateTo('bodymap');
}

/* Re-renders the screen and puts focus back where it was. */
function rerenderBodyMap(focusKey) {
  const active = document.activeElement;
  const key = focusKey || (active && active.dataset ? active.dataset.focusKey : undefined);
  render({ focus: false });
  if (!key) return;
  const target = document.querySelector(`[data-focus-key="${key.replace(/["\\]/g, '\\$&')}"]`)
    || document.getElementById(key);
  if (target) {
    if (!target.hasAttribute('tabindex') && !/^(INPUT|BUTTON|A|TEXTAREA|SELECT)$/.test(target.tagName)) target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
  }
}

/* ---------- Search ---------- */

/* Where symptoms found by search are filed when they belong to several
   body parts (otherwise the first body part that lists them). */
const BODY_SEARCH_HOME = { nausea: 'abd_um', acidity: 'abd_um', diarrhoea: 'abd_lm', constipation: 'abd_lm', gi_blood: 'abd_lm' };

function homeAreaFor(symptomId) {
  if (BODY_SEARCH_HOME[symptomId]) return BODY_SEARCH_HOME[symptomId];
  const area = BODY_AREAS.find((item) => bodyAreaSymptomIds(item).includes(symptomId));
  return area ? area.id : null;
}

function bodyAreaSymptomIds(area) {
  return area.groups ? area.groups.flatMap((group) => group.symptoms) : area.symptoms || [];
}

function areasListing(symptomId) {
  return BODY_AREAS.filter((area) => bodyAreaSymptomIds(area).includes(symptomId));
}

/**
 * Search results, best first:
 *   pair     a symptom in a named body part ("knee pain" → Right knee: pain)
 *   symptom  a symptom that means the same anywhere (added to its home part)
 *   choose   a symptom that needs a body part ("numbness"): the matching
 *            parts are highlighted on the figure
 *   area     a body part, opened to show its symptoms
 */
function bodySearch(query) {
  const trimmed = String(query || '').trim().toLowerCase();
  const terms = trimmed.split(/\s+/).filter(Boolean);
  if (!terms.length || terms.join('').length < 2) return [];
  const picked = new Set(state.assessment.bodyMap.selections.map((sel) => sel.key));
  const symptomText = (def) => `${def.label} ${def.searchLabel || ''} ${def.hint || ''} ${def.keywords || ''}`.toLowerCase();
  const areaText = (area) => `${area.label} ${area.group || ''} ${area.limb || ''} ${BODY_AREA_KEYWORDS[area.id] || ''} ${BODY_AREA_KEYWORDS[area.id.replace(/_[rl]$/, '')] || ''}`.toLowerCase();
  const pairs = [];
  const symptoms = [];
  const choose = [];
  const areas = [];
  BODY_SYMPTOMS.forEach((def) => {
    const sText = symptomText(def);
    const bySymptom = terms.every((term) => sText.includes(term));
    if (def.perArea) {
      const listing = areasListing(def.id);
      listing.forEach((area) => {
        const aText = areaText(area);
        const all = terms.every((term) => sText.includes(term) || aText.includes(term));
        const namesPlace = terms.some((term) => aText.includes(term));
        const namesSymptom = terms.some((term) => sText.includes(term));
        if (all && namesSymptom && (namesPlace || (bySymptom && listing.length <= 2))) {
          const key = bodySelectionKey(def.id, area.id);
          pairs.push({ kind: 'pair', id: def.id, area: area.id, label: `${area.label}: ${def.label.toLowerCase()}`, meta: picked.has(key) ? 'Already added' : 'Add to the list' });
        }
      });
      if (bySymptom && listing.length > 2) {
        choose.push({ kind: 'choose', id: def.id, label: def.searchLabel || def.label, meta: 'Select where on the body', exact: false });
      }
      return;
    }
    if (!bySymptom) return;
    const home = homeAreaFor(def.id);
    if (!home) return;
    symptoms.push({
      kind: 'symptom', id: def.id, area: home, label: def.label, warning: Boolean(def.warning),
      meta: `${BODY_AREA_INDEX[home].label}${picked.has(def.id) ? ' · already added' : ''}`,
      exact: def.label.toLowerCase() === trimmed,
    });
  });
  BODY_AREAS.forEach((area) => {
    if (terms.every((term) => areaText(area).includes(term))) areas.push({ kind: 'area', id: area.id, label: area.label, meta: 'Body part: see its symptoms' });
  });
  return uniqueBy([...pairs, ...symptoms, ...choose, ...areas], (item) => `${item.kind}:${item.id}:${item.area || ''}`).slice(0, 8);
}

function renderSearchResults(query) {
  const trimmed = String(query || '').trim();
  if (!trimmed) return '';
  const results = bodySearch(trimmed);
  if (!results.length) {
    return html`<p class="bm-results__empty">No match for “${trimmed}”. Try another word, or select a body part.</p>`;
  }
  const iconFor = { pair: 'plus', symptom: 'plus', choose: 'person-standing', area: 'person-standing' };
  return html`
    <p class="visually-hidden" role="status">${pluralise(results.length, 'result')}</p>
    <ul class="bm-results__list">
      ${results.map((item, index) => html`
        <li><button type="button" class="bm-result" data-action="bm-search-pick" data-kind="${item.kind}" data-id="${item.id}" data-area="${item.area || ''}" data-focus-key="bm-result-${index}" ${item.exact ? raw('data-exact="true"') : ''}>
          <span class="bm-result__icon" aria-hidden="true">${icon(iconFor[item.kind])}</span>
          <span class="bm-result__text"><span class="bm-result__label">${item.label}</span><span class="bm-result__meta">${item.warning ? 'Warning sign · ' : ''}${item.meta}</span></span>
        </button></li>`)}
    </ul>`;
}

function updateBodySearch(value) {
  state.ui.bmQuery = value;
  const box = document.getElementById('bm-search-results');
  if (!box) return;
  box.innerHTML = String(renderSearchResults(value));
  box.hidden = !String(value).trim();
}

function addBodyPick(symptomId, areaId) {
  const bm = state.assessment.bodyMap;
  const key = bodySelectionKey(symptomId, areaId);
  if (!bm.selections.some((sel) => sel.key === key)) bm.selections.push({ key, symptom: symptomId, area: areaId, pain: null });
  return key;
}

function showBodyArea(areaId) {
  state.ui.bmArea = areaId;
  if (BODY_BACK_ONLY.has(areaId)) state.ui.bmView = 'back';
  if (BODY_FRONT_ONLY.has(areaId)) state.ui.bmView = 'front';
}

function pickBodySearchResult(kind, id, areaId) {
  state.ui.bmQuery = '';
  state.ui.bmHint = null;
  if (kind === 'symptom' || kind === 'pair') {
    const area = kind === 'pair' ? areaId : homeAreaFor(id);
    if (!BODY_SYMPTOM_INDEX[id] || !BODY_AREA_INDEX[area]) return;
    const key = addBodyPick(id, area);
    showBodyArea(area);
    afterBodyMapChange(`bm-sym-${key}`);
    return;
  }
  if (kind === 'choose') {
    // Highlight the body parts that list this symptom and ask for one.
    state.ui.bmHint = id;
    state.ui.bmArea = null;
    const frontHas = BODY_FIGURE.views.front.some((region) => bodyAreaSymptomIds(BODY_AREA_INDEX[region.area]).includes(id));
    if (!frontHas) state.ui.bmView = 'back';
    rerenderBodyMap('bm-figure-title');
    return;
  }
  openBodyArea(id, { moveFocus: true });
}

/* ---------- Rendering ---------- */

function renderBodyMapScreen() {
  const a = state.assessment;
  const bm = a.bodyMap;
  const listMode = bm.mode === 'list';
  const patientLine = [a.patient.name, a.patient.age ? `${a.patient.age} yrs` : '', a.patient.gender ? genderLabel(a.patient.gender) : '']
    .filter(Boolean).join(', ');

  return html`
    <section class="screen screen--flow screen--bodymap">
      ${renderUrgentBanner('bodymap')}
      <div class="flow-head">
        <div>
          <h1 class="screen-title" tabindex="-1">${listMode ? 'What is the main problem today?' : 'Where are the symptoms?'}</h1>
          <p class="screen-lead">${listMode
            ? 'Choose the patient’s main reason for the visit. The questions that follow depend on it.'
            : 'Select the part of the body that is bothering the patient, then tick what they feel there. Add as many body parts as needed.'}</p>
          ${patientLine ? html`<p class="bm-patient">${icon('user')}<span>${patientLine}</span></p>` : ''}
        </div>
        <div class="segmented bm-mode" role="radiogroup" aria-label="How to record the symptoms">
          <label class="segmented__item"><input type="radio" name="bm-mode" value="map" data-bm-mode data-focus-key="bm-mode-map" ${listMode ? '' : raw('checked')}><span>${icon('person-standing')}Body map</span></label>
          <label class="segmented__item"><input type="radio" name="bm-mode" value="list" data-bm-mode data-focus-key="bm-mode-list" ${listMode ? raw('checked') : ''}><span>${icon('list')}Choose from a list</span></label>
        </div>
      </div>
      ${listMode ? renderComplaintPicker() : renderBodyMapWorkspace()}
      <div class="bm-actions">
        <button type="button" class="btn btn-ghost" data-action="edit-patient">${icon('chevron-left')}<span>Patient details</span></button>
        <button type="button" class="btn btn-ghost" data-action="cancel-assessment">${icon('x')}<span>Cancel assessment</span></button>
      </div>
    </section>`;
}

function renderComplaintPicker() {
  const bm = state.assessment.bodyMap;
  return html`
    <section class="card bm-list-card" aria-labelledby="bm-list-title">
      <h2 class="bm-card-title" id="bm-list-title">Main complaint</h2>
      <div class="complaint-grid" role="radiogroup" aria-labelledby="bm-list-title">
        ${COMPLAINTS.map((complaint) => html`
          <label class="q-option q-option--complaint">
            <input class="q-option__input" type="radio" name="complaint" value="${complaint.id}" data-bm-complaint data-focus-key="bm-complaint-${complaint.id}"
              ${bm.listComplaint === complaint.id ? raw('checked') : ''}>
            <span class="q-option__face">
              <span class="q-option__icon">${icon(complaint.icon)}</span>
              <span class="q-option__text">
                <span class="q-option__label">${complaint.label}</span>
                <span class="q-option__hint">${complaint.hint}</span>
              </span>
              <span class="q-option__mark" aria-hidden="true">${icon('check')}</span>
            </span>
          </label>`)}
      </div>
      <p class="field__error bm-error" id="bm-error" role="alert" tabindex="-1">${state.ui.bmError ? html`${icon('circle-alert')}<span>${state.ui.bmError}</span>` : ''}</p>
      <footer class="bm-list-card__foot">
        <button type="button" class="btn btn-primary btn-lg" data-action="bm-continue" data-focus-key="bm-continue"><span>Continue to questions</span>${icon('chevron-right')}</button>
      </footer>
    </section>`;
}

function renderBodyMapWorkspace() {
  const bm = state.assessment.bodyMap;
  const entries = bodyMapEntries(bm);
  const view = state.ui.bmView === 'back' ? 'back' : 'front';
  const openArea = BODY_AREA_INDEX[state.ui.bmArea] || null;
  const counts = entries.reduce((tally, entry) => ({ ...tally, [entry.area.id]: (tally[entry.area.id] || 0) + 1 }), {});

  return html`
    <div class="bm-layout">
      <section class="card bm-figure-card" aria-labelledby="bm-figure-title">
        <header class="bm-figure-card__head">
          <h2 class="bm-card-title" id="bm-figure-title">Select a body part</h2>
          <div class="segmented segmented--sm" role="radiogroup" aria-label="Body view">
            ${['front', 'back'].map((v) => html`
              <label class="segmented__item"><input type="radio" name="bm-view" value="${v}" data-bm-view data-focus-key="bm-view-${v}" ${view === v ? raw('checked') : ''}><span>${v === 'front' ? 'Front' : 'Back'}</span></label>`)}
          </div>
        </header>
        <div class="bm-quick">
          ${['skin', 'general'].map((id) => {
            const area = BODY_AREA_INDEX[id];
            const open = openArea && openArea.id === id;
            return html`
              <button type="button" class="bm-area-btn${open ? ' is-open' : ''}" data-action="bm-open-area" data-area="${id}" data-focus-key="bm-region-${id}" aria-pressed="${open ? 'true' : 'false'}">
                ${icon(id === 'skin' ? 'skin' : 'thermometer')}
                <span class="bm-area-btn__text"><span class="bm-area-btn__label">${area.label}</span><span class="bm-area-btn__hint">${area.button}</span></span>
                ${counts[id] ? html`<span class="bm-count" aria-label="${pluralise(counts[id], 'symptom')} selected">${counts[id]}</span>` : ''}
              </button>`;
          })}
        </div>
        ${renderBodyFigure(view, counts, openArea)}
        <p class="visually-hidden">${view === 'front' ? 'Front view: the patient’s right side is on your left.' : 'Back view: the patient’s left side is on your left.'}</p>
      </section>

      <div class="bm-side">
        <section class="card bm-panel" id="bm-panel" aria-label="Symptoms">
          <div class="bm-search">
            <label class="visually-hidden" for="bm-search-input">Search symptoms or body parts</label>
            <span class="bm-search__icon" aria-hidden="true">${icon('search')}</span>
            <input id="bm-search-input" class="input bm-search__input" type="search" autocomplete="off" spellcheck="false"
              placeholder="Search symptoms or body parts, e.g. cough or knee" value="${state.ui.bmQuery || ''}"
              data-bm-search data-focus-key="bm-search" aria-controls="bm-search-results">
            <div class="bm-results" id="bm-search-results" ${String(state.ui.bmQuery || '').trim() ? '' : raw('hidden')}>${renderSearchResults(state.ui.bmQuery)}</div>
          </div>
          ${openArea ? renderAreaSymptoms(openArea, bm) : html`
            <div class="bm-placeholder${state.ui.bmHint ? ' bm-placeholder--hint' : ''}" role="status">
              <span class="bm-placeholder__icon" aria-hidden="true">${icon('person-standing')}</span>
              ${state.ui.bmHint && BODY_SYMPTOM_INDEX[state.ui.bmHint]
                ? html`<p class="bm-placeholder__title">Where is the ${(BODY_SYMPTOM_INDEX[state.ui.bmHint].searchLabel || BODY_SYMPTOM_INDEX[state.ui.bmHint].label).toLowerCase()}?</p>
                  <p>The body parts where it can be picked are highlighted. Select the one that is affected.</p>`
                : html`<p class="bm-placeholder__title">Select a body part to see its symptoms</p>
                  <p>Click the body, or use <strong>Skin</strong> and <strong>Whole body</strong> for symptoms that are not in one place.</p>`}
            </div>`}
        </section>
        ${renderSelectedSymptoms(entries, bm)}
      </div>
    </div>`;
}

function renderBodyFigure(view, counts, openArea) {
  const regions = BODY_FIGURE.views[view];
  const { width, height } = BODY_FIGURE;
  const hint = state.ui.bmHint;
  // Front view: the patient's right side is on the viewer's left. Back view: the opposite.
  const [leftLabel, rightLabel] = view === 'front' ? ['Right', 'Left'] : ['Left', 'Right'];
  const openRegion = openArea ? regions.find((region) => region.area === openArea.id) : null;
  return html`
    <div class="bm-figure">
      <svg class="bm-svg" viewBox="0 0 ${width} ${height}" role="group" aria-label="${view === 'front' ? 'Front' : 'Back'} of the body. Select a body part to see its symptoms.">
        <use class="bm-svg__art" href="#bm-art-${view}" aria-hidden="true"></use>
        <text class="bm-svg__side" x="14" y="40" aria-hidden="true">${leftLabel}</text>
        <text class="bm-svg__side" x="${width - 14}" y="40" text-anchor="end" aria-hidden="true">${rightLabel}</text>
        ${regions.map(({ area: areaId, d }) => {
          const area = BODY_AREA_INDEX[areaId];
          const n = counts[areaId] || 0;
          const open = Boolean(openArea && openArea.id === areaId);
          const hinted = hint && bodyAreaSymptomIds(area).includes(hint);
          return html`<path class="bm-region${n ? ' has-symptoms' : ''}${open ? ' is-open' : ''}${hinted ? ' is-hinted' : ''}" d="${d}"
            role="button" tabindex="0" data-action="bm-open-area" data-area="${areaId}" data-bm-region="${areaId}" data-focus-key="bm-region-${areaId}"
            aria-pressed="${open ? 'true' : 'false'}" aria-label="${area.label}${n ? `, ${pluralise(n, 'symptom')} selected` : ''}"><title>${area.label}</title></path>`;
        })}
        ${openRegion ? html`<path class="bm-region-outline" d="${openRegion.d}" aria-hidden="true"></path>` : ''}
        ${regions.filter(({ area }) => counts[area]).map(({ area, badge: [x, y] }) => html`
          <g class="bm-badge" aria-hidden="true"><circle cx="${x}" cy="${y}" r="19"></circle><text x="${x}" y="${y + 7.5}" text-anchor="middle">${counts[area]}</text></g>`)}
      </svg>
    </div>`;
}

function renderAreaSymptoms(area, bm) {
  const groups = area.groups || [{ label: '', symptoms: area.symptoms }];
  const eyebrow = area.group || (area.side ? (area.limb === 'arm' ? 'Arm' : 'Leg') : (['skin', 'general'].includes(area.id) ? 'Anywhere' : 'Body part'));
  return html`
    <div class="bm-area">
      <header class="bm-area__head">
        <div>
          <p class="bm-area__eyebrow">${eyebrow}</p>
          <h2 class="bm-area__title" id="bm-panel-title" tabindex="-1" data-focus-key="bm-panel-title">${area.label}</h2>
          <p class="bm-area__lead">${area.lead || 'Tick everything the patient feels here.'}${area.lead ? ' Tick everything that applies.' : ''}</p>
        </div>
        <button type="button" class="icon-button" data-action="bm-close-area" aria-label="Close ${area.label}">${icon('x')}</button>
      </header>
      ${groups.map((group) => html`
        <fieldset class="bm-group">
          <legend class="${group.label ? 'bm-group__title' : 'visually-hidden'}">${group.label || `Symptoms: ${area.label}`}</legend>
          <ul class="bm-syms">${group.symptoms.map((id) => renderBodySymptomOption(BODY_SYMPTOM_INDEX[id], area, bm))}</ul>
        </fieldset>`)}
    </div>`;
}

function renderBodySymptomOption(def, area, bm) {
  if (!def) return '';
  const key = bodySelectionKey(def.id, area.id);
  const sel = bm.selections.find((item) => item.key === key);
  const elsewhere = sel && sel.area !== area.id ? BODY_AREA_INDEX[sel.area] : null;
  const hasPain = Boolean(sel && def.pain);
  return html`
    <li class="bm-sym${sel ? ' is-checked' : ''}${hasPain ? ' has-pain' : ''}">
      <label class="bm-sym__row">
        <input type="checkbox" class="bm-sym__input" data-bm-symptom="${def.id}" data-bm-area="${area.id}" data-focus-key="bm-sym-${key}" ${sel ? raw('checked') : ''}>
        <span class="bm-sym__box" aria-hidden="true">${icon('check')}</span>
        <span class="bm-sym__text">
          <span class="bm-sym__label">${def.label}</span>
          ${def.hint ? html`<span class="bm-sym__hint">${def.hint}</span>` : ''}
          ${def.warning ? html`<span class="bm-sym__warn">${icon('triangle-alert')}Warning sign</span>` : ''}
          ${elsewhere ? html`<span class="bm-sym__hint">Added under ${elsewhere.label}</span>` : ''}
        </span>
      </label>
      ${hasPain ? renderBodyPain(sel, def, area) : ''}
    </li>`;
}

function renderBodyPain(sel, def, area) {
  const scale = PAIN_SCALES[def.pain.scale] || PAIN_SCALES.general;
  const value = Number.isInteger(sel.pain) ? sel.pain : null;
  const what = def.perArea ? `${def.label.toLowerCase()} in the ${area.label.toLowerCase()}` : def.label.toLowerCase();
  const items = [];
  for (let n = 0; n <= 10; n += 1) items.push(n);
  return html`
    <div class="bm-pain">
      <p class="bm-pain__q" id="bm-pain-q-${sel.key}">How bad is it right now? <span>0 is no pain</span></p>
      <div class="bm-pain__track" role="radiogroup" aria-labelledby="bm-pain-q-${sel.key}" aria-describedby="bm-pain-ends-${sel.key}">
        ${items.map((n) => html`
          <label class="bm-pain__item" data-band="${painBand(n).level}">
            <input class="q-option__input" type="radio" name="bm-pain-${sel.key}" value="${n}" data-bm-pain="${sel.key}" data-focus-key="bm-pain-${sel.key}-${n}"
              aria-label="${what}: ${n}, ${painBand(n).label.toLowerCase()}, ${describePainScore(scale, n)}" ${value === n ? raw('checked') : ''}>
            <span class="bm-pain__face">${n}</span>
          </label>`)}
      </div>
      <div class="bm-pain__ends" id="bm-pain-ends-${sel.key}">
        <p class="bm-pain__end bm-pain__end--low"><strong>1</strong><span>${scale.low}</span></p>
        <p class="bm-pain__end bm-pain__end--high"><span>${scale.high}</span><strong>10</strong></p>
      </div>
      <p class="bm-pain__readout">${value === null
        ? 'Optional here. If you skip it, the pain score is asked in the questions.'
        : painReadout(scale, value)}</p>
    </div>`;
}

/* Picks that could be the main problem: one per different outcome. A pick
   that would lead to the same questions as another one (swelling of the
   same knee as the pain) is not offered separately. */
function mainProblemCandidates(entries, primaryKey, bodyMap) {
  const seen = new Map();
  entries.forEach((entry) => {
    const derived = deriveFromBodyMap({ ...bodyMap, primary: entry.key });
    const signature = derived ? derived.signature : entry.key;
    if (!seen.has(signature) || entry.key === primaryKey) seen.set(signature, entry);
  });
  const chosen = new Set(seen.values());
  return entries.filter((entry) => chosen.has(entry));
}

function renderSelectedSymptoms(entries, bm) {
  const derived = deriveFromBodyMap(bm);
  const primaryKey = derived ? derived.primaryKey : null;
  const candidates = mainProblemCandidates(entries, primaryKey, bm);
  const needsChoice = Boolean(derived && derived.secondaryKeys.length && candidates.length > 1);
  const primaryEntry = entries.find((entry) => entry.key === primaryKey);
  return html`
    <section class="card bm-selected" aria-labelledby="bm-selected-title">
      <header class="bm-selected__head">
        <h2 class="bm-card-title" id="bm-selected-title" tabindex="-1" data-focus-key="bm-selected-title">Patient’s symptoms</h2>
        ${entries.length ? html`<span class="bm-count">${entries.length}</span>` : ''}
      </header>
      ${entries.length ? html`
        <ul class="bm-list">
          ${entries.map((entry) => {
            const pain = Number.isInteger(entry.sel.pain) ? entry.sel.pain : null;
            const meta = [entry.def.perArea ? '' : entry.area.label, entry.key === primaryKey && needsChoice ? 'Main problem' : '']
              .filter(Boolean).join(' · ');
            return html`
              <li class="bm-list__item">
                <button type="button" class="bm-list__open" data-action="bm-open-area" data-area="${entry.area.id}" data-focus-key="bm-open-${entry.key}">
                  <span class="bm-list__label">${bodyEntryLabel(entry)}</span>
                  ${meta ? html`<span class="bm-list__meta">${meta}</span>` : ''}
                </button>
                ${pain !== null ? html`<span class="bm-list__pain" data-band="${painBand(pain).level}">Pain ${pain}/10</span>` : ''}
                <button type="button" class="icon-button bm-list__remove" data-action="bm-remove" data-key="${entry.key}" data-focus-key="bm-remove-${entry.key}" aria-label="Remove ${bodyEntryLabel(entry)}">${icon('x')}</button>
              </li>`;
          })}
        </ul>
        ${needsChoice ? html`
          <div class="bm-primary">
            <fieldset class="bm-primary__set">
              <legend class="bm-primary__title">Which is the main problem today?</legend>
              <p class="bm-primary__hint">The follow-up questions start with it. Everything else is still recorded.</p>
              <div class="bm-primary__options">
                ${candidates.map((entry) => html`
                  <label class="bm-primary__option"><input type="radio" name="bm-primary" value="${entry.key}" data-bm-primary data-focus-key="bm-primary-${entry.key}" ${entry.key === primaryKey ? raw('checked') : ''}><span>${bodyEntryLabel(entry)}</span></label>`)}
              </div>
            </fieldset>
          </div>` : ''}`
        : html`<p class="bm-selected__empty">Nothing selected yet. Select a body part, or search above.</p>`}
      <p class="field__error bm-error" id="bm-error" role="alert" tabindex="-1">${state.ui.bmError ? html`${icon('circle-alert')}<span>${state.ui.bmError}</span>` : ''}</p>
      <button type="button" class="btn btn-primary btn-lg bm-continue" data-action="bm-continue" data-focus-key="bm-continue"><span>Continue to questions</span>${icon('chevron-right')}</button>
      ${primaryEntry ? html`<p class="bm-selected__note">The questions start with <strong>${bodyEntryLabel(primaryEntry).toLowerCase()}</strong>${derived.mergedKeys.length > 1 ? ` and ${pluralise(derived.mergedKeys.length - 1, 'related symptom')}` : ''}.</p>` : ''}
    </section>`;
}

/* The main problem in plain words: the body-map pick the questions start
   with, or the complaint chosen from the list. */
function mainProblemLabel(assessment) {
  const bm = assessment.bodyMap;
  if (bm && bm.mode === 'map' && bm.applied && bm.applied.complaint === assessment.patient.complaint) {
    const derived = deriveFromBodyMap(bm);
    const entry = derived && derived.complaint === assessment.patient.complaint
      ? bodyMapEntries(bm).find((item) => item.key === derived.primaryKey) : null;
    if (entry) return bodyEntryLabel(entry);
  }
  return complaintLabel(assessment.patient.complaint);
}

/* Compact list of the body-map picks, for the review screen, the
   questionnaire side panel and the report. */
function bodyMapSummary(assessment) {
  const bm = assessment.bodyMap;
  if (!bm || bm.mode !== 'map') return [];
  return bodyMapEntries(bm).map((entry) => ({
    key: entry.key,
    label: bodyEntryLabel(entry),
    area: entry.area.label,
    pain: Number.isInteger(entry.sel.pain) ? entry.sel.pain : null,
    text: `${bodyEntryLabel(entry)}${Number.isInteger(entry.sel.pain) ? ` (${entry.sel.pain}/10)` : ''}`,
  }));
}
