/* =====================================================================
   5. QUESTIONNAIRE ENGINE
   ---------------------------------------------------------------------
   The questionnaire is a route through QUESTION_TREE. The active route is
   always recomputed from the recorded answers, starting at the main
   complaint's entry question. Changing an earlier answer therefore
   changes every question that follows it, and answers that fall off the
   route are cleared (section 6).
   ===================================================================== */

function defineQuestions(list) {
  const tree = {};
  list.forEach((definition) => {
    const question = { required: true, ...definition };
    if (question.type === 'yesno' && !question.options) question.options = YES_NO_UNSURE_OPTIONS;
    tree[question.id] = Object.freeze(question);
  });
  return Object.freeze(tree);
}

function getQuestion(id) {
  return (id && hasOwn(QUESTION_TREE, id) && QUESTION_TREE[id]) || null;
}

function getComplaint(id) {
  return COMPLAINTS.find((complaint) => complaint.id === id) || null;
}

function getEntryQuestion(complaintId) {
  const complaint = getComplaint(complaintId);
  return complaint ? complaint.entry : null;
}

function findOption(question, value) {
  return (question.options || []).find((option) => option.value === value) || null;
}

function getUnit(question, unitValue) {
  const units = question.units || [];
  return units.find((unit) => unit.value === unitValue) || units[0];
}

function evaluateCondition(question, activeAnswers) {
  if (typeof question.condition !== 'function') return true;
  try {
    return Boolean(question.condition(activeAnswers));
  } catch (error) {
    return false;
  }
}

/* Resolves the id of the question that follows `question`.
   `next` may be an id, a map keyed by answer value, or a function. */
function resolveNext(question, answer, activeAnswers) {
  const { next } = question;
  if (next === null || next === undefined) return null;
  if (typeof next === 'string') return next;
  if (typeof next === 'function') {
    try {
      return next(answer, activeAnswers) || null;
    } catch (error) {
      return null;
    }
  }
  if (typeof answer === 'string' && hasOwn(next, answer)) return next[answer];
  return next.default || null;
}

function hasStaticNext(question) {
  return question.next === null || typeof question.next === 'string' || (question.lookAhead === true && typeof question.next === 'function');
}

function validateAnswer(question, value) {
  const emptyMessage = {
    multi: 'Select at least one option, or choose “None of these”.',
    number: 'Enter the temperature reading.',
    scale: `Choose a number from ${question.min} to ${question.max}.`,
  }[question.type] || 'Select an option to continue.';

  if (value === undefined || value === null || value === '') return emptyMessage;

  switch (question.type) {
    case 'multi':
      if (!Array.isArray(value) || value.length === 0) return emptyMessage;
      return value.every((v) => findOption(question, v)) ? null : emptyMessage;
    case 'scale':
      return Number.isInteger(value) && value >= question.min && value <= question.max ? null : emptyMessage;
    case 'number': {
      if (typeof value !== 'object') return emptyMessage;
      const unit = getUnit(question, value.unit);
      if (typeof value.value !== 'number' || !Number.isFinite(value.value)) return emptyMessage;
      if (value.value < unit.min || value.value > unit.max) {
        return `Enter a value between ${unit.min} and ${unit.max} ${unit.label}.`;
      }
      return null;
    }
    default:
      return findOption(question, value) ? null : emptyMessage;
  }
}

function isAnswerComplete(question, value) {
  return validateAnswer(question, value) === null;
}

/**
 * Walks the decision tree for the given answers.
 * Returns
 *   path             ids of the questions that apply, in the order asked
 *   activeAnswers    answers recorded on that route
 *   firstUnanswered  index in `path` of the first unanswered question (-1 if none)
 *   complete         every question on the route is answered and the tree ended
 * The walk looks ahead past an unanswered question only when the next
 * question does not depend on its answer, so answers further along a
 * shared route are kept when an earlier answer adds a new question.
 */
function buildQuestionSequence(answers, complaintId) {
  const path = [];
  const activeAnswers = {};
  const visited = new Set();
  let firstUnanswered = -1;
  let blocked = false;
  let id = getEntryQuestion(complaintId);

  if (!id) return { path, activeAnswers, firstUnanswered, complete: false };

  while (id) {
    if (visited.has(id)) { blocked = true; break; }
    visited.add(id);
    const question = getQuestion(id);
    if (!question) break;

    if (!evaluateCondition(question, activeAnswers)) {
      id = resolveNext(question, undefined, activeAnswers);
      continue;
    }

    path.push(id);
    const answered = hasOwn(answers, id) && isAnswerComplete(question, answers[id]);
    if (answered) {
      activeAnswers[id] = answers[id];
      id = resolveNext(question, answers[id], activeAnswers);
    } else {
      if (firstUnanswered === -1) firstUnanswered = path.length - 1;
      if (!hasStaticNext(question)) { blocked = true; break; }
      id = typeof question.next === 'function' ? resolveNext(question, undefined, activeAnswers) : question.next;
    }
  }

  return { path, activeAnswers, firstUnanswered, complete: path.length > 0 && firstUnanswered === -1 && !blocked };
}

/* The next question still to be answered, or null when the route is complete. */
function getNextQuestion(answers, complaintId) {
  const sequence = buildQuestionSequence(answers, complaintId);
  if (sequence.complete || sequence.firstUnanswered === -1) return null;
  return getQuestion(sequence.path[sequence.firstUnanswered]);
}

function currentSequence() {
  const a = state.assessment;
  return buildQuestionSequence(a.answers, a.patient.complaint);
}

/* Estimated route length: follows recorded answers, then the most typical
   branch for unanswered questions. Shown as "about N more", never as an
   exact promise, because later answers can change the route. */
function estimateQuestionCount(answers, complaintId) {
  const active = {};
  const visited = new Set();
  let id = getEntryQuestion(complaintId);
  let count = 0;
  while (id && !visited.has(id) && count < 60) {
    visited.add(id);
    const question = getQuestion(id);
    if (!question) break;
    if (!evaluateCondition(question, active)) {
      id = resolveNext(question, undefined, active);
      continue;
    }
    count += 1;
    const answer = hasOwn(answers, id) && isAnswerComplete(question, answers[id]) ? answers[id] : typicalAnswer(question);
    active[id] = answer;
    id = resolveNext(question, answer, active);
  }
  return count;
}

function typicalAnswer(question) {
  switch (question.type) {
    case 'yesno': return 'no';
    case 'multi': return ['none'];
    case 'scale': return 5;
    case 'number': return null;
    default: return question.options && question.options[0] ? question.options[0].value : null;
  }
}

function formatAnswer(question, value) {
  if (!question) return '';
  if (value === undefined || value === null) return 'Not answered';
  switch (question.type) {
    case 'multi': {
      const labels = (Array.isArray(value) ? value : [])
        .map((v) => findOption(question, v))
        .filter(Boolean)
        .map((option) => option.label);
      return labels.length ? labels.join('; ') : 'Not answered';
    }
    case 'scale':
      return Number.isInteger(value) ? `${value} / ${question.max} (${painBand(value).label.toLowerCase()})` : 'Not answered';
    case 'number': {
      if (!value || typeof value.value !== 'number') return 'Not answered';
      const unit = getUnit(question, value.unit);
      const celsius = unit.value === 'F' ? (value.value - 32) * (5 / 9) : value.value;
      const fahrenheit = unit.value === 'F' ? value.value : (value.value * 9) / 5 + 32;
      return unit.value === 'F'
        ? `${formatNumber(value.value)} °F (${formatNumber(round(celsius, 1))} °C)`
        : `${formatNumber(value.value)} °C (${formatNumber(round(fahrenheit, 1))} °F)`;
    }
    default: {
      const option = findOption(question, value);
      return option ? option.label : 'Not answered';
    }
  }
}

/* ---------------------------------------------------------------------
   Questionnaire rendering
   --------------------------------------------------------------------- */

function renderQuestionnaireScreen() {
  const a = state.assessment;
  const sequence = currentSequence();
  if (!a.patient.complaint || sequence.path.length === 0) {
    return html`<section class="screen screen--flow">
      ${renderEmptyState({
        icon: 'clipboard-list',
        title: 'Choose the symptoms first',
        text: 'The follow-up questions depend on the symptoms picked on the body map (or the main complaint chosen from the list).',
        action: { label: 'Go to the body map', action: 'edit-bodymap', icon: 'person-standing' },
      })}</section>`;
  }

  state.ui.cursor = clamp(state.ui.cursor, 0, sequence.path.length - 1);
  const question = getQuestion(sequence.path[state.ui.cursor]);
  const fromMap = bodyMapAnsweredIds(a);
  const demoValue = state.ui.demoAnswers ? state.ui.demoAnswers[question.id] : undefined;
  let value = state.ui.pending !== undefined ? state.ui.pending : a.answers[question.id];
  const fromDemo = value === undefined && demoValue !== undefined;
  if (fromDemo) value = demoValue;
  const suggestion = value === undefined ? bodyMapSuggestion(question, a) : undefined;
  if (suggestion !== undefined) value = suggestion;
  // Questions answered on the body map are not counted as questions asked here.
  const index = sequence.path.slice(0, state.ui.cursor + 1).filter((id) => !fromMap.has(id)).length;
  const estimate = Math.max(estimateQuestionCount(a.answers, a.patient.complaint) - fromMap.size, index, 1);
  const remaining = Math.max(0, estimate - index);

  return html`
    <section class="screen screen--flow screen--questionnaire">
      <h1 class="visually-hidden">Symptom questionnaire for ${textOr(a.patient.name, 'the patient')}</h1>
      ${renderUrgentBanner('questionnaire')}
      <div class="q-layout">
        ${renderQuestion(question, {
          index,
          estimate,
          remaining,
          value,
          fromDemo,
          fromMap: fromMap.has(question.id) && state.ui.pending === undefined,
          suggested: suggestion !== undefined,
          error: state.ui.questionError,
          complete: sequence.complete,
        })}
        ${renderQuestionAside(sequence)}
      </div>
    </section>`;
}

function renderQuestion(question, context) {
  const percent = Math.round((Math.max(context.index, 1) / Math.max(context.estimate, 1)) * 100);
  let remainingText = 'Last question on this route';
  if (context.remaining === 1) remainingText = 'About 1 more question';
  else if (context.remaining > 1) remainingText = `About ${context.remaining} more questions`;
  const optionCount = (question.options || []).length;

  return html`
    <article class="q-card q-card--enter-${state.ui.direction}" data-question-id="${question.id}">
      <header class="q-card__head">
        <div class="q-card__meta">
          <span class="q-card__count">${context.fromMap ? 'Answered on the body map' : `Question ${Math.max(context.index, 1)}`}</span>
          <span class="q-card__section">${question.section}</span>
        </div>
        <div class="progress" role="progressbar" aria-label="Questionnaire progress (estimated)" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}">
          <span class="progress__bar" style="width: ${percent}%"></span>
        </div>
        <p class="q-card__adapt">${icon('git-branch')}<span>Questions adapt based on previous responses.</span><span class="q-card__remaining">${remainingText}</span></p>
      </header>
      ${renderBranchNotice()}
      <form class="q-form" data-form="question" novalidate>
        <h2 class="q-title" id="q-title" tabindex="-1">${question.text}</h2>
        ${question.helpText ? html`<p class="q-help">${icon('info')}<span>${question.helpText}</span></p>` : ''}
        ${context.fromDemo ? html`<p class="q-demo-hint">${icon('list-checks')}<span>Demo answer pre-selected. Change it or continue.</span></p>` : ''}
        ${context.fromMap ? html`<p class="q-demo-hint">${icon('person-standing')}<span>Answered from the body map. Change it here if it is not right.</span></p>` : ''}
        ${context.suggested ? html`<p class="q-demo-hint">${icon('person-standing')}<span>Pre-selected from the symptoms on the body map. Check with the patient, then continue.</span></p>` : ''}
        <div class="q-input" data-question-type="${question.type}">${renderQuestionInput(question, context.value)}</div>
        <p class="q-error" id="q-error" role="alert">${context.error ? html`${icon('circle-alert')}<span>${context.error}</span>` : ''}</p>
        <footer class="q-actions">
          <button type="button" class="btn btn-secondary" data-action="question-prev">${icon('chevron-left')}<span>Previous</span></button>
          ${optionCount > 1 && question.type !== 'number'
            ? html`<p class="q-actions__hint"><kbd>1</kbd>–<kbd>${Math.min(optionCount, 9)}</kbd> to choose, <kbd>Enter</kbd> to continue</p>`
            : html`<p class="q-actions__hint"><kbd>Enter</kbd> to continue</p>`}
          <button type="button" class="btn btn-primary" data-action="submit-answer"><span>${question.next === null ? 'Continue to review' : 'Continue'}</span>${icon('chevron-right')}</button>
        </footer>
      </form>
    </article>`;
}

function renderQuestionInput(question, value) {
  switch (question.type) {
    case 'yesno': return renderChoiceOptions(question, value, 'yesno');
    case 'location': return renderChoiceOptions(question, value, 'location');
    case 'severity': return renderChoiceOptions(question, value, 'severity');
    case 'duration': return renderChoiceOptions(question, value, 'duration');
    case 'single': return renderChoiceOptions(question, value, question.options.some((o) => o.label.length > 30) ? 'list' : 'grid');
    case 'multi': return renderMultiOptions(question, value);
    case 'scale': return renderScale(question, value);
    case 'number': return renderNumber(question, value);
    default: return '';
  }
}

function renderChoiceOptions(question, value, layout) {
  return html`
    <div class="q-options q-options--${layout}" role="radiogroup" aria-labelledby="q-title" aria-describedby="q-error">
      ${question.options.map((option, i) => html`
        <label class="q-option${option.unsure ? ' q-option--unsure' : ''}">
          <input class="q-option__input" type="radio" name="q-${question.id}" value="${option.value}"
            data-question-input="${question.id}" data-key="${i + 1}" ${value === option.value ? raw('checked') : ''}>
          <span class="q-option__face">
            ${layout === 'location' ? html`<span class="q-option__figure">${bodyMap(option.region)}</span>` : ''}
            ${layout === 'severity' ? html`<span class="level-bars" data-level="${option.score}" aria-hidden="true"><i></i><i></i><i></i></span>` : ''}
            <span class="q-option__text">
              <span class="q-option__label">${option.label}</span>
              ${option.hint ? html`<span class="q-option__hint">${option.hint}</span>` : ''}
            </span>
            ${i < 9 ? html`<span class="q-option__key" aria-hidden="true">${i + 1}</span>` : ''}
            <span class="q-option__mark" aria-hidden="true">${icon('check')}</span>
          </span>
        </label>`)}
    </div>`;
}

function renderMultiOptions(question, value) {
  const selected = Array.isArray(value) ? value : [];
  return html`
    <p class="q-subhint" id="q-multi-hint">Select all that apply.</p>
    <div class="q-options q-options--multi" role="group" aria-labelledby="q-title" aria-describedby="q-multi-hint q-error">
      ${question.options.map((option, i) => html`
        <label class="q-option q-option--check${option.exclusive ? ' q-option--exclusive' : ''}">
          <input class="q-option__input" type="checkbox" name="q-${question.id}" value="${option.value}"
            data-question-input="${question.id}" data-key="${i + 1}" ${option.exclusive ? raw('data-exclusive="true"') : ''}
            ${selected.includes(option.value) ? raw('checked') : ''}>
          <span class="q-option__face">
            <span class="q-option__text"><span class="q-option__label">${option.label}</span></span>
            ${i < 9 ? html`<span class="q-option__key" aria-hidden="true">${i + 1}</span>` : ''}
            <span class="q-option__mark q-option__mark--box" aria-hidden="true">${icon('check')}</span>
          </span>
        </label>`)}
    </div>`;
}

/* The plain-language scale for a pain question (see PAIN_SCALES). */
function painScaleFor(question, answers = state.assessment.answers) {
  const key = typeof question.painScale === 'function' ? question.painScale(answers || {}) : question.painScale;
  return PAIN_SCALES[key] || PAIN_SCALES.general;
}

/* What a 0–10 score means on a given scale, in plain words. */
function describePainScore(scale, value) {
  if (!Number.isInteger(value)) return '';
  if (value <= 0) return 'No pain at all';
  if (value === 1) return scale.low;
  if (value >= 10) return scale.high;
  return [scale.mild, scale.mild, scale.moderate, scale.severe][painBand(value).level];
}

function painReadout(scale, value, max = 10) {
  if (!Number.isInteger(value)) return html`No score selected yet`;
  return html`Selected <strong>${value} out of ${max}</strong>, ${painBand(value).label.toLowerCase()}: ${describePainScore(scale, value)}`;
}

function renderScale(question, value) {
  const items = [];
  for (let n = question.min; n <= question.max; n += 1) items.push(n);
  const scale = painScaleFor(question);
  return html`
    <div class="q-scale">
      <div class="q-scale__track" role="radiogroup" aria-labelledby="q-title" aria-describedby="q-scale-ends q-scale-readout q-error">
        ${items.map((n) => html`
          <label class="q-scale__item" data-band="${painBand(n).level}">
            <input class="q-option__input" type="radio" name="q-${question.id}" value="${n}" data-question-input="${question.id}"
              aria-label="${n}, ${painBand(n).label.toLowerCase()}: ${describePainScore(scale, n)}" ${value === n ? raw('checked') : ''}>
            <span class="q-scale__face">${n}</span>
          </label>`)}
      </div>
      <div class="q-scale__ends" id="q-scale-ends">
        <p class="q-scale__end q-scale__end--low"><strong>1</strong><span>${scale.low}</span></p>
        <p class="q-scale__end q-scale__end--high"><span>${scale.high}</span><strong>10</strong></p>
      </div>
      <div class="q-scale__legend" aria-hidden="true">
        <span class="q-scale__band q-scale__band--0">No pain</span>
        <span class="q-scale__band q-scale__band--1">Mild</span>
        <span class="q-scale__band q-scale__band--2">Moderate</span>
        <span class="q-scale__band q-scale__band--3">Severe</span>
      </div>
      <p class="q-scale__readout" id="q-scale-readout" aria-live="polite">${painReadout(scale, value, question.max)}</p>
    </div>`;
}

function renderNumber(question, value) {
  const unitValue = (value && value.unit) || question.units[0].value;
  const unit = getUnit(question, unitValue);
  const numeric = value && typeof value.value === 'number' && Number.isFinite(value.value) ? value.value : '';
  return html`
    <div class="q-number">
      <label class="field__label" for="q-number-input">Temperature reading</label>
      <div class="q-number__row">
        <input id="q-number-input" class="input input--number" type="number" inputmode="decimal"
          step="${unit.step}" min="${unit.min}" max="${unit.max}" placeholder="${unit.placeholder}" value="${numeric}"
          data-question-number="${question.id}" aria-describedby="q-number-range q-error">
        <div class="segmented" role="radiogroup" aria-label="Temperature unit">
          ${question.units.map((u) => html`
            <label class="segmented__item">
              <input type="radio" name="q-unit" value="${u.value}" data-question-unit="${question.id}" ${u.value === unitValue ? raw('checked') : ''}>
              <span>${u.label}</span>
            </label>`)}
        </div>
      </div>
      <p class="q-subhint" id="q-number-range">Accepted range ${unit.min}–${unit.max} ${unit.label}</p>
    </div>`;
}

function renderBranchNotice() {
  const notice = state.ui.branchNotice;
  if (!notice) return '';
  return html`
    <div class="notice notice--info q-card__notice" role="status">
      ${icon('git-branch')}
      <p><strong>Route updated.</strong> ${pluralise(notice.count, 'earlier response')} no longer ${notice.count === 1 ? 'applies' : 'apply'} and ${notice.count === 1 ? 'was' : 'were'} removed (${notice.sections.join(', ')}).</p>
    </div>`;
}

function renderQuestionAside(sequence) {
  const a = state.assessment;
  const fromMap = bodyMapAnsweredIds(a);
  const picks = bodyMapSummary(a);
  const answered = sequence.path
    .map((id, index) => ({ id, index, question: getQuestion(id) }))
    .filter((item) => hasOwn(a.answers, item.id) || item.index === state.ui.cursor);

  return html`
    <aside class="q-aside" aria-label="Assessment context">
      <section class="panel patient-mini">
        <div class="avatar" aria-hidden="true">${initials(a.patient.name)}</div>
        <div class="patient-mini__body">
          <p class="patient-mini__name">${textOr(a.patient.name, 'Patient')}</p>
          <p class="patient-mini__meta">${[a.patient.age ? `${a.patient.age} yrs` : '', a.patient.gender ? genderLabel(a.patient.gender) : ''].filter(Boolean).join(', ')}</p>
          <p class="patient-mini__complaint">${icon(getComplaint(a.patient.complaint)?.icon || 'clipboard-list')}<span>${mainProblemLabel(a)}</span></p>
        </div>
      </section>
      ${picks.length ? html`
        <section class="panel bm-mini" aria-labelledby="bm-mini-title">
          <div class="bm-mini__head">
            <h3 class="panel__title" id="bm-mini-title">On the body map</h3>
            <button type="button" class="link-button" data-action="edit-bodymap">Edit</button>
          </div>
          <ul class="bm-mini__list">${picks.map((pick) => html`<li><span>${pick.label}</span>${pick.pain !== null ? html`<span class="bm-mini__pain" data-band="${painBand(pick.pain).level}">${pick.pain}/10</span>` : ''}</li>`)}</ul>
        </section>` : ''}
      <section class="panel trail">
        <h3 class="panel__title">Responses so far</h3>
        ${answered.length <= 1 && !hasOwn(a.answers, sequence.path[0])
          ? html`<p class="trail__empty">Answers appear here as you go. Select one to change it.</p>`
          : html`<ol class="trail__list">
            ${answered.map((item) => {
              const current = item.index === state.ui.cursor;
              const answerText = hasOwn(a.answers, item.id) ? formatAnswer(item.question, a.answers[item.id]) : 'Current question';
              return html`<li>
                <button type="button" class="trail__item${current ? ' is-current' : ''}" data-action="question-jump" data-index="${item.index}" ${current ? raw('aria-current="step"') : ''}>
                  <span class="trail__q">${item.question.short || item.question.text}${fromMap.has(item.id) ? html`<span class="tag">Body map</span>` : ''}</span>
                  <span class="trail__a">${answerText}</span>
                </button>
              </li>`;
            })}
          </ol>`}
      </section>
      <div class="q-aside__actions">
        ${sequence.complete ? html`<button type="button" class="btn btn-secondary btn-block" data-action="go-review">${icon('list-checks')}<span>Review answers</span></button>` : ''}
        <button type="button" class="btn btn-ghost btn-block btn-ghost-danger" data-action="flag-urgent" ${state.assessment.urgentFlag ? raw('disabled') : ''}>${icon('siren')}<span>${state.assessment.urgentFlag ? 'Marked as urgent' : 'Patient looks unwell? Flag as urgent'}</span></button>
        <button type="button" class="btn btn-ghost btn-block" data-action="cancel-assessment">${icon('x')}<span>Cancel assessment</span></button>
      </div>
    </aside>`;
}

/* Reads the current input state of the visible question. */
function readQuestionInput(question) {
  const form = document.querySelector('[data-form="question"]');
  if (!form) return undefined;
  switch (question.type) {
    case 'multi':
      return Array.from(form.querySelectorAll(`[data-question-input="${question.id}"]:checked`)).map((el) => el.value);
    case 'scale': {
      const checked = form.querySelector(`[data-question-input="${question.id}"]:checked`);
      return checked ? Number(checked.value) : undefined;
    }
    case 'number': {
      const input = form.querySelector('[data-question-number]');
      const unit = form.querySelector('[data-question-unit]:checked');
      const text = input ? input.value.trim() : '';
      const numeric = text === '' ? null : Number(text);
      return { value: numeric === null || Number.isNaN(numeric) ? null : numeric, unit: unit ? unit.value : question.units[0].value };
    }
    default: {
      const checked = form.querySelector(`[data-question-input="${question.id}"]:checked`);
      return checked ? checked.value : undefined;
    }
  }
}

function getCurrentQuestion() {
  const sequence = currentSequence();
  if (!sequence.path.length) return null;
  return getQuestion(sequence.path[clamp(state.ui.cursor, 0, sequence.path.length - 1)]);
}

/* Small body figure used by location questions. Highlighted region in the
   current colour; the rest of the figure stays neutral. */
function bodyMap(region) {
  const regions = {
    head: '<circle cx="20" cy="8" r="6"/>',
    chest: '<path d="M11 17h18a3 3 0 0 1 3 3v6H8v-6a3 3 0 0 1 3-3z"/>',
    abdomen: '<path d="M8 27.5h24V35a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2z"/>',
    limb: '<circle cx="14.5" cy="50" r="3.4"/><circle cx="5.25" cy="29" r="2.9"/><circle cx="34.75" cy="29" r="2.9"/>',
    back: '<rect x="18.4" y="17" width="3.2" height="20" rx="1.6"/><path d="M12 19.5c2 0 3.6 1.4 4 3.3l.4 2.4-3.6.8C11 26.4 10 25 10 23.2v-1.5c0-1.2 1-2.2 2-2.2zM28 19.5c-2 0-3.6 1.4-4 3.3l-.4 2.4 3.6.8c1.8.4 2.8-1 2.8-2.8v-1.5c0-1.2-1-2.2-2-2.2z"/>',
    other: '<rect x="17.5" y="13" width="5" height="4.5" rx="1.5"/><circle cx="20" cy="40.5" r="3"/>',
  };
  return raw(`<svg class="body-map" viewBox="0 0 40 64" aria-hidden="true" focusable="false">
    <g class="body-map__base">
      <circle cx="20" cy="8" r="6"/><rect x="17.5" y="13" width="5" height="5" rx="1.5"/>
      <path d="M11 17h18a3 3 0 0 1 3 3v15a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2V20a3 3 0 0 1 3-3z"/>
      <rect x="3" y="18" width="4.5" height="21" rx="2.25"/><rect x="32.5" y="18" width="4.5" height="21" rx="2.25"/>
      <rect x="11" y="38" width="7.5" height="24" rx="3"/><rect x="21.5" y="38" width="7.5" height="24" rx="3"/>
    </g>
    <g class="body-map__region">${regions[region] || ''}</g>
  </svg>`);
}
