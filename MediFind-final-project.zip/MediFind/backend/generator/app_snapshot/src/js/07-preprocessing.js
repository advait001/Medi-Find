/* =====================================================================
   7. PREPROCESSING
   ---------------------------------------------------------------------
   validateAssessment → encodeSymptoms → constructFeatureVector →
   preprocessFeatures. The output is the ordered, normalised feature
   vector that a trained model (or the local prototype engine) consumes.
   Encoding rules: Yes = 1, No = 0, Not sure = missing; scored options
   (e.g. Mild = 1, Moderate = 2, Severe = 3) become ordinal values; ticked
   multi-select options = 1, unticked = 0. Missing values are imputed
   as 0 and reduce the completeness used for model confidence.
   Derived features: age bands (under 16, under 30, 45+, 65+), high temperature (39 °C or above),
   severity from the pain score, and yes/no duration bands.
   ===================================================================== */

function validateAssessment(assessment) {
  const errors = [];
  const patientCheck = validatePatientDetails(assessment.patient);
  if (!patientCheck.valid) errors.push('Patient details are incomplete or invalid.');
  if (!getComplaint(assessment.patient.complaint)) errors.push('The main complaint has not been recorded.');
  if (bodyMapPending(assessment)) errors.push('The symptoms step has changes that are not applied yet.');
  const sequence = buildQuestionSequence(assessment.answers, assessment.patient.complaint);
  const escalated = assessment.urgentFlag || (assessment.safety && assessment.safety.urgent.length > 0);
  if (!sequence.complete && !(assessment.endedEarly && escalated)) {
    errors.push('The symptom questionnaire is not complete.');
  }
  return { valid: errors.length === 0, errors, sequence };
}

/* Merges a value into a feature map: known values replace unknown (null),
   and among known values the strongest evidence (maximum) is kept. */
function mergeFeature(target, key, value) {
  if (value === null || value === undefined) {
    if (!hasOwn(target, key)) target[key] = null;
    return;
  }
  const current = target[key];
  target[key] = current === null || current === undefined ? value : Math.max(current, value);
}

function encodeAnswer(question, value) {
  const features = {};
  let unsure = false;
  const put = (key, v) => mergeFeature(features, key, v);

  switch (question.type) {
    case 'yesno':
      if (value === 'unsure') {
        unsure = true;
        if (question.featureKey) put(question.featureKey, null);
      } else if (question.featureKey) {
        put(question.featureKey, value === 'yes' ? 1 : 0);
      }
      break;
    case 'single':
    case 'location':
    case 'duration':
    case 'severity': {
      const option = findOption(question, value);
      if (!option) break;
      if (option.unsure) unsure = true;
      if (question.featureKey) put(question.featureKey, typeof option.score === 'number' ? option.score : null);
      Object.entries(option.set || {}).forEach(([key, v]) => put(key, v));
      break;
    }
    case 'multi': {
      const selected = Array.isArray(value) ? value : [];
      question.options.forEach((option) => {
        if (option.exclusive) return;
        const ticked = selected.includes(option.value);
        if (option.feature) put(option.feature, ticked ? 1 : 0);
        if (ticked) Object.entries(option.alsoSet || {}).forEach(([key, v]) => put(key, v));
      });
      break;
    }
    case 'scale':
      put(question.featureKey, Number.isInteger(value) ? value : null);
      if (question.areaScoreKey) put(question.areaScoreKey, Number.isInteger(value) ? value : null);
      break;
    case 'number': {
      if (!value || typeof value.value !== 'number') { put(question.featureKey, null); break; }
      const unit = getUnit(question, value.unit);
      const celsius = unit.value === 'F' ? (value.value - 32) * (5 / 9) : value.value;
      put(question.featureKey, round(celsius, 1));
      break;
    }
    default:
      break;
  }
  return { features, unsure };
}

/* Converts the answers on the active route into raw feature values.
   `extras` are findings from the body map (see bodyMapExtras). They fill
   features that are still unknown, so a questionnaire answer wins, except
   for warning-sign findings (BODY_WARNING_FEATURES): a warning sign
   reported on the body map always counts. */
function encodeSymptoms(answers, complaintId, extras = null) {
  const sequence = buildQuestionSequence(answers, complaintId);
  const features = {};
  const unsureQuestions = [];
  const askedQuestions = [];
  const complaint = getComplaint(complaintId);

  if (complaint) {
    mergeFeature(features, `complaint_${complaint.id}`, 1);
    Object.entries(complaint.sets || {}).forEach(([key, v]) => mergeFeature(features, key, v));
  }

  sequence.path.forEach((id) => {
    if (!hasOwn(answers, id)) return;
    const question = getQuestion(id);
    askedQuestions.push(id);
    const encoded = encodeAnswer(question, answers[id]);
    if (encoded.unsure) unsureQuestions.push(id);
    Object.entries(encoded.features).forEach(([key, v]) => mergeFeature(features, key, v));
  });

  if (extras) {
    Object.entries(extras).forEach(([key, value]) => {
      if (features[key] === null || features[key] === undefined) features[key] = value;
      else if (BODY_WARNING_FEATURES.has(key) && value > features[key]) features[key] = value;
    });
  }

  const notAsked = sequence.path.filter((id) => !hasOwn(answers, id));
  return { features, unsureQuestions, askedQuestions, notAsked };
}

/* Places patient factors and encoded symptoms into the fixed schema order.
   Values stay raw here (null = missing); see preprocessFeatures. */
function constructFeatureVector(patient, encoding) {
  const rawFeatures = Object.fromEntries(FEATURE_ORDER.map((key) => [key, null]));
  const age = Number.parseInt(patient.age, 10);

  rawFeatures.age = Number.isFinite(age) ? age : null;
  rawFeatures.genderFemale = patient.gender === 'female' ? 1 : 0;
  rawFeatures.genderMale = patient.gender === 'male' ? 1 : 0;
  rawFeatures.genderOther = patient.gender === 'other' ? 1 : 0;
  COMPLAINTS.forEach((c) => { rawFeatures[`complaint_${c.id}`] = 0; });

  Object.entries(encoding.features).forEach(([key, value]) => {
    if (hasOwn(rawFeatures, key)) mergeFeature(rawFeatures, key, value);
  });

  // Derived features
  rawFeatures.ageOver45 = rawFeatures.age === null ? null : Number(rawFeatures.age >= 45);
  rawFeatures.ageUnder30 = rawFeatures.age === null ? null : Number(rawFeatures.age < 30);
  rawFeatures.ageOver65 = rawFeatures.age === null ? null : Number(rawFeatures.age >= 65);
  rawFeatures.ageUnder16 = rawFeatures.age === null ? null : Number(rawFeatures.age < 16);
  if (rawFeatures.temperatureC !== null) {
    rawFeatures.highFever = Number(rawFeatures.temperatureC >= 39);
  }
  if (rawFeatures.severity === null && rawFeatures.painScore !== null) {
    rawFeatures.severity = painBand(rawFeatures.painScore).level;
  }
  // Duration bands as yes/no features used by the condition model
  // (band 1 = under 24 hours … band 5 = more than a month).
  if (rawFeatures.durationBand !== null) {
    const band = rawFeatures.durationBand;
    rawFeatures.durationShort = Number(band <= 2);
    rawFeatures.durationOver3Days = Number(band >= 3);
    rawFeatures.durationOverWeek = Number(band >= 4);
    rawFeatures.durationOverMonth = Number(band >= 5);
  }

  return {
    schemaVersion: FEATURE_SCHEMA_VERSION,
    order: FEATURE_ORDER,
    raw: rawFeatures,
    vector: FEATURE_ORDER.map((key) => rawFeatures[key]),
  };
}

function normaliseFeature(definition, value) {
  if (definition.type === 'binary') return value ? 1 : 0;
  const span = definition.max - definition.min;
  return span > 0 ? round(clamp((value - definition.min) / span, 0, 1), 3) : 0;
}

/* Missing-value handling, normalisation and completeness. */
function preprocessFeatures(featureVector, encoding) {
  const named = {};
  const imputed = [];
  FEATURE_SCHEMA.forEach((definition) => {
    let value = featureVector.raw[definition.key];
    if (value === null || value === undefined || Number.isNaN(value)) {
      imputed.push(definition.key);
      value = definition.type === 'numeric' ? definition.min : 0;
      named[definition.key] = definition.type === 'numeric' ? 0 : normaliseFeature(definition, value);
      return;
    }
    named[definition.key] = normaliseFeature(definition, value);
  });

  const asked = encoding.askedQuestions.length;
  const unsure = encoding.unsureQuestions.length;
  const notAsked = encoding.notAsked.length;
  const completeness = asked + notAsked > 0 ? (asked - unsure) / (asked + notAsked) : 0;

  return {
    schemaVersion: featureVector.schemaVersion,
    order: featureVector.order,
    vector: featureVector.order.map((key) => named[key]),
    named,
    raw: featureVector.raw,
    meta: {
      asked,
      unsure,
      notAsked,
      completeness: round(clamp(completeness, 0, 1), 3),
      imputedCount: imputed.length,
      unsureQuestions: encoding.unsureQuestions.slice(),
    },
  };
}

/* Convenience: answers → raw features, used by live safety checks and summaries. */
function computeRawFeatures(assessment) {
  const encoding = encodeSymptoms(assessment.answers, assessment.patient.complaint, bodyMapExtras(assessment));
  return constructFeatureVector(assessment.patient, encoding).raw;
}

/* Readable summary of the reported symptoms for review, results and the report. */
function summariseFindings(assessment) {
  const rawFeatures = computeRawFeatures(assessment);
  const sequence = buildQuestionSequence(assessment.answers, assessment.patient.complaint);
  const present = [];

  FEATURE_SCHEMA.forEach((definition) => {
    if (definition.internal) return;
    const value = rawFeatures[definition.key];
    if (value === null || value === undefined) return;
    const label = SYMPTOM_LABELS[definition.key];
    switch (definition.key) {
      case 'painScore':
      case 'severity':
      case 'durationBand':
      case 'temperatureC':
        return; // reported separately
      case 'breathingDifficulty':
        if (value > 0) present.push({ key: definition.key, label: `${label} (${BREATHING_OPTIONS[value].label.toLowerCase()})` });
        return;
      default:
        if (definition.type === 'binary' && value === 1) present.push({ key: definition.key, label });
    }
  });

  const absent = [];
  const unsure = [];
  const responses = [];
  let duration = null;
  let severityText = null;

  sequence.path.forEach((id) => {
    if (!hasOwn(assessment.answers, id)) return;
    const question = getQuestion(id);
    const value = assessment.answers[id];
    const answerText = formatAnswer(question, value);
    responses.push({ id, section: question.section, question: question.text, short: question.short, answer: answerText });

    if (question.type === 'yesno' && value === 'no') absent.push(question.short);
    if (question.type === 'yesno' && value === 'unsure') unsure.push(question.short);
    if (question.featureKey === 'breathingDifficulty' && value === 'none') absent.push(question.short);
    if (question.type !== 'yesno') {
      const option = findOption(question, value);
      if (option && option.unsure) unsure.push(question.short);
    }
    if (question.featureKey === 'durationBand') duration = { label: question.short, value: answerText };
    if (question.type === 'scale') severityText = `Pain ${answerText}`;
    if (question.type === 'severity' && !severityText) severityText = answerText;
  });

  if (!severityText && rawFeatures.breathingDifficulty > 0) {
    severityText = `Breathing difficulty: ${BREATHING_OPTIONS[rawFeatures.breathingDifficulty].label.toLowerCase()}`;
  }

  const temperature = sequence.path.includes('fever_temp') && assessment.answers.fever_temp
    ? formatAnswer(getQuestion('fever_temp'), assessment.answers.fever_temp)
    : null;

  return {
    present: uniqueBy(present, (item) => item.label),
    absent: uniqueBy(absent, (item) => item),
    unsure: uniqueBy(unsure, (item) => item),
    responses,
    duration,
    severity: severityText,
    temperature,
    notAsked: sequence.complete ? 0 : sequence.path.filter((id) => !hasOwn(assessment.answers, id)).length,
  };
}
