/* =====================================================================
   6. BRANCH MANAGEMENT
   ---------------------------------------------------------------------
   Answers are kept only while their question is on the active route.
   When an earlier answer changes the route (for example Pain → Chest is
   changed to Pain → Joint / Limb), every answer from the old branch is
   removed from state.answers, and the derived feature vector,
   prediction, recommendation and report are invalidated, so nothing
   from the old branch can reach the prediction or the report.
   ===================================================================== */

function saveAnswer(questionId, value) {
  const assessment = state.assessment;
  const changed = !answersEqual(assessment.answers[questionId], value);
  assessment.answers[questionId] = deepClone(value);

  let removed = [];
  if (changed) {
    removed = clearObsoleteBranchAnswers();
    invalidateDerivedResults();
    if (assessment.endedEarly && currentSequence().complete) assessment.endedEarly = false;
  }
  refreshSafetyState();
  persistDraft();
  return { changed, removed };
}

/* Removes answers that are no longer on the active route.
   Returns the ids of the removed answers. */
function clearObsoleteBranchAnswers() {
  const assessment = state.assessment;
  const sequence = buildQuestionSequence(assessment.answers, assessment.patient.complaint);
  const onRoute = new Set(sequence.path);
  const removed = Object.keys(assessment.answers).filter((id) => !onRoute.has(id));
  if (removed.length) {
    // The route changed: questions marked for reconfirmation (the warning-sign
    // check) are asked again rather than carried over from the old route.
    sequence.path
      .filter((id) => (getQuestion(id) || {}).reconfirmOnRouteChange && hasOwn(assessment.answers, id))
      .forEach((id) => removed.push(id));
  }
  removed.forEach((id) => { delete assessment.answers[id]; });
  assessment.questionHistory = sequence.path.filter((id) => hasOwn(assessment.answers, id));
  if (removed.length) invalidateDerivedResults();
  return removed;
}

function buildBranchNotice(removedIds) {
  if (!removedIds.length) return null;
  const sections = uniqueBy(
    removedIds.map((id) => (getQuestion(id) || {}).section || 'Previous route'),
    (section) => section,
  );
  return { count: removedIds.length, sections };
}

/* Saves the visible answer if it is valid and different from the stored one.
   Used when the receptionist leaves a question with Previous or the trail. */
function commitPendingAnswer() {
  const question = getCurrentQuestion();
  if (!question) return { removed: [] };
  const value = readQuestionInput(question);
  if (validateAnswer(question, value) !== null) return { removed: [] };
  if (answersEqual(state.assessment.answers[question.id], value)) return { removed: [] };
  return saveAnswer(question.id, value);
}

function submitCurrentAnswer() {
  const question = getCurrentQuestion();
  if (!question) return;
  const value = readQuestionInput(question);
  const error = validateAnswer(question, value);
  if (error) {
    showQuestionError(error);
    return;
  }
  const { removed } = saveAnswer(question.id, value);
  state.ui.branchNotice = buildBranchNotice(removed);
  state.ui.questionError = '';
  state.ui.pending = undefined;
  advanceQuestion();
}

function advanceQuestion() {
  const sequence = currentSequence();
  // Questions already answered on the body map are not asked again.
  const fromMap = bodyMapAnsweredIds();
  let nextIndex = state.ui.cursor + 1;
  while (nextIndex < sequence.path.length && fromMap.has(sequence.path[nextIndex])) nextIndex += 1;
  state.ui.direction = 'forward';

  if (nextIndex < sequence.path.length) {
    state.ui.cursor = nextIndex;
    render();
    return;
  }
  if (sequence.complete) {
    reviewAssessment();
    return;
  }
  // The route still has an unanswered question earlier on (for example after
  // jumping ahead from the response list), so return to it.
  state.ui.cursor = Math.max(0, sequence.firstUnanswered);
  state.ui.questionError = 'Please answer this question to complete the assessment.';
  render();
}

/* Steps back to the previous question the receptionist answered; answers
   that came from the body map are skipped, and before the first question
   the body map opens again. */
function goToPreviousQuestion() {
  const { removed } = commitPendingAnswer();
  state.ui.branchNotice = buildBranchNotice(removed);
  state.ui.questionError = '';
  state.ui.pending = undefined;
  state.ui.direction = 'back';
  const path = currentSequence().path;
  const fromMap = bodyMapAnsweredIds();
  let target = Math.min(state.ui.cursor, path.length) - 1;
  while (target >= 0 && fromMap.has(path[target])) target -= 1;
  if (target < 0) {
    state.ui.branchNotice = null;
    navigateTo('bodymap');
    return;
  }
  state.ui.cursor = target;
  render();
}

function jumpToQuestion(index) {
  const { removed } = commitPendingAnswer();
  const sequence = currentSequence();
  state.ui.branchNotice = buildBranchNotice(removed);
  state.ui.questionError = '';
  state.ui.pending = undefined;
  state.ui.direction = index < state.ui.cursor ? 'back' : 'forward';
  state.ui.cursor = clamp(index, 0, Math.max(0, sequence.path.length - 1));
  render();
}

function showQuestionError(message) {
  state.ui.questionError = message;
  const slot = document.getElementById('q-error');
  if (slot) {
    slot.innerHTML = html`${icon('circle-alert')}<span>${message}</span>`.toString();
    const card = slot.closest('.q-card');
    if (card) {
      card.classList.remove('is-shaking');
      void card.offsetWidth; // restart the animation
      card.classList.add('is-shaking');
    }
  }
}

/* Opens the questionnaire, e.g. from "Edit symptoms" on the review screen. */
function editSymptoms(fromReview = false) {
  state.ui.returnTo = fromReview ? 'review' : null;
  state.ui.branchNotice = null;
  state.ui.questionError = '';
  state.ui.pending = undefined;
  state.ui.direction = 'forward';
  const sequence = currentSequence();
  state.ui.cursor = sequence.firstUnanswered >= 0 && !fromReview ? sequence.firstUnanswered : firstQuestionToShow(sequence);
  navigateTo('questionnaire');
}

/* After an urgent escalation the receptionist may stop the questionnaire
   and go straight to review; the remaining questions are recorded as not asked. */
function finishQuestionnaireEarly() {
  const a = state.assessment;
  if (!(a.urgentFlag || a.safety.urgent.length)) return;
  commitPendingAnswer();
  a.endedEarly = !currentSequence().complete;
  persistDraft();
  reviewAssessment();
}
