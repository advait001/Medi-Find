/* =====================================================================
   12a. PLAIN-LANGUAGE SUMMARY ("In simple words")
   ---------------------------------------------------------------------
   A short summary for patients and families, shown on the result screen
   and printed on the report: what was reported, what it might be, where
   to go, and what to do while waiting. The wording comes from
   PLAIN_LANGUAGE. It never says "you have" a condition, never names a
   condition for urgent cases and never mentions medicines or treatment.
   The result is plain data (strings and { strong } segments), so it can
   be stored with the report.
   ===================================================================== */

function matchWord(likelihood) {
  if (!Number.isFinite(likelihood)) return '';
  const bands = PLAIN_LANGUAGE.matchBands;
  return (bands.find((band) => likelihood >= band.min) || bands[bands.length - 1]).label;
}

/* Lower-cases the first letter unless the word is an abbreviation (COPD). */
function lowerFirst(text) {
  const value = String(text || '');
  if (value.length > 1 && value[1] === value[1].toUpperCase() && /[A-Z]/.test(value[1])) return value;
  return value.charAt(0).toLowerCase() + value.slice(1);
}

/* "a, b and c"; semicolons when an item already contains a comma. */
function joinWords(items, tail = '') {
  const all = tail ? [...items, tail] : items;
  if (all.length <= 1) return all.join('');
  const separator = all.some((item) => item.includes(',')) ? '; ' : ', ';
  return `${all.slice(0, -1).join(separator)}${separator === '; ' ? '; and ' : ' and '}${all[all.length - 1]}`;
}

/* Findings that describe timing rather than a symptom are left out of the
   plain list (the duration is given separately). */
const PLAIN_SKIPPED_FINDINGS = new Set(['acuteOnset', 'otherPain']);

/* The finding behind each 0–10 pain question; left out of the list when
   that pain was rated 0 (other pains stay listed). */
const PLAIN_PAIN_FINDING = {
  chest_score: 'chestPain', head_score: 'headache', abd_score: 'abdominalPain', joint_score: 'jointLimbPain', back_score: 'backPain', other_pain_score: 'otherPain',
};

/* What a 0–10 pain question measured, in plain words. */
const PLAIN_PAIN_NAMES = {
  chest_score: 'Chest pain', head_score: 'Headache', abd_score: 'Stomach pain', joint_score: 'Joint or limb pain', back_score: 'Back or neck pain',
};
const PLAIN_OTHER_PAIN_NAMES = {
  throat: 'Sore throat', ear: 'Earache', teeth: 'Toothache or jaw pain', pelvis: 'Pelvic or groin pain', urine: 'Pain when passing urine', all_over: 'Body aches',
};

function plainPainName(questionId, answers) {
  if (questionId === 'other_pain_score') return PLAIN_OTHER_PAIN_NAMES[answers.pain_other_area] || 'Pain';
  return PLAIN_PAIN_NAMES[questionId] || 'Pain';
}

/* Pain ratings given on the body map for other places than the main
   problem, such as "Pain in the right knee: 3 out of 10". */
function otherBodyMapRatings(assessment, mainQuestionId) {
  const bm = assessment.bodyMap;
  if (!bm || bm.mode !== 'map' || !bm.applied) return [];
  const derived = deriveFromBodyMap(bm);
  const merged = new Set(derived ? derived.mergedKeys : []);
  return bodyMapEntries(bm)
    .filter((entry) => entry.def.pain && Number.isInteger(entry.sel.pain)
      && !(merged.has(entry.key) && entry.def.pain.question === mainQuestionId))
    .map((entry) => `${entry.def.perArea ? `${entry.def.label} in the ${entry.area.label.toLowerCase()}` : entry.def.label}: ${entry.sel.pain} out of 10`);
}

function plainSummary(assessment) {
  const prediction = assessment.prediction || null;
  const recommendation = assessment.recommendation || null;
  const urgent = isUrgentAssessment(assessment);
  const findings = summariseFindings(assessment);
  const rawFeatures = computeRawFeatures(assessment);

  const sequence = buildQuestionSequence(assessment.answers, assessment.patient.complaint);
  const painQuestionId = sequence.path.find((id) => getQuestion(id).type === 'scale' && hasOwn(assessment.answers, id)) || null;
  const noPain = rawFeatures.painScore === 0;
  const labels = findings.present
    .filter((item) => !PLAIN_SKIPPED_FINDINGS.has(item.key) && !(noPain && item.key === PLAIN_PAIN_FINDING[painQuestionId]))
    .map((item) => item.label);
  const shown = labels.slice(0, 6).map((label, index) => (index === 0 ? label : lowerFirst(label)));
  const more = labels.length - shown.length;
  const told = [];
  told.push(shown.length
    ? `${joinWords(shown, more > 0 ? pluralise(more, 'other symptom') : '')}.`
    : 'No specific symptoms were reported.');
  if (noPain) {
    told.push(`${plainPainName(painQuestionId, assessment.answers)}: none right now (0 out of 10).`);
  } else if (Number.isInteger(rawFeatures.painScore)) {
    told.push(`${plainPainName(painQuestionId, assessment.answers)}: ${rawFeatures.painScore} out of 10 (${painBand(rawFeatures.painScore).label.toLowerCase()}).`);
  } else if (findings.severity) {
    told.push(findings.severity.includes(':') ? `${findings.severity}.` : `How bad it is: ${lowerFirst(findings.severity)}.`);
  }
  const otherRatings = otherBodyMapRatings(assessment, painQuestionId);
  if (otherRatings.length) told.push(`${otherRatings.join('. ')}.`);
  if (findings.duration) told.push(`${findings.duration.label}: ${lowerFirst(findings.duration.value)}.`);

  let mightBe;
  let whereToGo;
  let sure = '';
  const key = recommendation ? recommendation.key || 'general' : 'general';
  const department = recommendation ? recommendation.department : SPECIALIST_MAPPING.general.department;
  if (urgent) {
    const warningSigns = assessment.safety && assessment.safety.urgent && assessment.safety.urgent.length;
    mightBe = [warningSigns
      ? 'No condition is suggested. Some answers are warning signs, and those come first.'
      : 'No condition is suggested. Reception marked the patient for immediate clinical evaluation, and that comes first.'];
    whereToGo = 'The emergency team should see the patient now. Staff will follow the hospital’s emergency procedure.';
  } else if (!prediction) {
    const doctor = doctorForKey('general');
    mightBe = ['Not worked out yet.'];
    whereToGo = `See ${doctor ? `${doctor.name}, ` : ''}${PLAIN_LANGUAGE.specialists.general}${doctor ? ',' : ''} in the ${SPECIALIST_MAPPING.general.department} department.`;
  } else {
    if (prediction.isInconclusive) {
      mightBe = ['The answers do not point clearly to one illness, so no single condition is suggested.'];
    } else if (prediction.conditionIsFallback || !prediction.predictedConditionId) {
      const area = PLAIN_LANGUAGE.areas[prediction.topCategoryId];
      mightBe = [area
        ? `The answers point to a problem with ${area}, but not to one particular condition. ${PLAIN_LANGUAGE.notDiagnosis}`
        : `The answers point to a general health problem, but not to one particular condition. ${PLAIN_LANGUAGE.notDiagnosis}`];
    } else {
      const word = matchWord(prediction.conditionLikelihood);
      mightBe = ['The answers fit ', { strong: prediction.predictedCondition }, ` best${word ? `, a ${word}` : ''}. ${PLAIN_LANGUAGE.notDiagnosis}`];
    }
    const specialist = PLAIN_LANGUAGE.specialists[key] || PLAIN_LANGUAGE.specialists.general;
    const doctor = recommendedDoctor(recommendation);
    const who = doctor ? `${doctor.name}, ${specialist}` : specialist;
    whereToGo = prediction.isInconclusive
      ? `See ${who} (${department} department) for a general check-up.`
      : `See ${who} (${department} department).`;
    sure = PLAIN_LANGUAGE.sure[confidenceBand(prediction.confidence).id] || '';
  }
  const priority = !urgent && assessment.safety && assessment.safety.priority && assessment.safety.priority.length;
  return {
    urgent,
    told: told.join(' '),
    mightBe,
    whereToGo,
    sure,
    soon: priority ? 'The patient may need to be seen soon.' : '',
    waiting: urgent ? PLAIN_LANGUAGE.urgentWaiting : PLAIN_LANGUAGE.waiting,
  };
}

/* Plain text of a summary line made of strings and { strong } segments. */
function plainText(segments) {
  return (Array.isArray(segments) ? segments : [segments]).map((part) => (typeof part === 'string' ? part : part.strong)).join('');
}

function renderPlainSegments(segments) {
  return (Array.isArray(segments) ? segments : [segments])
    .map((part) => (typeof part === 'string' ? html`${part}` : html`<strong>${part.strong}</strong>`));
}

/* "In simple words" rows shared by the result screen and the report. */
function plainRows(summary) {
  return [
    { id: 'told', icon: 'clipboard-list', label: 'What the patient told us', body: [summary.told] },
    { id: 'might', icon: 'stethoscope', label: summary.urgent ? 'What happens now' : 'What it might be', body: summary.mightBe },
    { id: 'where', icon: 'signpost', label: 'Where to go', body: [[summary.whereToGo, summary.sure, summary.soon].filter(Boolean).join(' ')] },
    { id: 'waiting', icon: 'clock', label: 'While waiting', body: [summary.waiting] },
  ];
}
