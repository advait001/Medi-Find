# MediFind engine snapshot

A copy of the MediFind files the dataset generator needs: the questionnaire, encoder,
knowledge base and safety rules (`src/js`, feature schema `sdp-features-v3`) and the
engine-test scenarios (`tests/condition-scenarios.json`). It is the exact version
`data/medifind_symptom_dataset.csv` was generated from, so the dataset can be rebuilt
without the app project. It is not the full app; the app itself is MediFind's `index.html`.

To generate from another copy of the app, set `MEDIFIND_SRC` (to its `src/js`) and
`MEDIFIND_SCENARIOS` (to its `tests/condition-scenarios.json`).
