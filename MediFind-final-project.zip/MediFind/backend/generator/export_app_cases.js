#!/usr/bin/env node
/* =====================================================================
   Exports MediFind's hand-written test cases as an extra evaluation set.
   ---------------------------------------------------------------------
   Sources (not produced by the dataset generator):
     - the 160 clinical scenarios in MediFind's engine tests
       (sdp/tests/condition-scenarios.json), each with the condition(s)
       the scenario describes; 7 are urgent-only and have none;
     - the demo cases built into the app (DEMO_CASES).
   Each case is encoded with the app's own pipeline into the same 160
   features as the training data, and the app's current rule-based
   prediction is recorded for comparison.

   Run:  node generator/export_app_cases.js
   Env:  MEDIFIND_SCENARIOS (default generator/app_snapshot/tests/condition-scenarios.json)
         MEDIFIND_SRC (default generator/app_snapshot/src/js)
   ===================================================================== */

const fs = require('fs');
const path = require('path');
const { loadApp } = require('./load_app');

const ROOT = path.join(__dirname, '..');
const SCENARIOS = process.env.MEDIFIND_SCENARIOS || path.join(__dirname, 'app_snapshot', 'tests', 'condition-scenarios.json');
const OUT = path.join(ROOT, 'data', 'app_test_vignettes.csv');

const app = loadApp();
const ORDER = app.FEATURE_ORDER;

function csvCell(value) {
  if (value === null || value === undefined) return '';
  const text = String(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function encode(patientIn, answers) {
  const patient = { name: 'Test case', age: patientIn.age ?? '', gender: patientIn.gender ?? '', contact: '', complaint: patientIn.complaint, description: '' };
  const encoding = app.encodeSymptoms(answers, patient.complaint);
  const fv = app.constructFeatureVector(patient, encoding);
  const processed = app.preprocessFeatures(fv, encoding);
  const sequence = app.buildQuestionSequence(answers, patient.complaint);
  const prediction = app.predictLocally(processed, { complaint: patient.complaint });
  const urgent = app.detectRedFlags(fv.raw).urgent.map((r) => r.id);
  return { patient, fv, prediction, urgent, complete: sequence.complete };
}

const rows = [];
JSON.parse(fs.readFileSync(SCENARIOS, 'utf8')).forEach((s) => {
  rows.push({ id: s.id, source: 'engine-test scenario', expected: s.expect || '', expectedUrgent: s.expectUrgent ? 1 : 0, note: s.note || '', ...encode(s.patient, s.answers) });
});
app.DEMO_CASES.forEach((d) => {
  rows.push({ id: d.id, source: 'app demo case', expected: d.expectCondition || '', expectedUrgent: d.expect === 'Emergency & Triage' ? 1 : 0, note: d.label || '', ...encode(d.patient, d.answers) });
});

const header = ['vignette_id', 'source', 'expected_condition', 'expected_urgent', 'note', 'patient_gender', 'main_complaint', ...ORDER,
  'questionnaire_complete', 'red_flags', 'rule_condition_id', 'rule_category', 'rule_top_category'];
const lines = [header.map(csvCell).join(',')];
rows.forEach((r) => {
  lines.push([
    r.id, r.source, r.expected, r.expectedUrgent, r.note, r.patient.gender, r.patient.complaint,
    ...ORDER.map((k) => (r.fv.raw[k] === null || r.fv.raw[k] === undefined ? null : r.fv.raw[k])),
    r.complete ? 1 : 0, r.urgent.join(';'), r.prediction.predictedConditionId, r.prediction.predictedCategoryId, r.prediction.topCategoryId,
  ].map(csvCell).join(','));
});
fs.writeFileSync(OUT, `${lines.join('\n')}\n`);
console.log(`Exported ${rows.length} hand-written cases (${rows.filter((r) => r.expected).length} with an expected condition) to ${OUT}`);
