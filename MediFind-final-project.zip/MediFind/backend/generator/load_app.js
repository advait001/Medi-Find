// Loads MediFind's own engine code (questionnaire, encoder, knowledge base)
// into an isolated VM context, exactly as the app's engine tests do.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Default: the copy in app_snapshot/, the exact engine version the dataset was generated from.
// Set MEDIFIND_SRC to use another copy of MediFind's src/js.
const APP_SRC = process.env.MEDIFIND_SRC || path.join(__dirname, 'app_snapshot', 'src', 'js');
const FILES = ['01-config.js', '02-state.js', '03a-auth.js', '04-intake.js', '05-questionnaire.js', '05a-body-figure.js', '05b-bodymap.js',
  '06-branching.js', '07-preprocessing.js', '08-prediction.js', '09-confidence.js', '10-safety.js', '11-specialist.js', '12a-plain-language.js', '17-utils.js'];

function loadApp() {
  const source = FILES.map((f) => fs.readFileSync(path.join(APP_SRC, f), 'utf8')).join('\n');
  const exportNames = ['FEATURE_SCHEMA', 'FEATURE_SCHEMA_VERSION', 'FEATURE_ORDER', 'COMPLAINTS', 'QUESTION_TREE', 'CONDITIONS', 'CONDITION_INDEX',
    'CATEGORIES', 'CATEGORY_ORDER', 'PREDICTION_RULES', 'SPECIALIST_MAPPING', 'DOCTOR_DIRECTORY', 'RED_FLAG_RULES', 'SYMPTOM_LABELS', 'CONFIDENCE_THRESHOLDS', 'DEMO_CASES',
    'getQuestion', 'findOption', 'buildQuestionSequence', 'encodeSymptoms', 'constructFeatureVector', 'preprocessFeatures', 'predictLocally',
    'detectRedFlags', 'mapPredictionToSpecialist', 'primaryCategory', 'conditionCategories', 'scoreCondition', 'getComplaint', 'getUnit'];
  const context = {
    console, Math, JSON, Date, Object, Array, Number, String, Set, Map, Boolean, RegExp, Error, Symbol, Promise, Intl, isFinite, parseFloat, parseInt,
    window: { matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }), localStorage: null, sessionStorage: null, crypto: undefined },
    document: { body: { dataset: {} }, documentElement: { dataset: {} }, getElementById: () => null, querySelector: () => null, querySelectorAll: () => [], addEventListener() {} },
    navigator: { userAgent: 'node' }, performance: { now: () => 0 }, setTimeout, clearTimeout,
  };
  vm.createContext(context);
  vm.runInContext(`${source}\n;globalThis.__app = { ${exportNames.join(', ')} };`, context, { filename: 'medifind-engine.js' });
  return context.__app;
}

module.exports = { loadApp, APP_SRC };
