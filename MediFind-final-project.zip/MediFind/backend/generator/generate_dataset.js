#!/usr/bin/env node
/* =====================================================================
   MediFind synthetic dataset generator
   ---------------------------------------------------------------------
   Creates the labelled symptom–disease dataset used to train the
   MediFind ML models. There is no real patient data in it: every row is
   a SIMULATED patient case.

   Why simulated: MediFind has no collection of labelled hospital records,
   and public symptom datasets do not use MediFind's questions, so a model
   trained on them could not read the features the app produces. Real
   patient data would also need consent, de-identification and ethics
   approval. A real deployment must retrain on clinically labelled data.

   How a case is made (for one condition, e.g. angina):
     1. Age and gender are drawn from a population mix, re-weighted by the
        condition's age/gender evidence (angina: older patients).
     2. The presenting complaint is drawn from the complaints whose
        question branch can express the condition, weighted by how often
        people name that body system first (angina: mostly Pain).
     3. MediFind's REAL questionnaire is walked question by question, with
        its real branching. Each answer is drawn with probability
          p(answer) ∝ exp( β · fit(answer) − presence − irrelevance )
        fit         = how strongly the app's knowledge base links the
                      features this answer produces to the condition
                      (condition weights + 0.3 × department weights);
        presence    = a small cost for every symptom the answer adds;
        irrelevance = a larger cost for symptoms the condition does not
                      have, so unrelated symptoms stay uncommon;
        warning     = a cost for answers that trigger one of the app's
                      urgent warning-sign rules (lower for conditions such
                      as stroke-like deficits, where they are common);
        β varies per case (clear or vague presentations), a little uniform
        noise is mixed in, and some yes/no answers are "Not sure".
     4. The answers are encoded with the app's own encoder into the 160
        features of schema sdp-features-v3 — the exact vector the app
        sends to a model at prediction time.
     5. A case is kept only if it meets the condition's defining rule
        (angina requires chest pain or discomfort); otherwise it is drawn
        again.

   Run:  node generator/generate_dataset.js
   Env:  CASES_PER_CONDITION (default 275), SEED (default 20261023),
         MEDIFIND_SRC (path to MediFind's src/js; default generator/app_snapshot/src/js,
                       the copy of the engine files this dataset was generated from)
   ===================================================================== */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { loadApp, APP_SRC } = require('./load_app');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const FIXTURE_DIR = path.join(ROOT, 'tests', 'fixtures');
const CASES_PER_CONDITION = Number(process.env.CASES_PER_CONDITION || 275);
const SEED = Number(process.env.SEED || 20261023);
const QUIET = process.env.QUIET === '1';

/* Generation settings (documented in the model documentation). */
const GEN = {
  departmentWeightShare: 0.3, // share of the department-level weights added to a condition's own weights
  presenceCost: 0.9, // cost of each symptom an answer adds
  irrelevantCost: 1.6, // extra cost of a symptom the condition does not have
  irrelevantBreathingCost: 3.0, // cost per unit (0–1) of breathing difficulty the condition does not cause
  multiOptionBias: 0.8, // extra cost for ticking an option in a "tick all that apply" question
  warningSignBias: 3.5, // extra cost for ticking a warning sign in the final safety question
  urgentSignCost: 2.5, // cost of an answer that newly triggers one of the app's urgent warning-sign rules
  urgentProneConditions: { // conditions whose presentation often includes a warning sign: lower cost
    focal_deficit: 0.2, first_seizure: 0.35, febrile_headache_warning: 0.4, gi_bleeding: 0.5, epilepsy: 0.8,
  },
  complaintAcceptancePower: 2, // favours questionnaire branches that express the condition reliably
  betaRange: [0.35, 0.85], // how clearly the patient presents the condition (per case)
  noiseRange: [0.02, 0.1], // share of uniform noise in each single-choice answer (per case)
  unsureRange: [0, 0.08], // chance of answering "Not sure" to a yes/no question (per case)
  multiNoiseTick: 0.08, // tick rate of an option when noise decides it
  demographicBeta: 0.8,
  painPrior: { mean: 5, sd: 2.1 },
  temperaturePrior: { mean: 38.6, sd: 0.7 },
  fahrenheitShare: 0.25, // temperature readings entered in °F (the encoder converts them)
  pilotWalks: 30, // pilot walks per condition and complaint, used to choose presenting complaints
  complaintFitScale: 0.15,
  // How likely a patient with a condition in each department is to name each
  // main complaint first (people describe the body system that troubles them).
  // Multiplied by how reliably that complaint's question branch can express the
  // condition; complaints not listed get 0.1.
  complaintAffinity: {
    cardiovascular: { pain: 1, dizziness: 0.6, weakness: 0.4, respiratory: 0.3, other: 0.3 },
    respiratory: { respiratory: 1, fever: 0.6, pain: 0.2, other: 0.3 },
    musculoskeletal: { joint_limb: 1, pain: 1, other: 0.3 },
    dermatological: { skin: 1, fever: 0.2, other: 0.3 },
    neurological: { neuro: 1, dizziness: 0.8, pain: 0.6, weakness: 0.5, other: 0.3 },
    gastrointestinal: { digestive: 1, pain: 0.8, fever: 0.2, other: 0.3 },
    general: { fever: 1, weakness: 0.8, pain: 0.4, dizziness: 0.4, other: 0.4, respiratory: 0.3, digestive: 0.3, skin: 0.2, joint_limb: 0.2, neuro: 0.2 },
  },
  minComplaintAcceptance: 0.03,
  minComplaintShare: 0.15, // complaints below 15% of the best one are dropped
  maxAttempts: 400,
  ageBands: [ // population mix of patients at a hospital reception desk
    { min: 5, max: 15, share: 0.06 },
    { min: 16, max: 29, share: 0.22 },
    { min: 30, max: 44, share: 0.27 },
    { min: 45, max: 64, share: 0.3 },
    { min: 65, max: 88, share: 0.15 },
  ],
};

/* ---------- Seeded random numbers (reproducible) ---------- */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(SEED);
const uniform = (a, b) => a + (b - a) * rand();
const sigmoid = (x) => 1 / (1 + Math.exp(-x));
function pick(weights) {
  const total = weights.reduce((sum, w) => sum + w, 0);
  let r = rand() * total;
  for (let i = 0; i < weights.length; i += 1) {
    r -= weights[i];
    if (r <= 0) return i;
  }
  return weights.length - 1;
}
function softmax(scores) {
  const max = Math.max(...scores);
  const exps = scores.map((s) => Math.exp(s - max));
  const total = exps.reduce((sum, e) => sum + e, 0);
  return exps.map((e) => e / total);
}
const withNoise = (probs, noise) => probs.map((p) => (1 - noise) * p + noise / probs.length);
const round1 = (x) => Math.round(x * 10) / 10;

/* ---------- The app's knowledge base ---------- */
const app = loadApp();
const SCHEMA = app.FEATURE_SCHEMA;
const ORDER = app.FEATURE_ORDER;
const NOT_SYMPTOMS = new Set(['durationShort', 'durationOver3Days', 'durationOverWeek', 'durationOverMonth', 'acuteOnset', 'highFever',
  'breathingConcern', 'skinConcern', 'neuroConcern', 'digestiveConcern', 'mskConcern']);
const SYMPTOM_BINARY = SCHEMA
  .filter((d) => d.type === 'binary' && !/^(age|gender|complaint_)/.test(d.key) && !NOT_SYMPTOMS.has(d.key))
  .map((d) => d.key);

function primaryCategoryOf(condition) {
  return Array.isArray(condition.category) ? condition.category[0] : condition.category;
}

/* Per condition: merged evidence weights W and the set of features it has (POS). */
const MODELS = app.CONDITIONS.map((condition) => {
  const category = primaryCategoryOf(condition);
  const departmentWeights = (app.PREDICTION_RULES[category] || { weights: {} }).weights;
  const W = {};
  Object.entries(departmentWeights).forEach(([k, w]) => { W[k] = (W[k] || 0) + GEN.departmentWeightShare * w; });
  Object.entries(condition.weights).forEach(([k, w]) => { W[k] = (W[k] || 0) + w; });
  // Symptoms the condition itself has (its own positive weights). Department-level
  // weights still add to the fit, but do not make a symptom common on their own.
  const POS = new Set(Object.keys(condition.weights).filter((k) => condition.weights[k] > 0));
  const urgentCost = GEN.urgentSignCost * (GEN.urgentProneConditions[condition.id] ?? 1);
  return { condition, category, W, POS, urgentCost };
});

function fit(model, f) {
  let s = 0;
  for (const k in model.W) s += model.W[k] * (f[k] || 0);
  return s;
}

function evaluate(patient, complaint, answers) {
  const encoding = app.encodeSymptoms(answers, complaint);
  const fv = app.constructFeatureVector(patient, encoding);
  const processed = app.preprocessFeatures(fv, encoding);
  return { encoding, fv, processed };
}
/* Normalised features plus the urgent warning-sign rules they trigger. */
function stateOf(ctx, answers) {
  const ev = evaluate(ctx.patient, ctx.complaint, answers);
  const f = ev.processed.named;
  Object.defineProperty(f, '__urgent', { value: new Set(app.detectRedFlags(ev.fv.raw).urgent.map((r) => r.id)), enumerable: false });
  return f;
}
const featuresOf = stateOf;
function newUrgentSigns(before, after) {
  let n = 0;
  after.__urgent.forEach((id) => { if (!before.__urgent.has(id)) n += 1; });
  return n;
}

function novelty(model, before, after) {
  let presence = 0;
  let irrelevant = 0;
  for (const k of SYMPTOM_BINARY) {
    if (after[k] === 1 && before[k] !== 1) {
      presence += 1;
      if (!model.POS.has(k)) irrelevant += 1;
    }
  }
  const breathingRise = Math.max(0, (after.breathingDifficulty || 0) - (before.breathingDifficulty || 0));
  return { presence, irrelevant, breathing: model.POS.has('breathingDifficulty') ? 0 : breathingRise, urgent: newUrgentSigns(before, after) };
}

function answerScore(model, ctx, before, after) {
  const nv = novelty(model, before, after);
  return ctx.beta * fit(model, after) - GEN.presenceCost * nv.presence - GEN.irrelevantCost * nv.irrelevant
    - GEN.irrelevantBreathingCost * nv.breathing - model.urgentCost * nv.urgent;
}

/* ---------- Answer sampling, per question type ---------- */
function sampleSingle(model, ctx, q, answers, before) {
  const isUnsure = (o) => o.unsure || o.value === 'unsure';
  const unsure = q.options.find(isUnsure);
  if (unsure && rand() < ctx.unsureRate) return unsure.value;
  const candidates = q.options.filter((o) => !isUnsure(o));
  const scores = candidates.map((o) => answerScore(model, ctx, before, featuresOf(ctx, { ...answers, [q.id]: o.value })));
  return candidates[pick(withNoise(softmax(scores), ctx.noise))].value;
}

function sampleMulti(model, ctx, q, answers) {
  const none = q.options.find((o) => o.exclusive);
  const empty = featuresOf(ctx, { ...answers, [q.id]: none ? [none.value] : [] });
  const emptyFit = fit(model, empty);
  const warning = q.id === 'safety_check';
  const bias = warning ? GEN.warningSignBias : GEN.multiOptionBias;
  const ticked = [];
  q.options.filter((o) => !o.exclusive).forEach((o) => {
    const after = featuresOf(ctx, { ...answers, [q.id]: [o.value] });
    const nv = novelty(model, empty, after);
    const logit = ctx.beta * (fit(model, after) - emptyFit) - GEN.presenceCost * nv.presence - GEN.irrelevantCost * nv.irrelevant
      - GEN.irrelevantBreathingCost * nv.breathing - model.urgentCost * nv.urgent - bias;
    const noiseTick = warning ? 0 : GEN.multiNoiseTick;
    const p = (1 - ctx.noise) * sigmoid(logit) + ctx.noise * noiseTick;
    if (rand() < p) ticked.push(o.value);
  });
  if (ticked.length) return ticked;
  return none ? [none.value] : [q.options[0].value];
}

function sampleScale(model, ctx, q, answers) {
  const values = [];
  for (let v = q.min; v <= q.max; v += 1) values.push(v);
  const { mean, sd } = GEN.painPrior;
  const before = featuresOf(ctx, answers);
  const scores = values.map((v) => {
    const prior = -0.5 * ((v - mean) / sd) ** 2 - (v === 0 ? 2 : 0);
    const after = featuresOf(ctx, { ...answers, [q.id]: v });
    return ctx.beta * fit(model, after) + prior - model.urgentCost * newUrgentSigns(before, after);
  });
  return values[pick(withNoise(softmax(scores), ctx.noise))];
}

function sampleNumber(model, ctx, q, answers) {
  const temps = [37.2, 37.6, 38.0, 38.4, 38.8, 39.2, 39.6, 40.0, 40.4];
  const { mean, sd } = GEN.temperaturePrior;
  const scores = temps.map((t) => ctx.beta * fit(model, featuresOf(ctx, { ...answers, [q.id]: { value: t, unit: 'C' } }))
    - 0.5 * ((t - mean) / sd) ** 2);
  const celsius = round1(temps[pick(withNoise(softmax(scores), ctx.noise))] + uniform(-0.15, 0.15));
  if (rand() < GEN.fahrenheitShare) return { value: round1(celsius * 9 / 5 + 32), unit: 'F' };
  return { value: celsius, unit: 'C' };
}

function sampleAnswer(model, ctx, q, answers) {
  if (q.type === 'multi') return sampleMulti(model, ctx, q, answers);
  if (q.type === 'scale') return sampleScale(model, ctx, q, answers);
  if (q.type === 'number') return sampleNumber(model, ctx, q, answers);
  return sampleSingle(model, ctx, q, answers, featuresOf(ctx, answers));
}

/* Walks the app's real decision tree until the questionnaire is complete. */
function walk(model, ctx) {
  const answers = {};
  for (let step = 0; step < 60; step += 1) {
    const seq = app.buildQuestionSequence(answers, ctx.complaint);
    if (seq.complete) return answers;
    if (seq.firstUnanswered < 0) return null;
    const q = app.getQuestion(seq.path[seq.firstUnanswered]);
    if (!q) return null;
    answers[q.id] = sampleAnswer(model, ctx, q, answers);
  }
  return null;
}

/* ---------- Demographics ---------- */
function sampleAgeFromPopulation() {
  const band = GEN.ageBands[pick(GEN.ageBands.map((b) => b.share))];
  return Math.floor(uniform(band.min, band.max + 1));
}
function ageFit(model, age) {
  const f = { age: age / 100, ageOver45: Number(age >= 45), ageUnder30: Number(age < 30), ageOver65: Number(age >= 65), ageUnder16: Number(age < 16) };
  return Object.keys(f).reduce((sum, k) => sum + (model.W[k] || 0) * f[k], 0);
}
function sampleDemographics(model) {
  const candidates = Array.from({ length: 10 }, sampleAgeFromPopulation);
  const age = candidates[pick(softmax(candidates.map((a) => GEN.demographicBeta * ageFit(model, a))))];
  let gender = 'other';
  if (rand() >= 0.01) {
    const female = Math.exp(GEN.demographicBeta * (model.W.genderFemale || 0));
    const male = Math.exp(GEN.demographicBeta * (model.W.genderMale || 0));
    gender = rand() < female / (female + male) ? 'female' : 'male';
  }
  return { age, gender };
}

function newContext(model, complaint) {
  const demo = sampleDemographics(model);
  return {
    complaint,
    patient: { name: 'Simulated patient', age: String(demo.age), gender: demo.gender, contact: '', complaint, description: '' },
    beta: uniform(...GEN.betaRange),
    noise: uniform(...GEN.noiseRange),
    unsureRate: uniform(...GEN.unsureRange),
  };
}

function meetsDefinition(model, f) {
  return app.scoreCondition(model.condition, f).met;
}

/* ---------- Presenting complaints, chosen by pilot walks ---------- */
function complaintMix(model) {
  const rows = app.COMPLAINTS.map((complaint) => {
    let accepted = 0;
    let fitSum = 0;
    for (let i = 0; i < GEN.pilotWalks; i += 1) {
      const ctx = newContext(model, complaint.id);
      const answers = walk(model, ctx);
      if (!answers) continue;
      const f = featuresOf(ctx, answers);
      if (!meetsDefinition(model, f)) continue;
      accepted += 1;
      fitSum += fit(model, f);
    }
    const acceptance = accepted / GEN.pilotWalks;
    const meanFit = accepted ? fitSum / accepted : 0;
    const affinity = (GEN.complaintAffinity[model.category] || {})[complaint.id] ?? 0.1;
    const weight = acceptance >= GEN.minComplaintAcceptance
      ? affinity * (acceptance ** GEN.complaintAcceptancePower) * Math.exp(GEN.complaintFitScale * meanFit) : 0;
    return { complaint: complaint.id, acceptance, meanFit, weight };
  });
  const best = Math.max(...rows.map((r) => r.weight));
  const kept = rows.filter((r) => r.weight > 0 && r.weight >= GEN.minComplaintShare * best);
  const total = kept.reduce((sum, r) => sum + r.weight, 0);
  return kept.map((r) => ({ ...r, share: r.weight / total })).sort((a, b) => b.share - a.share);
}

/* ---------- CSV helpers ---------- */
function csvCell(value) {
  if (value === null || value === undefined) return '';
  const text = typeof value === 'number' ? String(value) : String(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}
const csvLine = (cells) => cells.map(csvCell).join(',');

/* ---------- Data dictionary: where each feature comes from ---------- */
function featureSources() {
  const sources = Object.fromEntries(ORDER.map((k) => [k, []]));
  const add = (k, text) => { if (sources[k] && !sources[k].includes(text)) sources[k].push(text); };
  app.COMPLAINTS.forEach((c) => {
    add(`complaint_${c.id}`, `Main complaint "${c.label}"`);
    Object.keys(c.sets || {}).forEach((k) => add(k, `Main complaint "${c.label}"`));
  });
  Object.values(app.QUESTION_TREE).forEach((q) => {
    if (q.featureKey) add(q.featureKey, `${q.id} (${q.short})`);
    if (q.areaScoreKey) add(q.areaScoreKey, `${q.id} (${q.short})`);
    (q.options || []).forEach((o) => {
      Object.keys(o.set || {}).forEach((k) => add(k, `${q.id} = "${o.label}"`));
      if (o.feature) add(o.feature, `${q.id}: ticked "${o.label}"`);
      Object.keys(o.alsoSet || {}).forEach((k) => add(k, `${q.id}: ticked "${o.label}"`));
    });
  });
  const derived = {
    age: 'Patient details: age in years', genderFemale: 'Patient details: gender', genderMale: 'Patient details: gender', genderOther: 'Patient details: gender',
    ageOver45: 'Derived: age 45 or over', ageUnder30: 'Derived: age under 30', ageOver65: 'Derived: age 65 or over', ageUnder16: 'Derived: age under 16',
    highFever: 'Derived: temperature 39 °C or above', durationShort: 'Derived: duration band 1–2 (up to 3 days)', durationOver3Days: 'Derived: duration band 3 or more',
    durationOverWeek: 'Derived: duration band 4 or more', durationOverMonth: 'Derived: duration band 5 (over a month)',
  };
  Object.entries(derived).forEach(([k, text]) => add(k, text));
  return sources;
}

/* ---------- Main ---------- */
function main() {
  const started = Date.now();
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(FIXTURE_DIR, { recursive: true });

  const log = (...args) => { if (!QUIET) console.log(...args); };
  log(`MediFind dataset generator — schema ${app.FEATURE_SCHEMA_VERSION}, ${ORDER.length} features, ${MODELS.length} conditions, ${CASES_PER_CONDITION} cases each, seed ${SEED}`);

  // 1. Presenting complaints per condition
  const mixes = {};
  MODELS.forEach((model) => {
    mixes[model.condition.id] = complaintMix(model);
    if (!mixes[model.condition.id].length) throw new Error(`No questionnaire branch can express ${model.condition.id}`);
  });
  log(`Complaint mix chosen in ${((Date.now() - started) / 1000).toFixed(1)} s`);

  // 2. Cases
  const cases = [];
  const stats = {};
  MODELS.forEach((model) => {
    const id = model.condition.id;
    const mix = mixes[id];
    const st = { attempts: 0, accepted: 0, failedWalks: 0 };
    for (let n = 0; n < CASES_PER_CONDITION; n += 1) {
      let made = null;
      for (let attempt = 0; attempt < GEN.maxAttempts && !made; attempt += 1) {
        st.attempts += 1;
        const complaint = mix[pick(mix.map((m) => m.share))].complaint;
        const ctx = newContext(model, complaint);
        const answers = walk(model, ctx);
        if (!answers) { st.failedWalks += 1; continue; }
        const ev = evaluate(ctx.patient, complaint, answers);
        if (!meetsDefinition(model, ev.processed.named)) continue;
        made = { model, ctx, answers, ev };
      }
      if (!made) throw new Error(`Could not generate a case for ${id} in ${GEN.maxAttempts} attempts`);
      st.accepted += 1;
      cases.push(made);
    }
    stats[id] = { ...st, acceptance: Math.round((st.accepted / st.attempts) * 1000) / 1000 };
  });
  log(`Generated ${cases.length} cases in ${((Date.now() - started) / 1000).toFixed(1)} s`);

  // 3. Shuffle (seeded) and number the cases
  for (let i = cases.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [cases[i], cases[j]] = [cases[j], cases[i]];
  }

  // 4. Write the dataset, answers, baseline and parity fixture
  const header = ['case_id', 'patient_gender', 'main_complaint', ...ORDER, 'condition_id', 'condition_name', 'category', 'department', 'specialist',
    'red_flag', 'red_flags', 'questions_asked', 'unsure_answers'];
  const datasetLines = [csvLine(header)];
  const answerLines = [];
  const baselineLines = [csvLine(['case_id', 'rule_condition_id', 'rule_category', 'rule_top_category', 'rule_confidence', 'rule_inconclusive'])];
  const parityLines = [csvLine(['case_id', ...ORDER])];
  const parityEvery = Math.max(1, Math.floor(cases.length / 1000));
  let redFlagCount = 0;

  cases.forEach((item, index) => {
    const caseId = `MF-SYN-${String(index + 1).padStart(5, '0')}`;
    const { model, ctx, answers, ev } = item;
    const c = model.condition;
    const mapping = app.SPECIALIST_MAPPING[model.category];
    const raw = ev.fv.raw;
    const flags = app.detectRedFlags(raw).urgent.map((r) => r.id);
    if (flags.length) redFlagCount += 1;
    datasetLines.push(csvLine([
      caseId, ctx.patient.gender, ctx.complaint,
      ...ORDER.map((k) => (raw[k] === null || raw[k] === undefined ? null : raw[k])),
      c.id, c.name, model.category, mapping.department, mapping.specialist,
      flags.length ? 1 : 0, flags.join(';'), ev.encoding.askedQuestions.length, ev.encoding.unsureQuestions.length,
    ]));
    answerLines.push(JSON.stringify({ case_id: caseId, patient: { age: ctx.patient.age, gender: ctx.patient.gender, complaint: ctx.complaint }, answers, condition_id: c.id }));
    const prediction = app.predictLocally(ev.processed, { complaint: ctx.complaint });
    baselineLines.push(csvLine([caseId, prediction.predictedConditionId, prediction.predictedCategoryId, prediction.topCategoryId, prediction.confidence, prediction.isInconclusive ? 1 : 0]));
    if (index % parityEvery === 0) parityLines.push(csvLine([caseId, ...ev.processed.vector]));
  });

  fs.writeFileSync(path.join(DATA_DIR, 'medifind_symptom_dataset.csv'), `${datasetLines.join('\n')}\n`);
  fs.writeFileSync(path.join(DATA_DIR, 'questionnaire_answers.jsonl'), `${answerLines.join('\n')}\n`);
  fs.writeFileSync(path.join(DATA_DIR, 'rule_engine_baseline.csv'), `${baselineLines.join('\n')}\n`);
  fs.writeFileSync(path.join(FIXTURE_DIR, 'js_preprocessed_sample.csv'), `${parityLines.join('\n')}\n`);

  // 5. Schema, conditions and data dictionary
  const labels = app.SYMPTOM_LABELS;
  fs.writeFileSync(path.join(DATA_DIR, 'feature_schema.json'), `${JSON.stringify({
    schemaVersion: app.FEATURE_SCHEMA_VERSION,
    note: 'Fixed feature order used by MediFind (src/js/01-config.js FEATURE_SCHEMA). Binary 0/1; ordinal and numeric are min-max normalised to 0-1; missing values are imputed as 0.',
    order: ORDER,
    features: SCHEMA.map((d) => ({ key: d.key, type: d.type, min: d.min ?? null, max: d.max ?? null, internal: Boolean(d.internal), label: labels[d.key] || d.key })),
  }, null, 2)}\n`);

  const conditions = MODELS.map((model) => {
    const c = model.condition;
    const mapping = app.SPECIALIST_MAPPING[model.category];
    const doctor = app.DOCTOR_DIRECTORY[model.category];
    return {
      id: c.id, name: c.name, short: c.short, description: c.description,
      category: model.category, categories: Array.isArray(c.category) ? c.category : [c.category],
      department: mapping.department, specialist: mapping.specialist, doctor: doctor ? doctor.name : null,
      presentingComplaints: mixes[c.id].map((m) => ({ complaint: m.complaint, share: Math.round(m.share * 1000) / 1000 })),
    };
  });
  fs.writeFileSync(path.join(DATA_DIR, 'conditions.json'), `${JSON.stringify({ categories: app.CATEGORY_ORDER.map((id) => ({
    id, label: app.CATEGORIES[id].label, department: app.SPECIALIST_MAPPING[id].department, specialist: app.SPECIALIST_MAPPING[id].specialist,
  })), conditions }, null, 2)}\n`);

  const sources = featureSources();
  const dictLines = [csvLine(['column', 'type', 'min', 'max', 'model_input', 'description', 'produced_by'])];
  dictLines.push(csvLine(['case_id', 'id', null, null, 'no', 'Simulated case identifier', 'Generator']));
  dictLines.push(csvLine(['patient_gender', 'category', null, null, 'no (see the gender features)', 'female, male or other, as entered on the intake form', 'Generator']));
  dictLines.push(csvLine(['main_complaint', 'category', null, null, 'no (see the complaint features)', 'Main complaint chosen at the start of the questionnaire (MediFind complaint id)', 'Generator']));
  SCHEMA.forEach((d) => {
    dictLines.push(csvLine([d.key, d.type, d.min ?? (d.type === 'binary' ? 0 : null), d.max ?? (d.type === 'binary' ? 1 : null), 'yes',
      `${labels[d.key] || d.key}${d.internal ? ' (internal: used by the model, not shown as a symptom)' : ''}. Blank = question not asked or answered "Not sure".`,
      sources[d.key].slice(0, 4).join('; ') + (sources[d.key].length > 4 ? '; …' : '')]));
  });
  [
    ['condition_id', 'label', null, null, 'target', 'Condition the case was generated from (the class the model learns)', 'Generator'],
    ['condition_name', 'text', null, null, 'no', 'Readable condition name from MediFind', 'MediFind CONDITIONS'],
    ['category', 'label', null, null, 'derived target', 'Primary disease category of the condition', 'MediFind CONDITIONS'],
    ['department', 'text', null, null, 'no', 'Department the category maps to', 'MediFind SPECIALIST_MAPPING'],
    ['specialist', 'text', null, null, 'no', 'Suggested specialist', 'MediFind SPECIALIST_MAPPING'],
    ['red_flag', 'binary', 0, 1, 'no', '1 if the answers include an urgent warning sign (the app escalates these whatever the model says)', 'MediFind RED_FLAG_RULES'],
    ['red_flags', 'text', null, null, 'no', 'Ids of the urgent warning signs found', 'MediFind RED_FLAG_RULES'],
    ['questions_asked', 'integer', null, null, 'no', 'Number of questions on the case route', 'MediFind questionnaire'],
    ['unsure_answers', 'integer', null, null, 'no', 'Number of "Not sure" answers', 'MediFind questionnaire'],
  ].forEach((row) => dictLines.push(csvLine(row)));
  fs.writeFileSync(path.join(DATA_DIR, 'data_dictionary.csv'), `${dictLines.join('\n')}\n`);

  // 6. Generation report
  const srcHash = crypto.createHash('sha256');
  ['01-config.js', '05-questionnaire.js', '07-preprocessing.js'].forEach((f) => srcHash.update(fs.readFileSync(path.join(APP_SRC, f))));
  const report = {
    generatedAt: new Date().toISOString(),
    seed: SEED,
    casesPerCondition: CASES_PER_CONDITION,
    totalCases: cases.length,
    conditions: MODELS.length,
    featureSchema: app.FEATURE_SCHEMA_VERSION,
    features: ORDER.length,
    redFlagCases: redFlagCount,
    appSourceSha256: srcHash.digest('hex'),
    settings: GEN,
    perCondition: Object.fromEntries(MODELS.map((m) => [m.condition.id, { ...stats[m.condition.id], complaints: conditions.find((c) => c.id === m.condition.id).presentingComplaints }])),
    seconds: Math.round((Date.now() - started) / 100) / 10,
  };
  fs.writeFileSync(path.join(DATA_DIR, 'generation_report.json'), `${JSON.stringify(report, null, 2)}\n`);
  log(`Done in ${report.seconds} s: ${cases.length} cases, ${redFlagCount} with urgent warning signs. Files in ${DATA_DIR}`);
}

main();
