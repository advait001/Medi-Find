"""MediFind prediction API (Flask).

The production design in the project documents serves the trained model from
a Python backend. MediFind's front end already calls it when its prediction
service is switched to API mode (PredictionService.mode = 'api' in
src/js/08-prediction.js): it POSTs the normalised feature vector to
/api/predict and maps the response with normaliseApiPrediction().

Endpoints
    POST /api/predict   body: MediFind's payload
                          {"schemaVersion", "featureOrder", "features": [160 normalised values], "completeness", "complaint"}
                        or raw values {"features": {"chestPain": 1, ...}}
                        returns {"category", "probabilities", "disease", "diseaseProbability", "differentials",
                                 "evidence": {"supporting": [...], "against": [...]}, ...}
    GET  /api/health    model name, version, schema and test metrics
    GET  /              MediFind's index.html, when started with --app, so the app and the API share one origin

Run
    python ml/api.py --port 5000
    python ml/api.py --port 5000 --app ../sdp/index.html
Use a production WSGI server (for example gunicorn or waitress) behind HTTPS for real use.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from flask import Flask, jsonify, request, send_file

import predict as service


def create_app(bundle: dict | None = None, app_html: str | Path | None = None) -> Flask:
    bundle = bundle or service.load_bundle()
    api = Flask(__name__)
    api.json.sort_keys = False
    api.config["MAX_CONTENT_LENGTH"] = 64 * 1024  # a feature vector is about 2 KB

    @api.post("/api/predict")
    def predict_route():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify(error="Send a JSON object with the feature vector."), 400
        try:
            X = service.vector_from_payload(payload, bundle)
        except ValueError as problem:
            return jsonify(error=str(problem)), 400
        # The request body is not logged or stored. It holds the encoded answers (with age and
        # gender), the complaint group and completeness, never a name or contact number.
        # Flask's development server still prints one line per request (time, path, status).
        return jsonify(service.predict(bundle, X))

    @api.get("/api/health")
    def health_route():
        metrics = bundle.get("metrics", {})
        return jsonify(
            status="ok",
            model=bundle["model_name"],
            version=bundle["model_version"],
            schemaVersion=bundle["schema_version"],
            features=len(bundle["feature_order"]),
            conditions=len(bundle["classes"]),
            trainedAt=bundle.get("trained_at"),
            testMetrics={k: round(float(metrics[k]), 4) for k in ("accuracy", "f1_macro", "department_accuracy") if k in metrics},
            trainingData="simulated cases (no real patient data)",
        )

    if app_html:
        page = Path(app_html).resolve()

        @api.get("/")
        def app_route():
            return send_file(page)

    return api


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve the MediFind model over HTTP")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--app", help="path to MediFind's index.html, served at / on the same origin")
    args = parser.parse_args()
    create_app(app_html=args.app).run(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
