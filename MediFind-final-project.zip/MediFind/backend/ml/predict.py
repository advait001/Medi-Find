"""Predicts with the saved MediFind model.

Examples
    python ml/predict.py --case MF-SYN-00042          # a case from the dataset (shows its true label)
    python ml/predict.py --json examples/chest_pain_case.json
    python ml/predict.py --json case.json --raw-output # print the /api/predict response as JSON

The JSON file holds either raw feature values, as MediFind's
constructFeatureVector produces them (missing = null):
    {"features": {"age": 52, "genderMale": 1, "complaint_pain": 1, "chestPain": 1, ...}}
or a normalised vector in schema order, as MediFind sends to /api/predict:
    {"schemaVersion": "sdp-features-v3", "featureOrder": [...], "features": [0.52, 0, ...]}
"""
from __future__ import annotations

import argparse
import json
import sys

import joblib
import numpy as np

import medifind_ml as mm


def load_bundle(path=mm.MODEL_PATH) -> dict:
    if not path.exists():
        sys.exit(f"No saved model at {path}. Run: python ml/train_models.py")
    return joblib.load(path)


def vector_from_payload(payload: dict, bundle: dict) -> np.ndarray:
    """Accepts MediFind's /api/predict payload (normalised) or raw feature values."""
    features = payload.get("features")
    if isinstance(features, dict):
        schema = {"order": bundle["feature_order"], "features": bundle["feature_schema"]}
        return mm.preprocess(mm.raw_to_frame(features, schema), schema)
    if isinstance(features, list):
        version = payload.get("schemaVersion", bundle["schema_version"])
        if version != bundle["schema_version"]:
            raise ValueError(f"schemaVersion {version!r} does not match the model ({bundle['schema_version']!r})")
        order = payload.get("featureOrder", bundle["feature_order"])
        if list(order) != bundle["feature_order"]:
            raise ValueError("featureOrder does not match the order the model was trained on")
        if len(features) != len(bundle["feature_order"]):
            raise ValueError(f"expected {len(bundle['feature_order'])} features, got {len(features)}")
        try:
            vector = np.asarray(features, dtype=float)
        except (TypeError, ValueError):
            raise ValueError("normalised features must be numbers between 0 and 1") from None
        if vector.ndim != 1 or not np.all(np.isfinite(vector)) or vector.min() < 0 or vector.max() > 1:
            raise ValueError("normalised features must be numbers between 0 and 1")
        return vector[None, :]
    raise ValueError("'features' must be an object of raw values or a list of normalised values")


def predict(bundle: dict, X: np.ndarray) -> dict:
    proba = bundle["model"].predict_proba(X)[0]
    return mm.build_prediction(proba, bundle, x_row=X[0])


def describe(result: dict) -> str:
    lines = [
        f"Department:   {result['department']} ({result['probabilities'][result['category']]:.0%} model confidence)"
        + ("  -> below 55%: MediFind shows 'General / Inconclusive'" if result["inconclusive"] else ""),
        f"Specialist:   {result['specialist']}" + (f"  (doctor to see: {result['doctor']})" if result.get("doctor") else ""),
        f"Condition:    {result['disease']} ({result['diseaseProbability']:.0%}) - a preliminary prediction, not a diagnosis",
        "Alternatives: " + "; ".join(f"{d['disease']} {d['probability']:.0%}" for d in result["differentials"]),
    ]
    evidence = result.get("evidence") or {}
    if evidence.get("supporting"):
        lines.append("Answers that pushed the model towards it: " + ", ".join(e["label"] for e in evidence["supporting"][:5]))
    lines += [
        f"Model:        {result['model']['name']} v{result['model']['version']} (schema {result['model']['schemaVersion']})",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Predict with the saved MediFind model")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--case", help="case_id from data/medifind_symptom_dataset.csv")
    source.add_argument("--json", help="JSON file with raw features or a normalised vector")
    parser.add_argument("--raw-output", action="store_true", help="print the API response JSON")
    args = parser.parse_args()

    bundle = load_bundle()
    truth = None
    if args.case:
        df = mm.load_dataset()
        row = df[df["case_id"] == args.case]
        if row.empty:
            sys.exit(f"No case {args.case} in the dataset")
        schema = {"order": bundle["feature_order"], "features": bundle["feature_schema"]}
        X = mm.preprocess(row, schema)
        truth = row.iloc[0]
    else:
        with open(args.json, encoding="utf-8") as handle:
            X = vector_from_payload(json.load(handle), bundle)

    result = predict(bundle, X)
    if args.raw_output:
        print(json.dumps(result, indent=2))
        return
    print(describe(result))
    if truth is not None:
        hit = "match" if truth["condition_id"] == result["diseaseId"] else "different"
        print(f"Generated as: {truth['condition_name']} ({truth['department']}) -> {hit}")


if __name__ == "__main__":
    main()
