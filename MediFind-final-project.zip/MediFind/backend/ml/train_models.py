"""Trains, compares and saves the MediFind disease-prediction models.

Follows section 7 of the project's algorithm document: the labelled
symptom-disease dataset is split into training and testing sets; Random
Forest, Decision Tree and Logistic Regression are trained on the same
features; they are compared with accuracy, precision, recall, F1-score and
confusion matrices; the selected model is saved for the web application.

    python ml/train_models.py            # full run (about 2 minutes on 2 CPU cores)
    python ml/train_models.py --quick    # smaller search grids, for a quick check

Outputs: models/medifind_model.joblib, models/model_card.json and the
metrics, tables and charts in reports/.
"""
from __future__ import annotations

import argparse
import json
import platform
import time
from datetime import datetime, timezone

import joblib
import matplotlib
import numpy as np
import pandas as pd
import sklearn

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from sklearn.ensemble import RandomForestClassifier  # noqa: E402
from sklearn.inspection import permutation_importance  # noqa: E402
from sklearn.linear_model import LogisticRegression  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_recall_fscore_support,
    top_k_accuracy_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split  # noqa: E402
from sklearn.tree import DecisionTreeClassifier, export_text  # noqa: E402

import medifind_ml as mm  # noqa: E402

MODEL_VERSION = "1.0.0"
DEPARTMENT_COLOURS = {
    "cardiovascular": "#b02a6b", "respiratory": "#1f6fa8", "musculoskeletal": "#9a5b0b", "dermatological": "#7b45a8",
    "neurological": "#4f4fc4", "gastrointestinal": "#4b7a2a", "general": "#1f6b6f",
}
MODEL_COLOURS = {"Logistic Regression": "#143293", "Random Forest": "#2f8f6a", "Decision Tree": "#c07a12", "Rule-based engine (current app)": "#8a94a6"}


def model_specs(quick: bool) -> dict:
    rs = mm.RANDOM_STATE
    if quick:
        return {
            "Logistic Regression": (LogisticRegression(max_iter=3000), {"C": [1.0]}),
            "Decision Tree": (DecisionTreeClassifier(random_state=rs), {"max_depth": [20], "min_samples_leaf": [3]}),
            "Random Forest": (RandomForestClassifier(n_estimators=100, random_state=rs, n_jobs=-1), {"min_samples_leaf": [1]}),
        }
    return {
        "Logistic Regression": (LogisticRegression(max_iter=3000), {"C": [0.1, 0.3, 1.0, 3.0]}),
        "Decision Tree": (DecisionTreeClassifier(random_state=rs),
                          {"criterion": ["gini", "entropy"], "max_depth": [12, 20, None], "min_samples_leaf": [1, 3, 8]}),
        "Random Forest": (RandomForestClassifier(n_estimators=200, random_state=rs, n_jobs=-1),
                          {"max_features": ["sqrt", 0.15], "min_samples_leaf": [1, 2]}),
    }


def slug(name: str) -> str:
    return name.lower().replace(" ", "_")


def estimator_size_kb(model, name: str) -> float:
    """Size of the fitted estimator alone, compressed like the saved model file.

    The saved file (models/medifind_model.joblib) also holds metadata such as the
    feature schema and condition table, so it is somewhat larger.
    """
    tmp = mm.MODEL_DIR / f"_size_check_{slug(name)}.joblib"
    joblib.dump(model, tmp, compress=3)
    size = tmp.stat().st_size / 1024
    tmp.unlink()
    return size


def single_case_ms(model, X: np.ndarray, repeats: int = 200) -> float:
    """Median time to predict one case on its own, as MediFind asks for one patient at a time."""
    model.predict_proba(X[:1])  # warm-up
    times = []
    for i in range(repeats):
        row = X[i % len(X): i % len(X) + 1]
        start = time.perf_counter()
        model.predict_proba(row)
        times.append(time.perf_counter() - start)
    return float(np.median(times) * 1000)


def routed_departments(cat_proba: np.ndarray, category_order) -> np.ndarray:
    """The department MediFind would show: General Medicine when the top department is below 55%."""
    top = np.asarray(category_order)[cat_proba.argmax(1)]
    return np.where(cat_proba.max(1) < mm.INCONCLUSIVE_BELOW, "general", top)


def calibration_error(confidence: np.ndarray, correct: np.ndarray, bins: int = 10) -> float:
    """Expected calibration error: average gap between stated confidence and actual accuracy."""
    edges = np.linspace(0, 1, bins + 1)
    total = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (confidence > lo) & (confidence <= hi)
        if mask.any():
            total += mask.mean() * abs(correct[mask].mean() - confidence[mask].mean())
    return float(total)


def evaluate(name, model, X_test, y_test, index, category_order, classes) -> tuple[dict, np.ndarray]:
    start = time.perf_counter()
    proba = model.predict_proba(X_test)
    predict_ms = (time.perf_counter() - start) * 1000 / len(X_test)
    pred = np.asarray(classes)[proba.argmax(1)]
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, pred, average="macro", zero_division=0)
    cat_proba = mm.category_probabilities(proba, classes, index, category_order)
    dept_true = mm.department_of(y_test, index)
    dept_pred = np.asarray(category_order)[cat_proba.argmax(1)]
    dept_conf = cat_proba.max(1)
    dept_routed = routed_departments(cat_proba, category_order)
    confident = dept_conf >= mm.INCONCLUSIVE_BELOW
    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, pred),
        "precision_macro": precision,
        "recall_macro": recall,
        "f1_macro": f1,
        "f1_weighted": f1_score(y_test, pred, average="weighted"),
        "top3_accuracy": top_k_accuracy_score(y_test, proba, k=3, labels=classes),
        "log_loss": log_loss(y_test, proba, labels=classes),
        "department_accuracy": accuracy_score(dept_true, dept_pred),
        # As MediFind routes: results below 55% go to General Medicine (comparable with the rule engine).
        "department_accuracy_routed": accuracy_score(dept_true, dept_routed),
        "department_f1_macro": f1_score(dept_true, dept_pred, average="macro"),
        "department_calibration_error": calibration_error(dept_conf, dept_true == dept_pred),
        "confident_share": float(confident.mean()),
        "department_accuracy_when_confident": float((dept_true[confident] == dept_pred[confident]).mean()) if confident.any() else None,
        "predict_ms_per_case": predict_ms,  # batch of all test cases, divided by the number of cases
        "predict_ms_single_case": single_case_ms(model, X_test),
    }
    return metrics, proba


# Expected results in MediFind's test cases that are not one of the 73 conditions:
# a department-level fallback ("no single condition stands out") or "inconclusive",
# which MediFind routes to General Medicine.
FALLBACK_DEPARTMENT = {
    "cardio_unspecified": "cardiovascular", "resp_unspecified": "respiratory", "msk_unspecified": "musculoskeletal",
    "derm_unspecified": "dermatological", "neuro_unspecified": "neurological", "gi_unspecified": "gastrointestinal",
    "general_unspecified": "general", "inconclusive": "general",
}


def vignette_check(model, schema, index, category_order, classes) -> dict | None:
    """Scores the model on MediFind's hand-written test cases (not produced by the generator).

    The file holds every engine-test scenario and demo case; cases without an expected
    non-urgent result (urgent-only scenarios and three demos) are left out here.
    Condition level: cases whose expected result names at least one of the 73 conditions.
    Department level: every case with an expected result; the department as MediFind would
    route it (General Medicine when the department probability is below 55%).
    Inconclusive: cases that accept "inconclusive" as a result, and those where it is the
    only accepted result.
    """
    if not mm.VIGNETTES_PATH.exists():
        return None
    vig_all = pd.read_csv(mm.VIGNETTES_PATH, low_memory=False)
    vig = vig_all[vig_all["expected_condition"].notna() & (vig_all["expected_condition"] != "")].reset_index(drop=True)
    expected = vig["expected_condition"].str.split("|")
    proba = model.predict_proba(mm.preprocess(vig, schema))
    order = np.argsort(-proba, axis=1)
    cat_proba = mm.category_probabilities(proba, classes, index, category_order)
    dept_conf = cat_proba.max(1)
    routed = routed_departments(cat_proba, category_order)
    rule_routed = np.where(vig["rule_category"] == "inconclusive", "general", vig["rule_category"])
    rule_inconclusive = (vig["rule_category"] == "inconclusive").to_numpy()

    named = [[i for i in ids if i in index] for ids in expected]
    has_named = np.array([bool(n) for n in named])
    top1 = np.asarray(classes)[order[:, 0]]
    top3 = [set(np.asarray(classes)[row[:3]]) for row in order]
    expected_departments = [{index[i]["category"] if i in index else FALLBACK_DEPARTMENT.get(i) for i in ids} - {None} for ids in expected]

    def inconclusive_summary(mask: np.ndarray) -> dict:
        return {
            "cases": int(mask.sum()),
            "model_at_or_above_threshold": int((dept_conf[mask] >= mm.INCONCLUSIVE_BELOW).sum()),
            "model_median_department_confidence": float(np.median(dept_conf[mask])) if mask.any() else None,
            "rule_engine_inconclusive": int(rule_inconclusive[mask].sum()),
        }

    return {
        "file_cases": int(len(vig_all)),
        "cases": int(len(vig)),
        "condition_cases": int(has_named.sum()),
        "accepts_inconclusive": inconclusive_summary(np.array(["inconclusive" in ids for ids in expected])),
        "only_inconclusive": inconclusive_summary(np.array([ids == ["inconclusive"] for ids in expected])),
        "top1_match": float(np.mean([t in set(n) for t, n, h in zip(top1, named, has_named) if h])),
        "top3_match": float(np.mean([bool(s & set(n)) for s, n, h in zip(top3, named, has_named) if h])),
        "department_match": float(np.mean([d in e for d, e in zip(routed, expected_departments)])),
        "rule_engine_top1_match": float(np.mean([r in set(n) for r, n, h in zip(vig["rule_condition_id"], named, has_named) if h])),
        "rule_engine_department_match": float(np.mean([d in e for d, e in zip(rule_routed, expected_departments)])),
    }


def rule_engine_baseline(test_ids: pd.Series, y_test, index) -> dict | None:
    """The app's current rule-based engine, scored on the same test cases."""
    if not mm.BASELINE_PATH.exists():
        return None
    base = pd.read_csv(mm.BASELINE_PATH).set_index("case_id").loc[test_ids]
    dept_true = mm.department_of(y_test, index)
    routed = np.where(base["rule_category"] == "inconclusive", "general", base["rule_category"])
    return {
        "model": "Rule-based engine (current app)",
        "accuracy": accuracy_score(y_test, base["rule_condition_id"]),
        "department_accuracy": accuracy_score(dept_true, routed),
        "department_accuracy_top_category": accuracy_score(dept_true, base["rule_top_category"]),
        "inconclusive_share": float((base["rule_category"] == "inconclusive").mean()),
    }


# ---------------------------------------------------------------- charts

def plot_comparison(rows: list[dict], baseline: dict | None, path):
    # Department: routed as MediFind does (below 55% -> General Medicine), so the models and
    # the rule engine (whose inconclusive results also go to General Medicine) compare like for like.
    labels = ["Condition accuracy", "Macro F1", "Department routed correctly\n(below 55% → General Medicine)"]
    keys = ["accuracy", "f1_macro", "department_accuracy_routed"]
    series = [(r["model"], [r[k] for k in keys]) for r in rows]
    if baseline:
        series.append((baseline["model"], [baseline["accuracy"], np.nan, baseline["department_accuracy"]]))
    fig, ax = plt.subplots(figsize=(8.6, 4.9))
    width = 0.8 / len(series)
    x = np.arange(len(labels))
    for i, (name, values) in enumerate(series):
        bars = ax.bar(x + (i - (len(series) - 1) / 2) * width, values, width * 0.92, label=name, color=MODEL_COLOURS.get(name, "#666"))
        for bar, v in zip(bars, values):
            if not np.isnan(v):
                ax.text(bar.get_x() + bar.get_width() / 2, v + 0.01, f"{v:.1%}", ha="center", va="bottom", fontsize=8)
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 1.08)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.set_title("Test-set results (20% of cases, never seen in training)", fontsize=11)
    ax.legend(fontsize=8, ncol=len(series), loc="upper center", bbox_to_anchor=(0.5, -0.09), frameon=False)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def plot_department_confusion(cm: np.ndarray, category_order, categories, title, path):
    names = [categories[c]["department"] for c in category_order]
    share = cm / cm.sum(axis=1, keepdims=True)
    fig, ax = plt.subplots(figsize=(7.4, 6.2))
    ax.imshow(share, cmap="Blues", vmin=0, vmax=1)
    for i in range(len(names)):
        for j in range(len(names)):
            if cm[i, j]:
                ax.text(j, i, f"{cm[i, j]}\n{share[i, j]:.0%}", ha="center", va="center", fontsize=7.5,
                        color="white" if share[i, j] > 0.55 else "#111a30")
    ax.set_xticks(range(len(names)), names, rotation=35, ha="right", fontsize=8.5)
    ax.set_yticks(range(len(names)), names, fontsize=8.5)
    ax.set_xlabel("Predicted department")
    ax.set_ylabel("True department")
    ax.set_title(title, fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def plot_condition_confusion(cm: np.ndarray, labels, index, path):
    share = cm / cm.sum(axis=1, keepdims=True)
    fig, ax = plt.subplots(figsize=(13, 12))
    ax.imshow(share, cmap="Blues", vmin=0, vmax=1)
    short = [index[c]["short"] for c in labels]
    ax.set_xticks(range(len(labels)), short, rotation=90, fontsize=5.5)
    ax.set_yticks(range(len(labels)), short, fontsize=5.5)
    for tick, cid in zip(ax.get_yticklabels(), labels):
        tick.set_color(DEPARTMENT_COLOURS[index[cid]["category"]])
    for tick, cid in zip(ax.get_xticklabels(), labels):
        tick.set_color(DEPARTMENT_COLOURS[index[cid]["category"]])
    ax.set_xlabel("Predicted condition")
    ax.set_ylabel("True condition")
    ax.set_title("Condition confusion matrix (share of each true condition), grouped by department", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_per_condition_f1(report: pd.DataFrame, path):
    data = report.sort_values("f1")
    fig, ax = plt.subplots(figsize=(8, 13))
    ax.barh(range(len(data)), data["f1"], color=[DEPARTMENT_COLOURS[c] for c in data["category"]])
    ax.set_yticks(range(len(data)), data["condition_short"], fontsize=6.5)
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.set_title("F1-score per condition (test set), coloured by department", fontsize=11)
    handles = [matplotlib.patches.Patch(color=col, label=cat.capitalize()) for cat, col in DEPARTMENT_COLOURS.items()]
    ax.legend(handles=handles, fontsize=7, loc="lower right", frameon=False)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def plot_importance(importance: pd.DataFrame, title, path):
    top = importance.head(20).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7.6, 6))
    ax.barh(top["label"], top["importance_mean"], xerr=top["importance_std"], color="#143293", alpha=0.85)
    ax.set_xlabel("Drop in test accuracy when the feature is shuffled")
    ax.set_title(title, fontsize=11)
    ax.tick_params(axis="y", labelsize=8)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def plot_calibration(curves: dict, path):
    fig, ax = plt.subplots(figsize=(5.8, 5.2))
    ax.plot([0, 1], [0, 1], ls="--", color="#999", lw=1, label="Perfectly calibrated")
    for name, (conf, correct) in curves.items():
        edges = np.linspace(0, 1, 11)
        xs, ys = [], []
        for lo, hi in zip(edges[:-1], edges[1:]):
            mask = (conf > lo) & (conf <= hi)
            if mask.sum() >= 20:
                xs.append(conf[mask].mean())
                ys.append(correct[mask].mean())
        ax.plot(xs, ys, marker="o", ms=4, lw=1.6, label=name, color=MODEL_COLOURS.get(name))
    ax.set_xlabel("Department confidence shown (model probability)")
    ax.set_ylabel("Share routed to the right department")
    ax.set_title("Is the confidence honest? (test set)", fontsize=11)
    ax.legend(fontsize=8, frameon=False)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------- main

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--quick", action="store_true", help="small search grids for a quick check")
    parser.add_argument("--folds", type=int, default=5, help="cross-validation folds (default 5)")
    args = parser.parse_args()

    started = time.perf_counter()
    mm.MODEL_DIR.mkdir(exist_ok=True)
    mm.REPORT_DIR.mkdir(exist_ok=True)

    schema = mm.load_schema()
    conditions = mm.load_conditions()
    index = mm.condition_index(conditions)
    categories = {c["id"]: c for c in conditions["categories"]}
    category_order = [c["id"] for c in conditions["categories"]]
    df = mm.load_dataset()
    unknown = set(df[mm.LABEL_COLUMN]) - set(index)
    if unknown:
        raise ValueError(f"Labels without a condition record: {sorted(unknown)[:5]}")

    X = mm.preprocess(df, schema)
    y = df[mm.LABEL_COLUMN].to_numpy()
    X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
        X, y, df["case_id"], test_size=mm.TEST_SIZE, stratify=y, random_state=mm.RANDOM_STATE)
    print(f"Dataset: {len(df)} cases, {X.shape[1]} features, {len(index)} conditions -> train {len(y_train)}, test {len(y_test)}")

    cv = StratifiedKFold(n_splits=args.folds, shuffle=True, random_state=mm.RANDOM_STATE)
    results, searches, probas = [], {}, {}
    for name, (estimator, grid) in model_specs(args.quick).items():
        t0 = time.perf_counter()
        search = GridSearchCV(estimator, grid, scoring="f1_macro", cv=cv, n_jobs=1 if name == "Random Forest" else -1, refit=True)
        search.fit(X_train, y_train)
        search_seconds = time.perf_counter() - t0
        best = search.best_estimator_
        t1 = time.perf_counter()
        type(best)(**best.get_params()).fit(X_train, y_train)  # time one refit on the training set
        fit_seconds = time.perf_counter() - t1
        classes = list(best.classes_)
        metrics, proba = evaluate(name, best, X_test, y_test, index, category_order, classes)
        cv_row = search.cv_results_
        metrics.update({
            "cv_f1_macro_mean": float(search.best_score_),
            "cv_f1_macro_std": float(cv_row["std_test_score"][search.best_index_]),
            "best_params": search.best_params_,
            "grid_size": int(len(cv_row["params"])),
            "search_seconds": search_seconds,
            "fit_seconds": fit_seconds,
            "estimator_size_kb": estimator_size_kb(best, name),
            "vignettes": vignette_check(best, schema, index, category_order, classes),
        })
        pd.DataFrame(cv_row).drop(columns=[c for c in cv_row if c.startswith("split")], errors="ignore") \
            .to_csv(mm.REPORT_DIR / f"cv_results_{slug(name)}.csv", index=False)
        results.append(metrics)
        searches[name] = search
        probas[name] = proba
        print(f"  {name:20s} CV macro-F1 {metrics['cv_f1_macro_mean']:.3f} ± {metrics['cv_f1_macro_std']:.3f} | test acc {metrics['accuracy']:.3f} "
              f"F1 {metrics['f1_macro']:.3f} dept {metrics['department_accuracy']:.3f} (routed {metrics['department_accuracy_routed']:.3f}) "
              f"| {search_seconds:.0f}s  {search.best_params_}")

    baseline = rule_engine_baseline(id_test, y_test, index)
    if baseline:
        print(f"  {'Rule-based engine':20s} test acc {baseline['accuracy']:.3f} dept {baseline['department_accuracy']:.3f}")

    # Selection: highest cross-validated macro-F1 on the training data (the test set is not used to choose).
    best_row = max(results, key=lambda r: r["cv_f1_macro_mean"])
    best_name = best_row["model"]
    best_model = searches[best_name].best_estimator_
    classes = list(best_model.classes_)
    print(f"Selected: {best_name}")

    # ---- reports
    comparison = pd.DataFrame([{k: v for k, v in r.items() if k not in ("best_params", "vignettes")} for r in results])
    comparison["best_params"] = [json.dumps(r["best_params"]) for r in results]
    comparison.to_csv(mm.REPORT_DIR / "model_comparison.csv", index=False)
    plot_comparison(results, baseline, mm.REPORT_DIR / "model_comparison.png")

    for r in results:
        name = r["model"]
        proba = probas[name]
        cls = list(searches[name].best_estimator_.classes_)
        cat_proba = mm.category_probabilities(proba, cls, index, category_order)
        dept_pred = np.asarray(category_order)[cat_proba.argmax(1)]
        cm = confusion_matrix(mm.department_of(y_test, index), dept_pred, labels=category_order)
        pd.DataFrame(cm, index=[categories[c]["department"] for c in category_order],
                     columns=[categories[c]["department"] for c in category_order]).to_csv(mm.REPORT_DIR / f"confusion_department_{slug(name)}.csv")
        plot_department_confusion(cm, category_order, categories, f"{name}: department confusion matrix (test set)",
                                  mm.REPORT_DIR / f"confusion_department_{slug(name)}.png")

    best_proba = probas[best_name]
    best_pred = np.asarray(classes)[best_proba.argmax(1)]
    labels = sorted(classes, key=lambda c: (category_order.index(index[c]["category"]), c))
    cm = confusion_matrix(y_test, best_pred, labels=labels)
    pd.DataFrame(cm, index=labels, columns=labels).to_csv(mm.REPORT_DIR / "confusion_conditions_selected_model.csv")
    plot_condition_confusion(cm, labels, index, mm.REPORT_DIR / "confusion_conditions_selected_model.png")

    p, r_, f, s = precision_recall_fscore_support(y_test, best_pred, labels=labels, zero_division=0)
    per_condition = pd.DataFrame({
        "condition_id": labels, "condition": [index[c]["name"] for c in labels], "condition_short": [index[c]["short"] for c in labels],
        "category": [index[c]["category"] for c in labels], "department": [index[c]["department"] for c in labels],
        "precision": p, "recall": r_, "f1": f, "support": s,
    })
    per_condition.to_csv(mm.REPORT_DIR / "per_condition_metrics_selected_model.csv", index=False)
    plot_per_condition_f1(per_condition, mm.REPORT_DIR / "per_condition_f1_selected_model.png")

    pairs = pd.DataFrame({"true": y_test, "predicted": best_pred})
    pairs = pairs[pairs["true"] != pairs["predicted"]].value_counts().reset_index(name="cases")
    support = pd.Series(y_test).value_counts()
    pairs["share_of_true_condition"] = pairs["cases"] / pairs["true"].map(support)
    pairs["same_department"] = [index[a]["category"] == index[b]["category"] for a, b in zip(pairs["true"], pairs["predicted"])]
    pairs.insert(1, "true_name", pairs["true"].map(lambda c: index[c]["short"]))
    pairs.insert(3, "predicted_name", pairs["predicted"].map(lambda c: index[c]["short"]))
    pairs.head(25).to_csv(mm.REPORT_DIR / "top_confusions_selected_model.csv", index=False)

    importance = permutation_importance(best_model, X_test, y_test, n_repeats=3, random_state=mm.RANDOM_STATE, scoring="accuracy", n_jobs=1)
    labels_by_key = {f["key"]: f["label"] for f in schema["features"]}
    imp = pd.DataFrame({"feature": schema["order"], "label": [labels_by_key[k] for k in schema["order"]],
                        "importance_mean": importance.importances_mean, "importance_std": importance.importances_std})
    imp = imp.sort_values("importance_mean", ascending=False)
    imp.to_csv(mm.REPORT_DIR / "feature_importance_selected_model.csv", index=False)
    plot_importance(imp, f"{best_name}: the 20 most important features", mm.REPORT_DIR / "feature_importance_selected_model.png")

    curves = {}
    for r in results:
        name = r["model"]
        cls = list(searches[name].best_estimator_.classes_)
        cat_proba = mm.category_probabilities(probas[name], cls, index, category_order)
        curves[name] = (cat_proba.max(1), mm.department_of(y_test, index) == np.asarray(category_order)[cat_proba.argmax(1)])
    plot_calibration(curves, mm.REPORT_DIR / "calibration_department.png")
    calibration_rows = []
    edges = np.linspace(0, 1, 11)
    for name, (conf, correct) in curves.items():
        for lo, hi in zip(edges[:-1], edges[1:]):
            mask = (conf > lo) & (conf <= hi)
            if mask.any():
                calibration_rows.append({"model": name, "confidence_band": f"{lo:.1f}-{hi:.1f}", "cases": int(mask.sum()),
                                         "mean_confidence": round(float(conf[mask].mean()), 4),
                                         "share_routed_correctly": round(float(correct[mask].mean()), 4)})
    pd.DataFrame(calibration_rows).to_csv(mm.REPORT_DIR / "calibration_department.csv", index=False)

    tree = searches["Decision Tree"].best_estimator_
    (mm.REPORT_DIR / "decision_tree_top_rules.txt").write_text(
        "Top four levels of the tuned Decision Tree (features are normalised 0-1; a binary feature <= 0.50 means 'absent').\n\n"
        + export_text(tree, feature_names=schema["order"], max_depth=4, decimals=2), encoding="utf-8")

    pd.DataFrame({
        "case_id": id_test.to_numpy(), "true_condition": y_test, "predicted_condition": best_pred,
        "probability": best_proba.max(1).round(4),
        "true_department": mm.department_of(y_test, index),
        "predicted_department": np.asarray(category_order)[mm.category_probabilities(best_proba, classes, index, category_order).argmax(1)],
    }).to_csv(mm.REPORT_DIR / "test_predictions_selected_model.csv", index=False)

    # ---- save the selected model
    bundle = {
        "model": best_model,
        "model_name": best_name,
        "model_version": MODEL_VERSION,
        "classes": classes,
        "feature_order": schema["order"],
        "schema_version": schema["schemaVersion"],
        "feature_schema": schema["features"],
        "condition_index": index,
        "categories": conditions["categories"],
        "category_order": category_order,
        "inconclusive_below": mm.INCONCLUSIVE_BELOW,
        "best_params": best_row["best_params"],
        "metrics": {k: v for k, v in best_row.items() if k not in ("best_params",)},
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dataset_sha256": mm.file_sha256(mm.DATASET_PATH),
        "training_cases": int(len(y_train)),
        "test_cases": int(len(y_test)),
        "sklearn_version": sklearn.__version__,
    }
    joblib.dump(bundle, mm.MODEL_PATH, compress=3)

    summary = {
        "selected_model": best_name,
        "model_version": MODEL_VERSION,
        "trained_at": bundle["trained_at"],
        "dataset": {"path": str(mm.DATASET_PATH.relative_to(mm.ROOT)), "sha256": bundle["dataset_sha256"], "cases": int(len(df)),
                    "features": int(X.shape[1]), "conditions": len(index), "train": int(len(y_train)), "test": int(len(y_test)),
                    "split": f"stratified {int((1 - mm.TEST_SIZE) * 100)}/{int(mm.TEST_SIZE * 100)}, random_state={mm.RANDOM_STATE}"},
        "cross_validation": f"{args.folds}-fold stratified on the training set, scoring = macro F1",
        "models": results,
        "rule_engine_baseline": baseline,
        "selection_rule": "highest cross-validated macro F1 on the training set",
        "model_file": str(mm.MODEL_PATH.relative_to(mm.ROOT)),
        "model_file_kb": round(mm.MODEL_PATH.stat().st_size / 1024, 1),
        "environment": {"python": platform.python_version(), "scikit_learn": sklearn.__version__, "numpy": np.__version__,
                        "pandas": pd.__version__, "platform": platform.platform()},
        "quick_run": bool(args.quick),
        "seconds": round(time.perf_counter() - started, 1),
    }
    (mm.REPORT_DIR / "metrics.json").write_text(json.dumps(summary, indent=2, default=float), encoding="utf-8")
    card = {
        "name": "MediFind disease and department classifier",
        "version": MODEL_VERSION,
        "algorithm": best_name,
        "hyperparameters": best_row["best_params"],
        "input": f"{X.shape[1]} features, schema {schema['schemaVersion']} (data/feature_schema.json), normalised as in MediFind's preprocessFeatures",
        "output": f"probabilities for {len(index)} conditions; department probability = sum over the department's conditions",
        "training_data": "SIMULATED patient cases generated from MediFind's questionnaire and knowledge base (no real patient data)",
        "intended_use": "Preliminary routing support at a hospital reception desk. Not a diagnosis. MediFind's urgent warning-sign rules override the model.",
        "status": "Used by the MediFind app when it is started with run_medifind.py: the app finds this backend by itself and every result says which engine made it. Opened on its own, the app uses its built-in rules.",
        "test_metrics": {k: round(best_row[k], 4) for k in ("accuracy", "precision_macro", "recall_macro", "f1_macro", "top3_accuracy",
                                                            "department_accuracy", "department_accuracy_routed")},
        "limitations": "Accuracy is measured on simulated data drawn from the same knowledge base; it says nothing about accuracy on real patients until the model is validated on clinically labelled records.",
        "trained_at": bundle["trained_at"],
        "file": str(mm.MODEL_PATH.relative_to(mm.ROOT)),
    }
    (mm.MODEL_DIR / "model_card.json").write_text(json.dumps(card, indent=2, default=float), encoding="utf-8")
    print(f"Saved {mm.MODEL_PATH.relative_to(mm.ROOT)} ({mm.MODEL_PATH.stat().st_size / 1024:.0f} KB) and reports in {mm.REPORT_DIR.relative_to(mm.ROOT)}/ "
          f"in {summary['seconds']} s")


if __name__ == "__main__":
    main()
