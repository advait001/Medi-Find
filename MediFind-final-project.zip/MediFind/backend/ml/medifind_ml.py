"""Shared code for the MediFind ML pipeline.

Paths, the feature schema, preprocessing and the prediction output used by
train_models.py, predict.py, api.py and the tests.

Preprocessing mirrors MediFind's browser code (src/js/07-preprocessing.js,
``preprocessFeatures``) exactly, so a feature vector built by the app can be
given to the trained model unchanged:

    binary              -> 1 if the value is present and non-zero, else 0
    ordinal and numeric -> (value - min) / (max - min), clamped to 0..1 and
                           rounded to 3 decimals (half up, as in the app)
    missing             -> 0 (a question not asked, or answered "Not sure")
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
DATASET_PATH = DATA_DIR / "medifind_symptom_dataset.csv"
SCHEMA_PATH = DATA_DIR / "feature_schema.json"
CONDITIONS_PATH = DATA_DIR / "conditions.json"
BASELINE_PATH = DATA_DIR / "rule_engine_baseline.csv"
VIGNETTES_PATH = DATA_DIR / "app_test_vignettes.csv"
MODEL_PATH = MODEL_DIR / "medifind_model.joblib"

RANDOM_STATE = 42
TEST_SIZE = 0.2
LABEL_COLUMN = "condition_id"
# MediFind shows "General / Inconclusive" and routes to General Medicine when
# the department probability is below this (CONFIDENCE_THRESHOLDS.inconclusiveBelow = 55).
INCONCLUSIVE_BELOW = 0.55


def load_schema(path: Path = SCHEMA_PATH) -> dict:
    with open(path, encoding="utf-8") as handle:
        schema = json.load(handle)
    if [f["key"] for f in schema["features"]] != schema["order"]:
        raise ValueError("feature_schema.json: features and order disagree")
    return schema


def load_conditions(path: Path = CONDITIONS_PATH) -> dict:
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def condition_index(conditions: dict) -> dict:
    """condition id -> condition record (name, category, department, specialist, doctor)."""
    return {c["id"]: c for c in conditions["conditions"]}


def load_dataset(path: Path = DATASET_PATH) -> pd.DataFrame:
    return pd.read_csv(path, low_memory=False)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _round_half_up(values: np.ndarray, decimals: int = 3) -> np.ndarray:
    factor = 10 ** decimals
    return np.floor(values * factor + 0.5 + 1e-9) / factor


def preprocess(raw: pd.DataFrame, schema: dict) -> np.ndarray:
    """Raw feature values (blank = missing) -> the normalised matrix the models use."""
    missing = [key for key in schema["order"] if key not in raw.columns]
    if missing:
        raise ValueError(f"Missing feature columns: {missing[:5]}{'...' if len(missing) > 5 else ''}")
    columns = []
    for feature in schema["features"]:
        values = pd.to_numeric(raw[feature["key"]], errors="coerce").to_numpy(dtype=float)
        if feature["type"] == "binary":
            column = np.where(np.isnan(values), 0.0, (values != 0).astype(float))
        else:
            span = feature["max"] - feature["min"]
            scaled = np.clip((values - feature["min"]) / span, 0.0, 1.0)
            column = np.where(np.isnan(scaled), 0.0, _round_half_up(scaled))
        columns.append(column)
    return np.column_stack(columns)


def raw_to_frame(raw_features: dict, schema: dict) -> pd.DataFrame:
    """One case given as {feature: value or None} -> a one-row frame in schema order."""
    unknown = sorted(set(raw_features) - set(schema["order"]))
    if unknown:
        raise ValueError(f"Unknown features: {unknown[:5]}")
    return pd.DataFrame([{key: raw_features.get(key) for key in schema["order"]}], dtype=float)


def department_of(condition_ids, index: dict) -> np.ndarray:
    return np.array([index[c]["category"] for c in condition_ids])


def category_probabilities(proba: np.ndarray, classes, index: dict, category_order) -> np.ndarray:
    """Condition probabilities (n x classes) -> department probabilities (n x 7), summed by primary category."""
    out = np.zeros((proba.shape[0], len(category_order)))
    position = {cat: i for i, cat in enumerate(category_order)}
    for j, cls in enumerate(classes):
        out[:, position[index[cls]["category"]]] += proba[:, j]
    return out


def explain_condition(model, x_row: np.ndarray, class_pos: int, features: list[dict], top_n: int = 8) -> dict | None:
    """The answers that pushed the model towards, and against, one condition.

    In Logistic Regression a condition's score is a weighted sum of the
    features, so every answer given contributes weight x value. Only answers
    the patient gave (value above 0) and features MediFind lists as symptoms
    (not internal ones such as age bands) are returned. Other model types,
    which have no per-feature weights, return None.
    """
    coef = getattr(model, "coef_", None)
    if coef is None or coef.ndim != 2 or coef.shape[0] <= class_pos or coef.shape[1] != len(features):
        return None
    contributions = coef[class_pos] * x_row
    listed = [j for j, feature in enumerate(features) if x_row[j] > 0 and not feature.get("internal")]
    ranked = sorted(listed, key=lambda j: -contributions[j])

    def item(j):
        return {"feature": features[j]["key"], "label": features[j].get("label", features[j]["key"]),
                "contribution": round(float(contributions[j]), 3)}

    return {
        "supporting": [item(j) for j in ranked if contributions[j] > 0][:top_n],
        "against": [item(j) for j in reversed(ranked) if contributions[j] < 0][:max(1, top_n // 2)],
    }


def build_prediction(proba_row: np.ndarray, bundle: dict, top_k: int = 3, x_row: np.ndarray | None = None) -> dict:
    """One row of condition probabilities -> the response MediFind's /api/predict expects.

    MediFind (normaliseApiPrediction in src/js/08-prediction.js) reads
    ``category``, ``probabilities`` (per department), ``disease`` (a condition
    name), ``diseaseProbability``, ``differentials`` and, when the normalised
    feature row is given, ``evidence`` (the answers that pushed the model
    towards and against the predicted condition). The other fields help
    people reading the response.
    """
    classes = bundle["classes"]
    index = bundle["condition_index"]
    category_order = bundle["category_order"]
    cat_proba = category_probabilities(proba_row[None, :], classes, index, category_order)[0]
    top_cat_pos = int(np.argmax(cat_proba))
    top_cat = category_order[top_cat_pos]
    order = np.argsort(-proba_row)
    in_category = [j for j in order if index[classes[j]]["category"] == top_cat]
    disease_pos = in_category[0]
    disease = index[classes[disease_pos]]
    differentials = [j for j in order if j != disease_pos][:top_k]
    confidence = float(cat_proba[top_cat_pos])
    categories = {c["id"]: c for c in bundle["categories"]}
    return {
        "category": top_cat,
        "probabilities": {cat: round(float(p), 4) for cat, p in zip(category_order, cat_proba)},
        "disease": disease["name"],
        "diseaseId": disease["id"],
        "diseaseProbability": round(float(proba_row[disease_pos]), 4),
        "differentials": [
            {"disease": index[classes[j]]["name"], "diseaseId": classes[j], "probability": round(float(proba_row[j]), 4)}
            for j in differentials
        ],
        "department": categories[top_cat]["department"],
        "specialist": categories[top_cat]["specialist"],
        "doctor": disease.get("doctor"),
        "inconclusive": confidence < INCONCLUSIVE_BELOW,
        "evidence": (explain_condition(bundle["model"], np.asarray(x_row, dtype=float), disease_pos, bundle["feature_schema"])
                     if x_row is not None else None),
        "model": {"name": bundle["model_name"], "version": bundle["model_version"], "schemaVersion": bundle["schema_version"]},
    }
