# MediFind backend: the machine-learning model

This folder is MediFind's Python backend. It holds the labelled dataset, the code that
trains and compares Random Forest, Decision Tree and Logistic Regression, the selected
model, its evaluation reports, and the Flask service (`ml/api.py`) that serves the
MediFind app and answers `POST /api/predict`.

You normally don't start anything in here yourself. `run_medifind.py` in the project
folder starts this backend together with the app (see the main README). The full
write-up is in the **MediFind ML Model Documentation** document.

> **The dataset is simulated.** It contains 20,075 artificial patient cases generated
> through MediFind's real questionnaire from its built-in medical knowledge base.
> No real patient data is used. The accuracy figures below show how well a model
> recovers the condition a simulated case was generated from; they are **not**
> clinical accuracy and must not be presented as such.

## Results on the test set (4,015 cases never used in training)

The models were trained on the other 16,060 cases (220 per condition).

| Model | Condition accuracy | Macro F1 | Top-3 accuracy | Department accuracy | Routed correctly¹ | Model size² |
| --- | --- | --- | --- | --- | --- | --- |
| **Logistic Regression (selected)** | 85.5% | 85.2% | 98.4% | 96.3% | 95.9% | 85 KB |
| Random Forest | 84.5% | 84.2% | 98.0% | 95.9% | 95.6% | 23 MB |
| Decision Tree | 82.2% | 82.0% | 94.7% | 95.3% | 95.0% | 53 KB |
| Rule-based engine in the app | 71.9% | – | – | 91.4% | 90.0% | – |

¹ The department MediFind would show: General Medicine when the top department's
probability is below 55% (for the rule engine, when it calls the case inconclusive,
9.6% of cases). "Department accuracy" is the top department alone.
² The fitted estimator, compressed. The saved file `models/medifind_model.joblib`
also holds the feature schema and condition table and is 100 KB.

Logistic Regression had the highest 5-fold cross-validated macro F1 on the training
data (0.847), which is how it was selected; the test set was not used to choose.

## How the app uses the model

1. `run_medifind.py` starts `ml/api.py`, which serves the app (`../frontend/index.html`)
   and the API on the same address, by default `http://127.0.0.1:5050`.
2. When the app opens, it calls `GET /api/health`. If the backend answers with the same
   feature schema (`sdp-features-v3`), the app switches to the trained model and says so
   on the dashboard.
3. For each assessment the app sends `POST /api/predict` with the 160 encoded answers
   (no name or contact number). The backend returns a probability for every condition and
   department, the most likely condition, alternatives, and the answers that pushed the
   model towards and against that condition.
4. The app applies its safeguards: urgent warning signs override the model; contradictory
   answers lower the confidence; when the app's built-in rules find the evidence too weak
   to decide (and the model is less than 90% sure, or answers contradict each other) the
   result becomes "General / Inconclusive"; the confidence is capped at 94%.
5. If the backend stops, the app uses its built-in rules for the next assessment and says
   so on screen. Every result and report records which engine produced it.

## API

`POST /api/predict` takes the body the app sends:

```json
{"schemaVersion": "sdp-features-v3", "featureOrder": ["age", "ageOver45", "..."], "features": [0.52, 1, "..."], "completeness": 1.0, "complaint": "pain"}
```

or raw feature values: `{"features": {"age": 52, "chestPain": 1, ...}}`. It answers with
`category`, `probabilities` (per department), `disease`, `diseaseId`, `diseaseProbability`,
`differentials`, `department`, `specialist`, `doctor`, `inconclusive`, `model` and
`evidence` (`supporting` and `against`: the answers given and their contribution to the
predicted condition). A different schema version, feature order or length, or values that
are not numbers from 0 to 1, return HTTP 400 with the reason.

`GET /api/health` returns the model name, version, schema and test metrics.

The service does not store or log request bodies. Flask's development server prints one
line per request (time, path and status). For use beyond a single computer, run it behind
a production WSGI server with HTTPS and access control.

## What is in this folder

| Path | What it is |
| --- | --- |
| `data/medifind_symptom_dataset.csv` | The labelled dataset: 20,075 cases × 160 features (schema `sdp-features-v3`) + labels. Blank = question not asked or answered "Not sure" |
| `data/data_dictionary.csv` | Every column: type, range and the question that produces it |
| `data/feature_schema.json` | Feature order, types and ranges used by MediFind and the model |
| `data/conditions.json` | The 73 conditions with department, specialist and doctor |
| `data/questionnaire_answers.jsonl` | The questionnaire answers behind every case (replayable in MediFind) |
| `data/rule_engine_baseline.csv` | What the app's rule-based engine predicts for each case |
| `data/app_test_vignettes.csv` | MediFind's 172 hand-written cases: 160 engine-test scenarios and 12 demos. The 162 with an expected non-urgent result are an extra check (146 of them name a specific condition) |
| `data/generation_report.json` | Generator settings, seed, acceptance rates and presenting complaints per condition |
| `generator/` | Node.js scripts that generate the dataset with MediFind's own questionnaire and encoder; `app_snapshot/` holds the exact app files the dataset was made from |
| `ml/medifind_ml.py` | Shared code: schema, preprocessing (identical to the app), the prediction output and its explanation |
| `ml/train_models.py` | Trains, tunes, compares and saves the models; writes `reports/` |
| `ml/predict.py` | Command-line prediction |
| `ml/api.py` | Flask service: serves the app, `POST /api/predict`, `GET /api/health` |
| `models/medifind_model.joblib` | The selected model with its metadata (feature order, classes, metrics) |
| `models/model_card.json` | Short description of the model, its data, use and limits |
| `reports/` | Metrics, comparison table, confusion matrices, per-condition scores, feature importance, calibration chart and table |
| `tests/test_ml.py` | 19 checks: dataset, preprocessing parity with the app, model, API contract and explanations |
| `examples/chest_pain_case.json` | A sample input (MediFind's cardiology demo case) |

## Commands (run inside this folder)

```bash
python ml/train_models.py                         # about 2 minutes on 2 CPU cores; rewrites models/ and reports/
python -m unittest discover -s tests -v           # 19 checks
python ml/predict.py --case MF-SYN-00042          # predict a dataset case and compare with its label
python ml/predict.py --json examples/chest_pain_case.json
python ml/api.py --port 5050 --app ../frontend/index.html   # what run_medifind.py does
```

The saved model was built with scikit-learn 1.9.1. `run_medifind.py` retrains it
automatically when your scikit-learn version is different.

Regenerating the dataset is optional and needs Node.js 18 or newer:

```bash
node generator/generate_dataset.js                # about 9 minutes; the fixed seed gives the same data
node generator/export_app_cases.js                # re-exports the hand-written cases
```

## Reproducibility

- Generator seed 20261023; train/test split and models `random_state=42`.
- Dataset SHA-256: `74fa7fc8ac446c8fd4071574168f2c359a809618913293a46698fb2b50451f94`.
- Built with Python 3.13, NumPy 2.5.3, pandas 3.0.5, scikit-learn 1.9.1, joblib 1.6.0,
  matplotlib 3.11.2 and Flask 3.1.3.

## Intended use

Preliminary routing support at a hospital reception desk. The output is never a
diagnosis or a prescription; final diagnosis and treatment are decided by a qualified
healthcare professional. Before any real use, the model must be retrained and
validated on clinically labelled patient records with the necessary approvals.
